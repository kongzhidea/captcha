/*     */ package com.jhlabs.vecmath;
/*     */ 
/*     */ public class Tuple3f
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   public float z;
/*     */ 
/*     */   public Tuple3f()
/*     */   {
/*  26 */     this(0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public Tuple3f(float[] x) {
/*  30 */     this.x = x[0];
/*  31 */     this.y = x[1];
/*  32 */     this.z = x[2];
/*     */   }
/*     */ 
/*     */   public Tuple3f(float x, float y, float z) {
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.z = z;
/*     */   }
/*     */ 
/*     */   public Tuple3f(Tuple3f t) {
/*  42 */     this.x = t.x;
/*  43 */     this.y = t.y;
/*  44 */     this.z = t.z;
/*     */   }
/*     */ 
/*     */   public void absolute() {
/*  48 */     this.x = Math.abs(this.x);
/*  49 */     this.y = Math.abs(this.y);
/*  50 */     this.z = Math.abs(this.z);
/*     */   }
/*     */ 
/*     */   public void absolute(Tuple3f t) {
/*  54 */     this.x = Math.abs(t.x);
/*  55 */     this.y = Math.abs(t.y);
/*  56 */     this.z = Math.abs(t.z);
/*     */   }
/*     */ 
/*     */   public void clamp(float min, float max) {
/*  60 */     if (this.x < min)
/*  61 */       this.x = min;
/*  62 */     else if (this.x > max)
/*  63 */       this.x = max;
/*  64 */     if (this.y < min)
/*  65 */       this.y = min;
/*  66 */     else if (this.y > max)
/*  67 */       this.y = max;
/*  68 */     if (this.z < min)
/*  69 */       this.z = min;
/*  70 */     else if (this.z > max)
/*  71 */       this.z = max;
/*     */   }
/*     */ 
/*     */   public void set(float x, float y, float z) {
/*  75 */     this.x = x;
/*  76 */     this.y = y;
/*  77 */     this.z = z;
/*     */   }
/*     */ 
/*     */   public void set(float[] x) {
/*  81 */     this.x = x[0];
/*  82 */     this.y = x[1];
/*  83 */     this.z = x[2];
/*     */   }
/*     */ 
/*     */   public void set(Tuple3f t) {
/*  87 */     this.x = t.x;
/*  88 */     this.y = t.y;
/*  89 */     this.z = t.z;
/*     */   }
/*     */ 
/*     */   public void get(Tuple3f t) {
/*  93 */     t.x = this.x;
/*  94 */     t.y = this.y;
/*  95 */     t.z = this.z;
/*     */   }
/*     */ 
/*     */   public void get(float[] t) {
/*  99 */     t[0] = this.x;
/* 100 */     t[1] = this.y;
/* 101 */     t[2] = this.z;
/*     */   }
/*     */ 
/*     */   public void negate() {
/* 105 */     this.x = (-this.x);
/* 106 */     this.y = (-this.y);
/* 107 */     this.z = (-this.z);
/*     */   }
/*     */ 
/*     */   public void negate(Tuple3f t) {
/* 111 */     this.x = (-t.x);
/* 112 */     this.y = (-t.y);
/* 113 */     this.z = (-t.z);
/*     */   }
/*     */ 
/*     */   public void interpolate(Tuple3f t, float alpha) {
/* 117 */     float a = 1.0F - alpha;
/* 118 */     this.x = (a * this.x + alpha * t.x);
/* 119 */     this.y = (a * this.y + alpha * t.y);
/* 120 */     this.z = (a * this.z + alpha * t.z);
/*     */   }
/*     */ 
/*     */   public void scale(float s) {
/* 124 */     this.x *= s;
/* 125 */     this.y *= s;
/* 126 */     this.z *= s;
/*     */   }
/*     */ 
/*     */   public void add(Tuple3f t) {
/* 130 */     this.x += t.x;
/* 131 */     this.y += t.y;
/* 132 */     this.z += t.z;
/*     */   }
/*     */ 
/*     */   public void add(Tuple3f t1, Tuple3f t2) {
/* 136 */     t1.x += t2.x;
/* 137 */     t1.y += t2.y;
/* 138 */     t1.z += t2.z;
/*     */   }
/*     */ 
/*     */   public void sub(Tuple3f t) {
/* 142 */     this.x -= t.x;
/* 143 */     this.y -= t.y;
/* 144 */     this.z -= t.z;
/*     */   }
/*     */ 
/*     */   public void sub(Tuple3f t1, Tuple3f t2) {
/* 148 */     t1.x -= t2.x;
/* 149 */     t1.y -= t2.y;
/* 150 */     t1.z -= t2.z;
/*     */   }
/*     */ 
/*     */   public void scaleAdd(float s, Tuple3f t) {
/* 154 */     this.x += s * t.x;
/* 155 */     this.y += s * t.y;
/* 156 */     this.z += s * t.z;
/*     */   }
/*     */ 
/*     */   public void scaleAdd(float s, Tuple3f t1, Tuple3f t2) {
/* 160 */     this.x = (s * t1.x + t2.x);
/* 161 */     this.y = (s * t1.y + t2.y);
/* 162 */     this.z = (s * t1.z + t2.z);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 166 */     return "[" + this.x + ", " + this.y + ", " + this.z + "]";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Tuple3f
 * JD-Core Version:    0.6.1
 */