/*     */ package com.jhlabs.vecmath;
/*     */ 
/*     */ public class Matrix4f
/*     */ {
/*     */   public float m00;
/*     */   public float m01;
/*     */   public float m02;
/*     */   public float m03;
/*     */   public float m10;
/*     */   public float m11;
/*     */   public float m12;
/*     */   public float m13;
/*     */   public float m20;
/*     */   public float m21;
/*     */   public float m22;
/*     */   public float m23;
/*     */   public float m30;
/*     */   public float m31;
/*     */   public float m32;
/*     */   public float m33;
/*     */ 
/*     */   public Matrix4f()
/*     */   {
/*  29 */     setIdentity();
/*     */   }
/*     */ 
/*     */   public Matrix4f(Matrix4f m) {
/*  33 */     set(m);
/*     */   }
/*     */ 
/*     */   public Matrix4f(float[] m) {
/*  37 */     set(m);
/*     */   }
/*     */ 
/*     */   public void set(Matrix4f m) {
/*  41 */     this.m00 = m.m00;
/*  42 */     this.m01 = m.m01;
/*  43 */     this.m02 = m.m02;
/*  44 */     this.m03 = m.m03;
/*  45 */     this.m10 = m.m10;
/*  46 */     this.m11 = m.m11;
/*  47 */     this.m12 = m.m12;
/*  48 */     this.m13 = m.m13;
/*  49 */     this.m20 = m.m20;
/*  50 */     this.m21 = m.m21;
/*  51 */     this.m22 = m.m22;
/*  52 */     this.m23 = m.m23;
/*  53 */     this.m30 = m.m30;
/*  54 */     this.m31 = m.m31;
/*  55 */     this.m32 = m.m32;
/*  56 */     this.m33 = m.m33;
/*     */   }
/*     */ 
/*     */   public void set(float[] m) {
/*  60 */     this.m00 = m[0];
/*  61 */     this.m01 = m[1];
/*  62 */     this.m02 = m[2];
/*  63 */     this.m03 = m[3];
/*  64 */     this.m10 = m[4];
/*  65 */     this.m11 = m[5];
/*  66 */     this.m12 = m[6];
/*  67 */     this.m13 = m[7];
/*  68 */     this.m20 = m[8];
/*  69 */     this.m21 = m[9];
/*  70 */     this.m22 = m[10];
/*  71 */     this.m23 = m[11];
/*  72 */     this.m30 = m[12];
/*  73 */     this.m31 = m[13];
/*  74 */     this.m32 = m[14];
/*  75 */     this.m33 = m[15];
/*     */   }
/*     */ 
/*     */   public void get(Matrix4f m) {
/*  79 */     m.m00 = this.m00;
/*  80 */     m.m01 = this.m01;
/*  81 */     m.m02 = this.m02;
/*  82 */     m.m03 = this.m03;
/*  83 */     m.m10 = this.m10;
/*  84 */     m.m11 = this.m11;
/*  85 */     m.m12 = this.m12;
/*  86 */     m.m13 = this.m13;
/*  87 */     m.m20 = this.m20;
/*  88 */     m.m21 = this.m21;
/*  89 */     m.m22 = this.m22;
/*  90 */     m.m23 = this.m23;
/*  91 */     m.m30 = this.m30;
/*  92 */     m.m31 = this.m31;
/*  93 */     m.m32 = this.m32;
/*  94 */     m.m33 = this.m33;
/*     */   }
/*     */ 
/*     */   public void get(float[] m) {
/*  98 */     m[0] = this.m00;
/*  99 */     m[1] = this.m01;
/* 100 */     m[2] = this.m02;
/* 101 */     m[3] = this.m03;
/* 102 */     m[4] = this.m10;
/* 103 */     m[5] = this.m11;
/* 104 */     m[6] = this.m12;
/* 105 */     m[7] = this.m13;
/* 106 */     m[8] = this.m20;
/* 107 */     m[9] = this.m21;
/* 108 */     m[10] = this.m22;
/* 109 */     m[11] = this.m23;
/* 110 */     m[12] = this.m30;
/* 111 */     m[13] = this.m31;
/* 112 */     m[14] = this.m32;
/* 113 */     m[15] = this.m33;
/*     */   }
/*     */ 
/*     */   public void setIdentity() {
/* 117 */     this.m00 = 1.0F;
/* 118 */     this.m01 = 0.0F;
/* 119 */     this.m02 = 0.0F;
/* 120 */     this.m03 = 0.0F;
/*     */ 
/* 122 */     this.m10 = 0.0F;
/* 123 */     this.m11 = 1.0F;
/* 124 */     this.m12 = 0.0F;
/* 125 */     this.m13 = 0.0F;
/*     */ 
/* 127 */     this.m20 = 0.0F;
/* 128 */     this.m21 = 0.0F;
/* 129 */     this.m22 = 1.0F;
/* 130 */     this.m23 = 0.0F;
/*     */ 
/* 132 */     this.m30 = 0.0F;
/* 133 */     this.m31 = 0.0F;
/* 134 */     this.m32 = 0.0F;
/* 135 */     this.m33 = 1.0F;
/*     */   }
/*     */ 
/*     */   public void mul(Matrix4f m) {
/* 139 */     float tm00 = this.m00;
/* 140 */     float tm01 = this.m01;
/* 141 */     float tm02 = this.m02;
/* 142 */     float tm03 = this.m03;
/* 143 */     float tm10 = this.m10;
/* 144 */     float tm11 = this.m11;
/* 145 */     float tm12 = this.m12;
/* 146 */     float tm13 = this.m13;
/* 147 */     float tm20 = this.m20;
/* 148 */     float tm21 = this.m21;
/* 149 */     float tm22 = this.m22;
/* 150 */     float tm23 = this.m23;
/* 151 */     float tm30 = this.m30;
/* 152 */     float tm31 = this.m31;
/* 153 */     float tm32 = this.m32;
/* 154 */     float tm33 = this.m33;
/*     */ 
/* 156 */     this.m00 = (tm00 * m.m00 + tm10 * m.m01 + tm20 * m.m02 + tm30 * m.m03);
/* 157 */     this.m01 = (tm01 * m.m00 + tm11 * m.m01 + tm21 * m.m02 + tm31 * m.m03);
/* 158 */     this.m02 = (tm02 * m.m00 + tm12 * m.m01 + tm22 * m.m02 + tm32 * m.m03);
/* 159 */     this.m03 = (tm03 * m.m00 + tm13 * m.m01 + tm23 * m.m02 + tm33 * m.m03);
/* 160 */     this.m10 = (tm00 * m.m10 + tm10 * m.m11 + tm20 * m.m12 + tm30 * m.m13);
/* 161 */     this.m11 = (tm01 * m.m10 + tm11 * m.m11 + tm21 * m.m12 + tm31 * m.m13);
/* 162 */     this.m12 = (tm02 * m.m10 + tm12 * m.m11 + tm22 * m.m12 + tm32 * m.m13);
/* 163 */     this.m13 = (tm03 * m.m10 + tm13 * m.m11 + tm23 * m.m12 + tm33 * m.m13);
/* 164 */     this.m20 = (tm00 * m.m20 + tm10 * m.m21 + tm20 * m.m22 + tm30 * m.m23);
/* 165 */     this.m21 = (tm01 * m.m20 + tm11 * m.m21 + tm21 * m.m22 + tm31 * m.m23);
/* 166 */     this.m22 = (tm02 * m.m20 + tm12 * m.m21 + tm22 * m.m22 + tm32 * m.m23);
/* 167 */     this.m23 = (tm03 * m.m20 + tm13 * m.m21 + tm23 * m.m22 + tm33 * m.m23);
/* 168 */     this.m30 = (tm00 * m.m30 + tm10 * m.m31 + tm20 * m.m32 + tm30 * m.m33);
/* 169 */     this.m31 = (tm01 * m.m30 + tm11 * m.m31 + tm21 * m.m32 + tm31 * m.m33);
/* 170 */     this.m32 = (tm02 * m.m30 + tm12 * m.m31 + tm22 * m.m32 + tm32 * m.m33);
/* 171 */     this.m33 = (tm03 * m.m30 + tm13 * m.m31 + tm23 * m.m32 + tm33 * m.m33);
/*     */   }
/*     */ 
/*     */   public void invert() {
/* 175 */     Matrix4f t = new Matrix4f(this);
/* 176 */     invert(t);
/*     */   }
/*     */ 
/*     */   public void invert(Matrix4f t) {
/* 180 */     this.m00 = t.m00;
/* 181 */     this.m01 = t.m10;
/* 182 */     this.m02 = t.m20;
/* 183 */     this.m03 = t.m03;
/*     */ 
/* 185 */     this.m10 = t.m01;
/* 186 */     this.m11 = t.m11;
/* 187 */     this.m12 = t.m21;
/* 188 */     this.m13 = t.m13;
/*     */ 
/* 190 */     this.m20 = t.m02;
/* 191 */     this.m21 = t.m12;
/* 192 */     this.m22 = t.m22;
/* 193 */     this.m23 = t.m23;
/*     */ 
/* 195 */     this.m30 *= -1.0F;
/* 196 */     this.m31 *= -1.0F;
/* 197 */     this.m32 *= -1.0F;
/* 198 */     this.m33 = t.m33;
/*     */   }
/*     */ 
/*     */   public void set(AxisAngle4f a) {
/* 202 */     float halfTheta = a.angle * 0.5F;
/* 203 */     float cosHalfTheta = (float)Math.cos(halfTheta);
/* 204 */     float sinHalfTheta = (float)Math.sin(halfTheta);
/* 205 */     set(new Quat4f(a.x * sinHalfTheta, a.y * sinHalfTheta, a.z * sinHalfTheta, cosHalfTheta));
/*     */   }
/*     */ 
/*     */   public void set(Quat4f q)
/*     */   {
/* 210 */     float x2 = q.x + q.x;
/* 211 */     float y2 = q.y + q.y;
/* 212 */     float z2 = q.z + q.z;
/* 213 */     float xx = q.x * x2;
/* 214 */     float xy = q.x * y2;
/* 215 */     float xz = q.x * z2;
/* 216 */     float yy = q.y * y2;
/* 217 */     float yz = q.y * z2;
/* 218 */     float zz = q.z * z2;
/* 219 */     float wx = q.w * x2;
/* 220 */     float wy = q.w * y2;
/* 221 */     float wz = q.w * z2;
/* 222 */     this.m00 = (1.0F - (yy + zz));
/* 223 */     this.m01 = (xy - wz);
/* 224 */     this.m02 = (xz + wy);
/* 225 */     this.m03 = 0.0F;
/* 226 */     this.m10 = (xy + wz);
/* 227 */     this.m11 = (1.0F - (xx + zz));
/* 228 */     this.m12 = (yz - wx);
/* 229 */     this.m13 = 0.0F;
/* 230 */     this.m20 = (xz - wy);
/* 231 */     this.m21 = (yz + wx);
/* 232 */     this.m22 = (1.0F - (xx + yy));
/* 233 */     this.m23 = 0.0F;
/* 234 */     this.m30 = 0.0F;
/* 235 */     this.m31 = 0.0F;
/* 236 */     this.m32 = 0.0F;
/* 237 */     this.m33 = 1.0F;
/*     */   }
/*     */ 
/*     */   public void transform(Point3f v) {
/* 241 */     float x = v.x * this.m00 + v.y * this.m10 + v.z * this.m20 + this.m30;
/* 242 */     float y = v.x * this.m01 + v.y * this.m11 + v.z * this.m21 + this.m31;
/* 243 */     float z = v.x * this.m02 + v.y * this.m12 + v.z * this.m22 + this.m32;
/* 244 */     v.x = x;
/* 245 */     v.y = y;
/* 246 */     v.z = z;
/*     */   }
/*     */ 
/*     */   public void transform(Vector3f v) {
/* 250 */     float x = v.x * this.m00 + v.y * this.m10 + v.z * this.m20;
/* 251 */     float y = v.x * this.m01 + v.y * this.m11 + v.z * this.m21;
/* 252 */     float z = v.x * this.m02 + v.y * this.m12 + v.z * this.m22;
/* 253 */     v.x = x;
/* 254 */     v.y = y;
/* 255 */     v.z = z;
/*     */   }
/*     */ 
/*     */   public void setTranslation(Vector3f v) {
/* 259 */     this.m30 = v.x;
/* 260 */     this.m31 = v.y;
/* 261 */     this.m32 = v.z;
/*     */   }
/*     */ 
/*     */   public void set(float scale) {
/* 265 */     this.m00 = scale;
/* 266 */     this.m11 = scale;
/* 267 */     this.m22 = scale;
/*     */   }
/*     */ 
/*     */   public void rotX(float angle) {
/* 271 */     float s = (float)Math.sin(angle);
/* 272 */     float c = (float)Math.cos(angle);
/* 273 */     this.m00 = 1.0F;
/* 274 */     this.m01 = 0.0F;
/* 275 */     this.m02 = 0.0F;
/* 276 */     this.m03 = 0.0F;
/*     */ 
/* 278 */     this.m10 = 0.0F;
/* 279 */     this.m11 = c;
/* 280 */     this.m12 = s;
/* 281 */     this.m13 = 0.0F;
/*     */ 
/* 283 */     this.m20 = 0.0F;
/* 284 */     this.m21 = (-s);
/* 285 */     this.m22 = c;
/* 286 */     this.m23 = 0.0F;
/*     */ 
/* 288 */     this.m30 = 0.0F;
/* 289 */     this.m31 = 0.0F;
/* 290 */     this.m32 = 0.0F;
/* 291 */     this.m33 = 1.0F;
/*     */   }
/*     */ 
/*     */   public void rotY(float angle) {
/* 295 */     float s = (float)Math.sin(angle);
/* 296 */     float c = (float)Math.cos(angle);
/* 297 */     this.m00 = c;
/* 298 */     this.m01 = 0.0F;
/* 299 */     this.m02 = (-s);
/* 300 */     this.m03 = 0.0F;
/*     */ 
/* 302 */     this.m10 = 0.0F;
/* 303 */     this.m11 = 1.0F;
/* 304 */     this.m12 = 0.0F;
/* 305 */     this.m13 = 0.0F;
/*     */ 
/* 307 */     this.m20 = s;
/* 308 */     this.m21 = 0.0F;
/* 309 */     this.m22 = c;
/* 310 */     this.m23 = 0.0F;
/*     */ 
/* 312 */     this.m30 = 0.0F;
/* 313 */     this.m31 = 0.0F;
/* 314 */     this.m32 = 0.0F;
/* 315 */     this.m33 = 1.0F;
/*     */   }
/*     */ 
/*     */   public void rotZ(float angle) {
/* 319 */     float s = (float)Math.sin(angle);
/* 320 */     float c = (float)Math.cos(angle);
/* 321 */     this.m00 = c;
/* 322 */     this.m01 = s;
/* 323 */     this.m02 = 0.0F;
/* 324 */     this.m03 = 0.0F;
/*     */ 
/* 326 */     this.m10 = (-s);
/* 327 */     this.m11 = c;
/* 328 */     this.m12 = 0.0F;
/* 329 */     this.m13 = 0.0F;
/*     */ 
/* 331 */     this.m20 = 0.0F;
/* 332 */     this.m21 = 0.0F;
/* 333 */     this.m22 = 1.0F;
/* 334 */     this.m23 = 0.0F;
/*     */ 
/* 336 */     this.m30 = 0.0F;
/* 337 */     this.m31 = 0.0F;
/* 338 */     this.m32 = 0.0F;
/* 339 */     this.m33 = 1.0F;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Matrix4f
 * JD-Core Version:    0.6.1
 */