/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ public class Point4f extends Tuple4f
/*    */ {
/*    */   public Point4f()
/*    */   {
/* 25 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public Point4f(float[] x) {
/* 29 */     this.x = x[0];
/* 30 */     this.y = x[1];
/* 31 */     this.z = x[2];
/* 32 */     this.w = x[3];
/*    */   }
/*    */ 
/*    */   public Point4f(float x, float y, float z, float w) {
/* 36 */     this.x = x;
/* 37 */     this.y = y;
/* 38 */     this.z = z;
/* 39 */     this.w = w;
/*    */   }
/*    */ 
/*    */   public Point4f(Point4f t) {
/* 43 */     this.x = t.x;
/* 44 */     this.y = t.y;
/* 45 */     this.z = t.z;
/* 46 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public Point4f(Tuple4f t) {
/* 50 */     this.x = t.x;
/* 51 */     this.y = t.y;
/* 52 */     this.z = t.z;
/* 53 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public float distanceL1(Point4f p) {
/* 57 */     return Math.abs(this.x - p.x) + Math.abs(this.y - p.y) + Math.abs(this.z - p.z) + Math.abs(this.w - p.w);
/*    */   }
/*    */ 
/*    */   public float distanceSquared(Point4f p) {
/* 61 */     float dx = this.x - p.x;
/* 62 */     float dy = this.y - p.y;
/* 63 */     float dz = this.z - p.z;
/* 64 */     float dw = this.w - p.w;
/* 65 */     return dx * dx + dy * dy + dz * dz + dw * dw;
/*    */   }
/*    */ 
/*    */   public float distance(Point4f p) {
/* 69 */     float dx = this.x - p.x;
/* 70 */     float dy = this.y - p.y;
/* 71 */     float dz = this.z - p.z;
/* 72 */     float dw = this.w - p.w;
/* 73 */     return (float)Math.sqrt(dx * dx + dy * dy + dz * dz + dw * dw);
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Point4f
 * JD-Core Version:    0.6.1
 */