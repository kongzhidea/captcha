/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class Color4f extends Tuple4f
/*    */ {
/*    */   public Color4f()
/*    */   {
/* 27 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public Color4f(float[] x) {
/* 31 */     this.x = x[0];
/* 32 */     this.y = x[1];
/* 33 */     this.z = x[2];
/* 34 */     this.w = x[3];
/*    */   }
/*    */ 
/*    */   public Color4f(float x, float y, float z, float w) {
/* 38 */     this.x = x;
/* 39 */     this.y = y;
/* 40 */     this.z = z;
/* 41 */     this.w = w;
/*    */   }
/*    */ 
/*    */   public Color4f(Color4f t) {
/* 45 */     this.x = t.x;
/* 46 */     this.y = t.y;
/* 47 */     this.z = t.z;
/* 48 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public Color4f(Tuple4f t) {
/* 52 */     this.x = t.x;
/* 53 */     this.y = t.y;
/* 54 */     this.z = t.z;
/* 55 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public Color4f(Color c) {
/* 59 */     set(c);
/*    */   }
/*    */ 
/*    */   public void set(Color c) {
/* 63 */     set(c.getRGBComponents(null));
/*    */   }
/*    */ 
/*    */   public Color get() {
/* 67 */     return new Color(this.x, this.y, this.z, this.w);
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Color4f
 * JD-Core Version:    0.6.1
 */