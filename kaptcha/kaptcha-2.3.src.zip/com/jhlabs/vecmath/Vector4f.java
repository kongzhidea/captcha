/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ public class Vector4f extends Tuple4f
/*    */ {
/*    */   public Vector4f()
/*    */   {
/* 25 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public Vector4f(float[] x) {
/* 29 */     this.x = x[0];
/* 30 */     this.y = x[1];
/* 31 */     this.z = x[2];
/* 32 */     this.w = x[2];
/*    */   }
/*    */ 
/*    */   public Vector4f(float x, float y, float z, float w) {
/* 36 */     this.x = x;
/* 37 */     this.y = y;
/* 38 */     this.z = z;
/* 39 */     this.w = w;
/*    */   }
/*    */ 
/*    */   public Vector4f(Vector4f t) {
/* 43 */     this.x = t.x;
/* 44 */     this.y = t.y;
/* 45 */     this.z = t.z;
/* 46 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public Vector4f(Tuple4f t) {
/* 50 */     this.x = t.x;
/* 51 */     this.y = t.y;
/* 52 */     this.z = t.z;
/* 53 */     this.w = t.w;
/*    */   }
/*    */ 
/*    */   public float dot(Vector4f v) {
/* 57 */     return v.x * this.x + v.y * this.y + v.z * this.z + v.w * this.w;
/*    */   }
/*    */ 
/*    */   public float length() {
/* 61 */     return (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
/*    */   }
/*    */ 
/*    */   public void normalize() {
/* 65 */     float d = 1.0F / (this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
/* 66 */     this.x *= d;
/* 67 */     this.y *= d;
/* 68 */     this.z *= d;
/* 69 */     this.w *= d;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Vector4f
 * JD-Core Version:    0.6.1
 */