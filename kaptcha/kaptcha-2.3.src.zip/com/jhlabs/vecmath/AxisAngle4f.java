/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ public class AxisAngle4f
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   public float angle;
/*    */ 
/*    */   public AxisAngle4f()
/*    */   {
/* 26 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public AxisAngle4f(float[] x) {
/* 30 */     this.x = x[0];
/* 31 */     this.y = x[1];
/* 32 */     this.z = x[2];
/* 33 */     this.angle = x[2];
/*    */   }
/*    */ 
/*    */   public AxisAngle4f(float x, float y, float z, float angle) {
/* 37 */     this.x = x;
/* 38 */     this.y = y;
/* 39 */     this.z = z;
/* 40 */     this.angle = angle;
/*    */   }
/*    */ 
/*    */   public AxisAngle4f(AxisAngle4f t) {
/* 44 */     this.x = t.x;
/* 45 */     this.y = t.y;
/* 46 */     this.z = t.z;
/* 47 */     this.angle = t.angle;
/*    */   }
/*    */ 
/*    */   public AxisAngle4f(Vector3f v, float angle) {
/* 51 */     this.x = v.x;
/* 52 */     this.y = v.y;
/* 53 */     this.z = v.z;
/* 54 */     this.angle = angle;
/*    */   }
/*    */ 
/*    */   public void set(float x, float y, float z, float angle) {
/* 58 */     this.x = x;
/* 59 */     this.y = y;
/* 60 */     this.z = z;
/* 61 */     this.angle = angle;
/*    */   }
/*    */ 
/*    */   public void set(AxisAngle4f t) {
/* 65 */     this.x = t.x;
/* 66 */     this.y = t.y;
/* 67 */     this.z = t.z;
/* 68 */     this.angle = t.angle;
/*    */   }
/*    */ 
/*    */   public void get(AxisAngle4f t) {
/* 72 */     t.x = this.x;
/* 73 */     t.y = this.y;
/* 74 */     t.z = this.z;
/* 75 */     t.angle = this.angle;
/*    */   }
/*    */ 
/*    */   public void get(float[] t) {
/* 79 */     t[0] = this.x;
/* 80 */     t[1] = this.y;
/* 81 */     t[2] = this.z;
/* 82 */     t[3] = this.angle;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 86 */     return "[" + this.x + ", " + this.y + ", " + this.z + ", " + this.angle + "]";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.AxisAngle4f
 * JD-Core Version:    0.6.1
 */