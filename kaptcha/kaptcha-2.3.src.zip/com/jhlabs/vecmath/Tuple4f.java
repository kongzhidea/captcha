/*     */ package com.jhlabs.vecmath;
/*     */ 
/*     */ public class Tuple4f
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   public float z;
/*     */   public float w;
/*     */ 
/*     */   public Tuple4f()
/*     */   {
/*  26 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public Tuple4f(float[] x) {
/*  30 */     this.x = x[0];
/*  31 */     this.y = x[1];
/*  32 */     this.z = x[2];
/*  33 */     this.w = x[2];
/*     */   }
/*     */ 
/*     */   public Tuple4f(float x, float y, float z, float w) {
/*  37 */     this.x = x;
/*  38 */     this.y = y;
/*  39 */     this.z = z;
/*  40 */     this.w = w;
/*     */   }
/*     */ 
/*     */   public Tuple4f(Tuple4f t) {
/*  44 */     this.x = t.x;
/*  45 */     this.y = t.y;
/*  46 */     this.z = t.z;
/*  47 */     this.w = t.w;
/*     */   }
/*     */ 
/*     */   public void absolute() {
/*  51 */     this.x = Math.abs(this.x);
/*  52 */     this.y = Math.abs(this.y);
/*  53 */     this.z = Math.abs(this.z);
/*  54 */     this.w = Math.abs(this.w);
/*     */   }
/*     */ 
/*     */   public void absolute(Tuple4f t) {
/*  58 */     this.x = Math.abs(t.x);
/*  59 */     this.y = Math.abs(t.y);
/*  60 */     this.z = Math.abs(t.z);
/*  61 */     this.w = Math.abs(t.w);
/*     */   }
/*     */ 
/*     */   public void clamp(float min, float max) {
/*  65 */     if (this.x < min)
/*  66 */       this.x = min;
/*  67 */     else if (this.x > max)
/*  68 */       this.x = max;
/*  69 */     if (this.y < min)
/*  70 */       this.y = min;
/*  71 */     else if (this.y > max)
/*  72 */       this.y = max;
/*  73 */     if (this.z < min)
/*  74 */       this.z = min;
/*  75 */     else if (this.z > max)
/*  76 */       this.z = max;
/*  77 */     if (this.w < min)
/*  78 */       this.w = min;
/*  79 */     else if (this.w > max)
/*  80 */       this.w = max;
/*     */   }
/*     */ 
/*     */   public void set(float x, float y, float z, float w) {
/*  84 */     this.x = x;
/*  85 */     this.y = y;
/*  86 */     this.z = z;
/*  87 */     this.w = w;
/*     */   }
/*     */ 
/*     */   public void set(float[] x) {
/*  91 */     this.x = x[0];
/*  92 */     this.y = x[1];
/*  93 */     this.z = x[2];
/*  94 */     this.w = x[2];
/*     */   }
/*     */ 
/*     */   public void set(Tuple4f t) {
/*  98 */     this.x = t.x;
/*  99 */     this.y = t.y;
/* 100 */     this.z = t.z;
/* 101 */     this.w = t.w;
/*     */   }
/*     */ 
/*     */   public void get(Tuple4f t) {
/* 105 */     t.x = this.x;
/* 106 */     t.y = this.y;
/* 107 */     t.z = this.z;
/* 108 */     t.w = this.w;
/*     */   }
/*     */ 
/*     */   public void get(float[] t) {
/* 112 */     t[0] = this.x;
/* 113 */     t[1] = this.y;
/* 114 */     t[2] = this.z;
/* 115 */     t[3] = this.w;
/*     */   }
/*     */ 
/*     */   public void negate() {
/* 119 */     this.x = (-this.x);
/* 120 */     this.y = (-this.y);
/* 121 */     this.z = (-this.z);
/* 122 */     this.w = (-this.w);
/*     */   }
/*     */ 
/*     */   public void negate(Tuple4f t) {
/* 126 */     this.x = (-t.x);
/* 127 */     this.y = (-t.y);
/* 128 */     this.z = (-t.z);
/* 129 */     this.w = (-t.w);
/*     */   }
/*     */ 
/*     */   public void interpolate(Tuple4f t, float alpha) {
/* 133 */     float a = 1.0F - alpha;
/* 134 */     this.x = (a * this.x + alpha * t.x);
/* 135 */     this.y = (a * this.y + alpha * t.y);
/* 136 */     this.z = (a * this.z + alpha * t.z);
/* 137 */     this.w = (a * this.w + alpha * t.w);
/*     */   }
/*     */ 
/*     */   public void scale(float s) {
/* 141 */     this.x *= s;
/* 142 */     this.y *= s;
/* 143 */     this.z *= s;
/* 144 */     this.w *= s;
/*     */   }
/*     */ 
/*     */   public void add(Tuple4f t) {
/* 148 */     this.x += t.x;
/* 149 */     this.y += t.y;
/* 150 */     this.z += t.z;
/* 151 */     this.w += t.w;
/*     */   }
/*     */ 
/*     */   public void add(Tuple4f t1, Tuple4f t2) {
/* 155 */     t1.x += t2.x;
/* 156 */     t1.y += t2.y;
/* 157 */     t1.z += t2.z;
/* 158 */     t1.w += t2.w;
/*     */   }
/*     */ 
/*     */   public void sub(Tuple4f t) {
/* 162 */     this.x -= t.x;
/* 163 */     this.y -= t.y;
/* 164 */     this.z -= t.z;
/* 165 */     this.w -= t.w;
/*     */   }
/*     */ 
/*     */   public void sub(Tuple4f t1, Tuple4f t2) {
/* 169 */     t1.x -= t2.x;
/* 170 */     t1.y -= t2.y;
/* 171 */     t1.z -= t2.z;
/* 172 */     t1.w -= t2.w;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 176 */     return "[" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + "]";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Tuple4f
 * JD-Core Version:    0.6.1
 */