/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ public class Vector3f extends Tuple3f
/*    */ {
/*    */   public Vector3f()
/*    */   {
/* 25 */     this(0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public Vector3f(float[] x) {
/* 29 */     this.x = x[0];
/* 30 */     this.y = x[1];
/* 31 */     this.z = x[2];
/*    */   }
/*    */ 
/*    */   public Vector3f(float x, float y, float z) {
/* 35 */     this.x = x;
/* 36 */     this.y = y;
/* 37 */     this.z = z;
/*    */   }
/*    */ 
/*    */   public Vector3f(Vector3f t) {
/* 41 */     this.x = t.x;
/* 42 */     this.y = t.y;
/* 43 */     this.z = t.z;
/*    */   }
/*    */ 
/*    */   public Vector3f(Tuple3f t) {
/* 47 */     this.x = t.x;
/* 48 */     this.y = t.y;
/* 49 */     this.z = t.z;
/*    */   }
/*    */ 
/*    */   public float angle(Vector3f v) {
/* 53 */     return (float)Math.acos(dot(v) / (length() * v.length()));
/*    */   }
/*    */ 
/*    */   public float dot(Vector3f v) {
/* 57 */     return v.x * this.x + v.y * this.y + v.z * this.z;
/*    */   }
/*    */ 
/*    */   public void cross(Vector3f v1, Vector3f v2) {
/* 61 */     this.x = (v1.y * v2.z - v1.z * v2.y);
/* 62 */     this.y = (v1.z * v2.x - v1.x * v2.z);
/* 63 */     this.z = (v1.x * v2.y - v1.y * v2.x);
/*    */   }
/*    */ 
/*    */   public float length() {
/* 67 */     return (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*    */   }
/*    */ 
/*    */   public void normalize() {
/* 71 */     float d = 1.0F / (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 72 */     this.x *= d;
/* 73 */     this.y *= d;
/* 74 */     this.z *= d;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Vector3f
 * JD-Core Version:    0.6.1
 */