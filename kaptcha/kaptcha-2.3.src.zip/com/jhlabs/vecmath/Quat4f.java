/*     */ package com.jhlabs.vecmath;
/*     */ 
/*     */ public class Quat4f extends Tuple4f
/*     */ {
/*     */   public Quat4f()
/*     */   {
/*  25 */     this(0.0F, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public Quat4f(float[] x) {
/*  29 */     this.x = x[0];
/*  30 */     this.y = x[1];
/*  31 */     this.z = x[2];
/*  32 */     this.w = x[3];
/*     */   }
/*     */ 
/*     */   public Quat4f(float x, float y, float z, float w) {
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.z = z;
/*  39 */     this.w = w;
/*     */   }
/*     */ 
/*     */   public Quat4f(Quat4f t) {
/*  43 */     this.x = t.x;
/*  44 */     this.y = t.y;
/*  45 */     this.z = t.z;
/*  46 */     this.w = t.w;
/*     */   }
/*     */ 
/*     */   public Quat4f(Tuple4f t) {
/*  50 */     this.x = t.x;
/*  51 */     this.y = t.y;
/*  52 */     this.z = t.z;
/*  53 */     this.w = t.w;
/*     */   }
/*     */ 
/*     */   public void set(AxisAngle4f a) {
/*  57 */     float halfTheta = a.angle * 0.5F;
/*  58 */     float cosHalfTheta = (float)Math.cos(halfTheta);
/*  59 */     float sinHalfTheta = (float)Math.sin(halfTheta);
/*  60 */     this.x = (a.x * sinHalfTheta);
/*  61 */     this.y = (a.y * sinHalfTheta);
/*  62 */     this.z = (a.z * sinHalfTheta);
/*  63 */     this.w = cosHalfTheta;
/*     */   }
/*     */ 
/*     */   public void normalize()
/*     */   {
/*  86 */     float d = 1.0F / (this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
/*  87 */     this.x *= d;
/*  88 */     this.y *= d;
/*  89 */     this.z *= d;
/*  90 */     this.w *= d;
/*     */   }
/*     */ 
/*     */   public void set(Matrix4f m)
/*     */   {
/* 121 */     float tr = m.m00 + m.m11 + m.m22;
/*     */ 
/* 123 */     if (tr > 0.0D) {
/* 124 */       float s = (float)Math.sqrt(tr + 1.0F);
/* 125 */       this.w = (s / 2.0F);
/* 126 */       s = 0.5F / s;
/* 127 */       this.x = ((m.m12 - m.m21) * s);
/* 128 */       this.y = ((m.m20 - m.m02) * s);
/* 129 */       this.z = ((m.m01 - m.m10) * s);
/*     */     } else {
/* 131 */       int i = 0;
/* 132 */       if (m.m11 > m.m00) {
/* 133 */         i = 1;
/* 134 */         if (m.m22 > m.m11) {
/* 135 */           i = 2;
/*     */         }
/*     */ 
/*     */       }
/* 139 */       else if (m.m22 > m.m00) {
/* 140 */         i = 2;
/*     */       }
/*     */       float s;
/* 145 */       switch (i) {
/*     */       case 0:
/* 147 */         s = (float)Math.sqrt(m.m00 - (m.m11 + m.m22) + 1.0F);
/* 148 */         this.x = (s * 0.5F);
/* 149 */         if (s != 0.0D)
/* 150 */           s = 0.5F / s;
/* 151 */         this.w = ((m.m12 - m.m21) * s);
/* 152 */         this.y = ((m.m01 + m.m10) * s);
/* 153 */         this.z = ((m.m02 + m.m20) * s);
/* 154 */         break;
/*     */       case 1:
/* 156 */         s = (float)Math.sqrt(m.m11 - (m.m22 + m.m00) + 1.0F);
/* 157 */         this.y = (s * 0.5F);
/* 158 */         if (s != 0.0D)
/* 159 */           s = 0.5F / s;
/* 160 */         this.w = ((m.m20 - m.m02) * s);
/* 161 */         this.z = ((m.m12 + m.m21) * s);
/* 162 */         this.x = ((m.m10 + m.m01) * s);
/* 163 */         break;
/*     */       case 2:
/* 165 */         s = (float)Math.sqrt(m.m00 - (m.m11 + m.m22) + 1.0F);
/* 166 */         this.z = (s * 0.5F);
/* 167 */         if (s != 0.0D)
/* 168 */           s = 0.5F / s;
/* 169 */         this.w = ((m.m01 - m.m10) * s);
/* 170 */         this.x = ((m.m20 + m.m02) * s);
/* 171 */         this.y = ((m.m21 + m.m12) * s);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Quat4f
 * JD-Core Version:    0.6.1
 */