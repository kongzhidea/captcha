/*    */ package com.jhlabs.vecmath;
/*    */ 
/*    */ public class Point3f extends Tuple3f
/*    */ {
/*    */   public Point3f()
/*    */   {
/* 25 */     this(0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public Point3f(float[] x) {
/* 29 */     this.x = x[0];
/* 30 */     this.y = x[1];
/* 31 */     this.z = x[2];
/*    */   }
/*    */ 
/*    */   public Point3f(float x, float y, float z) {
/* 35 */     this.x = x;
/* 36 */     this.y = y;
/* 37 */     this.z = z;
/*    */   }
/*    */ 
/*    */   public Point3f(Point3f t) {
/* 41 */     this.x = t.x;
/* 42 */     this.y = t.y;
/* 43 */     this.z = t.z;
/*    */   }
/*    */ 
/*    */   public Point3f(Tuple3f t) {
/* 47 */     this.x = t.x;
/* 48 */     this.y = t.y;
/* 49 */     this.z = t.z;
/*    */   }
/*    */ 
/*    */   public float distanceL1(Point3f p) {
/* 53 */     return Math.abs(this.x - p.x) + Math.abs(this.y - p.y) + Math.abs(this.z - p.z);
/*    */   }
/*    */ 
/*    */   public float distanceSquared(Point3f p) {
/* 57 */     float dx = this.x - p.x;
/* 58 */     float dy = this.y - p.y;
/* 59 */     float dz = this.z - p.z;
/* 60 */     return dx * dx + dy * dy + dz * dz;
/*    */   }
/*    */ 
/*    */   public float distance(Point3f p) {
/* 64 */     float dx = this.x - p.x;
/* 65 */     float dy = this.y - p.y;
/* 66 */     float dz = this.z - p.z;
/* 67 */     return (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.vecmath.Point3f
 * JD-Core Version:    0.6.1
 */