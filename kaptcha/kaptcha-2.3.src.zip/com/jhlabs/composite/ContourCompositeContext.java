/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ class ContourCompositeContext
/*    */   implements CompositeContext
/*    */ {
/*    */   private int offset;
/*    */ 
/*    */   public ContourCompositeContext(int offset, ColorModel srcColorModel, ColorModel dstColorModel)
/*    */   {
/* 56 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   public void dispose() {
/*    */   }
/*    */ 
/*    */   public void compose(Raster src, Raster dstIn, WritableRaster dstOut) {
/* 63 */     int x = src.getMinX();
/* 64 */     int y = src.getMinY();
/* 65 */     int w = src.getWidth();
/* 66 */     int h = src.getHeight();
/*    */ 
/* 68 */     int[] srcPix = null;
/* 69 */     int[] srcPix2 = null;
/* 70 */     int[] dstInPix = null;
/* 71 */     int[] dstOutPix = new int[w * 4];
/*    */ 
/* 73 */     for (int i = 0; i < h; i++) {
/* 74 */       srcPix = src.getPixels(x, y, w, 1, srcPix);
/* 75 */       dstInPix = dstIn.getPixels(x, y, w, 1, dstInPix);
/*    */ 
/* 77 */       int lastAlpha = 0;
/* 78 */       int k = 0;
/* 79 */       for (int j = 0; j < w; j++) {
/* 80 */         int alpha = srcPix[(k + 3)];
/* 81 */         int alphaAbove = i != 0 ? srcPix2[(k + 3)] : alpha;
/*    */ 
/* 83 */         if (((i != 0) && (j != 0) && (((alpha ^ lastAlpha) & 0x80) != 0)) || (((alpha ^ alphaAbove) & 0x80) != 0)) {
/* 84 */           if ((this.offset + i + j) % 10 > 4) {
/* 85 */             dstOutPix[k] = 0;
/* 86 */             dstOutPix[(k + 1)] = 0;
/* 87 */             dstOutPix[(k + 2)] = 0;
/*    */           } else {
/* 89 */             dstOutPix[k] = 255;
/* 90 */             dstOutPix[(k + 1)] = 255;
/* 91 */             dstOutPix[(k + 2)] = 127;
/*    */           }
/* 93 */           dstOutPix[(k + 3)] = 255;
/*    */         } else {
/* 95 */           dstOutPix[k] = dstInPix[k];
/* 96 */           dstOutPix[(k + 1)] = dstInPix[(k + 1)];
/* 97 */           dstOutPix[(k + 2)] = dstInPix[(k + 2)];
/*    */ 
/* 99 */           dstOutPix[k] = 255;
/* 100 */           dstOutPix[(k + 1)] = 0;
/* 101 */           dstOutPix[(k + 2)] = 0;
/* 102 */           dstOutPix[(k + 3)] = 0;
/*    */         }
/*    */ 
/* 107 */         lastAlpha = alpha;
/* 108 */         k += 4;
/*    */       }
/*    */ 
/* 111 */       dstOut.setPixels(x, y, w, 1, dstOutPix);
/*    */ 
/* 113 */       int[] t = srcPix;
/* 114 */       srcPix = srcPix2;
/* 115 */       srcPix2 = t;
/* 116 */       y++;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.ContourCompositeContext
 * JD-Core Version:    0.6.1
 */