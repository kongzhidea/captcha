/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public final class BurnComposite extends RGBComposite
/*    */ {
/*    */   public BurnComposite(float alpha)
/*    */   {
/* 25 */     super(alpha);
/*    */   }
/*    */ 
/*    */   public CompositeContext createContext(ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints) {
/* 29 */     return new Context(this.extraAlpha, srcColorModel, dstColorModel);
/*    */   }
/*    */ 
/*    */   static class Context extends RGBComposite.RGBCompositeContext {
/*    */     public Context(float alpha, ColorModel srcColorModel, ColorModel dstColorModel) {
/* 34 */       super(srcColorModel, dstColorModel);
/*    */     }
/*    */ 
/*    */     public void composeRGB(int[] src, int[] dst, float alpha) {
/* 38 */       int w = src.length;
/*    */ 
/* 40 */       for (int i = 0; i < w; i += 4) {
/* 41 */         int sr = src[i];
/* 42 */         int dir = dst[i];
/* 43 */         int sg = src[(i + 1)];
/* 44 */         int dig = dst[(i + 1)];
/* 45 */         int sb = src[(i + 2)];
/* 46 */         int dib = dst[(i + 2)];
/* 47 */         int sa = src[(i + 3)];
/* 48 */         int dia = dst[(i + 3)];
/*    */         int dor;
/*    */         int dor;
/* 51 */         if (dir != 255)
/* 52 */           dor = clamp(255 - (255 - sr << 8) / (dir + 1));
/*    */         else
/* 54 */           dor = sr;
/*    */         int dog;
/*    */         int dog;
/* 55 */         if (dig != 255)
/* 56 */           dog = clamp(255 - (255 - sg << 8) / (dig + 1));
/*    */         else
/* 58 */           dog = sg;
/*    */         int dob;
/*    */         int dob;
/* 59 */         if (dib != 255)
/* 60 */           dob = clamp(255 - (255 - sb << 8) / (dib + 1));
/*    */         else {
/* 62 */           dob = sb;
/*    */         }
/* 64 */         float a = alpha * sa / 255.0F;
/* 65 */         float ac = 1.0F - a;
/*    */ 
/* 67 */         dst[i] = (int)(a * dor + ac * dir);
/* 68 */         dst[(i + 1)] = (int)(a * dog + ac * dig);
/* 69 */         dst[(i + 2)] = (int)(a * dob + ac * dib);
/* 70 */         dst[(i + 3)] = (int)(sa * alpha + dia * ac);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.BurnComposite
 * JD-Core Version:    0.6.1
 */