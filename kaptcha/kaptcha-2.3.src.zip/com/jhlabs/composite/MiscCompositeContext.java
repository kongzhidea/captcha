/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.color.ColorSpace;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ public class MiscCompositeContext
/*    */   implements CompositeContext
/*    */ {
/*    */   private int rule;
/*    */   private float alpha;
/*    */   private ColorModel srcColorModel;
/*    */   private ColorModel dstColorModel;
/*    */   private ColorSpace srcColorSpace;
/*    */   private ColorSpace dstColorSpace;
/*    */   private boolean srcNeedsConverting;
/*    */   private boolean dstNeedsConverting;
/*    */ 
/*    */   public MiscCompositeContext(int rule, float alpha, ColorModel srcColorModel, ColorModel dstColorModel)
/*    */   {
/* 41 */     this.rule = rule;
/* 42 */     this.alpha = alpha;
/* 43 */     this.srcColorModel = srcColorModel;
/* 44 */     this.dstColorModel = dstColorModel;
/* 45 */     this.srcColorSpace = srcColorModel.getColorSpace();
/* 46 */     this.dstColorSpace = dstColorModel.getColorSpace();
/* 47 */     ColorModel srgbCM = ColorModel.getRGBdefault();
/*    */   }
/*    */ 
/*    */   public void dispose()
/*    */   {
/*    */   }
/*    */ 
/*    */   static int multiply255(int a, int b)
/*    */   {
/* 57 */     int t = a * b + 128;
/* 58 */     return (t >> 8) + t >> 8;
/*    */   }
/*    */ 
/*    */   static int clamp(int a) {
/* 62 */     return a > 255 ? 255 : a < 0 ? 0 : a;
/*    */   }
/*    */ 
/*    */   public void compose(Raster src, Raster dstIn, WritableRaster dstOut) {
/* 66 */     float a = 0.0F; float ac = 0.0F;
/* 67 */     float alpha = this.alpha;
/*    */ 
/* 70 */     float[] sHsv = null; float[] diHsv = null; float[] doHsv = null;
/* 71 */     switch (this.rule) {
/*    */     case 12:
/*    */     case 13:
/*    */     case 14:
/*    */     case 15:
/* 76 */       sHsv = new float[3];
/* 77 */       diHsv = new float[3];
/* 78 */       doHsv = new float[3];
/*    */     }
/*    */ 
/* 82 */     int[] srcPix = null;
/* 83 */     int[] dstPix = null;
/*    */ 
/* 85 */     int x = dstOut.getMinX();
/* 86 */     int w = dstOut.getWidth();
/*    */ 
/* 88 */     int y0 = dstOut.getMinY();
/* 89 */     int y1 = y0 + dstOut.getHeight();
/*    */ 
/* 91 */     for (int y = y0; y < y1; y++) {
/* 92 */       srcPix = src.getPixels(x, y, w, 1, srcPix);
/* 93 */       dstPix = dstIn.getPixels(x, y, w, 1, dstPix);
/* 94 */       int i = 0;
/* 95 */       int end = w * 4;
/*    */ 
/* 97 */       while (i < end) {
/* 98 */         int sr = srcPix[i];
/* 99 */         int dir = dstPix[i];
/* 100 */         int sg = srcPix[(i + 1)];
/* 101 */         int dig = dstPix[(i + 1)];
/* 102 */         int sb = srcPix[(i + 2)];
/* 103 */         int dib = dstPix[(i + 2)];
/* 104 */         int sa = srcPix[(i + 3)];
/* 105 */         int dia = dstPix[(i + 3)];
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/*    */         int t;
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/*    */         int dor;
/*    */         int dog;
/*    */         int dob;
/* 108 */         switch (this.rule) {
/*    */         case 1:
/*    */         default:
/* 111 */           dor = dir + sr;
/* 112 */           if (dor > 255)
/* 113 */             dor = 255;
/* 114 */           dog = dig + sg;
/* 115 */           if (dog > 255)
/* 116 */             dog = 255;
/* 117 */           dob = dib + sb;
/* 118 */           if (dob > 255)
/* 119 */             dob = 255; break;
/*    */         case 2:
/* 123 */           dor = dir - sr;
/* 124 */           if (dor < 0)
/* 125 */             dor = 0;
/* 126 */           dog = dig - sg;
/* 127 */           if (dog < 0)
/* 128 */             dog = 0;
/* 129 */           dob = dib - sb;
/* 130 */           if (dob < 0)
/* 131 */             dob = 0; break;
/*    */         case 3:
/* 135 */           dor = dir - sr;
/* 136 */           if (dor < 0)
/* 137 */             dor = -dor;
/* 138 */           dog = dig - sg;
/* 139 */           if (dog < 0)
/* 140 */             dog = -dog;
/* 141 */           dob = dib - sb;
/* 142 */           if (dob < 0)
/* 143 */             dob = -dob; break;
/*    */         case 4:
/* 147 */           t = dir * sr + 128;
/* 148 */           dor = (t >> 8) + t >> 8;
/* 149 */           t = dig * sg + 128;
/* 150 */           dog = (t >> 8) + t >> 8;
/* 151 */           t = dib * sb + 128;
/* 152 */           dob = (t >> 8) + t >> 8;
/* 153 */           break;
/*    */         case 8:
/* 156 */           t = (255 - dir) * (255 - sr) + 128;
/* 157 */           dor = 255 - ((t >> 8) + t >> 8);
/* 158 */           t = (255 - dig) * (255 - sg) + 128;
/* 159 */           dog = 255 - ((t >> 8) + t >> 8);
/* 160 */           t = (255 - dib) * (255 - sb) + 128;
/* 161 */           dob = 255 - ((t >> 8) + t >> 8);
/* 162 */           break;
/*    */         case 16:
/*    */           int t;
/* 165 */           if (dir < 128) {
/* 166 */             t = dir * sr + 128;
/* 167 */             dor = 2 * ((t >> 8) + t >> 8);
/*    */           } else {
/* 169 */             t = (255 - dir) * (255 - sr) + 128;
/* 170 */             dor = 2 * (255 - ((t >> 8) + t >> 8));
/*    */           }
/* 172 */           if (dig < 128) {
/* 173 */             t = dig * sg + 128;
/* 174 */             dog = 2 * ((t >> 8) + t >> 8);
/*    */           } else {
/* 176 */             t = (255 - dig) * (255 - sg) + 128;
/* 177 */             dog = 2 * (255 - ((t >> 8) + t >> 8));
/*    */           }
/* 179 */           if (dib < 128) {
/* 180 */             t = dib * sb + 128;
/* 181 */             dob = 2 * ((t >> 8) + t >> 8);
/*    */           } else {
/* 183 */             t = (255 - dib) * (255 - sb) + 128;
/* 184 */             dob = 2 * (255 - ((t >> 8) + t >> 8));
/*    */           }
/* 186 */           break;
/*    */         case 5:
/* 189 */           dor = dir < sr ? dir : sr;
/* 190 */           dog = dig < sg ? dig : sg;
/* 191 */           dob = dib < sb ? dib : sb;
/* 192 */           break;
/*    */         case 9:
/* 195 */           dor = dir > sr ? dir : sr;
/* 196 */           dog = dig > sg ? dig : sg;
/* 197 */           dob = dib > sb ? dib : sb;
/* 198 */           break;
/*    */         case 22:
/* 201 */           dor = (dir + sr) / 2;
/* 202 */           dog = (dig + sg) / 2;
/* 203 */           dob = (dib + sb) / 2;
/* 204 */           break;
/*    */         case 12:
/*    */         case 13:
/*    */         case 14:
/*    */         case 15:
/* 210 */           Color.RGBtoHSB(sr, sg, sb, sHsv);
/* 211 */           Color.RGBtoHSB(dir, dig, dib, diHsv);
/*    */ 
/* 213 */           switch (this.rule) {
/*    */           case 12:
/* 215 */             doHsv[0] = sHsv[0];
/* 216 */             doHsv[1] = diHsv[1];
/* 217 */             doHsv[2] = diHsv[2];
/* 218 */             break;
/*    */           case 13:
/* 220 */             doHsv[0] = diHsv[0];
/* 221 */             doHsv[1] = sHsv[1];
/* 222 */             doHsv[2] = diHsv[2];
/* 223 */             break;
/*    */           case 14:
/* 225 */             doHsv[0] = diHsv[0];
/* 226 */             doHsv[1] = diHsv[1];
/* 227 */             doHsv[2] = sHsv[2];
/* 228 */             break;
/*    */           case 15:
/* 230 */             doHsv[0] = sHsv[0];
/* 231 */             doHsv[1] = sHsv[1];
/* 232 */             doHsv[2] = diHsv[2];
/*    */           }
/*    */ 
/* 236 */           int doRGB = Color.HSBtoRGB(doHsv[0], doHsv[1], doHsv[2]);
/* 237 */           dor = (doRGB & 0xFF0000) >> 16;
/* 238 */           dog = (doRGB & 0xFF00) >> 8;
/* 239 */           dob = doRGB & 0xFF;
/* 240 */           break;
/*    */         case 6:
/* 243 */           if (dir != 255)
/* 244 */             dor = clamp(255 - (255 - sr << 8) / (dir + 1));
/*    */           else
/* 246 */             dor = sr;
/* 247 */           if (dig != 255)
/* 248 */             dog = clamp(255 - (255 - sg << 8) / (dig + 1));
/*    */           else
/* 250 */             dog = sg;
/* 251 */           if (dib != 255)
/* 252 */             dob = clamp(255 - (255 - sb << 8) / (dib + 1));
/*    */           else
/* 254 */             dob = sb;
/* 255 */           break;
/*    */         case 7:
/* 258 */           if (sr != 0)
/* 259 */             dor = Math.max(255 - (255 - dir << 8) / sr, 0);
/*    */           else
/* 261 */             dor = sr;
/* 262 */           if (sg != 0)
/* 263 */             dog = Math.max(255 - (255 - dig << 8) / sg, 0);
/*    */           else
/* 265 */             dog = sg;
/* 266 */           if (sb != 0)
/* 267 */             dob = Math.max(255 - (255 - dib << 8) / sb, 0);
/*    */           else
/* 269 */             dob = sb;
/* 270 */           break;
/*    */         case 10:
/* 273 */           dor = clamp((sr << 8) / (256 - dir));
/* 274 */           dog = clamp((sg << 8) / (256 - dig));
/* 275 */           dob = clamp((sb << 8) / (256 - dib));
/* 276 */           break;
/*    */         case 11:
/* 279 */           if (sr != 255)
/* 280 */             dor = Math.min((dir << 8) / (255 - sr), 255);
/*    */           else
/* 282 */             dor = sr;
/* 283 */           if (sg != 255)
/* 284 */             dog = Math.min((dig << 8) / (255 - sg), 255);
/*    */           else
/* 286 */             dog = sg;
/* 287 */           if (sb != 255)
/* 288 */             dob = Math.min((dib << 8) / (255 - sb), 255);
/*    */           else
/* 290 */             dob = sb;
/* 291 */           break;
/*    */         case 17:
/* 295 */           int d = multiply255(sr, dir);
/* 296 */           dor = d + multiply255(dir, 255 - multiply255(255 - dir, 255 - sr) - d);
/* 297 */           d = multiply255(sg, dig);
/* 298 */           dog = d + multiply255(dig, 255 - multiply255(255 - dig, 255 - sg) - d);
/* 299 */           d = multiply255(sb, dib);
/* 300 */           dob = d + multiply255(dib, 255 - multiply255(255 - dib, 255 - sb) - d);
/* 301 */           break;
/*    */         case 18:
/* 304 */           if (sr > 127)
/* 305 */             dor = 255 - 2 * multiply255(255 - sr, 255 - dir);
/*    */           else
/* 307 */             dor = 2 * multiply255(sr, dir);
/* 308 */           if (sg > 127)
/* 309 */             dog = 255 - 2 * multiply255(255 - sg, 255 - dig);
/*    */           else
/* 311 */             dog = 2 * multiply255(sg, dig);
/* 312 */           if (sb > 127)
/* 313 */             dob = 255 - 2 * multiply255(255 - sb, 255 - dib);
/*    */           else
/* 315 */             dob = 2 * multiply255(sb, dib);
/* 316 */           break;
/*    */         case 19:
/* 319 */           dor = sr > 127 ? Math.max(sr, dir) : Math.min(sr, dir);
/* 320 */           dog = sg > 127 ? Math.max(sg, dig) : Math.min(sg, dig);
/* 321 */           dob = sb > 127 ? Math.max(sb, dib) : Math.min(sb, dib);
/* 322 */           break;
/*    */         case 20:
/* 325 */           dor = dir + multiply255(sr, 255 - dir - dir);
/* 326 */           dog = dig + multiply255(sg, 255 - dig - dig);
/* 327 */           dob = dib + multiply255(sb, 255 - dib - dib);
/* 328 */           break;
/*    */         case 21:
/* 331 */           dor = 255 - Math.abs(255 - sr - dir);
/* 332 */           dog = 255 - Math.abs(255 - sg - dig);
/* 333 */           dob = 255 - Math.abs(255 - sb - dib);
/*    */         }
/*    */ 
/* 337 */         a = alpha * sa / 255.0F;
/* 338 */         ac = 1.0F - a;
/*    */ 
/* 340 */         dstPix[i] = (int)(a * dor + ac * dir);
/* 341 */         dstPix[(i + 1)] = (int)(a * dog + ac * dig);
/* 342 */         dstPix[(i + 2)] = (int)(a * dob + ac * dib);
/* 343 */         dstPix[(i + 3)] = (int)(sa * alpha + dia * ac);
/* 344 */         i += 4;
/*    */       }
/* 346 */       dstOut.setPixels(x, y, w, 1, dstPix);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.MiscCompositeContext
 * JD-Core Version:    0.6.1
 */