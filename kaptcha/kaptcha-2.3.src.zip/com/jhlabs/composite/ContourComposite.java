/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.Composite;
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public final class ContourComposite
/*    */   implements Composite
/*    */ {
/*    */   private int offset;
/*    */ 
/*    */   public ContourComposite(int offset)
/*    */   {
/* 32 */     this.offset = offset;
/*    */   }
/*    */ 
/*    */   public CompositeContext createContext(ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints) {
/* 36 */     return new ContourCompositeContext(this.offset, srcColorModel, dstColorModel);
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 40 */     return 0;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o) {
/* 44 */     if (!(o instanceof ContourComposite))
/* 45 */       return false;
/* 46 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.ContourComposite
 * JD-Core Version:    0.6.1
 */