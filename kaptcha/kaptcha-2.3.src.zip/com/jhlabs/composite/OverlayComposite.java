/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public final class OverlayComposite extends RGBComposite
/*    */ {
/*    */   public OverlayComposite(float alpha)
/*    */   {
/* 25 */     super(alpha);
/*    */   }
/*    */ 
/*    */   public CompositeContext createContext(ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints) {
/* 29 */     return new Context(this.extraAlpha, srcColorModel, dstColorModel);
/*    */   }
/*    */ 
/*    */   static class Context extends RGBComposite.RGBCompositeContext {
/*    */     public Context(float alpha, ColorModel srcColorModel, ColorModel dstColorModel) {
/* 34 */       super(srcColorModel, dstColorModel);
/*    */     }
/*    */ 
/*    */     public void composeRGB(int[] src, int[] dst, float alpha) {
/* 38 */       int w = src.length;
/*    */ 
/* 40 */       for (int i = 0; i < w; i += 4) {
/* 41 */         int sr = src[i];
/* 42 */         int dir = dst[i];
/* 43 */         int sg = src[(i + 1)];
/* 44 */         int dig = dst[(i + 1)];
/* 45 */         int sb = src[(i + 2)];
/* 46 */         int dib = dst[(i + 2)];
/* 47 */         int sa = src[(i + 3)];
/* 48 */         int dia = dst[(i + 3)];
/*    */         int dor;
/*    */         int t;
/*    */         int dor;
/* 52 */         if (dir < 128) {
/* 53 */           int t = dir * sr + 128;
/* 54 */           dor = 2 * ((t >> 8) + t >> 8);
/*    */         } else {
/* 56 */           t = (255 - dir) * (255 - sr) + 128;
/* 57 */           dor = 2 * (255 - ((t >> 8) + t >> 8));
/*    */         }
/*    */         int dog;
/*    */         int dog;
/* 59 */         if (dig < 128) {
/* 60 */           t = dig * sg + 128;
/* 61 */           dog = 2 * ((t >> 8) + t >> 8);
/*    */         } else {
/* 63 */           t = (255 - dig) * (255 - sg) + 128;
/* 64 */           dog = 2 * (255 - ((t >> 8) + t >> 8));
/*    */         }
/*    */         int dob;
/*    */         int dob;
/* 66 */         if (dib < 128) {
/* 67 */           t = dib * sb + 128;
/* 68 */           dob = 2 * ((t >> 8) + t >> 8);
/*    */         } else {
/* 70 */           t = (255 - dib) * (255 - sb) + 128;
/* 71 */           dob = 2 * (255 - ((t >> 8) + t >> 8));
/*    */         }
/*    */ 
/* 74 */         float a = alpha * sa / 255.0F;
/* 75 */         float ac = 1.0F - a;
/*    */ 
/* 77 */         dst[i] = (int)(a * dor + ac * dir);
/* 78 */         dst[(i + 1)] = (int)(a * dog + ac * dig);
/* 79 */         dst[(i + 2)] = (int)(a * dob + ac * dib);
/* 80 */         dst[(i + 3)] = (int)(sa * alpha + dia * ac);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.OverlayComposite
 * JD-Core Version:    0.6.1
 */