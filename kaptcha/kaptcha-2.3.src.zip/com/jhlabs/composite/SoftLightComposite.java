/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public final class SoftLightComposite extends RGBComposite
/*    */ {
/*    */   public SoftLightComposite(float alpha)
/*    */   {
/* 25 */     super(alpha);
/*    */   }
/*    */ 
/*    */   public CompositeContext createContext(ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints) {
/* 29 */     return new Context(this.extraAlpha, srcColorModel, dstColorModel);
/*    */   }
/*    */ 
/*    */   static class Context extends RGBComposite.RGBCompositeContext {
/*    */     public Context(float alpha, ColorModel srcColorModel, ColorModel dstColorModel) {
/* 34 */       super(srcColorModel, dstColorModel);
/*    */     }
/*    */ 
/*    */     public void composeRGB(int[] src, int[] dst, float alpha) {
/* 38 */       int w = src.length;
/*    */ 
/* 40 */       for (int i = 0; i < w; i += 4) {
/* 41 */         int sr = src[i];
/* 42 */         int dir = dst[i];
/* 43 */         int sg = src[(i + 1)];
/* 44 */         int dig = dst[(i + 1)];
/* 45 */         int sb = src[(i + 2)];
/* 46 */         int dib = dst[(i + 2)];
/* 47 */         int sa = src[(i + 3)];
/* 48 */         int dia = dst[(i + 3)];
/*    */ 
/* 52 */         int d = multiply255(sr, dir);
/* 53 */         int dor = d + multiply255(dir, 255 - multiply255(255 - dir, 255 - sr) - d);
/* 54 */         d = multiply255(sg, dig);
/* 55 */         int dog = d + multiply255(dig, 255 - multiply255(255 - dig, 255 - sg) - d);
/* 56 */         d = multiply255(sb, dib);
/* 57 */         int dob = d + multiply255(dib, 255 - multiply255(255 - dib, 255 - sb) - d);
/*    */ 
/* 59 */         float a = alpha * sa / 255.0F;
/* 60 */         float ac = 1.0F - a;
/*    */ 
/* 62 */         dst[i] = (int)(a * dor + ac * dir);
/* 63 */         dst[(i + 1)] = (int)(a * dog + ac * dig);
/* 64 */         dst[(i + 2)] = (int)(a * dob + ac * dib);
/* 65 */         dst[(i + 3)] = (int)(sa * alpha + dia * ac);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.SoftLightComposite
 * JD-Core Version:    0.6.1
 */