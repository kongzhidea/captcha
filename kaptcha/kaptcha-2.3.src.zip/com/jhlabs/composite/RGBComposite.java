/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.Composite;
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ public abstract class RGBComposite
/*    */   implements Composite
/*    */ {
/*    */   protected float extraAlpha;
/*    */ 
/*    */   public RGBComposite()
/*    */   {
/* 27 */     this(1.0F);
/*    */   }
/*    */ 
/*    */   public RGBComposite(float alpha) {
/* 31 */     if ((alpha < 0.0F) || (alpha > 1.0F))
/* 32 */       throw new IllegalArgumentException("RGBComposite: alpha must be between 0 and 1");
/* 33 */     this.extraAlpha = alpha;
/*    */   }
/*    */ 
/*    */   public float getAlpha() {
/* 37 */     return this.extraAlpha;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 41 */     return Float.floatToIntBits(this.extraAlpha);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o) {
/* 45 */     if (!(o instanceof RGBComposite))
/* 46 */       return false;
/* 47 */     RGBComposite c = (RGBComposite)o;
/*    */ 
/* 49 */     if (this.extraAlpha != c.extraAlpha)
/* 50 */       return false;
/* 51 */     return true;
/*    */   }
/*    */   public static abstract class RGBCompositeContext implements CompositeContext {
/*    */     private float alpha;
/*    */     private ColorModel srcColorModel;
/*    */     private ColorModel dstColorModel;
/*    */ 
/*    */     public RGBCompositeContext(float alpha, ColorModel srcColorModel, ColorModel dstColorModel) {
/* 61 */       this.alpha = alpha;
/* 62 */       this.srcColorModel = srcColorModel;
/* 63 */       this.dstColorModel = dstColorModel;
/*    */     }
/*    */ 
/*    */     public void dispose()
/*    */     {
/*    */     }
/*    */ 
/*    */     static int multiply255(int a, int b) {
/* 71 */       int t = a * b + 128;
/* 72 */       return (t >> 8) + t >> 8;
/*    */     }
/*    */ 
/*    */     static int clamp(int a) {
/* 76 */       return a > 255 ? 255 : a < 0 ? 0 : a;
/*    */     }
/*    */ 
/*    */     public abstract void composeRGB(int[] paramArrayOfInt1, int[] paramArrayOfInt2, float paramFloat);
/*    */ 
/*    */     public void compose(Raster src, Raster dstIn, WritableRaster dstOut) {
/* 82 */       float alpha = this.alpha;
/*    */ 
/* 84 */       int[] srcPix = null;
/* 85 */       int[] dstPix = null;
/*    */ 
/* 87 */       int x = dstOut.getMinX();
/* 88 */       int w = dstOut.getWidth();
/* 89 */       int y0 = dstOut.getMinY();
/* 90 */       int y1 = y0 + dstOut.getHeight();
/*    */ 
/* 92 */       for (int y = y0; y < y1; y++) {
/* 93 */         srcPix = src.getPixels(x, y, w, 1, srcPix);
/* 94 */         dstPix = dstIn.getPixels(x, y, w, 1, dstPix);
/* 95 */         composeRGB(srcPix, dstPix, alpha);
/* 96 */         dstOut.setPixels(x, y, w, 1, dstPix);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.RGBComposite
 * JD-Core Version:    0.6.1
 */