/*    */ package com.jhlabs.composite;
/*    */ 
/*    */ import java.awt.CompositeContext;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public final class DifferenceComposite extends RGBComposite
/*    */ {
/*    */   public DifferenceComposite(float alpha)
/*    */   {
/* 25 */     super(alpha);
/*    */   }
/*    */ 
/*    */   public CompositeContext createContext(ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints) {
/* 29 */     return new Context(this.extraAlpha, srcColorModel, dstColorModel);
/*    */   }
/*    */ 
/*    */   static class Context extends RGBComposite.RGBCompositeContext {
/*    */     public Context(float alpha, ColorModel srcColorModel, ColorModel dstColorModel) {
/* 34 */       super(srcColorModel, dstColorModel);
/*    */     }
/*    */ 
/*    */     public void composeRGB(int[] src, int[] dst, float alpha) {
/* 38 */       int w = src.length;
/*    */ 
/* 40 */       for (int i = 0; i < w; i += 4) {
/* 41 */         int sr = src[i];
/* 42 */         int dir = dst[i];
/* 43 */         int sg = src[(i + 1)];
/* 44 */         int dig = dst[(i + 1)];
/* 45 */         int sb = src[(i + 2)];
/* 46 */         int dib = dst[(i + 2)];
/* 47 */         int sa = src[(i + 3)];
/* 48 */         int dia = dst[(i + 3)];
/*    */ 
/* 51 */         int dor = dir - sr;
/* 52 */         if (dor < 0)
/* 53 */           dor = -dor;
/* 54 */         int dog = dig - sg;
/* 55 */         if (dog < 0)
/* 56 */           dog = -dog;
/* 57 */         int dob = dib - sb;
/* 58 */         if (dob < 0) {
/* 59 */           dob = -dob;
/*    */         }
/* 61 */         float a = alpha * sa / 255.0F;
/* 62 */         float ac = 1.0F - a;
/*    */ 
/* 64 */         dst[i] = (int)(a * dor + ac * dir);
/* 65 */         dst[(i + 1)] = (int)(a * dog + ac * dig);
/* 66 */         dst[(i + 2)] = (int)(a * dob + ac * dib);
/* 67 */         dst[(i + 3)] = (int)(sa * alpha + dia * ac);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.composite.DifferenceComposite
 * JD-Core Version:    0.6.1
 */