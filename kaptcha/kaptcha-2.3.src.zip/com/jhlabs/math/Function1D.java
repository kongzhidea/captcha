package com.jhlabs.math;

public abstract interface Function1D
{
  public abstract float evaluate(float paramFloat);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.Function1D
 * JD-Core Version:    0.6.1
 */