package com.jhlabs.math;

public abstract interface Function2D
{
  public abstract float evaluate(float paramFloat1, float paramFloat2);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.Function2D
 * JD-Core Version:    0.6.1
 */