/*     */ package com.jhlabs.math;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ public class CellularFunction2D
/*     */   implements Function2D
/*     */ {
/*  24 */   public float distancePower = 2.0F;
/*  25 */   public boolean cells = false;
/*  26 */   public boolean angular = false;
/*  27 */   private float[] coefficients = { 1.0F, 0.0F, 0.0F, 0.0F };
/*  28 */   private Random random = new Random();
/*  29 */   private Point[] results = null;
/*     */ 
/*     */   public CellularFunction2D() {
/*  32 */     this.results = new Point[2];
/*  33 */     for (int j = 0; j < this.results.length; j++)
/*  34 */       this.results[j] = new Point();
/*     */   }
/*     */ 
/*     */   public void setCoefficient(int c, float v) {
/*  38 */     this.coefficients[c] = v;
/*     */   }
/*     */ 
/*     */   public float getCoefficient(int c) {
/*  42 */     return this.coefficients[c];
/*     */   }
/*     */ 
/*     */   private float checkCube(float x, float y, int cubeX, int cubeY, Point[] results)
/*     */   {
/*  52 */     this.random.setSeed(571 * cubeX + 23 * cubeY);
/*  53 */     int numPoints = 3 + this.random.nextInt() % 4;
/*  54 */     numPoints = 4;
/*     */ 
/*  56 */     for (int i = 0; i < numPoints; i++) {
/*  57 */       float px = this.random.nextFloat();
/*  58 */       float py = this.random.nextFloat();
/*  59 */       float dx = Math.abs(x - px);
/*  60 */       float dy = Math.abs(y - py);
/*     */       float d;
/*     */       float d;
/*  62 */       if (this.distancePower == 1.0F) {
/*  63 */         d = dx + dy;
/*     */       }
/*     */       else
/*     */       {
/*     */         float d;
/*  64 */         if (this.distancePower == 2.0F)
/*  65 */           d = (float)Math.sqrt(dx * dx + dy * dy);
/*     */         else {
/*  67 */           d = (float)Math.pow(Math.pow(dx, this.distancePower) + Math.pow(dy, this.distancePower), 1.0F / this.distancePower);
/*     */         }
/*     */       }
/*  70 */       for (int j = 0; j < results.length; j++) {
/*  71 */         if (results[j].distance == (1.0D / 0.0D)) {
/*  72 */           Point last = results[j];
/*  73 */           last.distance = d;
/*  74 */           last.x = px;
/*  75 */           last.y = py;
/*  76 */           results[j] = last;
/*  77 */           break;
/*  78 */         }if (d < results[j].distance) {
/*  79 */           Point last = results[(results.length - 1)];
/*  80 */           for (int k = results.length - 1; k > j; k--)
/*  81 */             results[k] = results[(k - 1)];
/*  82 */           last.distance = d;
/*  83 */           last.x = px;
/*  84 */           last.y = py;
/*  85 */           results[j] = last;
/*  86 */           break;
/*     */         }
/*     */       }
/*     */     }
/*  90 */     return results[1].distance;
/*     */   }
/*     */ 
/*     */   public float evaluate(float x, float y) {
/*  94 */     for (int j = 0; j < this.results.length; j++) {
/*  95 */       this.results[j].distance = (1.0F / 1.0F);
/*     */     }
/*  97 */     int ix = (int)x;
/*  98 */     int iy = (int)y;
/*  99 */     float fx = x - ix;
/* 100 */     float fy = y - iy;
/*     */ 
/* 102 */     float d = checkCube(fx, fy, ix, iy, this.results);
/* 103 */     if (d > fy)
/* 104 */       d = checkCube(fx, fy + 1.0F, ix, iy - 1, this.results);
/* 105 */     if (d > 1.0F - fy)
/* 106 */       d = checkCube(fx, fy - 1.0F, ix, iy + 1, this.results);
/* 107 */     if (d > fx) {
/* 108 */       checkCube(fx + 1.0F, fy, ix - 1, iy, this.results);
/* 109 */       if (d > fy)
/* 110 */         d = checkCube(fx + 1.0F, fy + 1.0F, ix - 1, iy - 1, this.results);
/* 111 */       if (d > 1.0F - fy)
/* 112 */         d = checkCube(fx + 1.0F, fy - 1.0F, ix - 1, iy + 1, this.results);
/*     */     }
/* 114 */     if (d > 1.0F - fx) {
/* 115 */       d = checkCube(fx - 1.0F, fy, ix + 1, iy, this.results);
/* 116 */       if (d > fy)
/* 117 */         d = checkCube(fx - 1.0F, fy + 1.0F, ix + 1, iy - 1, this.results);
/* 118 */       if (d > 1.0F - fy) {
/* 119 */         d = checkCube(fx - 1.0F, fy - 1.0F, ix + 1, iy + 1, this.results);
/*     */       }
/*     */     }
/* 122 */     float t = 0.0F;
/* 123 */     for (int i = 0; i < 2; i++)
/* 124 */       t += this.coefficients[i] * this.results[i].distance;
/* 125 */     if (this.angular)
/* 126 */       t = (float)(t + (Math.atan2(fy - this.results[0].y, fx - this.results[0].x) / 6.283185307179586D + 0.5D));
/* 127 */     return t;
/*     */   }
/*     */ 
/*     */   class Point
/*     */   {
/*     */     int index;
/*     */     float x;
/*     */     float y;
/*     */     float distance;
/*     */ 
/*     */     Point()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.CellularFunction2D
 * JD-Core Version:    0.6.1
 */