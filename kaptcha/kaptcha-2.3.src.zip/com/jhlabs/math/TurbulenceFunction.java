/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class TurbulenceFunction extends CompoundFunction2D
/*    */ {
/*    */   private float octaves;
/*    */ 
/*    */   public TurbulenceFunction(Function2D basis, float octaves)
/*    */   {
/* 24 */     super(basis);
/* 25 */     this.octaves = octaves;
/*    */   }
/*    */ 
/*    */   public void setOctaves(float octaves) {
/* 29 */     this.octaves = octaves;
/*    */   }
/*    */ 
/*    */   public float getOctaves() {
/* 33 */     return this.octaves;
/*    */   }
/*    */ 
/*    */   public float evaluate(float x, float y) {
/* 37 */     float t = 0.0F;
/*    */ 
/* 39 */     for (float f = 1.0F; f <= this.octaves; f *= 2.0F)
/* 40 */       t += Math.abs(this.basis.evaluate(f * x, f * y)) / f;
/* 41 */     return t;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.TurbulenceFunction
 * JD-Core Version:    0.6.1
 */