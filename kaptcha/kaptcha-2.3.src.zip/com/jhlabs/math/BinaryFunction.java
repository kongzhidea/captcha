package com.jhlabs.math;

public abstract interface BinaryFunction
{
  public abstract boolean isBlack(int paramInt);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.BinaryFunction
 * JD-Core Version:    0.6.1
 */