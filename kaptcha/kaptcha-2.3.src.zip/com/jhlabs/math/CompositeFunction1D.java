/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class CompositeFunction1D
/*    */   implements Function1D
/*    */ {
/*    */   private Function1D f1;
/*    */   private Function1D f2;
/*    */ 
/*    */   public CompositeFunction1D(Function1D f1, Function1D f2)
/*    */   {
/* 24 */     this.f1 = f1;
/* 25 */     this.f2 = f2;
/*    */   }
/*    */ 
/*    */   public float evaluate(float v) {
/* 29 */     return this.f1.evaluate(this.f2.evaluate(v));
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.CompositeFunction1D
 * JD-Core Version:    0.6.1
 */