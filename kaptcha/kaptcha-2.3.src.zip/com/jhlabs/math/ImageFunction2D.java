/*     */ package com.jhlabs.math;
/*     */ 
/*     */ import com.jhlabs.image.ImageMath;
/*     */ import com.jhlabs.image.PixelUtils;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class ImageFunction2D
/*     */   implements Function2D
/*     */ {
/*     */   public static final int ZERO = 0;
/*     */   public static final int CLAMP = 1;
/*     */   public static final int WRAP = 2;
/*     */   protected int[] pixels;
/*     */   protected int width;
/*     */   protected int height;
/*  32 */   protected int edgeAction = 0;
/*  33 */   protected boolean alpha = false;
/*     */ 
/*     */   public ImageFunction2D(BufferedImage image) {
/*  36 */     this(image, false);
/*     */   }
/*     */ 
/*     */   public ImageFunction2D(BufferedImage image, boolean alpha) {
/*  40 */     this(image, 0, alpha);
/*     */   }
/*     */ 
/*     */   public ImageFunction2D(BufferedImage image, int edgeAction, boolean alpha) {
/*  44 */     init(getRGB(image, 0, 0, image.getWidth(), image.getHeight(), null), image.getWidth(), image.getHeight(), edgeAction, alpha);
/*     */   }
/*     */ 
/*     */   public ImageFunction2D(int[] pixels, int width, int height, int edgeAction, boolean alpha) {
/*  48 */     init(pixels, width, height, edgeAction, alpha);
/*     */   }
/*     */ 
/*     */   public ImageFunction2D(Image image) {
/*  52 */     this(image, 0, false);
/*     */   }
/*     */ 
/*     */   public ImageFunction2D(Image image, int edgeAction, boolean alpha) {
/*  56 */     PixelGrabber pg = new PixelGrabber(image, 0, 0, -1, -1, null, 0, -1);
/*     */     try {
/*  58 */       pg.grabPixels();
/*     */     } catch (InterruptedException e) {
/*  60 */       throw new RuntimeException("interrupted waiting for pixels!");
/*     */     }
/*  62 */     if ((pg.status() & 0x80) != 0) {
/*  63 */       throw new RuntimeException("image fetch aborted");
/*     */     }
/*  65 */     init((int[])pg.getPixels(), pg.getWidth(), pg.getHeight(), edgeAction, alpha);
/*     */   }
/*     */ 
/*     */   public int[] getRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*     */   {
/*  81 */     int type = image.getType();
/*  82 */     if ((type == 2) || (type == 1))
/*  83 */       return (int[])image.getRaster().getDataElements(x, y, width, height, pixels);
/*  84 */     return image.getRGB(x, y, width, height, pixels, 0, width);
/*     */   }
/*     */ 
/*     */   public void init(int[] pixels, int width, int height, int edgeAction, boolean alpha) {
/*  88 */     this.pixels = pixels;
/*  89 */     this.width = width;
/*  90 */     this.height = height;
/*  91 */     this.edgeAction = edgeAction;
/*  92 */     this.alpha = alpha;
/*     */   }
/*     */ 
/*     */   public float evaluate(float x, float y) {
/*  96 */     int ix = (int)x;
/*  97 */     int iy = (int)y;
/*  98 */     if (this.edgeAction == 2) {
/*  99 */       ix = ImageMath.mod(ix, this.width);
/* 100 */       iy = ImageMath.mod(iy, this.height);
/* 101 */     } else if ((ix < 0) || (iy < 0) || (ix >= this.width) || (iy >= this.height)) {
/* 102 */       if (this.edgeAction == 0)
/* 103 */         return 0.0F;
/* 104 */       if (ix < 0)
/* 105 */         ix = 0;
/* 106 */       else if (ix >= this.width)
/* 107 */         ix = this.width - 1;
/* 108 */       if (iy < 0)
/* 109 */         iy = 0;
/* 110 */       else if (iy >= this.height)
/* 111 */         iy = this.height - 1;
/*     */     }
/* 113 */     return this.alpha ? this.pixels[(iy * this.width + ix)] >> 24 & 0xFF / 255.0F : PixelUtils.brightness(this.pixels[(iy * this.width + ix)]) / 255.0F;
/*     */   }
/*     */ 
/*     */   public void setEdgeAction(int edgeAction) {
/* 117 */     this.edgeAction = edgeAction;
/*     */   }
/*     */ 
/*     */   public int getEdgeAction() {
/* 121 */     return this.edgeAction;
/*     */   }
/*     */ 
/*     */   public int getWidth() {
/* 125 */     return this.width;
/*     */   }
/*     */ 
/*     */   public int getHeight() {
/* 129 */     return this.height;
/*     */   }
/*     */ 
/*     */   public int[] getPixels() {
/* 133 */     return this.pixels;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.ImageFunction2D
 * JD-Core Version:    0.6.1
 */