/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public abstract class CompoundFunction2D
/*    */   implements Function2D
/*    */ {
/*    */   protected Function2D basis;
/*    */ 
/*    */   public CompoundFunction2D(Function2D basis)
/*    */   {
/* 24 */     this.basis = basis;
/*    */   }
/*    */ 
/*    */   public void setBasis(Function2D basis) {
/* 28 */     this.basis = basis;
/*    */   }
/*    */ 
/*    */   public Function2D getBasis() {
/* 32 */     return this.basis;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.CompoundFunction2D
 * JD-Core Version:    0.6.1
 */