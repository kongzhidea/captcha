/*     */ package com.jhlabs.math;
/*     */ 
/*     */ public class FFT
/*     */ {
/*     */   protected float[] w1;
/*     */   protected float[] w2;
/*     */   protected float[] w3;
/*     */ 
/*     */   public FFT(int logN)
/*     */   {
/*  28 */     this.w1 = new float[logN];
/*  29 */     this.w2 = new float[logN];
/*  30 */     this.w3 = new float[logN];
/*  31 */     int N = 1;
/*  32 */     for (int k = 0; k < logN; k++) {
/*  33 */       N <<= 1;
/*  34 */       double angle = -6.283185307179586D / N;
/*  35 */       this.w1[k] = (float)Math.sin(0.5D * angle);
/*  36 */       this.w2[k] = (-2.0F * this.w1[k] * this.w1[k]);
/*  37 */       this.w3[k] = (float)Math.sin(angle);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void scramble(int n, float[] real, float[] imag) {
/*  42 */     int j = 0;
/*     */ 
/*  44 */     for (int i = 0; i < n; i++) {
/*  45 */       if (i > j)
/*     */       {
/*  47 */         float t = real[j];
/*  48 */         real[j] = real[i];
/*  49 */         real[i] = t;
/*  50 */         t = imag[j];
/*  51 */         imag[j] = imag[i];
/*  52 */         imag[i] = t;
/*     */       }
/*  54 */       int m = n >> 1;
/*  55 */       while ((j >= m) && (m >= 2)) {
/*  56 */         j -= m;
/*  57 */         m >>= 1;
/*     */       }
/*  59 */       j += m;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void butterflies(int n, int logN, int direction, float[] real, float[] imag) {
/*  64 */     int N = 1;
/*     */ 
/*  66 */     for (int k = 0; k < logN; k++)
/*     */     {
/*  68 */       int half_N = N;
/*  69 */       N <<= 1;
/*  70 */       float wt = direction * this.w1[k];
/*  71 */       float wp_re = this.w2[k];
/*  72 */       float wp_im = direction * this.w3[k];
/*  73 */       float w_re = 1.0F;
/*  74 */       float w_im = 0.0F;
/*  75 */       for (int offset = 0; offset < half_N; offset++) {
/*  76 */         for (int i = offset; i < n; i += N) {
/*  77 */           int j = i + half_N;
/*  78 */           float re = real[j];
/*  79 */           float im = imag[j];
/*  80 */           float temp_re = w_re * re - w_im * im;
/*  81 */           float temp_im = w_im * re + w_re * im;
/*  82 */           real[i] -= temp_re;
/*  83 */           real[i] += temp_re;
/*  84 */           imag[i] -= temp_im;
/*  85 */           imag[i] += temp_im;
/*     */         }
/*  87 */         wt = w_re;
/*  88 */         w_re = wt * wp_re - w_im * wp_im + w_re;
/*  89 */         w_im = w_im * wp_re + wt * wp_im + w_im;
/*     */       }
/*     */     }
/*  92 */     if (direction == -1) {
/*  93 */       float nr = 1.0F / n;
/*  94 */       for (int i = 0; i < n; i++) {
/*  95 */         real[i] *= nr;
/*  96 */         imag[i] *= nr;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void transform1D(float[] real, float[] imag, int logN, int n, boolean forward) {
/* 102 */     scramble(n, real, imag);
/* 103 */     butterflies(n, logN, forward ? 1 : -1, real, imag);
/*     */   }
/*     */ 
/*     */   public void transform2D(float[] real, float[] imag, int cols, int rows, boolean forward) {
/* 107 */     int log2cols = log2(cols);
/* 108 */     int log2rows = log2(rows);
/* 109 */     int n = Math.max(rows, cols);
/* 110 */     float[] rtemp = new float[n];
/* 111 */     float[] itemp = new float[n];
/*     */ 
/* 114 */     for (int y = 0; y < rows; y++) {
/* 115 */       int offset = y * cols;
/* 116 */       System.arraycopy(real, offset, rtemp, 0, cols);
/* 117 */       System.arraycopy(imag, offset, itemp, 0, cols);
/* 118 */       transform1D(rtemp, itemp, log2cols, cols, forward);
/* 119 */       System.arraycopy(rtemp, 0, real, offset, cols);
/* 120 */       System.arraycopy(itemp, 0, imag, offset, cols);
/*     */     }
/*     */ 
/* 124 */     for (int x = 0; x < cols; x++) {
/* 125 */       int index = x;
/* 126 */       for (int y = 0; y < rows; y++) {
/* 127 */         rtemp[y] = real[index];
/* 128 */         itemp[y] = imag[index];
/* 129 */         index += cols;
/*     */       }
/* 131 */       transform1D(rtemp, itemp, log2rows, rows, forward);
/* 132 */       index = x;
/* 133 */       for (int y = 0; y < rows; y++) {
/* 134 */         real[index] = rtemp[y];
/* 135 */         imag[index] = itemp[y];
/* 136 */         index += cols;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private int log2(int n) {
/* 142 */     int m = 1;
/* 143 */     int log2n = 0;
/*     */ 
/* 145 */     while (m < n) {
/* 146 */       m *= 2;
/* 147 */       log2n++;
/*     */     }
/* 149 */     return m == n ? log2n : -1;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.FFT
 * JD-Core Version:    0.6.1
 */