/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class VLNoise
/*    */   implements Function2D
/*    */ {
/* 21 */   private float distortion = 10.0F;
/*    */ 
/*    */   public void setDistortion(float distortion) {
/* 24 */     this.distortion = distortion;
/*    */   }
/*    */ 
/*    */   public float getDistortion() {
/* 28 */     return this.distortion;
/*    */   }
/*    */ 
/*    */   public float evaluate(float x, float y) {
/* 32 */     float ox = Noise.noise2(x + 0.5F, y) * this.distortion;
/* 33 */     float oy = Noise.noise2(x, y + 0.5F) * this.distortion;
/* 34 */     return Noise.noise2(x + ox, y + oy);
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.VLNoise
 * JD-Core Version:    0.6.1
 */