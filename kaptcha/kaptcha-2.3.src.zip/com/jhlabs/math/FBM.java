/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class FBM
/*    */   implements Function2D
/*    */ {
/*    */   protected float[] exponents;
/*    */   protected float H;
/*    */   protected float lacunarity;
/*    */   protected float octaves;
/*    */   protected Function2D basis;
/*    */ 
/*    */   public FBM(float H, float lacunarity, float octaves)
/*    */   {
/* 28 */     this(H, lacunarity, octaves, new Noise());
/*    */   }
/*    */ 
/*    */   public FBM(float H, float lacunarity, float octaves, Function2D basis) {
/* 32 */     this.H = H;
/* 33 */     this.lacunarity = lacunarity;
/* 34 */     this.octaves = octaves;
/* 35 */     this.basis = basis;
/*    */ 
/* 37 */     this.exponents = new float[(int)octaves + 1];
/* 38 */     float frequency = 1.0F;
/* 39 */     for (int i = 0; i <= (int)octaves; i++) {
/* 40 */       this.exponents[i] = (float)Math.pow(frequency, -H);
/* 41 */       frequency *= lacunarity;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setBasis(Function2D basis) {
/* 46 */     this.basis = basis;
/*    */   }
/*    */ 
/*    */   public Function2D getBasisType() {
/* 50 */     return this.basis;
/*    */   }
/*    */ 
/*    */   public float evaluate(float x, float y) {
/* 54 */     float value = 0.0F;
/*    */ 
/* 59 */     x += 371.0F;
/* 60 */     y += 529.0F;
/*    */ 
/* 62 */     for (int i = 0; i < (int)this.octaves; i++) {
/* 63 */       value += this.basis.evaluate(x, y) * this.exponents[i];
/* 64 */       x *= this.lacunarity;
/* 65 */       y *= this.lacunarity;
/*    */     }
/*    */ 
/* 68 */     float remainder = this.octaves - (int)this.octaves;
/* 69 */     if (remainder != 0.0F) {
/* 70 */       value += remainder * this.basis.evaluate(x, y) * this.exponents[i];
/*    */     }
/* 72 */     return value;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.FBM
 * JD-Core Version:    0.6.1
 */