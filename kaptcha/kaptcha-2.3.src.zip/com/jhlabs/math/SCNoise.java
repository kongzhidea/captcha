/*     */ package com.jhlabs.math;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ public class SCNoise
/*     */   implements Function1D, Function2D, Function3D
/*     */ {
/*  26 */   private static Random randomGenerator = new Random();
/*     */ 
/* 102 */   public short[] perm = { 225, 155, 210, 108, 175, 199, 221, 144, 203, 116, 70, 213, 69, 158, 33, 252, 5, 82, 173, 133, 222, 139, 174, 27, 9, 71, 90, 246, 75, 130, 91, 191, 169, 138, 2, 151, 194, 235, 81, 7, 25, 113, 228, 159, 205, 253, 134, 142, 248, 65, 224, 217, 22, 121, 229, 63, 89, 103, 96, 104, 156, 17, 201, 129, 36, 8, 165, 110, 237, 117, 231, 56, 132, 211, 152, 20, 181, 111, 239, 218, 170, 163, 51, 172, 157, 47, 80, 212, 176, 250, 87, 49, 99, 242, 136, 189, 162, 115, 44, 43, 124, 94, 150, 16, 141, 247, 32, 10, 198, 223, 255, 72, 53, 131, 84, 57, 220, 197, 58, 50, 208, 11, 241, 28, 3, 192, 62, 202, 18, 215, 153, 24, 76, 41, 15, 179, 39, 46, 55, 6, 128, 167, 23, 188, 106, 34, 187, 140, 164, 73, 112, 182, 244, 195, 227, 13, 35, 77, 196, 185, 26, 200, 226, 119, 31, 123, 168, 125, 249, 68, 183, 230, 177, 135, 160, 180, 12, 1, 243, 148, 102, 166, 38, 238, 251, 37, 240, 126, 64, 74, 161, 40, 184, 149, 171, 178, 101, 66, 29, 59, 146, 61, 254, 107, 42, 86, 154, 4, 236, 232, 120, 21, 233, 209, 45, 98, 193, 114, 78, 19, 206, 14, 118, 127, 48, 79, 147, 85, 30, 207, 219, 54, 88, 234, 190, 122, 95, 67, 143, 109, 137, 214, 145, 93, 92, 100, 245, 0, 216, 186, 60, 83, 105, 97, 204, 52 };
/*     */   private static final int TABSIZE = 256;
/*     */   private static final int TABMASK = 255;
/*     */   private static final int NIMPULSES = 3;
/*     */   private static float[] impulseTab;
/*     */   private static final int SAMPRATE = 100;
/*     */   private static final int NENTRIES = 401;
/*     */   private static float[] table;
/*     */ 
/*     */   public float evaluate(float x)
/*     */   {
/*  29 */     return evaluate(x, 0.1F);
/*     */   }
/*     */ 
/*     */   public float evaluate(float x, float y)
/*     */   {
/*  35 */     float sum = 0.0F;
/*     */ 
/*  38 */     if (impulseTab == null) {
/*  39 */       impulseTab = impulseTabInit(665);
/*     */     }
/*  41 */     int ix = floor(x); float fx = x - ix;
/*  42 */     int iy = floor(y); float fy = y - iy;
/*     */ 
/*  45 */     int m = 2;
/*  46 */     for (int i = -m; i <= m; i++) {
/*  47 */       for (int j = -m; j <= m; j++)
/*     */       {
/*  49 */         int h = this.perm[(ix + i + this.perm[(iy + j & 0xFF)] & 0xFF)];
/*     */ 
/*  51 */         for (int n = 3; n > 0; h = h + 1 & 0xFF)
/*     */         {
/*  53 */           int h4 = h * 4;
/*  54 */           float dx = fx - (i + impulseTab[(h4++)]);
/*  55 */           float dy = fy - (j + impulseTab[(h4++)]);
/*  56 */           float distsq = dx * dx + dy * dy;
/*  57 */           sum += catrom2(distsq) * impulseTab[h4];
/*     */ 
/*  51 */           n--;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  62 */     return sum / 3.0F;
/*     */   }
/*     */ 
/*     */   public float evaluate(float x, float y, float z)
/*     */   {
/*  68 */     float sum = 0.0F;
/*     */ 
/*  71 */     if (impulseTab == null) {
/*  72 */       impulseTab = impulseTabInit(665);
/*     */     }
/*  74 */     int ix = floor(x); float fx = x - ix;
/*  75 */     int iy = floor(y); float fy = y - iy;
/*  76 */     int iz = floor(z); float fz = z - iz;
/*     */ 
/*  79 */     int m = 2;
/*  80 */     for (int i = -m; i <= m; i++) {
/*  81 */       for (int j = -m; j <= m; j++) {
/*  82 */         for (int k = -m; k <= m; k++)
/*     */         {
/*  84 */           int h = this.perm[(ix + i + this.perm[(iy + j + this.perm[(iz + k & 0xFF)] & 0xFF)] & 0xFF)];
/*     */ 
/*  86 */           for (int n = 3; n > 0; h = h + 1 & 0xFF)
/*     */           {
/*  88 */             int h4 = h * 4;
/*  89 */             float dx = fx - (i + impulseTab[(h4++)]);
/*  90 */             float dy = fy - (j + impulseTab[(h4++)]);
/*  91 */             float dz = fz - (k + impulseTab[(h4++)]);
/*  92 */             float distsq = dx * dx + dy * dy + dz * dz;
/*  93 */             sum += catrom2(distsq) * impulseTab[h4];
/*     */ 
/*  86 */             n--;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  99 */     return sum / 3.0F;
/*     */   }
/*     */ 
/*     */   public static int floor(float x)
/*     */   {
/* 128 */     int ix = (int)x;
/* 129 */     if ((x < 0.0F) && (x != ix))
/* 130 */       return ix - 1;
/* 131 */     return ix;
/*     */   }
/*     */ 
/*     */   public float catrom2(float d)
/*     */   {
/* 142 */     if (d >= 4.0F) {
/* 143 */       return 0.0F;
/*     */     }
/* 145 */     if (table == null) {
/* 146 */       table = new float[401];
/* 147 */       for (int i = 0; i < 401; i++) {
/* 148 */         float x = i / 100.0F;
/* 149 */         x = (float)Math.sqrt(x);
/* 150 */         if (x < 1.0F)
/* 151 */           table[i] = (0.5F * (2.0F + x * x * (-5.0F + x * 3.0F)));
/*     */         else {
/* 153 */           table[i] = (0.5F * (4.0F + x * (-8.0F + x * (5.0F - x))));
/*     */         }
/*     */       }
/*     */     }
/* 157 */     d = d * 100.0F + 0.5F;
/* 158 */     int i = floor(d);
/* 159 */     if (i >= 401)
/* 160 */       return 0.0F;
/* 161 */     return table[i];
/*     */   }
/*     */ 
/*     */   static float[] impulseTabInit(int seed) {
/* 165 */     float[] impulseTab = new float[1024];
/*     */ 
/* 167 */     randomGenerator = new Random(seed);
/* 168 */     for (int i = 0; i < 256; i++) {
/* 169 */       impulseTab[(i++)] = randomGenerator.nextFloat();
/* 170 */       impulseTab[(i++)] = randomGenerator.nextFloat();
/* 171 */       impulseTab[(i++)] = randomGenerator.nextFloat();
/* 172 */       impulseTab[(i++)] = (1.0F - 2.0F * randomGenerator.nextFloat());
/*     */     }
/*     */ 
/* 175 */     return impulseTab;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.SCNoise
 * JD-Core Version:    0.6.1
 */