package com.jhlabs.math;

public abstract interface Function3D
{
  public abstract float evaluate(float paramFloat1, float paramFloat2, float paramFloat3);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.Function3D
 * JD-Core Version:    0.6.1
 */