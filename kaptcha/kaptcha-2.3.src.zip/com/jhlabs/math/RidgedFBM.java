/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class RidgedFBM
/*    */   implements Function2D
/*    */ {
/*    */   public float evaluate(float x, float y)
/*    */   {
/* 22 */     return 1.0F - Math.abs(Noise.noise2(x, y));
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.RidgedFBM
 * JD-Core Version:    0.6.1
 */