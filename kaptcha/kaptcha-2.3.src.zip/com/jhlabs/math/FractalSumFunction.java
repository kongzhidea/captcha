/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class FractalSumFunction extends CompoundFunction2D
/*    */ {
/* 21 */   private float octaves = 1.0F;
/*    */ 
/*    */   public FractalSumFunction(Function2D basis) {
/* 24 */     super(basis);
/*    */   }
/*    */ 
/*    */   public float evaluate(float x, float y) {
/* 28 */     float t = 0.0F;
/*    */ 
/* 30 */     for (float f = 1.0F; f <= this.octaves; f *= 2.0F)
/* 31 */       t += this.basis.evaluate(f * x, f * y) / f;
/* 32 */     return t;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.FractalSumFunction
 * JD-Core Version:    0.6.1
 */