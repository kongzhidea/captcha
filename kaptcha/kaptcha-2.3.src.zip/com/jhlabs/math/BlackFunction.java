/*    */ package com.jhlabs.math;
/*    */ 
/*    */ public class BlackFunction
/*    */   implements BinaryFunction
/*    */ {
/*    */   public boolean isBlack(int rgb)
/*    */   {
/* 21 */     return rgb == -16777216;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.math.BlackFunction
 * JD-Core Version:    0.6.1
 */