/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class MotionBlurOp extends AbstractBufferedImageOp
/*     */ {
/*  28 */   private float centreX = 0.5F; private float centreY = 0.5F;
/*     */   private float distance;
/*     */   private float angle;
/*     */   private float rotation;
/*     */   private float zoom;
/*     */ 
/*     */   public MotionBlurOp()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MotionBlurOp(float distance, float angle, float rotation, float zoom)
/*     */   {
/*  48 */     this.distance = distance;
/*  49 */     this.angle = angle;
/*  50 */     this.rotation = rotation;
/*  51 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  61 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  70 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setDistance(float distance)
/*     */   {
/*  79 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public float getDistance()
/*     */   {
/*  88 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setRotation(float rotation)
/*     */   {
/*  97 */     this.rotation = rotation;
/*     */   }
/*     */ 
/*     */   public float getRotation()
/*     */   {
/* 106 */     return this.rotation;
/*     */   }
/*     */ 
/*     */   public void setZoom(float zoom)
/*     */   {
/* 115 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public float getZoom()
/*     */   {
/* 124 */     return this.zoom;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/* 133 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/* 142 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/* 151 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/* 160 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 169 */     this.centreX = (float)centre.getX();
/* 170 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 179 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   private int log2(int n) {
/* 183 */     int m = 1;
/* 184 */     int log2n = 0;
/*     */ 
/* 186 */     while (m < n) {
/* 187 */       m *= 2;
/* 188 */       log2n++;
/*     */     }
/* 190 */     return log2n;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 194 */     if (dst == null)
/* 195 */       dst = createCompatibleDestImage(src, null);
/* 196 */     BufferedImage tsrc = src;
/* 197 */     float cx = src.getWidth() * this.centreX;
/* 198 */     float cy = src.getHeight() * this.centreY;
/* 199 */     float imageRadius = (float)Math.sqrt(cx * cx + cy * cy);
/* 200 */     float translateX = (float)(this.distance * Math.cos(this.angle));
/* 201 */     float translateY = (float)(this.distance * -Math.sin(this.angle));
/* 202 */     float scale = this.zoom;
/* 203 */     float rotate = this.rotation;
/* 204 */     float maxDistance = this.distance + Math.abs(this.rotation * imageRadius) + this.zoom * imageRadius;
/* 205 */     int steps = log2((int)maxDistance);
/*     */ 
/* 207 */     translateX /= maxDistance;
/* 208 */     translateY /= maxDistance;
/* 209 */     scale /= maxDistance;
/* 210 */     rotate /= maxDistance;
/*     */ 
/* 212 */     if (steps == 0) {
/* 213 */       Graphics2D g = dst.createGraphics();
/* 214 */       g.drawRenderedImage(src, null);
/* 215 */       g.dispose();
/* 216 */       return dst;
/*     */     }
/*     */ 
/* 219 */     BufferedImage tmp = createCompatibleDestImage(src, null);
/* 220 */     for (int i = 0; i < steps; i++) {
/* 221 */       Graphics2D g = tmp.createGraphics();
/* 222 */       g.drawImage(tsrc, null, null);
/* 223 */       g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 224 */       g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 225 */       g.setComposite(AlphaComposite.getInstance(3, 0.5F));
/*     */ 
/* 227 */       g.translate(cx + translateX, cy + translateY);
/* 228 */       g.scale(1.0001D + scale, 1.0001D + scale);
/* 229 */       if (this.rotation != 0.0F)
/* 230 */         g.rotate(rotate);
/* 231 */       g.translate(-cx, -cy);
/*     */ 
/* 233 */       g.drawImage(dst, null, null);
/* 234 */       g.dispose();
/* 235 */       BufferedImage ti = dst;
/* 236 */       dst = tmp;
/* 237 */       tmp = ti;
/* 238 */       tsrc = dst;
/*     */ 
/* 240 */       translateX *= 2.0F;
/* 241 */       translateY *= 2.0F;
/* 242 */       scale *= 2.0F;
/* 243 */       rotate *= 2.0F;
/*     */     }
/* 245 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 249 */     return "Blur/Faster Motion Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MotionBlurOp
 * JD-Core Version:    0.6.1
 */