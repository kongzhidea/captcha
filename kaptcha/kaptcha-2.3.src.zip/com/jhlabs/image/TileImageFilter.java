/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ public class TileImageFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*     */   private int tileWidth;
/*     */   private int tileHeight;
/*     */ 
/*     */   public TileImageFilter()
/*     */   {
/*  36 */     this(32, 32);
/*     */   }
/*     */ 
/*     */   public TileImageFilter(int width, int height)
/*     */   {
/*  45 */     this.width = width;
/*  46 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/*  55 */     this.width = width;
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/*  64 */     return this.width;
/*     */   }
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/*  73 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/*  82 */     return this.height;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  86 */     int tileWidth = src.getWidth();
/*  87 */     int tileHeight = src.getHeight();
/*     */ 
/*  89 */     if (dst == null) {
/*  90 */       ColorModel dstCM = src.getColorModel();
/*  91 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(this.width, this.height), dstCM.isAlphaPremultiplied(), null);
/*     */     }
/*     */ 
/*  94 */     Graphics2D g = dst.createGraphics();
/*  95 */     for (int y = 0; y < this.height; y += tileHeight) {
/*  96 */       for (int x = 0; x < this.width; x += tileWidth) {
/*  97 */         g.drawImage(src, null, x, y);
/*     */       }
/*     */     }
/* 100 */     g.dispose();
/*     */ 
/* 102 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 106 */     return "Tile";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TileImageFilter
 * JD-Core Version:    0.6.1
 */