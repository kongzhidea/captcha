/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class InvertFilter extends PointFilter
/*    */ {
/*    */   public InvertFilter()
/*    */   {
/* 27 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 31 */     int a = rgb & 0xFF000000;
/* 32 */     return a | (rgb ^ 0xFFFFFFFF) & 0xFFFFFF;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 36 */     return "Colors/Invert";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.InvertFilter
 * JD-Core Version:    0.6.1
 */