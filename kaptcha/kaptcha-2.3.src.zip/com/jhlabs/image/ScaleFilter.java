/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public class ScaleFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */ 
/*    */   public ScaleFilter()
/*    */   {
/* 34 */     this(32, 32);
/*    */   }
/*    */ 
/*    */   public ScaleFilter(int width, int height)
/*    */   {
/* 43 */     this.width = width;
/* 44 */     this.height = height;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 48 */     int w = src.getWidth();
/* 49 */     int h = src.getHeight();
/*    */ 
/* 51 */     if (dst == null) {
/* 52 */       ColorModel dstCM = src.getColorModel();
/* 53 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(w, h), dstCM.isAlphaPremultiplied(), null);
/*    */     }
/*    */ 
/* 56 */     Image scaleImage = src.getScaledInstance(w, h, 16);
/* 57 */     Graphics2D g = dst.createGraphics();
/* 58 */     g.drawImage(src, 0, 0, this.width, this.height, null);
/* 59 */     g.dispose();
/*    */ 
/* 61 */     return dst;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return "Distort/Scale";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ScaleFilter
 * JD-Core Version:    0.6.1
 */