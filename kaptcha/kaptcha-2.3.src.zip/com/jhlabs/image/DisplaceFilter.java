/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class DisplaceFilter extends TransformFilter
/*     */ {
/*  29 */   private float amount = 1.0F;
/*  30 */   private BufferedImage displacementMap = null;
/*     */   private int[] xmap;
/*     */   private int[] ymap;
/*     */   private int dw;
/*     */   private int dh;
/*     */ 
/*     */   public void setDisplacementMap(BufferedImage displacementMap)
/*     */   {
/*  43 */     this.displacementMap = displacementMap;
/*     */   }
/*     */ 
/*     */   public BufferedImage getDisplacementMap()
/*     */   {
/*  52 */     return this.displacementMap;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  63 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  72 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  76 */     int w = src.getWidth();
/*  77 */     int h = src.getHeight();
/*     */ 
/*  79 */     BufferedImage dm = this.displacementMap != null ? this.displacementMap : src;
/*     */ 
/*  81 */     this.dw = dm.getWidth();
/*  82 */     this.dh = dm.getHeight();
/*     */ 
/*  84 */     int[] mapPixels = new int[this.dw * this.dh];
/*  85 */     getRGB(dm, 0, 0, this.dw, this.dh, mapPixels);
/*  86 */     this.xmap = new int[this.dw * this.dh];
/*  87 */     this.ymap = new int[this.dw * this.dh];
/*     */ 
/*  89 */     int i = 0;
/*  90 */     for (int y = 0; y < this.dh; y++) {
/*  91 */       for (int x = 0; x < this.dw; x++) {
/*  92 */         int rgb = mapPixels[i];
/*  93 */         int r = rgb >> 16 & 0xFF;
/*  94 */         int g = rgb >> 8 & 0xFF;
/*  95 */         int b = rgb & 0xFF;
/*  96 */         mapPixels[i] = ((r + g + b) / 8);
/*  97 */         i++;
/*     */       }
/*     */     }
/*     */ 
/* 101 */     i = 0;
/* 102 */     for (int y = 0; y < this.dh; y++) {
/* 103 */       int j1 = (y + this.dh - 1) % this.dh * this.dw;
/* 104 */       int j2 = y * this.dw;
/* 105 */       int j3 = (y + 1) % this.dh * this.dw;
/* 106 */       for (int x = 0; x < this.dw; x++) {
/* 107 */         int k1 = (x + this.dw - 1) % this.dw;
/* 108 */         int k2 = x;
/* 109 */         int k3 = (x + 1) % this.dw;
/* 110 */         this.xmap[i] = (mapPixels[(k1 + j1)] + mapPixels[(k1 + j2)] + mapPixels[(k1 + j3)] - mapPixels[(k3 + j1)] - mapPixels[(k3 + j2)] - mapPixels[(k3 + j3)]);
/* 111 */         this.ymap[i] = (mapPixels[(k1 + j3)] + mapPixels[(k2 + j3)] + mapPixels[(k3 + j3)] - mapPixels[(k1 + j1)] - mapPixels[(k2 + j1)] - mapPixels[(k3 + j1)]);
/* 112 */         i++;
/*     */       }
/*     */     }
/* 115 */     mapPixels = null;
/* 116 */     dst = super.filter(src, dst);
/* 117 */     this.xmap = (this.ymap = null);
/* 118 */     return dst;
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out)
/*     */   {
/* 123 */     float nx = x;
/* 124 */     float ny = y;
/* 125 */     int i = y % this.dh * this.dw + x % this.dw;
/* 126 */     out[0] = (x + this.amount * this.xmap[i]);
/* 127 */     out[1] = (y + this.amount * this.ymap[i]);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 131 */     return "Distort/Displace...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DisplaceFilter
 * JD-Core Version:    0.6.1
 */