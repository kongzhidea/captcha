/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class LookupFilter extends PointFilter
/*    */ {
/* 27 */   private Colormap colormap = new Gradient();
/*    */ 
/*    */   public LookupFilter()
/*    */   {
/* 33 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public LookupFilter(Colormap colormap)
/*    */   {
/* 41 */     this.canFilterIndexColorModel = true;
/* 42 */     this.colormap = colormap;
/*    */   }
/*    */ 
/*    */   public void setColormap(Colormap colormap)
/*    */   {
/* 51 */     this.colormap = colormap;
/*    */   }
/*    */ 
/*    */   public Colormap getColormap()
/*    */   {
/* 60 */     return this.colormap;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb)
/*    */   {
/* 65 */     int r = rgb >> 16 & 0xFF;
/* 66 */     int g = rgb >> 8 & 0xFF;
/* 67 */     int b = rgb & 0xFF;
/* 68 */     rgb = (r + g + b) / 3;
/* 69 */     return this.colormap.getColor(rgb / 255.0F);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 73 */     return "Colors/Lookup...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LookupFilter
 * JD-Core Version:    0.6.1
 */