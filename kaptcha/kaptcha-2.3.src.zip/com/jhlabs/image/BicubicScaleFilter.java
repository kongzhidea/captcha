/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ public class BicubicScaleFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */ 
/*    */   public BicubicScaleFilter()
/*    */   {
/* 34 */     this(32, 32);
/*    */   }
/*    */ 
/*    */   public BicubicScaleFilter(int width, int height)
/*    */   {
/* 45 */     this.width = width;
/* 46 */     this.height = height;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 50 */     int w = src.getWidth();
/* 51 */     int h = src.getHeight();
/*    */ 
/* 53 */     if (dst == null) {
/* 54 */       ColorModel dstCM = src.getColorModel();
/* 55 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(this.width, this.height), dstCM.isAlphaPremultiplied(), null);
/*    */     }
/*    */ 
/* 58 */     Graphics2D g = dst.createGraphics();
/* 59 */     g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
/* 60 */     g.drawImage(src, 0, 0, this.width, this.height, null);
/* 61 */     g.dispose();
/*    */ 
/* 63 */     return dst;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 67 */     return "Distort/Bicubic Scale";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BicubicScaleFilter
 * JD-Core Version:    0.6.1
 */