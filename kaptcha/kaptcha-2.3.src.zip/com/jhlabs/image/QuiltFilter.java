/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Date;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class QuiltFilter extends WholeImageFilter
/*     */ {
/*     */   private Random randomGenerator;
/*  27 */   private long seed = 567L;
/*  28 */   private int iterations = 25000;
/*  29 */   private float a = -0.59F;
/*  30 */   private float b = 0.2F;
/*  31 */   private float c = 0.1F;
/*  32 */   private float d = 0.0F;
/*  33 */   private int k = 0;
/*  34 */   private Colormap colormap = new LinearColormap();
/*     */ 
/*     */   public QuiltFilter() {
/*  37 */     this.randomGenerator = new Random();
/*     */   }
/*     */ 
/*     */   public void randomize() {
/*  41 */     this.seed = new Date().getTime();
/*  42 */     this.randomGenerator.setSeed(this.seed);
/*  43 */     this.a = this.randomGenerator.nextFloat();
/*  44 */     this.b = this.randomGenerator.nextFloat();
/*  45 */     this.c = this.randomGenerator.nextFloat();
/*  46 */     this.d = this.randomGenerator.nextFloat();
/*  47 */     this.k = (this.randomGenerator.nextInt() % 20 - 10);
/*     */   }
/*     */ 
/*     */   public void setIterations(int iterations)
/*     */   {
/*  57 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */   public int getIterations()
/*     */   {
/*  66 */     return this.iterations;
/*     */   }
/*     */ 
/*     */   public void setA(float a) {
/*  70 */     this.a = a;
/*     */   }
/*     */ 
/*     */   public float getA() {
/*  74 */     return this.a;
/*     */   }
/*     */ 
/*     */   public void setB(float b) {
/*  78 */     this.b = b;
/*     */   }
/*     */ 
/*     */   public float getB() {
/*  82 */     return this.b;
/*     */   }
/*     */ 
/*     */   public void setC(float c) {
/*  86 */     this.c = c;
/*     */   }
/*     */ 
/*     */   public float getC() {
/*  90 */     return this.c;
/*     */   }
/*     */ 
/*     */   public void setD(float d) {
/*  94 */     this.d = d;
/*     */   }
/*     */ 
/*     */   public float getD() {
/*  98 */     return this.d;
/*     */   }
/*     */ 
/*     */   public void setK(int k) {
/* 102 */     this.k = k;
/*     */   }
/*     */ 
/*     */   public int getK() {
/* 106 */     return this.k;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 115 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 124 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 128 */     int[] outPixels = new int[width * height];
/*     */ 
/* 130 */     int i = 0;
/* 131 */     int max = 0;
/*     */ 
/* 133 */     float x = 0.1F;
/* 134 */     float y = 0.3F;
/*     */ 
/* 136 */     for (int n = 0; n < 20; n++) {
/* 137 */       float mx = 3.141593F * x;
/* 138 */       float my = 3.141593F * y;
/* 139 */       float smx2 = (float)Math.sin(2.0F * mx);
/* 140 */       float smy2 = (float)Math.sin(2.0F * my);
/* 141 */       float x1 = (float)(this.a * smx2 + this.b * smx2 * Math.cos(2.0F * my) + this.c * Math.sin(4.0F * mx) + this.d * Math.sin(6.0F * mx) * Math.cos(4.0F * my) + this.k * x);
/*     */ 
/* 143 */       x1 = x1 >= 0.0F ? x1 - (int)x1 : x1 - (int)x1 + 1.0F;
/*     */ 
/* 145 */       float y1 = (float)(this.a * smy2 + this.b * smy2 * Math.cos(2.0F * mx) + this.c * Math.sin(4.0F * my) + this.d * Math.sin(6.0F * my) * Math.cos(4.0F * mx) + this.k * y);
/*     */ 
/* 147 */       y1 = y1 >= 0.0F ? y1 - (int)y1 : y1 - (int)y1 + 1.0F;
/* 148 */       x = x1;
/* 149 */       y = y1;
/*     */     }
/*     */ 
/* 152 */     for (int n = 0; n < this.iterations; n++) {
/* 153 */       float mx = 3.141593F * x;
/* 154 */       float my = 3.141593F * y;
/* 155 */       float x1 = (float)(this.a * Math.sin(2.0F * mx) + this.b * Math.sin(2.0F * mx) * Math.cos(2.0F * my) + this.c * Math.sin(4.0F * mx) + this.d * Math.sin(6.0F * mx) * Math.cos(4.0F * my) + this.k * x);
/*     */ 
/* 157 */       x1 = x1 >= 0.0F ? x1 - (int)x1 : x1 - (int)x1 + 1.0F;
/*     */ 
/* 159 */       float y1 = (float)(this.a * Math.sin(2.0F * my) + this.b * Math.sin(2.0F * my) * Math.cos(2.0F * mx) + this.c * Math.sin(4.0F * my) + this.d * Math.sin(6.0F * my) * Math.cos(4.0F * mx) + this.k * y);
/*     */ 
/* 161 */       y1 = y1 >= 0.0F ? y1 - (int)y1 : y1 - (int)y1 + 1.0F;
/* 162 */       x = x1;
/* 163 */       y = y1;
/* 164 */       int ix = (int)(width * x);
/* 165 */       int iy = (int)(height * y);
/* 166 */       if ((ix >= 0) && (ix < width) && (iy >= 0) && (iy < height))
/*     */       {
/*     */         int tmp622_621 = (width * iy + ix);
/*     */         int[] tmp622_613 = outPixels;
/*     */         int tmp624_623 = tmp622_613[tmp622_621]; tmp622_613[tmp622_621] = (tmp624_623 + 1); int t = tmp624_623;
/* 168 */         if (t > max) {
/* 169 */           max = t;
/*     */         }
/*     */       }
/*     */     }
/* 173 */     if (this.colormap != null) {
/* 174 */       int index = 0;
/* 175 */       for (y = 0.0F; y < height; y += 1.0F) {
/* 176 */         for (x = 0.0F; x < width; x += 1.0F) {
/* 177 */           outPixels[index] = this.colormap.getColor(outPixels[index] / max);
/* 178 */           index++;
/*     */         }
/*     */       }
/*     */     }
/* 182 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 186 */     return "Texture/Chaotic Quilt...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.QuiltFilter
 * JD-Core Version:    0.6.1
 */