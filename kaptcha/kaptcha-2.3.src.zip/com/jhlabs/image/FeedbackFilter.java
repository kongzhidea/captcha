/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class FeedbackFilter extends AbstractBufferedImageOp
/*     */ {
/*  27 */   private float centreX = 0.5F; private float centreY = 0.5F;
/*     */   private float distance;
/*     */   private float angle;
/*     */   private float rotation;
/*     */   private float zoom;
/*  32 */   private float startAlpha = 1.0F;
/*  33 */   private float endAlpha = 1.0F;
/*     */   private int iterations;
/*     */ 
/*     */   public FeedbackFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FeedbackFilter(float distance, float angle, float rotation, float zoom)
/*     */   {
/*  50 */     this.distance = distance;
/*  51 */     this.angle = angle;
/*  52 */     this.rotation = rotation;
/*  53 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  63 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  72 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setDistance(float distance)
/*     */   {
/*  81 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public float getDistance()
/*     */   {
/*  90 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setRotation(float rotation)
/*     */   {
/* 100 */     this.rotation = rotation;
/*     */   }
/*     */ 
/*     */   public float getRotation()
/*     */   {
/* 110 */     return this.rotation;
/*     */   }
/*     */ 
/*     */   public void setZoom(float zoom)
/*     */   {
/* 119 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public float getZoom()
/*     */   {
/* 128 */     return this.zoom;
/*     */   }
/*     */ 
/*     */   public void setStartAlpha(float startAlpha)
/*     */   {
/* 139 */     this.startAlpha = startAlpha;
/*     */   }
/*     */ 
/*     */   public float getStartAlpha()
/*     */   {
/* 148 */     return this.startAlpha;
/*     */   }
/*     */ 
/*     */   public void setEndAlpha(float endAlpha)
/*     */   {
/* 159 */     this.endAlpha = endAlpha;
/*     */   }
/*     */ 
/*     */   public float getEndAlpha()
/*     */   {
/* 168 */     return this.endAlpha;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/* 177 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/* 186 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/* 195 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/* 204 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 213 */     this.centreX = (float)centre.getX();
/* 214 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 223 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public void setIterations(int iterations)
/*     */   {
/* 233 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */   public int getIterations()
/*     */   {
/* 242 */     return this.iterations;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 246 */     if (dst == null)
/* 247 */       dst = createCompatibleDestImage(src, null);
/* 248 */     float cx = src.getWidth() * this.centreX;
/* 249 */     float cy = src.getHeight() * this.centreY;
/* 250 */     float imageRadius = (float)Math.sqrt(cx * cx + cy * cy);
/* 251 */     float translateX = (float)(this.distance * Math.cos(this.angle));
/* 252 */     float translateY = (float)(this.distance * -Math.sin(this.angle));
/* 253 */     float scale = (float)Math.exp(this.zoom);
/* 254 */     float rotate = this.rotation;
/*     */ 
/* 256 */     if (this.iterations == 0) {
/* 257 */       Graphics2D g = dst.createGraphics();
/* 258 */       g.drawRenderedImage(src, null);
/* 259 */       g.dispose();
/* 260 */       return dst;
/*     */     }
/*     */ 
/* 263 */     Graphics2D g = dst.createGraphics();
/* 264 */     g.drawImage(src, null, null);
/* 265 */     for (int i = 0; i < this.iterations; i++) {
/* 266 */       g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 267 */       g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 268 */       g.setComposite(AlphaComposite.getInstance(3, ImageMath.lerp(i / this.iterations - 1, this.startAlpha, this.endAlpha)));
/*     */ 
/* 270 */       g.translate(cx + translateX, cy + translateY);
/* 271 */       g.scale(scale, scale);
/* 272 */       if (this.rotation != 0.0F)
/* 273 */         g.rotate(rotate);
/* 274 */       g.translate(-cx, -cy);
/*     */ 
/* 276 */       g.drawImage(src, null, null);
/*     */     }
/* 278 */     g.dispose();
/* 279 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 283 */     return "Effects/Feedback...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FeedbackFilter
 * JD-Core Version:    0.6.1
 */