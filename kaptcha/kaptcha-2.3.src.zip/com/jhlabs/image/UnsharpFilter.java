/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class UnsharpFilter extends GaussianFilter
/*     */ {
/*  27 */   private float amount = 0.5F;
/*  28 */   private int threshold = 1;
/*     */ 
/*     */   public UnsharpFilter() {
/*  31 */     this.radius = 2.0F;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int threshold)
/*     */   {
/*  40 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public int getThreshold()
/*     */   {
/*  49 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  60 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  69 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  73 */     int width = src.getWidth();
/*  74 */     int height = src.getHeight();
/*     */ 
/*  76 */     if (dst == null) {
/*  77 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  79 */     int[] inPixels = new int[width * height];
/*  80 */     int[] outPixels = new int[width * height];
/*  81 */     src.getRGB(0, 0, width, height, inPixels, 0, width);
/*     */ 
/*  83 */     if (this.radius > 0.0F) {
/*  84 */       convolveAndTranspose(this.kernel, inPixels, outPixels, width, height, this.alpha, (this.alpha) && (this.premultiplyAlpha), false, CLAMP_EDGES);
/*  85 */       convolveAndTranspose(this.kernel, outPixels, inPixels, height, width, this.alpha, false, (this.alpha) && (this.premultiplyAlpha), CLAMP_EDGES);
/*     */     }
/*     */ 
/*  88 */     src.getRGB(0, 0, width, height, outPixels, 0, width);
/*     */ 
/*  90 */     float a = 4.0F * this.amount;
/*     */ 
/*  92 */     int index = 0;
/*  93 */     for (int y = 0; y < height; y++) {
/*  94 */       for (int x = 0; x < width; x++) {
/*  95 */         int rgb1 = outPixels[index];
/*  96 */         int r1 = rgb1 >> 16 & 0xFF;
/*  97 */         int g1 = rgb1 >> 8 & 0xFF;
/*  98 */         int b1 = rgb1 & 0xFF;
/*     */ 
/* 100 */         int rgb2 = inPixels[index];
/* 101 */         int r2 = rgb2 >> 16 & 0xFF;
/* 102 */         int g2 = rgb2 >> 8 & 0xFF;
/* 103 */         int b2 = rgb2 & 0xFF;
/*     */ 
/* 105 */         if (Math.abs(r1 - r2) >= this.threshold)
/* 106 */           r1 = PixelUtils.clamp((int)((a + 1.0F) * r1 - r2 + r2));
/* 107 */         if (Math.abs(g1 - g2) >= this.threshold)
/* 108 */           g1 = PixelUtils.clamp((int)((a + 1.0F) * g1 - g2 + g2));
/* 109 */         if (Math.abs(b1 - b2) >= this.threshold) {
/* 110 */           b1 = PixelUtils.clamp((int)((a + 1.0F) * b1 - b2 + b2));
/*     */         }
/* 112 */         inPixels[index] = (rgb1 & 0xFF000000 | r1 << 16 | g1 << 8 | b1);
/* 113 */         index++;
/*     */       }
/*     */     }
/*     */ 
/* 117 */     dst.setRGB(0, 0, width, height, inPixels, 0, width);
/* 118 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 122 */     return "Blur/Unsharp Mask...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.UnsharpFilter
 * JD-Core Version:    0.6.1
 */