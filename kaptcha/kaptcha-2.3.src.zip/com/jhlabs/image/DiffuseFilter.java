/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class DiffuseFilter extends TransformFilter
/*    */ {
/*    */   private float[] sinTable;
/*    */   private float[] cosTable;
/* 29 */   private float scale = 4.0F;
/*    */ 
/*    */   public DiffuseFilter() {
/* 32 */     setEdgeAction(1);
/*    */   }
/*    */ 
/*    */   public void setScale(float scale)
/*    */   {
/* 43 */     this.scale = scale;
/*    */   }
/*    */ 
/*    */   public float getScale()
/*    */   {
/* 52 */     return this.scale;
/*    */   }
/*    */ 
/*    */   protected void transformInverse(int x, int y, float[] out) {
/* 56 */     int angle = (int)(Math.random() * 255.0D);
/* 57 */     float distance = (float)Math.random();
/* 58 */     out[0] = (x + distance * this.sinTable[angle]);
/* 59 */     out[1] = (y + distance * this.cosTable[angle]);
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 63 */     this.sinTable = new float[256];
/* 64 */     this.cosTable = new float[256];
/* 65 */     for (int i = 0; i < 256; i++) {
/* 66 */       float angle = 6.283186F * i / 256.0F;
/* 67 */       this.sinTable[i] = (float)(this.scale * Math.sin(angle));
/* 68 */       this.cosTable[i] = (float)(this.scale * Math.cos(angle));
/*    */     }
/* 70 */     return super.filter(src, dst);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 74 */     return "Distort/Diffuse...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DiffuseFilter
 * JD-Core Version:    0.6.1
 */