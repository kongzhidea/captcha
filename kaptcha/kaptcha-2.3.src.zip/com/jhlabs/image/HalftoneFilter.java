/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class HalftoneFilter extends AbstractBufferedImageOp
/*     */ {
/*  27 */   private float softness = 0.1F;
/*     */   private boolean invert;
/*     */   private boolean monochrome;
/*     */   private BufferedImage mask;
/*     */ 
/*     */   public void setSoftness(float softness)
/*     */   {
/*  43 */     this.softness = softness;
/*     */   }
/*     */ 
/*     */   public float getSoftness()
/*     */   {
/*  52 */     return this.softness;
/*     */   }
/*     */ 
/*     */   public void setMask(BufferedImage mask)
/*     */   {
/*  61 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */   public BufferedImage getMask()
/*     */   {
/*  70 */     return this.mask;
/*     */   }
/*     */ 
/*     */   public void setInvert(boolean invert) {
/*  74 */     this.invert = invert;
/*     */   }
/*     */ 
/*     */   public boolean getInvert() {
/*  78 */     return this.invert;
/*     */   }
/*     */ 
/*     */   public void setMonochrome(boolean monochrome)
/*     */   {
/*  87 */     this.monochrome = monochrome;
/*     */   }
/*     */ 
/*     */   public boolean getMonochrome()
/*     */   {
/*  96 */     return this.monochrome;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 100 */     int width = src.getWidth();
/* 101 */     int height = src.getHeight();
/*     */ 
/* 103 */     if (dst == null)
/* 104 */       dst = createCompatibleDestImage(src, null);
/* 105 */     if (this.mask == null) {
/* 106 */       return dst;
/*     */     }
/* 108 */     int maskWidth = this.mask.getWidth();
/* 109 */     int maskHeight = this.mask.getHeight();
/*     */ 
/* 111 */     float s = 255.0F * this.softness;
/*     */ 
/* 113 */     int[] inPixels = new int[width];
/* 114 */     int[] maskPixels = new int[maskWidth];
/*     */ 
/* 116 */     for (int y = 0; y < height; y++) {
/* 117 */       getRGB(src, 0, y, width, 1, inPixels);
/* 118 */       getRGB(this.mask, 0, y % maskHeight, maskWidth, 1, maskPixels);
/*     */ 
/* 120 */       for (int x = 0; x < width; x++) {
/* 121 */         int maskRGB = maskPixels[(x % maskWidth)];
/* 122 */         int inRGB = inPixels[x];
/* 123 */         if (this.invert)
/* 124 */           maskRGB ^= 16777215;
/* 125 */         if (this.monochrome) {
/* 126 */           int v = PixelUtils.brightness(maskRGB);
/* 127 */           int iv = PixelUtils.brightness(inRGB);
/* 128 */           float f = 1.0F - ImageMath.smoothStep(iv - s, iv + s, v);
/* 129 */           int a = (int)(255.0F * f);
/* 130 */           inPixels[x] = (inRGB & 0xFF000000 | a << 16 | a << 8 | a);
/*     */         } else {
/* 132 */           int ir = inRGB >> 16 & 0xFF;
/* 133 */           int ig = inRGB >> 8 & 0xFF;
/* 134 */           int ib = inRGB & 0xFF;
/* 135 */           int mr = maskRGB >> 16 & 0xFF;
/* 136 */           int mg = maskRGB >> 8 & 0xFF;
/* 137 */           int mb = maskRGB & 0xFF;
/* 138 */           int r = (int)(255.0F * (1.0F - ImageMath.smoothStep(ir - s, ir + s, mr)));
/* 139 */           int g = (int)(255.0F * (1.0F - ImageMath.smoothStep(ig - s, ig + s, mg)));
/* 140 */           int b = (int)(255.0F * (1.0F - ImageMath.smoothStep(ib - s, ib + s, mb)));
/* 141 */           inPixels[x] = (inRGB & 0xFF000000 | r << 16 | g << 8 | b);
/*     */         }
/*     */       }
/*     */ 
/* 145 */       setRGB(dst, 0, y, width, 1, inPixels);
/*     */     }
/*     */ 
/* 148 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 152 */     return "Stylize/Halftone...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.HalftoneFilter
 * JD-Core Version:    0.6.1
 */