/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import com.jhlabs.math.BinaryFunction;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class DilateFilter extends BinaryFilter
/*    */ {
/* 27 */   private int threshold = 2;
/*    */ 
/*    */   public void setThreshold(int threshold)
/*    */   {
/* 38 */     this.threshold = threshold;
/*    */   }
/*    */ 
/*    */   public int getThreshold()
/*    */   {
/* 47 */     return this.threshold;
/*    */   }
/*    */ 
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 51 */     int[] outPixels = new int[width * height];
/*    */ 
/* 53 */     for (int i = 0; i < this.iterations; i++) {
/* 54 */       int index = 0;
/*    */ 
/* 56 */       if (i > 0) {
/* 57 */         int[] t = inPixels;
/* 58 */         inPixels = outPixels;
/* 59 */         outPixels = t;
/*    */       }
/* 61 */       for (int y = 0; y < height; y++) {
/* 62 */         for (int x = 0; x < width; x++) {
/* 63 */           int pixel = inPixels[(y * width + x)];
/* 64 */           if (!this.blackFunction.isBlack(pixel)) {
/* 65 */             int neighbours = 0;
/*    */ 
/* 67 */             for (int dy = -1; dy <= 1; dy++) {
/* 68 */               int iy = y + dy;
/*    */ 
/* 70 */               if ((0 <= iy) && (iy < height)) {
/* 71 */                 int ioffset = iy * width;
/* 72 */                 for (int dx = -1; dx <= 1; dx++) {
/* 73 */                   int ix = x + dx;
/* 74 */                   if (((dy != 0) || (dx != 0)) && (0 <= ix) && (ix < width)) {
/* 75 */                     int rgb = inPixels[(ioffset + ix)];
/* 76 */                     if (this.blackFunction.isBlack(rgb)) {
/* 77 */                       neighbours++;
/*    */                     }
/*    */                   }
/*    */                 }
/*    */               }
/*    */             }
/* 83 */             if (neighbours >= this.threshold) {
/* 84 */               if (this.colormap != null)
/* 85 */                 pixel = this.colormap.getColor(i / this.iterations);
/*    */               else
/* 87 */                 pixel = this.newColor;
/*    */             }
/*    */           }
/* 90 */           outPixels[(index++)] = pixel;
/*    */         }
/*    */       }
/*    */     }
/* 94 */     return outPixels;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 98 */     return "Binary/Dilate...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DilateFilter
 * JD-Core Version:    0.6.1
 */