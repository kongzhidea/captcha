/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class ArrayColormap
/*     */   implements Colormap, Cloneable
/*     */ {
/*     */   protected int[] map;
/*     */ 
/*     */   public ArrayColormap()
/*     */   {
/*  33 */     this.map = new int[256];
/*     */   }
/*     */ 
/*     */   public ArrayColormap(int[] map)
/*     */   {
/*  41 */     this.map = map;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/*     */     try {
/*  46 */       ArrayColormap g = (ArrayColormap)super.clone();
/*  47 */       g.map = ((int[])this.map.clone());
/*  48 */       return g;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   public void setMap(int[] map)
/*     */   {
/*  61 */     this.map = map;
/*     */   }
/*     */ 
/*     */   public int[] getMap()
/*     */   {
/*  70 */     return this.map;
/*     */   }
/*     */ 
/*     */   public int getColor(float v)
/*     */   {
/*  90 */     int n = (int)(v * 255.0F);
/*  91 */     if (n < 0)
/*  92 */       n = 0;
/*  93 */     else if (n > 255)
/*  94 */       n = 255;
/*  95 */     return this.map[n];
/*     */   }
/*     */ 
/*     */   public void setColorInterpolated(int index, int firstIndex, int lastIndex, int color)
/*     */   {
/* 108 */     int firstColor = this.map[firstIndex];
/* 109 */     int lastColor = this.map[lastIndex];
/* 110 */     for (int i = firstIndex; i <= index; i++)
/* 111 */       this.map[i] = ImageMath.mixColors(i - firstIndex / index - firstIndex, firstColor, color);
/* 112 */     for (int i = index; i < lastIndex; i++)
/* 113 */       this.map[i] = ImageMath.mixColors(i - index / lastIndex - index, color, lastColor);
/*     */   }
/*     */ 
/*     */   public void setColorRange(int firstIndex, int lastIndex, int color1, int color2)
/*     */   {
/* 124 */     for (int i = firstIndex; i <= lastIndex; i++)
/* 125 */       this.map[i] = ImageMath.mixColors(i - firstIndex / lastIndex - firstIndex, color1, color2);
/*     */   }
/*     */ 
/*     */   public void setColorRange(int firstIndex, int lastIndex, int color)
/*     */   {
/* 135 */     for (int i = firstIndex; i <= lastIndex; i++)
/* 136 */       this.map[i] = color;
/*     */   }
/*     */ 
/*     */   public void setColor(int index, int color)
/*     */   {
/* 146 */     this.map[index] = color;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ArrayColormap
 * JD-Core Version:    0.6.1
 */