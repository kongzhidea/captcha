/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class LevelsFilter extends WholeImageFilter
/*     */ {
/*     */   private int[][] lut;
/*  28 */   private float lowLevel = 0.0F;
/*  29 */   private float highLevel = 1.0F;
/*  30 */   private float lowOutputLevel = 0.0F;
/*  31 */   private float highOutputLevel = 1.0F;
/*     */ 
/*     */   public void setLowLevel(float lowLevel)
/*     */   {
/*  37 */     this.lowLevel = lowLevel;
/*     */   }
/*     */ 
/*     */   public float getLowLevel() {
/*  41 */     return this.lowLevel;
/*     */   }
/*     */ 
/*     */   public void setHighLevel(float highLevel) {
/*  45 */     this.highLevel = highLevel;
/*     */   }
/*     */ 
/*     */   public float getHighLevel() {
/*  49 */     return this.highLevel;
/*     */   }
/*     */ 
/*     */   public void setLowOutputLevel(float lowOutputLevel) {
/*  53 */     this.lowOutputLevel = lowOutputLevel;
/*     */   }
/*     */ 
/*     */   public float getLowOutputLevel() {
/*  57 */     return this.lowOutputLevel;
/*     */   }
/*     */ 
/*     */   public void setHighOutputLevel(float highOutputLevel) {
/*  61 */     this.highOutputLevel = highOutputLevel;
/*     */   }
/*     */ 
/*     */   public float getHighOutputLevel() {
/*  65 */     return this.highOutputLevel;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  69 */     Histogram histogram = new Histogram(inPixels, width, height, 0, width);
/*     */ 
/*  73 */     if (histogram.getNumSamples() > 0) {
/*  74 */       float scale = 255.0F / histogram.getNumSamples();
/*  75 */       this.lut = new int[3][256];
/*     */ 
/*  77 */       float low = this.lowLevel * 255.0F;
/*  78 */       float high = this.highLevel * 255.0F;
/*  79 */       if (low == high)
/*  80 */         high += 1.0F;
/*  81 */       for (int i = 0; i < 3; i++)
/*  82 */         for (int j = 0; j < 256; j++)
/*  83 */           this.lut[i][j] = PixelUtils.clamp((int)(255.0F * (this.lowOutputLevel + (this.highOutputLevel - this.lowOutputLevel) * (j - low) / (high - low))));
/*     */     }
/*     */     else {
/*  86 */       this.lut = ((int[][])null);
/*     */     }
/*  88 */     int i = 0;
/*  89 */     for (int y = 0; y < height; y++)
/*  90 */       for (int x = 0; x < width; x++) {
/*  91 */         inPixels[i] = filterRGB(x, y, inPixels[i]);
/*  92 */         i++;
/*     */       }
/*  94 */     this.lut = ((int[][])null);
/*     */ 
/*  96 */     return inPixels;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 100 */     if (this.lut != null) {
/* 101 */       int a = rgb & 0xFF000000;
/* 102 */       int r = this.lut[0][(rgb >> 16 & 0xFF)];
/* 103 */       int g = this.lut[1][(rgb >> 8 & 0xFF)];
/* 104 */       int b = this.lut[2][(rgb & 0xFF)];
/*     */ 
/* 106 */       return a | r << 16 | g << 8 | b;
/*     */     }
/* 108 */     return rgb;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 112 */     return "Colors/Levels...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LevelsFilter
 * JD-Core Version:    0.6.1
 */