/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Function2D;
/*     */ import com.jhlabs.math.Noise;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class CellularFilter extends WholeImageFilter
/*     */   implements Function2D, Cloneable
/*     */ {
/*  29 */   protected float scale = 32.0F;
/*  30 */   protected float stretch = 1.0F;
/*  31 */   protected float angle = 0.0F;
/*  32 */   public float amount = 1.0F;
/*  33 */   public float turbulence = 1.0F;
/*  34 */   public float gain = 0.5F;
/*  35 */   public float bias = 0.5F;
/*  36 */   public float distancePower = 2.0F;
/*  37 */   public boolean useColor = false;
/*  38 */   protected Colormap colormap = new Gradient();
/*  39 */   protected float[] coefficients = { 1.0F, 0.0F, 0.0F, 0.0F };
/*     */   protected float angleCoefficient;
/*  41 */   protected Random random = new Random();
/*  42 */   protected float m00 = 1.0F;
/*  43 */   protected float m01 = 0.0F;
/*  44 */   protected float m10 = 0.0F;
/*  45 */   protected float m11 = 1.0F;
/*  46 */   protected Point[] results = null;
/*  47 */   protected float randomness = 0.0F;
/*  48 */   protected int gridType = 2;
/*     */   private float min;
/*     */   private float max;
/*     */   private static byte[] probabilities;
/*     */   private float gradientCoefficient;
/*     */   public static final int RANDOM = 0;
/*     */   public static final int SQUARE = 1;
/*     */   public static final int HEXAGONAL = 2;
/*     */   public static final int OCTAGONAL = 3;
/*     */   public static final int TRIANGULAR = 4;
/*     */ 
/*     */   public CellularFilter()
/*     */   {
/*  61 */     this.results = new Point[3];
/*  62 */     for (int j = 0; j < this.results.length; j++)
/*  63 */       this.results[j] = new Point();
/*  64 */     if (probabilities == null) {
/*  65 */       probabilities = new byte[8192];
/*  66 */       float factorial = 1.0F;
/*  67 */       float total = 0.0F;
/*  68 */       float mean = 2.5F;
/*  69 */       for (int i = 0; i < 10; i++) {
/*  70 */         if (i > 1)
/*  71 */           factorial *= i;
/*  72 */         float probability = (float)Math.pow(mean, i) * (float)Math.exp(-mean) / factorial;
/*  73 */         int start = (int)(total * 8192.0F);
/*  74 */         total += probability;
/*  75 */         int end = (int)(total * 8192.0F);
/*  76 */         for (int j = start; j < end; j++)
/*  77 */           probabilities[j] = (byte)i;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  90 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  99 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setStretch(float stretch)
/*     */   {
/* 110 */     this.stretch = stretch;
/*     */   }
/*     */ 
/*     */   public float getStretch()
/*     */   {
/* 119 */     return this.stretch;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 129 */     this.angle = angle;
/* 130 */     float cos = (float)Math.cos(angle);
/* 131 */     float sin = (float)Math.sin(angle);
/* 132 */     this.m00 = cos;
/* 133 */     this.m01 = sin;
/* 134 */     this.m10 = (-sin);
/* 135 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 144 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setCoefficient(int i, float v) {
/* 148 */     this.coefficients[i] = v;
/*     */   }
/*     */ 
/*     */   public float getCoefficient(int i) {
/* 152 */     return this.coefficients[i];
/*     */   }
/*     */ 
/*     */   public void setAngleCoefficient(float angleCoefficient) {
/* 156 */     this.angleCoefficient = angleCoefficient;
/*     */   }
/*     */ 
/*     */   public float getAngleCoefficient() {
/* 160 */     return this.angleCoefficient;
/*     */   }
/*     */ 
/*     */   public void setGradientCoefficient(float gradientCoefficient) {
/* 164 */     this.gradientCoefficient = gradientCoefficient;
/*     */   }
/*     */ 
/*     */   public float getGradientCoefficient() {
/* 168 */     return this.gradientCoefficient;
/*     */   }
/*     */ 
/*     */   public void setF1(float v) {
/* 172 */     this.coefficients[0] = v;
/*     */   }
/*     */ 
/*     */   public float getF1() {
/* 176 */     return this.coefficients[0];
/*     */   }
/*     */ 
/*     */   public void setF2(float v) {
/* 180 */     this.coefficients[1] = v;
/*     */   }
/*     */ 
/*     */   public float getF2() {
/* 184 */     return this.coefficients[1];
/*     */   }
/*     */ 
/*     */   public void setF3(float v) {
/* 188 */     this.coefficients[2] = v;
/*     */   }
/*     */ 
/*     */   public float getF3() {
/* 192 */     return this.coefficients[2];
/*     */   }
/*     */ 
/*     */   public void setF4(float v) {
/* 196 */     this.coefficients[3] = v;
/*     */   }
/*     */ 
/*     */   public float getF4() {
/* 200 */     return this.coefficients[3];
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 209 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 218 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public void setRandomness(float randomness) {
/* 222 */     this.randomness = randomness;
/*     */   }
/*     */ 
/*     */   public float getRandomness() {
/* 226 */     return this.randomness;
/*     */   }
/*     */ 
/*     */   public void setGridType(int gridType) {
/* 230 */     this.gridType = gridType;
/*     */   }
/*     */ 
/*     */   public int getGridType() {
/* 234 */     return this.gridType;
/*     */   }
/*     */ 
/*     */   public void setDistancePower(float distancePower) {
/* 238 */     this.distancePower = distancePower;
/*     */   }
/*     */ 
/*     */   public float getDistancePower() {
/* 242 */     return this.distancePower;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/* 253 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 262 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/* 273 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/* 282 */     return this.amount;
/*     */   }
/*     */ 
/*     */   private float checkCube(float x, float y, int cubeX, int cubeY, Point[] results)
/*     */   {
/* 295 */     this.random.setSeed(571 * cubeX + 23 * cubeY);
/*     */     int numPoints;
/* 296 */     switch (this.gridType) {
/*     */     case 0:
/*     */     default:
/* 299 */       numPoints = probabilities[(this.random.nextInt() & 0x1FFF)];
/* 300 */       break;
/*     */     case 1:
/* 302 */       numPoints = 1;
/* 303 */       break;
/*     */     case 2:
/* 305 */       numPoints = 1;
/* 306 */       break;
/*     */     case 3:
/* 308 */       numPoints = 2;
/* 309 */       break;
/*     */     case 4:
/* 311 */       numPoints = 2;
/*     */     }
/*     */ 
/* 314 */     for (int i = 0; i < numPoints; i++) {
/* 315 */       float px = 0.0F; float py = 0.0F;
/* 316 */       float weight = 1.0F;
/* 317 */       switch (this.gridType) {
/*     */       case 0:
/* 319 */         px = this.random.nextFloat();
/* 320 */         py = this.random.nextFloat();
/* 321 */         break;
/*     */       case 1:
/* 323 */         px = py = 0.5F;
/* 324 */         if (this.randomness != 0.0F) {
/* 325 */           px = (float)(px + this.randomness * (this.random.nextFloat() - 0.5D));
/* 326 */           py = (float)(py + this.randomness * (this.random.nextFloat() - 0.5D));
/* 327 */         }break;
/*     */       case 2:
/* 330 */         if ((cubeX & 0x1) == 0) {
/* 331 */           px = 0.75F; py = 0.0F;
/*     */         } else {
/* 333 */           px = 0.75F; py = 0.5F;
/*     */         }
/* 335 */         if (this.randomness != 0.0F) {
/* 336 */           px += this.randomness * Noise.noise2(271.0F * (cubeX + px), 271.0F * (cubeY + py));
/* 337 */           py += this.randomness * Noise.noise2(271.0F * (cubeX + px) + 89.0F, 271.0F * (cubeY + py) + 137.0F);
/* 338 */         }break;
/*     */       case 3:
/* 341 */         switch (i) { case 0:
/* 342 */           px = 0.207F; py = 0.207F; break;
/*     */         case 1:
/* 343 */           px = 0.707F; py = 0.707F; weight = 1.6F;
/*     */         }
/* 345 */         if (this.randomness != 0.0F) {
/* 346 */           px += this.randomness * Noise.noise2(271.0F * (cubeX + px), 271.0F * (cubeY + py));
/* 347 */           py += this.randomness * Noise.noise2(271.0F * (cubeX + px) + 89.0F, 271.0F * (cubeY + py) + 137.0F);
/* 348 */         }break;
/*     */       case 4:
/* 351 */         if ((cubeY & 0x1) == 0) {
/* 352 */           if (i == 0) {
/* 353 */             px = 0.25F; py = 0.35F;
/*     */           } else {
/* 355 */             px = 0.75F; py = 0.65F;
/*     */           }
/*     */         }
/* 358 */         else if (i == 0) {
/* 359 */           px = 0.75F; py = 0.35F;
/*     */         } else {
/* 361 */           px = 0.25F; py = 0.65F;
/*     */         }
/*     */ 
/* 364 */         if (this.randomness != 0.0F) {
/* 365 */           px += this.randomness * Noise.noise2(271.0F * (cubeX + px), 271.0F * (cubeY + py));
/* 366 */           py += this.randomness * Noise.noise2(271.0F * (cubeX + px) + 89.0F, 271.0F * (cubeY + py) + 137.0F);
/*     */         }
/*     */         break;
/*     */       }
/* 370 */       float dx = Math.abs(x - px);
/* 371 */       float dy = Math.abs(y - py);
/*     */ 
/* 373 */       dx *= weight;
/* 374 */       dy *= weight;
/*     */       float d;
/*     */       float d;
/* 375 */       if (this.distancePower == 1.0F) {
/* 376 */         d = dx + dy;
/*     */       }
/*     */       else
/*     */       {
/*     */         float d;
/* 377 */         if (this.distancePower == 2.0F)
/* 378 */           d = (float)Math.sqrt(dx * dx + dy * dy);
/*     */         else {
/* 380 */           d = (float)Math.pow((float)Math.pow(dx, this.distancePower) + (float)Math.pow(dy, this.distancePower), 1.0F / this.distancePower);
/*     */         }
/*     */       }
/* 383 */       if (d < results[0].distance) {
/* 384 */         Point p = results[2];
/* 385 */         results[2] = results[1];
/* 386 */         results[1] = results[0];
/* 387 */         results[0] = p;
/* 388 */         p.distance = d;
/* 389 */         p.dx = dx;
/* 390 */         p.dy = dy;
/* 391 */         p.x = (cubeX + px);
/* 392 */         p.y = (cubeY + py);
/* 393 */       } else if (d < results[1].distance) {
/* 394 */         Point p = results[2];
/* 395 */         results[2] = results[1];
/* 396 */         results[1] = p;
/* 397 */         p.distance = d;
/* 398 */         p.dx = dx;
/* 399 */         p.dy = dy;
/* 400 */         p.x = (cubeX + px);
/* 401 */         p.y = (cubeY + py);
/* 402 */       } else if (d < results[2].distance) {
/* 403 */         Point p = results[2];
/* 404 */         p.distance = d;
/* 405 */         p.dx = dx;
/* 406 */         p.dy = dy;
/* 407 */         p.x = (cubeX + px);
/* 408 */         p.y = (cubeY + py);
/*     */       }
/*     */     }
/* 411 */     return results[2].distance;
/*     */   }
/*     */ 
/*     */   public float evaluate(float x, float y) {
/* 415 */     for (int j = 0; j < this.results.length; j++) {
/* 416 */       this.results[j].distance = (1.0F / 1.0F);
/*     */     }
/* 418 */     int ix = (int)x;
/* 419 */     int iy = (int)y;
/* 420 */     float fx = x - ix;
/* 421 */     float fy = y - iy;
/*     */ 
/* 423 */     float d = checkCube(fx, fy, ix, iy, this.results);
/* 424 */     if (d > fy)
/* 425 */       d = checkCube(fx, fy + 1.0F, ix, iy - 1, this.results);
/* 426 */     if (d > 1.0F - fy)
/* 427 */       d = checkCube(fx, fy - 1.0F, ix, iy + 1, this.results);
/* 428 */     if (d > fx) {
/* 429 */       checkCube(fx + 1.0F, fy, ix - 1, iy, this.results);
/* 430 */       if (d > fy)
/* 431 */         d = checkCube(fx + 1.0F, fy + 1.0F, ix - 1, iy - 1, this.results);
/* 432 */       if (d > 1.0F - fy)
/* 433 */         d = checkCube(fx + 1.0F, fy - 1.0F, ix - 1, iy + 1, this.results);
/*     */     }
/* 435 */     if (d > 1.0F - fx) {
/* 436 */       d = checkCube(fx - 1.0F, fy, ix + 1, iy, this.results);
/* 437 */       if (d > fy)
/* 438 */         d = checkCube(fx - 1.0F, fy + 1.0F, ix + 1, iy - 1, this.results);
/* 439 */       if (d > 1.0F - fy) {
/* 440 */         d = checkCube(fx - 1.0F, fy - 1.0F, ix + 1, iy + 1, this.results);
/*     */       }
/*     */     }
/* 443 */     float t = 0.0F;
/* 444 */     for (int i = 0; i < 3; i++)
/* 445 */       t += this.coefficients[i] * this.results[i].distance;
/* 446 */     if (this.angleCoefficient != 0.0F) {
/* 447 */       float angle = (float)Math.atan2(y - this.results[0].y, x - this.results[0].x);
/* 448 */       if (angle < 0.0F)
/* 449 */         angle += 6.283186F;
/* 450 */       angle /= 12.566371F;
/* 451 */       t += this.angleCoefficient * angle;
/*     */     }
/* 453 */     if (this.gradientCoefficient != 0.0F) {
/* 454 */       float a = 1.0F / (this.results[0].dy + this.results[0].dx);
/* 455 */       t += this.gradientCoefficient * a;
/*     */     }
/* 457 */     return t;
/*     */   }
/*     */ 
/*     */   public float turbulence2(float x, float y, float freq) {
/* 461 */     float t = 0.0F;
/*     */ 
/* 463 */     for (float f = 1.0F; f <= freq; f *= 2.0F)
/* 464 */       t += evaluate(f * x, f * y) / f;
/* 465 */     return t;
/*     */   }
/*     */ 
/*     */   public int getPixel(int x, int y, int[] inPixels, int width, int height) {
/* 469 */     float nx = this.m00 * x + this.m01 * y;
/* 470 */     float ny = this.m10 * x + this.m11 * y;
/* 471 */     nx /= this.scale;
/* 472 */     ny /= this.scale * this.stretch;
/* 473 */     nx += 1000.0F;
/* 474 */     ny += 1000.0F;
/* 475 */     float f = this.turbulence == 1.0F ? evaluate(nx, ny) : turbulence2(nx, ny, this.turbulence);
/*     */ 
/* 478 */     f *= 2.0F;
/* 479 */     f *= this.amount;
/* 480 */     int a = -16777216;
/*     */ 
/* 482 */     if (this.colormap != null) {
/* 483 */       int v = this.colormap.getColor(f);
/* 484 */       if (this.useColor) {
/* 485 */         int srcx = ImageMath.clamp((int)((this.results[0].x - 1000.0F) * this.scale), 0, width - 1);
/* 486 */         int srcy = ImageMath.clamp((int)((this.results[0].y - 1000.0F) * this.scale), 0, height - 1);
/* 487 */         v = inPixels[(srcy * width + srcx)];
/* 488 */         f = (this.results[1].distance - this.results[0].distance) / (this.results[1].distance + this.results[0].distance);
/* 489 */         f = ImageMath.smoothStep(this.coefficients[1], this.coefficients[0], f);
/* 490 */         v = ImageMath.mixColors(f, -16777216, v);
/*     */       }
/* 492 */       return v;
/*     */     }
/* 494 */     int v = PixelUtils.clamp((int)(f * 255.0F));
/* 495 */     int r = v << 16;
/* 496 */     int g = v << 8;
/* 497 */     int b = v;
/* 498 */     return a | r | g | b;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace)
/*     */   {
/* 507 */     int index = 0;
/* 508 */     int[] outPixels = new int[width * height];
/*     */ 
/* 510 */     for (int y = 0; y < height; y++) {
/* 511 */       for (int x = 0; x < width; x++) {
/* 512 */         outPixels[(index++)] = getPixel(x, y, inPixels, width, height);
/*     */       }
/*     */     }
/* 515 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/* 519 */     CellularFilter f = (CellularFilter)super.clone();
/* 520 */     f.coefficients = ((float[])this.coefficients.clone());
/* 521 */     f.results = ((Point[])this.results.clone());
/* 522 */     f.random = new Random();
/*     */ 
/* 525 */     return f;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 529 */     return "Texture/Cellular...";
/*     */   }
/*     */ 
/*     */   public class Point
/*     */   {
/*     */     public int index;
/*     */     public float x;
/*     */     public float y;
/*     */     public float dx;
/*     */     public float dy;
/*     */     public float cubeX;
/*     */     public float cubeY;
/*     */     public float distance;
/*     */ 
/*     */     public Point()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CellularFilter
 * JD-Core Version:    0.6.1
 */