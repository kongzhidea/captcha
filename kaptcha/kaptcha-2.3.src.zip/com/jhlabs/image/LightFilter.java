/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Function2D;
/*     */ import com.jhlabs.math.ImageFunction2D;
/*     */ import com.jhlabs.vecmath.Color4f;
/*     */ import com.jhlabs.vecmath.Vector3f;
/*     */ import java.awt.Color;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Kernel;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class LightFilter extends WholeImageFilter
/*     */ {
/*     */   public static final int COLORS_FROM_IMAGE = 0;
/*     */   public static final int COLORS_CONSTANT = 1;
/*     */   public static final int BUMPS_FROM_IMAGE = 0;
/*     */   public static final int BUMPS_FROM_IMAGE_ALPHA = 1;
/*     */   public static final int BUMPS_FROM_MAP = 2;
/*     */   public static final int BUMPS_FROM_BEVEL = 3;
/*     */   private float bumpHeight;
/*     */   private float bumpSoftness;
/*  63 */   private float viewDistance = 10000.0F;
/*     */   private Material material;
/*     */   private Vector lights;
/*  66 */   private int colorSource = 0;
/*  67 */   private int bumpSource = 0;
/*     */   private Function2D bumpFunction;
/*     */   private Image environmentMap;
/*     */   private int[] envPixels;
/*  71 */   private int envWidth = 1; private int envHeight = 1;
/*     */   private Vector3f l;
/*     */   private Vector3f v;
/*     */   private Vector3f n;
/*     */   private Color4f shadedColor;
/*     */   private Color4f diffuse_color;
/*     */   private Color4f specular_color;
/*     */   private Vector3f tmpv;
/*     */   private Vector3f tmpv2;
/*     */   protected static final float r255 = 0.003921569F;
/*     */   public static final int AMBIENT = 0;
/*     */   public static final int DISTANT = 1;
/*     */   public static final int POINT = 2;
/*     */   public static final int SPOT = 3;
/*     */ 
/*     */   public LightFilter()
/*     */   {
/*  83 */     this.lights = new Vector();
/*  84 */     addLight(new DistantLight());
/*  85 */     this.bumpHeight = 1.0F;
/*  86 */     this.bumpSoftness = 5.0F;
/*  87 */     this.material = new Material();
/*  88 */     this.l = new Vector3f();
/*  89 */     this.v = new Vector3f();
/*  90 */     this.n = new Vector3f();
/*  91 */     this.shadedColor = new Color4f();
/*  92 */     this.diffuse_color = new Color4f();
/*  93 */     this.specular_color = new Color4f();
/*  94 */     this.tmpv = new Vector3f();
/*  95 */     this.tmpv2 = new Vector3f();
/*     */   }
/*     */ 
/*     */   public void setMaterial(Material material) {
/*  99 */     this.material = material;
/*     */   }
/*     */ 
/*     */   public Material getMaterial() {
/* 103 */     return this.material;
/*     */   }
/*     */ 
/*     */   public void setBumpFunction(Function2D bumpFunction) {
/* 107 */     this.bumpFunction = bumpFunction;
/*     */   }
/*     */ 
/*     */   public Function2D getBumpFunction() {
/* 111 */     return this.bumpFunction;
/*     */   }
/*     */ 
/*     */   public void setBumpHeight(float bumpHeight) {
/* 115 */     this.bumpHeight = bumpHeight;
/*     */   }
/*     */ 
/*     */   public float getBumpHeight() {
/* 119 */     return this.bumpHeight;
/*     */   }
/*     */ 
/*     */   public void setBumpSoftness(float bumpSoftness) {
/* 123 */     this.bumpSoftness = bumpSoftness;
/*     */   }
/*     */ 
/*     */   public float getBumpSoftness() {
/* 127 */     return this.bumpSoftness;
/*     */   }
/*     */ 
/*     */   public void setViewDistance(float viewDistance) {
/* 131 */     this.viewDistance = viewDistance;
/*     */   }
/*     */ 
/*     */   public float getViewDistance() {
/* 135 */     return this.viewDistance;
/*     */   }
/*     */ 
/*     */   public void setEnvironmentMap(BufferedImage environmentMap) {
/* 139 */     this.environmentMap = environmentMap;
/* 140 */     if (environmentMap != null) {
/* 141 */       this.envWidth = environmentMap.getWidth();
/* 142 */       this.envHeight = environmentMap.getHeight();
/* 143 */       this.envPixels = getRGB(environmentMap, 0, 0, this.envWidth, this.envHeight, null);
/*     */     } else {
/* 145 */       this.envWidth = (this.envHeight = 1);
/* 146 */       this.envPixels = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Image getEnvironmentMap() {
/* 151 */     return this.environmentMap;
/*     */   }
/*     */ 
/*     */   public void setColorSource(int colorSource) {
/* 155 */     this.colorSource = colorSource;
/*     */   }
/*     */ 
/*     */   public int getColorSource() {
/* 159 */     return this.colorSource;
/*     */   }
/*     */ 
/*     */   public void setBumpSource(int bumpSource) {
/* 163 */     this.bumpSource = bumpSource;
/*     */   }
/*     */ 
/*     */   public int getBumpSource() {
/* 167 */     return this.bumpSource;
/*     */   }
/*     */ 
/*     */   public void setDiffuseColor(int diffuseColor) {
/* 171 */     this.material.diffuseColor = diffuseColor;
/*     */   }
/*     */ 
/*     */   public int getDiffuseColor() {
/* 175 */     return this.material.diffuseColor;
/*     */   }
/*     */ 
/*     */   public void addLight(Light light) {
/* 179 */     this.lights.addElement(light);
/*     */   }
/*     */ 
/*     */   public void removeLight(Light light) {
/* 183 */     this.lights.removeElement(light);
/*     */   }
/*     */ 
/*     */   public Vector getLights() {
/* 187 */     return this.lights;
/*     */   }
/*     */ 
/*     */   protected void setFromRGB(Color4f c, int argb)
/*     */   {
/* 193 */     c.set(argb >> 16 & 0xFF * 0.003921569F, argb >> 8 & 0xFF * 0.003921569F, argb & 0xFF * 0.003921569F, argb >> 24 & 0xFF * 0.003921569F);
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 197 */     int index = 0;
/* 198 */     int[] outPixels = new int[width * height];
/* 199 */     float width45 = Math.abs(6.0F * this.bumpHeight);
/* 200 */     boolean invertBumps = this.bumpHeight < 0.0F;
/* 201 */     Vector3f position = new Vector3f(0.0F, 0.0F, 0.0F);
/* 202 */     Vector3f viewpoint = new Vector3f(width / 2.0F, height / 2.0F, this.viewDistance);
/* 203 */     Vector3f normal = new Vector3f();
/* 204 */     Color4f envColor = new Color4f();
/* 205 */     Color4f diffuseColor = new Color4f(new Color(this.material.diffuseColor));
/* 206 */     Color4f specularColor = new Color4f(new Color(this.material.specularColor));
/* 207 */     Function2D bump = this.bumpFunction;
/*     */ 
/* 210 */     if ((this.bumpSource == 0) || (this.bumpSource == 1) || (this.bumpSource == 2) || (bump == null)) {
/* 211 */       if (this.bumpSoftness != 0.0F) {
/* 212 */         int bumpWidth = width;
/* 213 */         int bumpHeight = height;
/* 214 */         int[] bumpPixels = inPixels;
/* 215 */         if ((this.bumpSource == 2) && ((this.bumpFunction instanceof ImageFunction2D))) {
/* 216 */           ImageFunction2D if2d = (ImageFunction2D)this.bumpFunction;
/* 217 */           bumpWidth = if2d.getWidth();
/* 218 */           bumpHeight = if2d.getHeight();
/* 219 */           bumpPixels = if2d.getPixels();
/*     */         }
/* 221 */         int[] tmpPixels = new int[bumpWidth * bumpHeight];
/* 222 */         int[] softPixels = new int[bumpWidth * bumpHeight];
/*     */ 
/* 229 */         Kernel kernel = GaussianFilter.makeKernel(this.bumpSoftness);
/* 230 */         GaussianFilter.convolveAndTranspose(kernel, bumpPixels, tmpPixels, bumpWidth, bumpHeight, true, false, false, GaussianFilter.WRAP_EDGES);
/* 231 */         GaussianFilter.convolveAndTranspose(kernel, tmpPixels, softPixels, bumpHeight, bumpWidth, true, false, false, GaussianFilter.WRAP_EDGES);
/* 232 */         bump = new ImageFunction2D(softPixels, bumpWidth, bumpHeight, 1, this.bumpSource == 1);
/* 233 */       } else if (this.bumpSource != 2) {
/* 234 */         bump = new ImageFunction2D(inPixels, width, height, 1, this.bumpSource == 1);
/*     */       }
/*     */     }
/* 237 */     float reflectivity = this.material.reflectivity;
/* 238 */     float areflectivity = 1.0F - reflectivity;
/* 239 */     Vector3f v1 = new Vector3f();
/* 240 */     Vector3f v2 = new Vector3f();
/* 241 */     Vector3f n = new Vector3f();
/* 242 */     Light[] lightsArray = new Light[this.lights.size()];
/* 243 */     this.lights.copyInto(lightsArray);
/* 244 */     for (int i = 0; i < lightsArray.length; i++) {
/* 245 */       lightsArray[i].prepare(width, height);
/*     */     }
/* 247 */     float[][] heightWindow = new float[3][width];
/* 248 */     for (int x = 0; x < width; x++) {
/* 249 */       heightWindow[1][x] = (width45 * bump.evaluate(x, 0.0F));
/*     */     }
/*     */ 
/* 252 */     for (int y = 0; y < height; y++) {
/* 253 */       boolean y0 = y > 0;
/* 254 */       boolean y1 = y < height - 1;
/* 255 */       position.y = y;
/* 256 */       for (int x = 0; x < width; x++)
/* 257 */         heightWindow[2][x] = (width45 * bump.evaluate(x, y + 1));
/* 258 */       for (int x = 0; x < width; x++) {
/* 259 */         boolean x0 = x > 0;
/* 260 */         boolean x1 = x < width - 1;
/*     */ 
/* 263 */         if (this.bumpSource != 3)
/*     */         {
/* 266 */           int count = 0;
/* 267 */           normal.x = (normal.y = normal.z = 0.0F);
/* 268 */           float m0 = heightWindow[1][x];
/* 269 */           float m1 = x0 ? heightWindow[1][(x - 1)] - m0 : 0.0F;
/* 270 */           float m2 = y0 ? heightWindow[0][x] - m0 : 0.0F;
/* 271 */           float m3 = x1 ? heightWindow[1][(x + 1)] - m0 : 0.0F;
/* 272 */           float m4 = y1 ? heightWindow[2][x] - m0 : 0.0F;
/*     */ 
/* 274 */           if ((x0) && (y1)) {
/* 275 */             v1.x = -1.0F; v1.y = 0.0F; v1.z = m1;
/* 276 */             v2.x = 0.0F; v2.y = 1.0F; v2.z = m4;
/* 277 */             n.cross(v1, v2);
/* 278 */             n.normalize();
/* 279 */             if (n.z < 0.0D)
/* 280 */               n.z = (-n.z);
/* 281 */             normal.add(n);
/* 282 */             count++;
/*     */           }
/*     */ 
/* 285 */           if ((x0) && (y0)) {
/* 286 */             v1.x = -1.0F; v1.y = 0.0F; v1.z = m1;
/* 287 */             v2.x = 0.0F; v2.y = -1.0F; v2.z = m2;
/* 288 */             n.cross(v1, v2);
/* 289 */             n.normalize();
/* 290 */             if (n.z < 0.0D)
/* 291 */               n.z = (-n.z);
/* 292 */             normal.add(n);
/* 293 */             count++;
/*     */           }
/*     */ 
/* 296 */           if ((y0) && (x1)) {
/* 297 */             v1.x = 0.0F; v1.y = -1.0F; v1.z = m2;
/* 298 */             v2.x = 1.0F; v2.y = 0.0F; v2.z = m3;
/* 299 */             n.cross(v1, v2);
/* 300 */             n.normalize();
/* 301 */             if (n.z < 0.0D)
/* 302 */               n.z = (-n.z);
/* 303 */             normal.add(n);
/* 304 */             count++;
/*     */           }
/*     */ 
/* 307 */           if ((x1) && (y1)) {
/* 308 */             v1.x = 1.0F; v1.y = 0.0F; v1.z = m3;
/* 309 */             v2.x = 0.0F; v2.y = 1.0F; v2.z = m4;
/* 310 */             n.cross(v1, v2);
/* 311 */             n.normalize();
/* 312 */             if (n.z < 0.0D)
/* 313 */               n.z = (-n.z);
/* 314 */             normal.add(n);
/* 315 */             count++;
/*     */           }
/*     */ 
/* 319 */           normal.x /= count;
/* 320 */           normal.y /= count;
/* 321 */           normal.z /= count;
/*     */         }
/* 323 */         if (invertBumps) {
/* 324 */           normal.x = (-normal.x);
/* 325 */           normal.y = (-normal.y);
/*     */         }
/* 327 */         position.x = x;
/*     */ 
/* 329 */         if (normal.z >= 0.0F)
/*     */         {
/* 331 */           if (this.colorSource == 0)
/* 332 */             setFromRGB(diffuseColor, inPixels[index]);
/*     */           else
/* 334 */             setFromRGB(diffuseColor, this.material.diffuseColor);
/* 335 */           if ((reflectivity != 0.0F) && (this.environmentMap != null))
/*     */           {
/* 337 */             this.tmpv2.set(viewpoint);
/* 338 */             this.tmpv2.sub(position);
/* 339 */             this.tmpv2.normalize();
/* 340 */             this.tmpv.set(normal);
/* 341 */             this.tmpv.normalize();
/*     */ 
/* 344 */             this.tmpv.scale(2.0F * this.tmpv.dot(this.tmpv2));
/* 345 */             this.tmpv.sub(this.v);
/*     */ 
/* 347 */             this.tmpv.normalize();
/* 348 */             setFromRGB(envColor, getEnvironmentMap(this.tmpv, inPixels, width, height));
/* 349 */             diffuseColor.x = (reflectivity * envColor.x + areflectivity * diffuseColor.x);
/* 350 */             diffuseColor.y = (reflectivity * envColor.y + areflectivity * diffuseColor.y);
/* 351 */             diffuseColor.z = (reflectivity * envColor.z + areflectivity * diffuseColor.z);
/*     */           }
/*     */ 
/* 354 */           Color4f c = phongShade(position, viewpoint, normal, diffuseColor, specularColor, this.material, lightsArray);
/* 355 */           int alpha = inPixels[index] & 0xFF000000;
/* 356 */           int rgb = (int)(c.x * 255.0F) << 16 | (int)(c.y * 255.0F) << 8 | (int)(c.z * 255.0F);
/* 357 */           outPixels[(index++)] = (alpha | rgb);
/*     */         } else {
/* 359 */           outPixels[(index++)] = 0;
/*     */         }
/*     */       }
/* 361 */       float[] t = heightWindow[0];
/* 362 */       heightWindow[0] = heightWindow[1];
/* 363 */       heightWindow[1] = heightWindow[2];
/* 364 */       heightWindow[2] = t;
/*     */     }
/* 366 */     return outPixels;
/*     */   }
/*     */ 
/*     */   protected Color4f phongShade(Vector3f position, Vector3f viewpoint, Vector3f normal, Color4f diffuseColor, Color4f specularColor, Material material, Light[] lightsArray) {
/* 370 */     this.shadedColor.set(diffuseColor);
/* 371 */     this.shadedColor.scale(material.ambientIntensity);
/*     */ 
/* 373 */     for (int i = 0; i < lightsArray.length; i++) {
/* 374 */       Light light = lightsArray[i];
/* 375 */       this.n.set(normal);
/* 376 */       this.l.set(light.position);
/* 377 */       if (light.type != 1)
/* 378 */         this.l.sub(position);
/* 379 */       this.l.normalize();
/* 380 */       float nDotL = this.n.dot(this.l);
/* 381 */       if (nDotL >= 0.0D) {
/* 382 */         float dDotL = 0.0F;
/*     */ 
/* 384 */         this.v.set(viewpoint);
/* 385 */         this.v.sub(position);
/* 386 */         this.v.normalize();
/*     */ 
/* 389 */         if (light.type == 3) {
/* 390 */           dDotL = light.direction.dot(this.l);
/* 391 */           if (dDotL < light.cosConeAngle);
/*     */         }
/*     */         else {
/* 395 */           this.n.scale(2.0F * nDotL);
/* 396 */           this.n.sub(this.l);
/* 397 */           float rDotV = this.n.dot(this.v);
/*     */           float rv;
/*     */           float rv;
/* 400 */           if (rDotV < 0.0D) {
/* 401 */             rv = 0.0F;
/*     */           }
/*     */           else {
/* 404 */             rv = rDotV / (material.highlight - material.highlight * rDotV + rDotV);
/*     */           }
/*     */ 
/* 407 */           if (light.type == 3) {
/* 408 */             dDotL = light.cosConeAngle / dDotL;
/* 409 */             float e = dDotL;
/* 410 */             e *= e;
/* 411 */             e *= e;
/* 412 */             e *= e;
/* 413 */             e = (float)Math.pow(dDotL, light.focus * 10.0F) * (1.0F - e);
/* 414 */             rv *= e;
/* 415 */             nDotL *= e;
/*     */           }
/*     */ 
/* 418 */           this.diffuse_color.set(diffuseColor);
/* 419 */           this.diffuse_color.scale(material.diffuseReflectivity);
/* 420 */           this.diffuse_color.x *= light.realColor.x * nDotL;
/* 421 */           this.diffuse_color.y *= light.realColor.y * nDotL;
/* 422 */           this.diffuse_color.z *= light.realColor.z * nDotL;
/* 423 */           this.specular_color.set(specularColor);
/* 424 */           this.specular_color.scale(material.specularReflectivity);
/* 425 */           this.specular_color.x *= light.realColor.x * rv;
/* 426 */           this.specular_color.y *= light.realColor.y * rv;
/* 427 */           this.specular_color.z *= light.realColor.z * rv;
/* 428 */           this.diffuse_color.add(this.specular_color);
/* 429 */           this.diffuse_color.clamp(0.0F, 1.0F);
/* 430 */           this.shadedColor.add(this.diffuse_color);
/*     */         }
/*     */       }
/*     */     }
/* 433 */     this.shadedColor.clamp(0.0F, 1.0F);
/* 434 */     return this.shadedColor;
/*     */   }
/*     */ 
/*     */   private int getEnvironmentMap(Vector3f normal, int[] inPixels, int width, int height) {
/* 438 */     if (this.environmentMap != null) {
/* 439 */       float angle = (float)Math.acos(-normal.y);
/*     */ 
/* 442 */       float y = angle / 3.141593F;
/*     */       float x;
/* 444 */       if ((y == 0.0F) || (y == 1.0F)) {
/* 445 */         x = 0.0F;
/*     */       } else {
/* 447 */         float f = normal.x / (float)Math.sin(angle);
/*     */ 
/* 449 */         if (f > 1.0F)
/* 450 */           f = 1.0F;
/* 451 */         else if (f < -1.0F) {
/* 452 */           f = -1.0F;
/*     */         }
/* 454 */         x = (float)Math.acos(f) / 3.141593F;
/*     */       }
/*     */ 
/* 457 */       float x = ImageMath.clamp(x * this.envWidth, 0.0F, this.envWidth - 1);
/* 458 */       y = ImageMath.clamp(y * this.envHeight, 0.0F, this.envHeight - 1);
/* 459 */       int ix = (int)x;
/* 460 */       int iy = (int)y;
/*     */ 
/* 462 */       float xWeight = x - ix;
/* 463 */       float yWeight = y - iy;
/* 464 */       int i = this.envWidth * iy + ix;
/* 465 */       int dx = ix == this.envWidth - 1 ? 0 : 1;
/* 466 */       int dy = iy == this.envHeight - 1 ? 0 : this.envWidth;
/* 467 */       return ImageMath.bilinearInterpolate(xWeight, yWeight, this.envPixels[i], this.envPixels[(i + dx)], this.envPixels[(i + dy)], this.envPixels[(i + dx + dy)]);
/*     */     }
/* 469 */     return 0;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 473 */     return "Stylize/Light Effects...";
/*     */   }
/*     */ 
/*     */   public class SpotLight extends LightFilter.Light
/*     */   {
/*     */     public SpotLight()
/*     */     {
/* 702 */       this.type = 3;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 706 */       return "Spotlight";
/*     */     }
/*     */   }
/*     */ 
/*     */   public class DistantLight extends LightFilter.Light
/*     */   {
/*     */     public DistantLight()
/*     */     {
/* 692 */       this.type = 1;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 696 */       return "Distant Light";
/*     */     }
/*     */   }
/*     */ 
/*     */   public class PointLight extends LightFilter.Light
/*     */   {
/*     */     public PointLight()
/*     */     {
/* 682 */       this.type = 2;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 686 */       return "Point Light";
/*     */     }
/*     */   }
/*     */ 
/*     */   public class AmbientLight extends LightFilter.Light
/*     */   {
/*     */     public AmbientLight()
/*     */     {
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 676 */       return "Ambient Light";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Light
/*     */     implements Cloneable
/*     */   {
/* 518 */     int type = 0;
/*     */     Vector3f position;
/*     */     Vector3f direction;
/* 521 */     Color4f realColor = new Color4f();
/* 522 */     int color = -1;
/*     */     float intensity;
/*     */     float azimuth;
/*     */     float elevation;
/* 526 */     float focus = 0.5F;
/* 527 */     float centreX = 0.5F; float centreY = 0.5F;
/* 528 */     float coneAngle = 0.5235988F;
/*     */     float cosConeAngle;
/* 530 */     float distance = 100.0F;
/*     */ 
/*     */     public Light() {
/* 533 */       this(4.712389F, 0.5235988F, 1.0F);
/*     */     }
/*     */ 
/*     */     public Light(float azimuth, float elevation, float intensity) {
/* 537 */       this.azimuth = azimuth;
/* 538 */       this.elevation = elevation;
/* 539 */       this.intensity = intensity;
/*     */     }
/*     */ 
/*     */     public void setAzimuth(float azimuth) {
/* 543 */       this.azimuth = azimuth;
/*     */     }
/*     */ 
/*     */     public float getAzimuth() {
/* 547 */       return this.azimuth;
/*     */     }
/*     */ 
/*     */     public void setElevation(float elevation) {
/* 551 */       this.elevation = elevation;
/*     */     }
/*     */ 
/*     */     public float getElevation() {
/* 555 */       return this.elevation;
/*     */     }
/*     */ 
/*     */     public void setDistance(float distance) {
/* 559 */       this.distance = distance;
/*     */     }
/*     */ 
/*     */     public float getDistance() {
/* 563 */       return this.distance;
/*     */     }
/*     */ 
/*     */     public void setIntensity(float intensity) {
/* 567 */       this.intensity = intensity;
/*     */     }
/*     */ 
/*     */     public float getIntensity() {
/* 571 */       return this.intensity;
/*     */     }
/*     */ 
/*     */     public void setConeAngle(float coneAngle) {
/* 575 */       this.coneAngle = coneAngle;
/*     */     }
/*     */ 
/*     */     public float getConeAngle() {
/* 579 */       return this.coneAngle;
/*     */     }
/*     */ 
/*     */     public void setFocus(float focus) {
/* 583 */       this.focus = focus;
/*     */     }
/*     */ 
/*     */     public float getFocus() {
/* 587 */       return this.focus;
/*     */     }
/*     */ 
/*     */     public void setColor(int color) {
/* 591 */       this.color = color;
/*     */     }
/*     */ 
/*     */     public int getColor() {
/* 595 */       return this.color;
/*     */     }
/*     */ 
/*     */     public void setCentreX(float x)
/*     */     {
/* 604 */       this.centreX = x;
/*     */     }
/*     */ 
/*     */     public float getCentreX()
/*     */     {
/* 613 */       return this.centreX;
/*     */     }
/*     */ 
/*     */     public void setCentreY(float y)
/*     */     {
/* 622 */       this.centreY = y;
/*     */     }
/*     */ 
/*     */     public float getCentreY()
/*     */     {
/* 631 */       return this.centreY;
/*     */     }
/*     */ 
/*     */     public void prepare(int width, int height)
/*     */     {
/* 640 */       float lx = (float)(Math.cos(this.azimuth) * Math.cos(this.elevation));
/* 641 */       float ly = (float)(Math.sin(this.azimuth) * Math.cos(this.elevation));
/* 642 */       float lz = (float)Math.sin(this.elevation);
/* 643 */       this.direction = new Vector3f(lx, ly, lz);
/* 644 */       this.direction.normalize();
/* 645 */       if (this.type != 1) {
/* 646 */         lx *= this.distance;
/* 647 */         ly *= this.distance;
/* 648 */         lz *= this.distance;
/* 649 */         lx += width * this.centreX;
/* 650 */         ly += height * this.centreY;
/*     */       }
/* 652 */       this.position = new Vector3f(lx, ly, lz);
/* 653 */       this.realColor.set(new Color(this.color));
/* 654 */       this.realColor.scale(this.intensity);
/* 655 */       this.cosConeAngle = (float)Math.cos(this.coneAngle);
/*     */     }
/*     */ 
/*     */     public Object clone() {
/*     */       try {
/* 660 */         return (Light)super.clone();
/*     */       }
/*     */       catch (CloneNotSupportedException e) {
/*     */       }
/* 664 */       return null;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 669 */       return "Light";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Material
/*     */   {
/*     */     int diffuseColor;
/*     */     int specularColor;
/*     */     float ambientIntensity;
/*     */     float diffuseReflectivity;
/*     */     float specularReflectivity;
/*     */     float highlight;
/*     */     float reflectivity;
/*     */ 
/*     */     public Material()
/*     */     {
/* 489 */       this.ambientIntensity = 0.5F;
/* 490 */       this.diffuseReflectivity = 1.0F;
/* 491 */       this.specularReflectivity = 1.0F;
/* 492 */       this.highlight = 3.0F;
/* 493 */       this.reflectivity = 0.0F;
/* 494 */       this.diffuseColor = -7829368;
/* 495 */       this.specularColor = -1;
/*     */     }
/*     */ 
/*     */     public void setDiffuseColor(int diffuseColor) {
/* 499 */       this.diffuseColor = diffuseColor;
/*     */     }
/*     */ 
/*     */     public int getDiffuseColor() {
/* 503 */       return this.diffuseColor;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LightFilter
 * JD-Core Version:    0.6.1
 */