/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ public abstract class PointFilter extends AbstractBufferedImageOp
/*    */ {
/* 26 */   protected boolean canFilterIndexColorModel = false;
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 29 */     int width = src.getWidth();
/* 30 */     int height = src.getHeight();
/* 31 */     int type = src.getType();
/* 32 */     WritableRaster srcRaster = src.getRaster();
/*    */ 
/* 34 */     if (dst == null)
/* 35 */       dst = createCompatibleDestImage(src, null);
/* 36 */     WritableRaster dstRaster = dst.getRaster();
/*    */ 
/* 38 */     setDimensions(width, height);
/*    */ 
/* 40 */     int[] inPixels = new int[width];
/* 41 */     for (int y = 0; y < height; y++)
/*    */     {
/* 43 */       if (type == 2) {
/* 44 */         srcRaster.getDataElements(0, y, width, 1, inPixels);
/* 45 */         for (int x = 0; x < width; x++)
/* 46 */           inPixels[x] = filterRGB(x, y, inPixels[x]);
/* 47 */         dstRaster.setDataElements(0, y, width, 1, inPixels);
/*    */       } else {
/* 49 */         src.getRGB(0, y, width, 1, inPixels, 0, width);
/* 50 */         for (int x = 0; x < width; x++)
/* 51 */           inPixels[x] = filterRGB(x, y, inPixels[x]);
/* 52 */         dst.setRGB(0, y, width, 1, inPixels, 0, width);
/*    */       }
/*    */     }
/*    */ 
/* 56 */     return dst;
/*    */   }
/*    */ 
/*    */   public void setDimensions(int width, int height)
/*    */   {
/*    */   }
/*    */ 
/*    */   public abstract int filterRGB(int paramInt1, int paramInt2, int paramInt3);
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PointFilter
 * JD-Core Version:    0.6.1
 */