/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class CrystallizeFilter extends CellularFilter
/*    */ {
/* 28 */   private float edgeThickness = 0.4F;
/* 29 */   private boolean fadeEdges = false;
/* 30 */   private int edgeColor = -16777216;
/*    */ 
/*    */   public CrystallizeFilter() {
/* 33 */     setScale(16.0F);
/* 34 */     setRandomness(0.0F);
/*    */   }
/*    */ 
/*    */   public void setEdgeThickness(float edgeThickness) {
/* 38 */     this.edgeThickness = edgeThickness;
/*    */   }
/*    */ 
/*    */   public float getEdgeThickness() {
/* 42 */     return this.edgeThickness;
/*    */   }
/*    */ 
/*    */   public void setFadeEdges(boolean fadeEdges) {
/* 46 */     this.fadeEdges = fadeEdges;
/*    */   }
/*    */ 
/*    */   public boolean getFadeEdges() {
/* 50 */     return this.fadeEdges;
/*    */   }
/*    */ 
/*    */   public void setEdgeColor(int edgeColor) {
/* 54 */     this.edgeColor = edgeColor;
/*    */   }
/*    */ 
/*    */   public int getEdgeColor() {
/* 58 */     return this.edgeColor;
/*    */   }
/*    */ 
/*    */   public int getPixel(int x, int y, int[] inPixels, int width, int height) {
/* 62 */     float nx = this.m00 * x + this.m01 * y;
/* 63 */     float ny = this.m10 * x + this.m11 * y;
/* 64 */     nx /= this.scale;
/* 65 */     ny /= this.scale * this.stretch;
/* 66 */     nx += 1000.0F;
/* 67 */     ny += 1000.0F;
/* 68 */     float f = evaluate(nx, ny);
/*    */ 
/* 70 */     float f1 = this.results[0].distance;
/* 71 */     float f2 = this.results[1].distance;
/* 72 */     int srcx = ImageMath.clamp((int)((this.results[0].x - 1000.0F) * this.scale), 0, width - 1);
/* 73 */     int srcy = ImageMath.clamp((int)((this.results[0].y - 1000.0F) * this.scale), 0, height - 1);
/* 74 */     int v = inPixels[(srcy * width + srcx)];
/* 75 */     f = (f2 - f1) / this.edgeThickness;
/* 76 */     f = ImageMath.smoothStep(0.0F, this.edgeThickness, f);
/* 77 */     if (this.fadeEdges) {
/* 78 */       srcx = ImageMath.clamp((int)((this.results[1].x - 1000.0F) * this.scale), 0, width - 1);
/* 79 */       srcy = ImageMath.clamp((int)((this.results[1].y - 1000.0F) * this.scale), 0, height - 1);
/* 80 */       int v2 = inPixels[(srcy * width + srcx)];
/* 81 */       v2 = ImageMath.mixColors(0.5F, v2, v);
/* 82 */       v = ImageMath.mixColors(f, v2, v);
/*    */     } else {
/* 84 */       v = ImageMath.mixColors(f, this.edgeColor, v);
/* 85 */     }return v;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 89 */     return "Stylize/Crystallize...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CrystallizeFilter
 * JD-Core Version:    0.6.1
 */