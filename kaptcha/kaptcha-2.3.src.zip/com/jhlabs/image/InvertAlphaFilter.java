/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class InvertAlphaFilter extends PointFilter
/*    */ {
/*    */   public InvertAlphaFilter()
/*    */   {
/* 28 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 32 */     return rgb ^ 0xFF000000;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 36 */     return "Alpha/Invert";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.InvertAlphaFilter
 * JD-Core Version:    0.6.1
 */