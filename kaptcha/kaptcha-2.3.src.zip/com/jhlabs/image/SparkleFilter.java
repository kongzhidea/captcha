/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ public class SparkleFilter extends PointFilter
/*     */ {
/*  24 */   private int rays = 50;
/*  25 */   private int radius = 25;
/*  26 */   private int amount = 50;
/*  27 */   private int color = -1;
/*  28 */   private int randomness = 25;
/*     */   private int width;
/*     */   private int height;
/*     */   private int centreX;
/*     */   private int centreY;
/*  31 */   private long seed = 371L;
/*     */   private float[] rayLengths;
/*  33 */   private Random randomNumbers = new Random();
/*     */ 
/*     */   public void setColor(int color)
/*     */   {
/*  39 */     this.color = color;
/*     */   }
/*     */ 
/*     */   public int getColor() {
/*  43 */     return this.color;
/*     */   }
/*     */ 
/*     */   public void setRandomness(int randomness) {
/*  47 */     this.randomness = randomness;
/*     */   }
/*     */ 
/*     */   public int getRandomness() {
/*  51 */     return this.randomness;
/*     */   }
/*     */ 
/*     */   public void setAmount(int amount)
/*     */   {
/*  62 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public int getAmount()
/*     */   {
/*  71 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setRays(int rays) {
/*  75 */     this.rays = rays;
/*     */   }
/*     */ 
/*     */   public int getRays() {
/*  79 */     return this.rays;
/*     */   }
/*     */ 
/*     */   public void setRadius(int radius)
/*     */   {
/*  89 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public int getRadius()
/*     */   {
/*  98 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setDimensions(int width, int height) {
/* 102 */     this.width = width;
/* 103 */     this.height = height;
/* 104 */     this.centreX = (width / 2);
/* 105 */     this.centreY = (height / 2);
/* 106 */     super.setDimensions(width, height);
/* 107 */     this.randomNumbers.setSeed(this.seed);
/* 108 */     this.rayLengths = new float[this.rays];
/* 109 */     for (int i = 0; i < this.rays; i++)
/* 110 */       this.rayLengths[i] = (this.radius + this.randomness / 100.0F * this.radius * (float)this.randomNumbers.nextGaussian());
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 114 */     float dx = x - this.centreX;
/* 115 */     float dy = y - this.centreY;
/* 116 */     float distance = dx * dx + dy * dy;
/* 117 */     float angle = (float)Math.atan2(dy, dx);
/* 118 */     float d = (angle + 3.141593F) / 6.283186F * this.rays;
/* 119 */     int i = (int)d;
/* 120 */     float f = d - i;
/*     */ 
/* 122 */     if (this.radius != 0) {
/* 123 */       float length = ImageMath.lerp(f, this.rayLengths[(i % this.rays)], this.rayLengths[((i + 1) % this.rays)]);
/* 124 */       float g = length * length / (distance + 1.0E-004F);
/* 125 */       g = (float)Math.pow(g, 100 - this.amount / 50.0D);
/* 126 */       f -= 0.5F;
/*     */ 
/* 128 */       f = 1.0F - f * f;
/* 129 */       f *= g;
/*     */     }
/* 131 */     f = ImageMath.clamp(f, 0.0F, 1.0F);
/* 132 */     return ImageMath.mixColors(f, rgb, this.color);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 136 */     return "Stylize/Sparkle...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SparkleFilter
 * JD-Core Version:    0.6.1
 */