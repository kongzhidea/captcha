/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ 
/*     */ public class SwimFilter extends TransformFilter
/*     */ {
/*  28 */   private float scale = 32.0F;
/*  29 */   private float stretch = 1.0F;
/*  30 */   private float angle = 0.0F;
/*  31 */   private float amount = 1.0F;
/*  32 */   private float turbulence = 1.0F;
/*  33 */   private float time = 0.0F;
/*  34 */   private float m00 = 1.0F;
/*  35 */   private float m01 = 0.0F;
/*  36 */   private float m10 = 0.0F;
/*  37 */   private float m11 = 1.0F;
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  50 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  59 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  70 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  79 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setStretch(float stretch)
/*     */   {
/*  90 */     this.stretch = stretch;
/*     */   }
/*     */ 
/*     */   public float getStretch()
/*     */   {
/*  99 */     return this.stretch;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 109 */     this.angle = angle;
/* 110 */     float cos = (float)Math.cos(angle);
/* 111 */     float sin = (float)Math.sin(angle);
/* 112 */     this.m00 = cos;
/* 113 */     this.m01 = sin;
/* 114 */     this.m10 = (-sin);
/* 115 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 124 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/* 135 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 144 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   public void setTime(float time)
/*     */   {
/* 154 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public float getTime()
/*     */   {
/* 163 */     return this.time;
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 167 */     float nx = this.m00 * x + this.m01 * y;
/* 168 */     float ny = this.m10 * x + this.m11 * y;
/* 169 */     nx /= this.scale;
/* 170 */     ny /= this.scale * this.stretch;
/*     */ 
/* 172 */     if (this.turbulence == 1.0F) {
/* 173 */       out[0] = (x + this.amount * Noise.noise3(nx + 0.5F, ny, this.time));
/* 174 */       out[1] = (y + this.amount * Noise.noise3(nx, ny + 0.5F, this.time));
/*     */     } else {
/* 176 */       out[0] = (x + this.amount * Noise.turbulence3(nx + 0.5F, ny, this.turbulence, this.time));
/* 177 */       out[1] = (y + this.amount * Noise.turbulence3(nx, ny + 0.5F, this.turbulence, this.time));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 182 */     return "Distort/Swim...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SwimFilter
 * JD-Core Version:    0.6.1
 */