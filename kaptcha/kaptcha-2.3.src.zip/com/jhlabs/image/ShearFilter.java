/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class ShearFilter extends TransformFilter
/*     */ {
/*  24 */   private float xangle = 0.0F;
/*  25 */   private float yangle = 0.0F;
/*  26 */   private float shx = 0.0F;
/*  27 */   private float shy = 0.0F;
/*  28 */   private float xoffset = 0.0F;
/*  29 */   private float yoffset = 0.0F;
/*  30 */   private boolean resize = true;
/*     */ 
/*     */   public void setResize(boolean resize)
/*     */   {
/*  36 */     this.resize = resize;
/*     */   }
/*     */ 
/*     */   public boolean isResize() {
/*  40 */     return this.resize;
/*     */   }
/*     */ 
/*     */   public void setXAngle(float xangle) {
/*  44 */     this.xangle = xangle;
/*  45 */     initialize();
/*     */   }
/*     */ 
/*     */   public float getXAngle() {
/*  49 */     return this.xangle;
/*     */   }
/*     */ 
/*     */   public void setYAngle(float yangle) {
/*  53 */     this.yangle = yangle;
/*  54 */     initialize();
/*     */   }
/*     */ 
/*     */   public float getYAngle() {
/*  58 */     return this.yangle;
/*     */   }
/*     */ 
/*     */   private void initialize() {
/*  62 */     this.shx = (float)Math.sin(this.xangle);
/*  63 */     this.shy = (float)Math.sin(this.yangle);
/*     */   }
/*     */ 
/*     */   protected void transformSpace(Rectangle r) {
/*  67 */     float tangent = (float)Math.tan(this.xangle);
/*  68 */     this.xoffset = (-r.height * tangent);
/*  69 */     if (tangent < 0.0D)
/*  70 */       tangent = -tangent;
/*  71 */     r.width = (int)(r.height * tangent + r.width + 0.999999F);
/*  72 */     tangent = (float)Math.tan(this.yangle);
/*  73 */     this.yoffset = (-r.width * tangent);
/*  74 */     if (tangent < 0.0D)
/*  75 */       tangent = -tangent;
/*  76 */     r.height = (int)(r.width * tangent + r.height + 0.999999F);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out)
/*     */   {
/* 130 */     out[0] = (x + this.xoffset + y * this.shx);
/* 131 */     out[1] = (y + this.yoffset + x * this.shy);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 135 */     return "Distort/Shear...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ShearFilter
 * JD-Core Version:    0.6.1
 */