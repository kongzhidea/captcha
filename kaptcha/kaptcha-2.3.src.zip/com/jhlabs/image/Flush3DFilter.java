/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class Flush3DFilter extends WholeImageFilter
/*    */ {
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace)
/*    */   {
/* 31 */     int index = 0;
/* 32 */     int[] outPixels = new int[width * height];
/*    */ 
/* 34 */     for (int y = 0; y < height; y++) {
/* 35 */       for (int x = 0; x < width; x++) {
/* 36 */         int pixel = inPixels[(y * width + x)];
/*    */ 
/* 38 */         if ((pixel != -16777216) && (y > 0) && (x > 0)) {
/* 39 */           int count = 0;
/* 40 */           if (inPixels[(y * width + x - 1)] == -16777216)
/* 41 */             count++;
/* 42 */           if (inPixels[((y - 1) * width + x)] == -16777216)
/* 43 */             count++;
/* 44 */           if (inPixels[((y - 1) * width + x - 1)] == -16777216)
/* 45 */             count++;
/* 46 */           if (count >= 2)
/* 47 */             pixel = -1;
/*    */         }
/* 49 */         outPixels[(index++)] = pixel;
/*    */       }
/*    */     }
/*    */ 
/* 53 */     return outPixels;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 57 */     return "Stylize/Flush 3D...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Flush3DFilter
 * JD-Core Version:    0.6.1
 */