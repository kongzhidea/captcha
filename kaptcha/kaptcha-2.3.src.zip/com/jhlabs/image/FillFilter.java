/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class FillFilter extends PointFilter
/*    */ {
/*    */   private int fillColor;
/*    */ 
/*    */   public FillFilter()
/*    */   {
/* 34 */     this(-16777216);
/*    */   }
/*    */ 
/*    */   public FillFilter(int color)
/*    */   {
/* 42 */     this.fillColor = color;
/*    */   }
/*    */ 
/*    */   public void setFillColor(int fillColor)
/*    */   {
/* 51 */     this.fillColor = fillColor;
/*    */   }
/*    */ 
/*    */   public int getFillColor()
/*    */   {
/* 60 */     return this.fillColor;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 64 */     return this.fillColor;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FillFilter
 * JD-Core Version:    0.6.1
 */