/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class RotateFilter extends TransformFilter
/*     */ {
/*     */   private float angle;
/*     */   private float cos;
/*     */   private float sin;
/*  29 */   private boolean resize = true;
/*     */ 
/*     */   public RotateFilter()
/*     */   {
/*  35 */     this(3.141593F);
/*     */   }
/*     */ 
/*     */   public RotateFilter(float angle)
/*     */   {
/*  43 */     this(angle, true);
/*     */   }
/*     */ 
/*     */   public RotateFilter(float angle, boolean resize)
/*     */   {
/*  52 */     setAngle(angle);
/*  53 */     this.resize = resize;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  63 */     this.angle = angle;
/*  64 */     this.cos = (float)Math.cos(this.angle);
/*  65 */     this.sin = (float)Math.sin(this.angle);
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  74 */     return this.angle;
/*     */   }
/*     */ 
/*     */   protected void transformSpace(Rectangle rect) {
/*  78 */     if (this.resize) {
/*  79 */       Point out = new Point(0, 0);
/*  80 */       int minx = 2147483647;
/*  81 */       int miny = 2147483647;
/*  82 */       int maxx = -2147483648;
/*  83 */       int maxy = -2147483648;
/*  84 */       int w = rect.width;
/*  85 */       int h = rect.height;
/*  86 */       int x = rect.x;
/*  87 */       int y = rect.y;
/*     */ 
/*  89 */       for (int i = 0; i < 4; i++) {
/*  90 */         switch (i) { case 0:
/*  91 */           transform(x, y, out); break;
/*     */         case 1:
/*  92 */           transform(x + w, y, out); break;
/*     */         case 2:
/*  93 */           transform(x, y + h, out); break;
/*     */         case 3:
/*  94 */           transform(x + w, y + h, out);
/*     */         }
/*  96 */         minx = Math.min(minx, out.x);
/*  97 */         miny = Math.min(miny, out.y);
/*  98 */         maxx = Math.max(maxx, out.x);
/*  99 */         maxy = Math.max(maxy, out.y);
/*     */       }
/*     */ 
/* 102 */       rect.x = minx;
/* 103 */       rect.y = miny;
/* 104 */       rect.width = (maxx - rect.x);
/* 105 */       rect.height = (maxy - rect.y);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void transform(int x, int y, Point out) {
/* 110 */     out.x = (int)(x * this.cos + y * this.sin);
/* 111 */     out.y = (int)(y * this.cos - x * this.sin);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 115 */     out[0] = (x * this.cos - y * this.sin);
/* 116 */     out[1] = (y * this.cos + x * this.sin);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 120 */     return "Rotate " + (int)(this.angle * 180.0F / 3.141592653589793D);
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RotateFilter
 * JD-Core Version:    0.6.1
 */