/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class BlockFilter extends AbstractBufferedImageOp
/*     */ {
/*  27 */   private int blockSize = 2;
/*     */ 
/*     */   public BlockFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BlockFilter(int blockSize)
/*     */   {
/*  40 */     this.blockSize = blockSize;
/*     */   }
/*     */ 
/*     */   public void setBlockSize(int blockSize)
/*     */   {
/*  51 */     this.blockSize = blockSize;
/*     */   }
/*     */ 
/*     */   public int getBlockSize()
/*     */   {
/*  60 */     return this.blockSize;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  64 */     int width = src.getWidth();
/*  65 */     int height = src.getHeight();
/*  66 */     int type = src.getType();
/*  67 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/*  69 */     if (dst == null) {
/*  70 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  72 */     int[] pixels = new int[this.blockSize * this.blockSize];
/*  73 */     for (int y = 0; y < height; y += this.blockSize) {
/*  74 */       for (int x = 0; x < width; x += this.blockSize) {
/*  75 */         int w = Math.min(this.blockSize, width - x);
/*  76 */         int h = Math.min(this.blockSize, height - y);
/*  77 */         int t = w * h;
/*  78 */         getRGB(src, x, y, w, h, pixels);
/*  79 */         int r = 0; int g = 0; int b = 0;
/*     */ 
/*  81 */         int i = 0;
/*  82 */         for (int by = 0; by < h; by++) {
/*  83 */           for (int bx = 0; bx < w; bx++) {
/*  84 */             int argb = pixels[i];
/*  85 */             r += (argb >> 16 & 0xFF);
/*  86 */             g += (argb >> 8 & 0xFF);
/*  87 */             b += (argb & 0xFF);
/*  88 */             i++;
/*     */           }
/*     */         }
/*  91 */         int argb = r / t << 16 | g / t << 8 | b / t;
/*  92 */         i = 0;
/*  93 */         for (int by = 0; by < h; by++) {
/*  94 */           for (int bx = 0; bx < w; bx++) {
/*  95 */             pixels[i] = (pixels[i] & 0xFF000000 | argb);
/*  96 */             i++;
/*     */           }
/*     */         }
/*  99 */         setRGB(dst, x, y, w, h, pixels);
/*     */       }
/*     */     }
/*     */ 
/* 103 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 107 */     return "Pixellate/Mosaic...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BlockFilter
 * JD-Core Version:    0.6.1
 */