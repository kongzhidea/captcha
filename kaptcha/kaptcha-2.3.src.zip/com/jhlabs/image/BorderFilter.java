/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class BorderFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private int leftBorder;
/*     */   private int rightBorder;
/*     */   private int topBorder;
/*     */   private int bottomBorder;
/*     */   private Paint borderPaint;
/*     */ 
/*     */   public BorderFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BorderFilter(int leftBorder, int topBorder, int rightBorder, int bottomBorder, Paint borderPaint)
/*     */   {
/*  47 */     this.leftBorder = leftBorder;
/*  48 */     this.topBorder = topBorder;
/*  49 */     this.rightBorder = rightBorder;
/*  50 */     this.bottomBorder = bottomBorder;
/*  51 */     this.borderPaint = borderPaint;
/*     */   }
/*     */ 
/*     */   public void setLeftBorder(int leftBorder)
/*     */   {
/*  61 */     this.leftBorder = leftBorder;
/*     */   }
/*     */ 
/*     */   public int getLeftBorder()
/*     */   {
/*  70 */     return this.leftBorder;
/*     */   }
/*     */ 
/*     */   public void setRightBorder(int rightBorder)
/*     */   {
/*  80 */     this.rightBorder = rightBorder;
/*     */   }
/*     */ 
/*     */   public int getRightBorder()
/*     */   {
/*  89 */     return this.rightBorder;
/*     */   }
/*     */ 
/*     */   public void setTopBorder(int topBorder)
/*     */   {
/*  99 */     this.topBorder = topBorder;
/*     */   }
/*     */ 
/*     */   public int getTopBorder()
/*     */   {
/* 108 */     return this.topBorder;
/*     */   }
/*     */ 
/*     */   public void setBottomBorder(int bottomBorder)
/*     */   {
/* 118 */     this.bottomBorder = bottomBorder;
/*     */   }
/*     */ 
/*     */   public int getBottomBorder()
/*     */   {
/* 127 */     return this.bottomBorder;
/*     */   }
/*     */ 
/*     */   public void setBorderPaint(Paint borderPaint)
/*     */   {
/* 136 */     this.borderPaint = borderPaint;
/*     */   }
/*     */ 
/*     */   public Paint getBorderPaint()
/*     */   {
/* 145 */     return this.borderPaint;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 149 */     int width = src.getWidth();
/* 150 */     int height = src.getHeight();
/*     */ 
/* 152 */     if (dst == null)
/* 153 */       dst = new BufferedImage(width + this.leftBorder + this.rightBorder, height + this.topBorder + this.bottomBorder, src.getType());
/* 154 */     Graphics2D g = dst.createGraphics();
/* 155 */     if (this.borderPaint != null) {
/* 156 */       g.setPaint(this.borderPaint);
/* 157 */       if (this.leftBorder > 0)
/* 158 */         g.fillRect(0, 0, this.leftBorder, height);
/* 159 */       if (this.rightBorder > 0)
/* 160 */         g.fillRect(width - this.rightBorder, 0, this.rightBorder, height);
/* 161 */       if (this.topBorder > 0)
/* 162 */         g.fillRect(this.leftBorder, 0, width - this.leftBorder - this.rightBorder, this.topBorder);
/* 163 */       if (this.bottomBorder > 0)
/* 164 */         g.fillRect(this.leftBorder, height - this.bottomBorder, width - this.leftBorder - this.rightBorder, this.bottomBorder);
/*     */     }
/* 166 */     g.drawRenderedImage(src, AffineTransform.getTranslateInstance(this.leftBorder, this.rightBorder));
/* 167 */     g.dispose();
/* 168 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 172 */     return "Distort/Border...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BorderFilter
 * JD-Core Version:    0.6.1
 */