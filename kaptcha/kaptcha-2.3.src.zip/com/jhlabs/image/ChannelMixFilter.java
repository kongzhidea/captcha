/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class ChannelMixFilter extends PointFilter
/*    */ {
/*    */   private int blueGreen;
/*    */   private int redBlue;
/*    */   private int greenRed;
/*    */   private int intoR;
/*    */   private int intoG;
/*    */   private int intoB;
/*    */ 
/*    */   public ChannelMixFilter()
/*    */   {
/* 31 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public void setBlueGreen(int blueGreen) {
/* 35 */     this.blueGreen = blueGreen;
/*    */   }
/*    */ 
/*    */   public int getBlueGreen() {
/* 39 */     return this.blueGreen;
/*    */   }
/*    */ 
/*    */   public void setRedBlue(int redBlue) {
/* 43 */     this.redBlue = redBlue;
/*    */   }
/*    */ 
/*    */   public int getRedBlue() {
/* 47 */     return this.redBlue;
/*    */   }
/*    */ 
/*    */   public void setGreenRed(int greenRed) {
/* 51 */     this.greenRed = greenRed;
/*    */   }
/*    */ 
/*    */   public int getGreenRed() {
/* 55 */     return this.greenRed;
/*    */   }
/*    */ 
/*    */   public void setIntoR(int intoR) {
/* 59 */     this.intoR = intoR;
/*    */   }
/*    */ 
/*    */   public int getIntoR() {
/* 63 */     return this.intoR;
/*    */   }
/*    */ 
/*    */   public void setIntoG(int intoG) {
/* 67 */     this.intoG = intoG;
/*    */   }
/*    */ 
/*    */   public int getIntoG() {
/* 71 */     return this.intoG;
/*    */   }
/*    */ 
/*    */   public void setIntoB(int intoB) {
/* 75 */     this.intoB = intoB;
/*    */   }
/*    */ 
/*    */   public int getIntoB() {
/* 79 */     return this.intoB;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 83 */     int a = rgb & 0xFF000000;
/* 84 */     int r = rgb >> 16 & 0xFF;
/* 85 */     int g = rgb >> 8 & 0xFF;
/* 86 */     int b = rgb & 0xFF;
/* 87 */     int nr = PixelUtils.clamp((this.intoR * (this.blueGreen * g + (255 - this.blueGreen) * b) / 255 + (255 - this.intoR) * r) / 255);
/* 88 */     int ng = PixelUtils.clamp((this.intoG * (this.redBlue * b + (255 - this.redBlue) * r) / 255 + (255 - this.intoG) * g) / 255);
/* 89 */     int nb = PixelUtils.clamp((this.intoB * (this.greenRed * r + (255 - this.greenRed) * g) / 255 + (255 - this.intoB) * b) / 255);
/* 90 */     return a | nr << 16 | ng << 8 | nb;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 94 */     return "Colors/Mix Channels...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ChannelMixFilter
 * JD-Core Version:    0.6.1
 */