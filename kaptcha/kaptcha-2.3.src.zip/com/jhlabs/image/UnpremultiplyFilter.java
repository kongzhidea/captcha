/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class UnpremultiplyFilter extends PointFilter
/*    */ {
/*    */   public int filterRGB(int x, int y, int rgb)
/*    */   {
/* 20 */     int a = rgb >> 24 & 0xFF;
/* 21 */     int r = rgb >> 16 & 0xFF;
/* 22 */     int g = rgb >> 8 & 0xFF;
/* 23 */     int b = rgb & 0xFF;
/* 24 */     if ((a == 0) || (a == 255)) {
/* 25 */       return rgb;
/*    */     }
/* 27 */     float f = 255.0F / a;
/* 28 */     r = (int)(r * f);
/* 29 */     g = (int)(g * f);
/* 30 */     b = (int)(b * f);
/* 31 */     if (r > 255)
/* 32 */       r = 255;
/* 33 */     if (g > 255)
/* 34 */       g = 255;
/* 35 */     if (b > 255)
/* 36 */       b = 255;
/* 37 */     return a << 24 | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 41 */     return "Alpha/Unpremultiply";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.UnpremultiplyFilter
 * JD-Core Version:    0.6.1
 */