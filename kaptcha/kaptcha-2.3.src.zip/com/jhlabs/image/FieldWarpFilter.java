/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class FieldWarpFilter extends TransformFilter
/*     */ {
/*  47 */   private float amount = 1.0F;
/*  48 */   private float power = 1.0F;
/*  49 */   private float strength = 2.0F;
/*     */   private Line[] inLines;
/*     */   private Line[] outLines;
/*     */   private Line[] intermediateLines;
/*     */   private float width;
/*     */   private float height;
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  66 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  75 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setPower(float power) {
/*  79 */     this.power = power;
/*     */   }
/*     */ 
/*     */   public float getPower() {
/*  83 */     return this.power;
/*     */   }
/*     */ 
/*     */   public void setStrength(float strength) {
/*  87 */     this.strength = strength;
/*     */   }
/*     */ 
/*     */   public float getStrength() {
/*  91 */     return this.strength;
/*     */   }
/*     */ 
/*     */   public void setInLines(Line[] inLines) {
/*  95 */     this.inLines = inLines;
/*     */   }
/*     */ 
/*     */   public Line[] getInLines() {
/*  99 */     return this.inLines;
/*     */   }
/*     */ 
/*     */   public void setOutLines(Line[] outLines) {
/* 103 */     this.outLines = outLines;
/*     */   }
/*     */ 
/*     */   public Line[] getOutLines() {
/* 107 */     return this.outLines;
/*     */   }
/*     */ 
/*     */   protected void transform(int x, int y, Point out) {
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 114 */     float u = 0.0F; float v = 0.0F;
/* 115 */     float fraction = 0.0F;
/*     */ 
/* 119 */     float a = 0.001F;
/* 120 */     float b = 1.5F * this.strength + 0.5F;
/* 121 */     float p = this.power;
/*     */ 
/* 123 */     float totalWeight = 0.0F;
/* 124 */     float sumX = 0.0F;
/* 125 */     float sumY = 0.0F;
/*     */ 
/* 127 */     for (int line = 0; line < this.inLines.length; line++) {
/* 128 */       Line l1 = this.inLines[line];
/* 129 */       Line l = this.intermediateLines[line];
/* 130 */       float dx = x - l.x1;
/* 131 */       float dy = y - l.y1;
/*     */ 
/* 133 */       fraction = (dx * l.dx + dy * l.dy) / l.lengthSquared;
/* 134 */       float fdist = (dy * l.dx - dx * l.dy) / l.length;
/*     */       float distance;
/*     */       float distance;
/* 135 */       if (fraction <= 0.0F) {
/* 136 */         distance = (float)Math.sqrt(dx * dx + dy * dy);
/*     */       }
/*     */       else
/*     */       {
/*     */         float distance;
/* 137 */         if (fraction >= 1.0F) {
/* 138 */           dx = x - l.x2;
/* 139 */           dy = y - l.y2;
/* 140 */           distance = (float)Math.sqrt(dx * dx + dy * dy);
/*     */         }
/*     */         else
/*     */         {
/*     */           float distance;
/* 141 */           if (fdist >= 0.0F)
/* 142 */             distance = fdist;
/*     */           else
/* 144 */             distance = -fdist; 
/*     */         }
/*     */       }
/* 145 */       u = l1.x1 + fraction * l1.dx - fdist * l1.dy / l1.length;
/* 146 */       v = l1.y1 + fraction * l1.dy + fdist * l1.dx / l1.length;
/*     */ 
/* 148 */       float weight = (float)Math.pow(Math.pow(l.length, p) / a + distance, b);
/*     */ 
/* 150 */       sumX += (u - x) * weight;
/* 151 */       sumY += (v - y) * weight;
/*     */ 
/* 153 */       totalWeight += weight;
/*     */     }
/*     */ 
/* 158 */     out[0] = (x + sumX / totalWeight + 0.5F);
/* 159 */     out[1] = (y + sumY / totalWeight + 0.5F);
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 163 */     this.width = this.width;
/* 164 */     this.height = this.height;
/* 165 */     if ((this.inLines != null) && (this.outLines != null)) {
/* 166 */       this.intermediateLines = new Line[this.inLines.length];
/* 167 */       for (int line = 0; line < this.inLines.length; line++) {
/* 168 */         Line l = this.intermediateLines[line] =  = new Line(ImageMath.lerp(this.amount, this.inLines[line].x1, this.outLines[line].x1), ImageMath.lerp(this.amount, this.inLines[line].y1, this.outLines[line].y1), ImageMath.lerp(this.amount, this.inLines[line].x2, this.outLines[line].x2), ImageMath.lerp(this.amount, this.inLines[line].y2, this.outLines[line].y2));
/*     */ 
/* 174 */         l.setup();
/* 175 */         this.inLines[line].setup();
/*     */       }
/* 177 */       dst = super.filter(src, dst);
/* 178 */       this.intermediateLines = null;
/* 179 */       return dst;
/*     */     }
/* 181 */     return src;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 185 */     return "Distort/Field Warp...";
/*     */   }
/*     */ 
/*     */   public static class Line
/*     */   {
/*     */     public int x1;
/*     */     public int y1;
/*     */     public int x2;
/*     */     public int y2;
/*     */     public int dx;
/*     */     public int dy;
/*     */     public float length;
/*     */     public float lengthSquared;
/*     */ 
/*     */     public Line(int x1, int y1, int x2, int y2)
/*     */     {
/*  33 */       this.x1 = x1;
/*  34 */       this.y1 = y1;
/*  35 */       this.x2 = x2;
/*  36 */       this.y2 = y2;
/*     */     }
/*     */ 
/*     */     public void setup() {
/*  40 */       this.dx = (this.x2 - this.x1);
/*  41 */       this.dy = (this.y2 - this.y1);
/*  42 */       this.lengthSquared = this.dx * this.dx + this.dy * this.dy;
/*  43 */       this.length = (float)Math.sqrt(this.lengthSquared);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FieldWarpFilter
 * JD-Core Version:    0.6.1
 */