/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Function2D;
/*     */ import com.jhlabs.math.Noise;
/*     */ 
/*     */ public class TextureFilter extends PointFilter
/*     */ {
/*  24 */   private float scale = 32.0F;
/*  25 */   private float stretch = 1.0F;
/*  26 */   private float angle = 0.0F;
/*  27 */   public float amount = 1.0F;
/*  28 */   public float turbulence = 1.0F;
/*  29 */   public float gain = 0.5F;
/*  30 */   public float bias = 0.5F;
/*     */   public int operation;
/*  32 */   private float m00 = 1.0F;
/*  33 */   private float m01 = 0.0F;
/*  34 */   private float m10 = 0.0F;
/*  35 */   private float m11 = 1.0F;
/*  36 */   private Colormap colormap = new Gradient();
/*  37 */   private Function2D function = new Noise();
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  50 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  59 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setFunction(Function2D function) {
/*  63 */     this.function = function;
/*     */   }
/*     */ 
/*     */   public Function2D getFunction() {
/*  67 */     return this.function;
/*     */   }
/*     */ 
/*     */   public void setOperation(int operation) {
/*  71 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */   public int getOperation() {
/*  75 */     return this.operation;
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  86 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  95 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setStretch(float stretch)
/*     */   {
/* 106 */     this.stretch = stretch;
/*     */   }
/*     */ 
/*     */   public float getStretch()
/*     */   {
/* 115 */     return this.stretch;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 125 */     this.angle = angle;
/* 126 */     float cos = (float)Math.cos(angle);
/* 127 */     float sin = (float)Math.sin(angle);
/* 128 */     this.m00 = cos;
/* 129 */     this.m01 = sin;
/* 130 */     this.m10 = (-sin);
/* 131 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 140 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/* 151 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 160 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 169 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 178 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 182 */     float nx = this.m00 * x + this.m01 * y;
/* 183 */     float ny = this.m10 * x + this.m11 * y;
/* 184 */     nx /= this.scale;
/* 185 */     ny /= this.scale * this.stretch;
/* 186 */     float f = this.turbulence == 1.0D ? Noise.noise2(nx, ny) : Noise.turbulence2(nx, ny, this.turbulence);
/* 187 */     f = f * 0.5F + 0.5F;
/* 188 */     f = ImageMath.gain(f, this.gain);
/* 189 */     f = ImageMath.bias(f, this.bias);
/* 190 */     f *= this.amount;
/* 191 */     int a = rgb & 0xFF000000;
/*     */     int v;
/*     */     int v;
/* 193 */     if (this.colormap != null) {
/* 194 */       v = this.colormap.getColor(f);
/*     */     } else {
/* 196 */       v = PixelUtils.clamp((int)(f * 255.0F));
/* 197 */       int r = v << 16;
/* 198 */       int g = v << 8;
/* 199 */       int b = v;
/* 200 */       v = a | r | g | b;
/*     */     }
/* 202 */     if (this.operation != 0)
/* 203 */       v = PixelUtils.combinePixels(rgb, v, this.operation);
/* 204 */     return v;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 208 */     return "Texture/Noise...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TextureFilter
 * JD-Core Version:    0.6.1
 */