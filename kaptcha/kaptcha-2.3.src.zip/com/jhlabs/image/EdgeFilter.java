/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class EdgeFilter extends WholeImageFilter
/*     */ {
/*  27 */   public static final float R2 = (float)Math.sqrt(2.0D);
/*     */ 
/*  29 */   public static final float[] ROBERTS_V = { 0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F };
/*     */ 
/*  34 */   public static final float[] ROBERTS_H = { -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F };
/*     */ 
/*  39 */   public static final float[] PREWITT_V = { -1.0F, 0.0F, 1.0F, -1.0F, 0.0F, 1.0F, -1.0F, 0.0F, 1.0F };
/*     */ 
/*  44 */   public static final float[] PREWITT_H = { -1.0F, -1.0F, -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F };
/*     */ 
/*  49 */   public static final float[] SOBEL_V = { -1.0F, 0.0F, 1.0F, -2.0F, 0.0F, 2.0F, -1.0F, 0.0F, 1.0F };
/*     */ 
/*  54 */   public static float[] SOBEL_H = { -1.0F, -2.0F, -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F };
/*     */ 
/*  59 */   public static final float[] FREI_CHEN_V = { -1.0F, 0.0F, 1.0F, -R2, 0.0F, R2, -1.0F, 0.0F, 1.0F };
/*     */ 
/*  64 */   public static float[] FREI_CHEN_H = { -1.0F, -R2, -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, R2, 1.0F };
/*     */ 
/*  70 */   protected float[] vEdgeMatrix = SOBEL_V;
/*  71 */   protected float[] hEdgeMatrix = SOBEL_H;
/*     */ 
/*     */   public void setVEdgeMatrix(float[] vEdgeMatrix)
/*     */   {
/*  77 */     this.vEdgeMatrix = vEdgeMatrix;
/*     */   }
/*     */ 
/*     */   public float[] getVEdgeMatrix() {
/*  81 */     return this.vEdgeMatrix;
/*     */   }
/*     */ 
/*     */   public void setHEdgeMatrix(float[] hEdgeMatrix) {
/*  85 */     this.hEdgeMatrix = hEdgeMatrix;
/*     */   }
/*     */ 
/*     */   public float[] getHEdgeMatrix() {
/*  89 */     return this.hEdgeMatrix;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  93 */     int index = 0;
/*  94 */     int[] outPixels = new int[width * height];
/*     */ 
/*  96 */     for (int y = 0; y < height; y++) {
/*  97 */       for (int x = 0; x < width; x++) {
/*  98 */         int r = 0; int g = 0; int b = 0;
/*  99 */         int rh = 0; int gh = 0; int bh = 0;
/* 100 */         int rv = 0; int gv = 0; int bv = 0;
/* 101 */         int a = inPixels[(y * width + x)] & 0xFF000000;
/*     */ 
/* 103 */         for (int row = -1; row <= 1; row++) {
/* 104 */           int iy = y + row;
/*     */           int ioffset;
/*     */           int ioffset;
/* 106 */           if ((0 <= iy) && (iy < height))
/* 107 */             ioffset = iy * width;
/*     */           else
/* 109 */             ioffset = y * width;
/* 110 */           int moffset = 3 * (row + 1) + 1;
/* 111 */           for (int col = -1; col <= 1; col++) {
/* 112 */             int ix = x + col;
/* 113 */             if ((0 > ix) || (ix >= width))
/* 114 */               ix = x;
/* 115 */             int rgb = inPixels[(ioffset + ix)];
/* 116 */             float h = this.hEdgeMatrix[(moffset + col)];
/* 117 */             float v = this.vEdgeMatrix[(moffset + col)];
/*     */ 
/* 119 */             r = (rgb & 0xFF0000) >> 16;
/* 120 */             g = (rgb & 0xFF00) >> 8;
/* 121 */             b = rgb & 0xFF;
/* 122 */             rh += (int)(h * r);
/* 123 */             gh += (int)(h * g);
/* 124 */             bh += (int)(h * b);
/* 125 */             rv += (int)(v * r);
/* 126 */             gv += (int)(v * g);
/* 127 */             bv += (int)(v * b);
/*     */           }
/*     */         }
/* 130 */         r = (int)(Math.sqrt(rh * rh + rv * rv) / 1.8D);
/* 131 */         g = (int)(Math.sqrt(gh * gh + gv * gv) / 1.8D);
/* 132 */         b = (int)(Math.sqrt(bh * bh + bv * bv) / 1.8D);
/* 133 */         r = PixelUtils.clamp(r);
/* 134 */         g = PixelUtils.clamp(g);
/* 135 */         b = PixelUtils.clamp(b);
/* 136 */         outPixels[(index++)] = (a | r << 16 | g << 8 | b);
/*     */       }
/*     */     }
/*     */ 
/* 140 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 144 */     return "Blur/Detect Edges";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.EdgeFilter
 * JD-Core Version:    0.6.1
 */