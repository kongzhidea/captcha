/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import com.jhlabs.math.Function2D;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class MapFilter extends TransformFilter
/*    */ {
/*    */   private Function2D xMapFunction;
/*    */   private Function2D yMapFunction;
/*    */ 
/*    */   public void setXMapFunction(Function2D xMapFunction)
/*    */   {
/* 32 */     this.xMapFunction = xMapFunction;
/*    */   }
/*    */ 
/*    */   public Function2D getXMapFunction() {
/* 36 */     return this.xMapFunction;
/*    */   }
/*    */ 
/*    */   public void setYMapFunction(Function2D yMapFunction) {
/* 40 */     this.yMapFunction = yMapFunction;
/*    */   }
/*    */ 
/*    */   public Function2D getYMapFunction() {
/* 44 */     return this.yMapFunction;
/*    */   }
/*    */ 
/*    */   protected void transformInverse(int x, int y, float[] out)
/*    */   {
/* 49 */     float xMap = this.xMapFunction.evaluate(x, y);
/* 50 */     float yMap = this.yMapFunction.evaluate(x, y);
/* 51 */     out[0] = (xMap * this.transformedSpace.width);
/* 52 */     out[1] = (yMap * this.transformedSpace.height);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 56 */     return "Distort/Map Coordinates...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MapFilter
 * JD-Core Version:    0.6.1
 */