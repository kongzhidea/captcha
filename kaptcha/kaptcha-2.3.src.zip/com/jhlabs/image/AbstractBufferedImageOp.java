/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.geom.Point2D;
/*    */ import java.awt.geom.Point2D.Double;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.BufferedImageOp;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ public abstract class AbstractBufferedImageOp
/*    */   implements BufferedImageOp, Cloneable
/*    */ {
/*    */   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM)
/*    */   {
/* 29 */     if (dstCM == null)
/* 30 */       dstCM = src.getColorModel();
/* 31 */     return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
/*    */   }
/*    */ 
/*    */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 35 */     return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/*    */   }
/*    */ 
/*    */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 39 */     if (dstPt == null)
/* 40 */       dstPt = new Point2D.Double();
/* 41 */     dstPt.setLocation(srcPt.getX(), srcPt.getY());
/* 42 */     return dstPt;
/*    */   }
/*    */ 
/*    */   public RenderingHints getRenderingHints() {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public int[] getRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*    */   {
/* 62 */     int type = image.getType();
/* 63 */     if ((type == 2) || (type == 1))
/* 64 */       return (int[])image.getRaster().getDataElements(x, y, width, height, pixels);
/* 65 */     return image.getRGB(x, y, width, height, pixels, 0, width);
/*    */   }
/*    */ 
/*    */   public void setRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*    */   {
/* 80 */     int type = image.getType();
/* 81 */     if ((type == 2) || (type == 1))
/* 82 */       image.getRaster().setDataElements(x, y, width, height, pixels);
/*    */     else
/* 84 */       image.setRGB(x, y, width, height, pixels, 0, width);
/*    */   }
/*    */ 
/*    */   public Object clone() {
/*    */     try {
/* 89 */       return super.clone();
/*    */     } catch (CloneNotSupportedException e) {
/*    */     }
/* 92 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.AbstractBufferedImageOp
 * JD-Core Version:    0.6.1
 */