/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BandCombineOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ public class ShadowFilter extends AbstractBufferedImageOp
/*     */ {
/*  28 */   private float radius = 5.0F;
/*  29 */   private float angle = 4.712389F;
/*  30 */   private float distance = 5.0F;
/*  31 */   private float opacity = 0.5F;
/*  32 */   private boolean addMargins = false;
/*  33 */   private boolean shadowOnly = false;
/*  34 */   private int shadowColor = -16777216;
/*     */ 
/*     */   public ShadowFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ShadowFilter(float radius, float xOffset, float yOffset, float opacity)
/*     */   {
/*  50 */     this.radius = radius;
/*  51 */     this.angle = (float)Math.atan2(yOffset, xOffset);
/*  52 */     this.distance = (float)Math.sqrt(xOffset * xOffset + yOffset * yOffset);
/*  53 */     this.opacity = opacity;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  63 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  72 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setDistance(float distance)
/*     */   {
/*  81 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public float getDistance()
/*     */   {
/*  90 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/*  99 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 108 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setOpacity(float opacity)
/*     */   {
/* 117 */     this.opacity = opacity;
/*     */   }
/*     */ 
/*     */   public float getOpacity()
/*     */   {
/* 126 */     return this.opacity;
/*     */   }
/*     */ 
/*     */   public void setShadowColor(int shadowColor)
/*     */   {
/* 135 */     this.shadowColor = shadowColor;
/*     */   }
/*     */ 
/*     */   public int getShadowColor()
/*     */   {
/* 144 */     return this.shadowColor;
/*     */   }
/*     */ 
/*     */   public void setAddMargins(boolean addMargins)
/*     */   {
/* 153 */     this.addMargins = addMargins;
/*     */   }
/*     */ 
/*     */   public boolean getAddMargins()
/*     */   {
/* 162 */     return this.addMargins;
/*     */   }
/*     */ 
/*     */   public void setShadowOnly(boolean shadowOnly)
/*     */   {
/* 171 */     this.shadowOnly = shadowOnly;
/*     */   }
/*     */ 
/*     */   public boolean getShadowOnly()
/*     */   {
/* 180 */     return this.shadowOnly;
/*     */   }
/*     */ 
/*     */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 184 */     Rectangle r = new Rectangle(0, 0, src.getWidth(), src.getHeight());
/* 185 */     if (this.addMargins) {
/* 186 */       float xOffset = this.distance * (float)Math.cos(this.angle);
/* 187 */       float yOffset = -this.distance * (float)Math.sin(this.angle);
/* 188 */       r.width += (int)(Math.abs(xOffset) + 2.0F * this.radius);
/* 189 */       r.height += (int)(Math.abs(yOffset) + 2.0F * this.radius);
/*     */     }
/* 191 */     return r;
/*     */   }
/*     */ 
/*     */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 195 */     if (dstPt == null) {
/* 196 */       dstPt = new Point2D.Double();
/*     */     }
/* 198 */     if (this.addMargins) {
/* 199 */       float xOffset = this.distance * (float)Math.cos(this.angle);
/* 200 */       float yOffset = -this.distance * (float)Math.sin(this.angle);
/* 201 */       float topShadow = Math.max(0.0F, this.radius - yOffset);
/* 202 */       float leftShadow = Math.max(0.0F, this.radius - xOffset);
/* 203 */       dstPt.setLocation(srcPt.getX() + leftShadow, srcPt.getY() + topShadow);
/*     */     } else {
/* 205 */       dstPt.setLocation(srcPt.getX(), srcPt.getY());
/*     */     }
/* 207 */     return dstPt;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 211 */     int width = src.getWidth();
/* 212 */     int height = src.getHeight();
/*     */ 
/* 214 */     if (dst == null) {
/* 215 */       if (this.addMargins) {
/* 216 */         ColorModel cm = src.getColorModel();
/* 217 */         dst = new BufferedImage(cm, cm.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), cm.isAlphaPremultiplied(), null);
/*     */       } else {
/* 219 */         dst = createCompatibleDestImage(src, null);
/*     */       }
/*     */     }
/* 222 */     float shadowR = this.shadowColor >> 16 & 0xFF / 255.0F;
/* 223 */     float shadowG = this.shadowColor >> 8 & 0xFF / 255.0F;
/* 224 */     float shadowB = this.shadowColor & 0xFF / 255.0F;
/*     */ 
/* 227 */     float[][] extractAlpha = { { 0.0F, 0.0F, 0.0F, shadowR }, { 0.0F, 0.0F, 0.0F, shadowG }, { 0.0F, 0.0F, 0.0F, shadowB }, { 0.0F, 0.0F, 0.0F, this.opacity } };
/*     */ 
/* 233 */     BufferedImage shadow = new BufferedImage(width, height, 2);
/* 234 */     new BandCombineOp(extractAlpha, null).filter(src.getRaster(), shadow.getRaster());
/* 235 */     shadow = new GaussianFilter(this.radius).filter(shadow, null);
/*     */ 
/* 237 */     float xOffset = this.distance * (float)Math.cos(this.angle);
/* 238 */     float yOffset = -this.distance * (float)Math.sin(this.angle);
/*     */ 
/* 240 */     Graphics2D g = dst.createGraphics();
/* 241 */     g.setComposite(AlphaComposite.getInstance(3, this.opacity));
/* 242 */     if (this.addMargins) {
/* 243 */       float radius2 = this.radius / 2.0F;
/* 244 */       float topShadow = Math.max(0.0F, this.radius - yOffset);
/* 245 */       float leftShadow = Math.max(0.0F, this.radius - xOffset);
/* 246 */       g.translate(topShadow, leftShadow);
/*     */     }
/* 248 */     g.drawRenderedImage(shadow, AffineTransform.getTranslateInstance(xOffset, yOffset));
/* 249 */     if (!this.shadowOnly) {
/* 250 */       g.setComposite(AlphaComposite.SrcOver);
/* 251 */       g.drawRenderedImage(src, null);
/*     */     }
/* 253 */     g.dispose();
/*     */ 
/* 255 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 259 */     return "Stylize/Drop Shadow...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ShadowFilter
 * JD-Core Version:    0.6.1
 */