/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class GradientFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   public static final int LINEAR = 0;
/*     */   public static final int BILINEAR = 1;
/*     */   public static final int RADIAL = 2;
/*     */   public static final int CONICAL = 3;
/*     */   public static final int BICONICAL = 4;
/*     */   public static final int SQUARE = 5;
/*     */   public static final int INT_LINEAR = 0;
/*     */   public static final int INT_CIRCLE_UP = 1;
/*     */   public static final int INT_CIRCLE_DOWN = 2;
/*     */   public static final int INT_SMOOTH = 3;
/*  41 */   private float angle = 0.0F;
/*  42 */   private int color1 = -16777216;
/*  43 */   private int color2 = -1;
/*  44 */   private Point p1 = new Point(0, 0); private Point p2 = new Point(64, 64);
/*  45 */   private boolean repeat = false;
/*     */   private float x1;
/*     */   private float y1;
/*     */   private float dx;
/*     */   private float dy;
/*  50 */   private Colormap colormap = null;
/*     */   private int type;
/*  52 */   private int interpolation = 0;
/*  53 */   private int paintMode = 1;
/*     */ 
/*     */   public GradientFilter() {
/*     */   }
/*     */ 
/*     */   public GradientFilter(Point p1, Point p2, int color1, int color2, boolean repeat, int type, int interpolation) {
/*  59 */     this.p1 = p1;
/*  60 */     this.p2 = p2;
/*  61 */     this.color1 = color1;
/*  62 */     this.color2 = color2;
/*  63 */     this.repeat = repeat;
/*  64 */     this.type = type;
/*  65 */     this.interpolation = interpolation;
/*  66 */     this.colormap = new LinearColormap(color1, color2);
/*     */   }
/*     */ 
/*     */   public void setPoint1(Point point1) {
/*  70 */     this.p1 = point1;
/*     */   }
/*     */ 
/*     */   public Point getPoint1() {
/*  74 */     return this.p1;
/*     */   }
/*     */ 
/*     */   public void setPoint2(Point point2) {
/*  78 */     this.p2 = point2;
/*     */   }
/*     */ 
/*     */   public Point getPoint2() {
/*  82 */     return this.p2;
/*     */   }
/*     */ 
/*     */   public void setType(int type) {
/*  86 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  90 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setInterpolation(int interpolation) {
/*  94 */     this.interpolation = interpolation;
/*     */   }
/*     */ 
/*     */   public int getInterpolation() {
/*  98 */     return this.interpolation;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 108 */     this.angle = angle;
/* 109 */     this.p2 = new Point((int)(64.0D * Math.cos(angle)), (int)(64.0D * Math.sin(angle)));
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 118 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 127 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 136 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public void setPaintMode(int paintMode) {
/* 140 */     this.paintMode = paintMode;
/*     */   }
/*     */ 
/*     */   public int getPaintMode() {
/* 144 */     return this.paintMode;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 148 */     int width = src.getWidth();
/* 149 */     int height = src.getHeight();
/*     */ 
/* 151 */     if (dst == null) {
/* 152 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*     */ 
/* 156 */     float x1 = this.p1.x;
/* 157 */     float x2 = this.p2.x;
/*     */     int rgb2;
/*     */     float y1;
/*     */     float y2;
/*     */     int rgb2;
/* 159 */     if ((x1 > x2) && (this.type != 2)) {
/* 160 */       float y1 = x1;
/* 161 */       x1 = x2;
/* 162 */       x2 = y1;
/* 163 */       y1 = this.p2.y;
/* 164 */       float y2 = this.p1.y;
/* 165 */       int rgb1 = this.color2;
/* 166 */       rgb2 = this.color1;
/*     */     } else {
/* 168 */       y1 = this.p1.y;
/* 169 */       y2 = this.p2.y;
/* 170 */       int rgb1 = this.color1;
/* 171 */       rgb2 = this.color2;
/*     */     }
/* 173 */     float dx = x2 - x1;
/* 174 */     float dy = y2 - y1;
/* 175 */     float lenSq = dx * dx + dy * dy;
/* 176 */     this.x1 = x1;
/* 177 */     this.y1 = y1;
/* 178 */     if (lenSq >= 1.4E-45F) {
/* 179 */       dx /= lenSq;
/* 180 */       dy /= lenSq;
/* 181 */       if (this.repeat) {
/* 182 */         dx %= 1.0F;
/* 183 */         dy %= 1.0F;
/*     */       }
/*     */     }
/* 186 */     this.dx = dx;
/* 187 */     this.dy = dy;
/*     */ 
/* 189 */     int[] pixels = new int[width];
/* 190 */     for (int y = 0; y < height; y++) {
/* 191 */       getRGB(src, 0, y, width, 1, pixels);
/* 192 */       switch (this.type) {
/*     */       case 0:
/*     */       case 1:
/* 195 */         linearGradient(pixels, y, width, 1);
/* 196 */         break;
/*     */       case 2:
/* 198 */         radialGradient(pixels, y, width, 1);
/* 199 */         break;
/*     */       case 3:
/*     */       case 4:
/* 202 */         conicalGradient(pixels, y, width, 1);
/* 203 */         break;
/*     */       case 5:
/* 205 */         squareGradient(pixels, y, width, 1);
/*     */       }
/*     */ 
/* 208 */       setRGB(dst, 0, y, width, 1, pixels);
/*     */     }
/* 210 */     return dst;
/*     */   }
/*     */ 
/*     */   private void repeatGradient(int[] pixels, int w, int h, float rowrel, float dx, float dy) {
/* 214 */     int off = 0;
/* 215 */     for (int y = 0; y < h; y++) {
/* 216 */       float colrel = rowrel;
/* 217 */       int j = w;
/*     */       while (true) {
/* 219 */         j--; if (j < 0)
/*     */           break;
/*     */         int rgb;
/*     */         int rgb;
/* 220 */         if (this.type == 1)
/* 221 */           rgb = this.colormap.getColor(map(ImageMath.triangle(colrel)));
/*     */         else
/* 223 */           rgb = this.colormap.getColor(map(ImageMath.mod(colrel, 1.0F)));
/* 224 */         pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 225 */         off++;
/* 226 */         colrel += dx;
/*     */       }
/* 228 */       rowrel += dy;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void singleGradient(int[] pixels, int w, int h, float rowrel, float dx, float dy) {
/* 233 */     int off = 0;
/* 234 */     for (int y = 0; y < h; y++) {
/* 235 */       float colrel = rowrel;
/* 236 */       int j = w;
/*     */ 
/* 238 */       if (colrel <= 0.0D) {
/* 239 */         int rgb = this.colormap.getColor(0.0F);
/*     */         do {
/* 241 */           pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 242 */           off++;
/* 243 */           colrel += dx;
/* 244 */           j--; } while ((j > 0) && (colrel <= 0.0D));
/*     */       }
/* 246 */       while (colrel < 1.0D) { j--; if (j < 0)
/*     */           break;
/*     */         int rgb;
/*     */         int rgb;
/* 247 */         if (this.type == 1)
/* 248 */           rgb = this.colormap.getColor(map(ImageMath.triangle(colrel)));
/*     */         else
/* 250 */           rgb = this.colormap.getColor(map(colrel));
/* 251 */         pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 252 */         off++;
/* 253 */         colrel += dx;
/*     */       }
/* 255 */       if (j > 0)
/*     */       {
/*     */         int rgb;
/*     */         int rgb;
/* 256 */         if (this.type == 1)
/* 257 */           rgb = this.colormap.getColor(0.0F);
/*     */         else
/* 259 */           rgb = this.colormap.getColor(1.0F);
/*     */         do {
/* 261 */           pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 262 */           off++;
/* 263 */           j--; } while (j > 0);
/*     */       }
/* 265 */       rowrel += dy;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void linearGradient(int[] pixels, int y, int w, int h) {
/* 270 */     int x = 0;
/* 271 */     float rowrel = (x - this.x1) * this.dx + (y - this.y1) * this.dy;
/* 272 */     if (this.repeat)
/* 273 */       repeatGradient(pixels, w, h, rowrel, this.dx, this.dy);
/*     */     else
/* 275 */       singleGradient(pixels, w, h, rowrel, this.dx, this.dy);
/*     */   }
/*     */ 
/*     */   private void radialGradient(int[] pixels, int y, int w, int h) {
/* 279 */     int off = 0;
/* 280 */     float radius = distance(this.p2.x - this.p1.x, this.p2.y - this.p1.y);
/* 281 */     for (int x = 0; x < w; x++) {
/* 282 */       float distance = distance(x - this.p1.x, y - this.p1.y);
/* 283 */       float ratio = distance / radius;
/* 284 */       if (this.repeat)
/* 285 */         ratio %= 2.0F;
/* 286 */       else if (ratio > 1.0D)
/* 287 */         ratio = 1.0F;
/* 288 */       int rgb = this.colormap.getColor(map(ratio));
/* 289 */       pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 290 */       off++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void squareGradient(int[] pixels, int y, int w, int h) {
/* 295 */     int off = 0;
/* 296 */     float radius = Math.max(Math.abs(this.p2.x - this.p1.x), Math.abs(this.p2.y - this.p1.y));
/* 297 */     for (int x = 0; x < w; x++) {
/* 298 */       float distance = Math.max(Math.abs(x - this.p1.x), Math.abs(y - this.p1.y));
/* 299 */       float ratio = distance / radius;
/* 300 */       if (this.repeat)
/* 301 */         ratio %= 2.0F;
/* 302 */       else if (ratio > 1.0D)
/* 303 */         ratio = 1.0F;
/* 304 */       int rgb = this.colormap.getColor(map(ratio));
/* 305 */       pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 306 */       off++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void conicalGradient(int[] pixels, int y, int w, int h) {
/* 311 */     int off = 0;
/* 312 */     float angle0 = (float)Math.atan2(this.p2.x - this.p1.x, this.p2.y - this.p1.y);
/* 313 */     for (int x = 0; x < w; x++) {
/* 314 */       float angle = (float)(Math.atan2(x - this.p1.x, y - this.p1.y) - angle0) / 6.283186F;
/* 315 */       angle += 1.0F;
/* 316 */       angle %= 1.0F;
/* 317 */       if (this.type == 4)
/* 318 */         angle = ImageMath.triangle(angle);
/* 319 */       int rgb = this.colormap.getColor(map(angle));
/* 320 */       pixels[off] = PixelUtils.combinePixels(rgb, pixels[off], this.paintMode);
/* 321 */       off++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private float map(float v) {
/* 326 */     if (this.repeat)
/* 327 */       v = v > 1.0D ? 2.0F - v : v;
/* 328 */     switch (this.interpolation) {
/*     */     case 1:
/* 330 */       v = ImageMath.circleUp(ImageMath.clamp(v, 0.0F, 1.0F));
/* 331 */       break;
/*     */     case 2:
/* 333 */       v = ImageMath.circleDown(ImageMath.clamp(v, 0.0F, 1.0F));
/* 334 */       break;
/*     */     case 3:
/* 336 */       v = ImageMath.smoothStep(0.0F, 1.0F, v);
/*     */     }
/*     */ 
/* 339 */     return v;
/*     */   }
/*     */ 
/*     */   private float distance(float a, float b) {
/* 343 */     return (float)Math.sqrt(a * a + b * b);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 347 */     return "Other/Gradient Fill...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GradientFilter
 * JD-Core Version:    0.6.1
 */