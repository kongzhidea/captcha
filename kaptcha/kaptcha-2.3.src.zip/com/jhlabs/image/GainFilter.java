/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class GainFilter extends TransferFilter
/*    */ {
/* 27 */   private float gain = 0.5F;
/* 28 */   private float bias = 0.5F;
/*    */ 
/*    */   protected float transferFunction(float f) {
/* 31 */     f = ImageMath.gain(f, this.gain);
/* 32 */     f = ImageMath.bias(f, this.bias);
/* 33 */     return f;
/*    */   }
/*    */ 
/*    */   public void setGain(float gain)
/*    */   {
/* 44 */     this.gain = gain;
/* 45 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getGain()
/*    */   {
/* 54 */     return this.gain;
/*    */   }
/*    */ 
/*    */   public void setBias(float bias)
/*    */   {
/* 65 */     this.bias = bias;
/* 66 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getBias()
/*    */   {
/* 75 */     return this.bias;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 79 */     return "Colors/Gain...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GainFilter
 * JD-Core Version:    0.6.1
 */