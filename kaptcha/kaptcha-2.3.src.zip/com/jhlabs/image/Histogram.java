/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class Histogram
/*     */ {
/*     */   public static final int RED = 0;
/*     */   public static final int GREEN = 1;
/*     */   public static final int BLUE = 2;
/*     */   public static final int GRAY = 3;
/*     */   protected int[][] histogram;
/*     */   protected int numSamples;
/*     */   protected int[] minValue;
/*     */   protected int[] maxValue;
/*     */   protected int[] minFrequency;
/*     */   protected int[] maxFrequency;
/*     */   protected float[] mean;
/*     */   protected boolean isGray;
/*     */ 
/*     */   public Histogram()
/*     */   {
/*  42 */     this.histogram = ((int[][])null);
/*  43 */     this.numSamples = 0;
/*  44 */     this.isGray = true;
/*  45 */     this.minValue = null;
/*  46 */     this.maxValue = null;
/*  47 */     this.minFrequency = null;
/*  48 */     this.maxFrequency = null;
/*  49 */     this.mean = null;
/*     */   }
/*     */ 
/*     */   public Histogram(int[] pixels, int w, int h, int offset, int stride) {
/*  53 */     this.histogram = new int[3][256];
/*  54 */     this.minValue = new int[4];
/*  55 */     this.maxValue = new int[4];
/*  56 */     this.minFrequency = new int[3];
/*  57 */     this.maxFrequency = new int[3];
/*  58 */     this.mean = new float[3];
/*     */ 
/*  60 */     this.numSamples = (w * h);
/*  61 */     this.isGray = true;
/*     */ 
/*  63 */     int index = 0;
/*  64 */     for (int y = 0; y < h; y++) {
/*  65 */       index = offset + y * stride;
/*  66 */       for (int x = 0; x < w; x++) {
/*  67 */         int rgb = pixels[(index++)];
/*  68 */         int r = rgb >> 16 & 0xFF;
/*  69 */         int g = rgb >> 8 & 0xFF;
/*  70 */         int b = rgb & 0xFF;
/*  71 */         this.histogram[0][r] += 1;
/*  72 */         this.histogram[1][g] += 1;
/*  73 */         this.histogram[2][b] += 1;
/*     */       }
/*     */     }
/*     */ 
/*  77 */     for (int i = 0; i < 256; i++) {
/*  78 */       if ((this.histogram[0][i] != this.histogram[1][i]) || (this.histogram[1][i] != this.histogram[2][i])) {
/*  79 */         this.isGray = false;
/*  80 */         break;
/*     */       }
/*     */     }
/*     */ 
/*  84 */     for (int i = 0; i < 3; i++) {
/*  85 */       for (int j = 0; j < 256; j++) {
/*  86 */         if (this.histogram[i][j] > 0) {
/*  87 */           this.minValue[i] = j;
/*  88 */           break;
/*     */         }
/*     */       }
/*     */ 
/*  92 */       for (int j = 255; j >= 0; j--) {
/*  93 */         if (this.histogram[i][j] > 0) {
/*  94 */           this.maxValue[i] = j;
/*  95 */           break;
/*     */         }
/*     */       }
/*     */ 
/*  99 */       this.minFrequency[i] = 2147483647;
/* 100 */       this.maxFrequency[i] = 0;
/* 101 */       for (int j = 0; j < 256; j++) {
/* 102 */         this.minFrequency[i] = Math.min(this.minFrequency[i], this.histogram[i][j]);
/* 103 */         this.maxFrequency[i] = Math.max(this.maxFrequency[i], this.histogram[i][j]);
/* 104 */         this.mean[i] += j * this.histogram[i][j];
/*     */       }
/* 106 */       this.mean[i] /= this.numSamples;
/*     */     }
/* 108 */     this.minValue[3] = Math.min(Math.min(this.minValue[0], this.minValue[1]), this.minValue[2]);
/* 109 */     this.maxValue[3] = Math.max(Math.max(this.maxValue[0], this.maxValue[1]), this.maxValue[2]);
/*     */   }
/*     */ 
/*     */   public boolean isGray() {
/* 113 */     return this.isGray;
/*     */   }
/*     */ 
/*     */   public int getNumSamples() {
/* 117 */     return this.numSamples;
/*     */   }
/*     */ 
/*     */   public int getFrequency(int value) {
/* 121 */     if ((this.numSamples > 0) && (this.isGray) && (value >= 0) && (value <= 255))
/* 122 */       return this.histogram[0][value];
/* 123 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getFrequency(int channel, int value) {
/* 127 */     if ((this.numSamples < 1) || (channel < 0) || (channel > 2) || (value < 0) || (value > 255))
/*     */     {
/* 129 */       return -1;
/* 130 */     }return this.histogram[channel][value];
/*     */   }
/*     */ 
/*     */   public int getMinFrequency() {
/* 134 */     if ((this.numSamples > 0) && (this.isGray))
/* 135 */       return this.minFrequency[0];
/* 136 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getMinFrequency(int channel) {
/* 140 */     if ((this.numSamples < 1) || (channel < 0) || (channel > 2))
/* 141 */       return -1;
/* 142 */     return this.minFrequency[channel];
/*     */   }
/*     */ 
/*     */   public int getMaxFrequency()
/*     */   {
/* 147 */     if ((this.numSamples > 0) && (this.isGray))
/* 148 */       return this.maxFrequency[0];
/* 149 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getMaxFrequency(int channel) {
/* 153 */     if ((this.numSamples < 1) || (channel < 0) || (channel > 2))
/* 154 */       return -1;
/* 155 */     return this.maxFrequency[channel];
/*     */   }
/*     */ 
/*     */   public int getMinValue()
/*     */   {
/* 160 */     if ((this.numSamples > 0) && (this.isGray))
/* 161 */       return this.minValue[0];
/* 162 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getMinValue(int channel) {
/* 166 */     return this.minValue[channel];
/*     */   }
/*     */ 
/*     */   public int getMaxValue() {
/* 170 */     if ((this.numSamples > 0) && (this.isGray))
/* 171 */       return this.maxValue[0];
/* 172 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getMaxValue(int channel) {
/* 176 */     return this.maxValue[channel];
/*     */   }
/*     */ 
/*     */   public float getMeanValue() {
/* 180 */     if ((this.numSamples > 0) && (this.isGray))
/* 181 */       return this.mean[0];
/* 182 */     return -1.0F;
/*     */   }
/*     */ 
/*     */   public float getMeanValue(int channel) {
/* 186 */     if ((this.numSamples > 0) && (0 <= channel) && (channel <= 2))
/* 187 */       return this.mean[channel];
/* 188 */     return -1.0F;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Histogram
 * JD-Core Version:    0.6.1
 */