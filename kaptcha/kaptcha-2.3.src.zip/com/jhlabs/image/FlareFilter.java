/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ 
/*     */ public class FlareFilter extends PointFilter
/*     */ {
/*  29 */   private int rays = 50;
/*     */   private float radius;
/*  31 */   private float baseAmount = 1.0F;
/*  32 */   private float ringAmount = 0.2F;
/*  33 */   private float rayAmount = 0.1F;
/*  34 */   private int color = -1;
/*     */   private int width;
/*     */   private int height;
/*  36 */   private float centreX = 0.5F; private float centreY = 0.5F;
/*  37 */   private float ringWidth = 1.6F;
/*     */ 
/*  39 */   private float linear = 0.03F;
/*  40 */   private float gauss = 0.006F;
/*  41 */   private float mix = 0.5F;
/*  42 */   private float falloff = 6.0F;
/*     */   private float sigma;
/*     */   private float icentreX;
/*     */   private float icentreY;
/*     */ 
/*     */   public FlareFilter()
/*     */   {
/*  48 */     setRadius(50.0F);
/*     */   }
/*     */ 
/*     */   public void setColor(int color) {
/*  52 */     this.color = color;
/*     */   }
/*     */ 
/*     */   public int getColor() {
/*  56 */     return this.color;
/*     */   }
/*     */ 
/*     */   public void setRingWidth(float ringWidth) {
/*  60 */     this.ringWidth = ringWidth;
/*     */   }
/*     */ 
/*     */   public float getRingWidth() {
/*  64 */     return this.ringWidth;
/*     */   }
/*     */ 
/*     */   public void setBaseAmount(float baseAmount) {
/*  68 */     this.baseAmount = baseAmount;
/*     */   }
/*     */ 
/*     */   public float getBaseAmount() {
/*  72 */     return this.baseAmount;
/*     */   }
/*     */ 
/*     */   public void setRingAmount(float ringAmount) {
/*  76 */     this.ringAmount = ringAmount;
/*     */   }
/*     */ 
/*     */   public float getRingAmount() {
/*  80 */     return this.ringAmount;
/*     */   }
/*     */ 
/*     */   public void setRayAmount(float rayAmount) {
/*  84 */     this.rayAmount = rayAmount;
/*     */   }
/*     */ 
/*     */   public float getRayAmount() {
/*  88 */     return this.rayAmount;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre) {
/*  92 */     this.centreX = (float)centre.getX();
/*  93 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre() {
/*  97 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/* 107 */     this.radius = radius;
/* 108 */     this.sigma = (radius / 3.0F);
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 117 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setDimensions(int width, int height) {
/* 121 */     this.width = width;
/* 122 */     this.height = height;
/* 123 */     this.icentreX = (this.centreX * width);
/* 124 */     this.icentreY = (this.centreY * height);
/* 125 */     super.setDimensions(width, height);
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 129 */     float dx = x - this.icentreX;
/* 130 */     float dy = y - this.icentreY;
/* 131 */     float distance = (float)Math.sqrt(dx * dx + dy * dy);
/* 132 */     float a = (float)Math.exp(-distance * distance * this.gauss) * this.mix + (float)Math.exp(-distance * this.linear) * (1.0F - this.mix);
/*     */ 
/* 135 */     a *= this.baseAmount;
/*     */ 
/* 137 */     if (distance > this.radius + this.ringWidth)
/* 138 */       a = ImageMath.lerp((distance - (this.radius + this.ringWidth)) / this.falloff, a, 0.0F);
/*     */     float ring;
/*     */     float ring;
/* 140 */     if ((distance < this.radius - this.ringWidth) || (distance > this.radius + this.ringWidth)) {
/* 141 */       ring = 0.0F;
/*     */     } else {
/* 143 */       ring = Math.abs(distance - this.radius) / this.ringWidth;
/* 144 */       ring = 1.0F - ring * ring * (3.0F - 2.0F * ring);
/* 145 */       ring *= this.ringAmount;
/*     */     }
/*     */ 
/* 148 */     a += ring;
/*     */ 
/* 150 */     float angle = (float)Math.atan2(dx, dy) + 3.141593F;
/* 151 */     angle = (ImageMath.mod(angle / 3.141593F * 17.0F + 1.0F + Noise.noise1(angle * 10.0F), 1.0F) - 0.5F) * 2.0F;
/* 152 */     angle = Math.abs(angle);
/* 153 */     angle = (float)Math.pow(angle, 5.0D);
/*     */ 
/* 155 */     float b = this.rayAmount * angle / (1.0F + distance * 0.1F);
/* 156 */     a += b;
/*     */ 
/* 158 */     a = ImageMath.clamp(a, 0.0F, 1.0F);
/* 159 */     return ImageMath.mixColors(a, rgb, this.color);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 163 */     return "Stylize/Flare...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FlareFilter
 * JD-Core Version:    0.6.1
 */