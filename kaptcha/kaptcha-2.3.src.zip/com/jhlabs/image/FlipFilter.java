/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class FlipFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   public static final int FLIP_H = 1;
/*     */   public static final int FLIP_V = 2;
/*     */   public static final int FLIP_HV = 3;
/*     */   public static final int FLIP_90CW = 4;
/*     */   public static final int FLIP_90CCW = 5;
/*     */   public static final int FLIP_180 = 6;
/*     */   private int operation;
/*     */   private int width;
/*     */   private int height;
/*     */   private int newWidth;
/*     */   private int newHeight;
/*     */ 
/*     */   public FlipFilter()
/*     */   {
/*  64 */     this(3);
/*     */   }
/*     */ 
/*     */   public FlipFilter(int operation)
/*     */   {
/*  72 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */   public void setOperation(int operation)
/*     */   {
/*  81 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */   public int getOperation()
/*     */   {
/*  90 */     return this.operation;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  94 */     int width = src.getWidth();
/*  95 */     int height = src.getHeight();
/*  96 */     int type = src.getType();
/*  97 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/*  99 */     int[] inPixels = getRGB(src, 0, 0, width, height, null);
/*     */ 
/* 101 */     int x = 0; int y = 0;
/* 102 */     int w = width;
/* 103 */     int h = height;
/*     */ 
/* 105 */     int newX = 0;
/* 106 */     int newY = 0;
/* 107 */     int newW = w;
/* 108 */     int newH = h;
/* 109 */     switch (this.operation) {
/*     */     case 1:
/* 111 */       newX = width - (x + w);
/* 112 */       break;
/*     */     case 2:
/* 114 */       newY = height - (y + h);
/* 115 */       break;
/*     */     case 3:
/* 117 */       newW = h;
/* 118 */       newH = w;
/* 119 */       newX = y;
/* 120 */       newY = x;
/* 121 */       break;
/*     */     case 4:
/* 123 */       newW = h;
/* 124 */       newH = w;
/* 125 */       newX = height - (y + h);
/* 126 */       newY = x;
/* 127 */       break;
/*     */     case 5:
/* 129 */       newW = h;
/* 130 */       newH = w;
/* 131 */       newX = y;
/* 132 */       newY = width - (x + w);
/* 133 */       break;
/*     */     case 6:
/* 135 */       newX = width - (x + w);
/* 136 */       newY = height - (y + h);
/*     */     }
/*     */ 
/* 140 */     int[] newPixels = new int[newW * newH];
/*     */ 
/* 142 */     for (int row = 0; row < h; row++) {
/* 143 */       for (int col = 0; col < w; col++) {
/* 144 */         int index = row * width + col;
/* 145 */         int newRow = row;
/* 146 */         int newCol = col;
/* 147 */         switch (this.operation) {
/*     */         case 1:
/* 149 */           newCol = w - col - 1;
/* 150 */           break;
/*     */         case 2:
/* 152 */           newRow = h - row - 1;
/* 153 */           break;
/*     */         case 3:
/* 155 */           newRow = col;
/* 156 */           newCol = row;
/* 157 */           break;
/*     */         case 4:
/* 159 */           newRow = col;
/* 160 */           newCol = h - row - 1;
/* 161 */           break;
/*     */         case 5:
/* 163 */           newRow = w - col - 1;
/* 164 */           newCol = row;
/* 165 */           break;
/*     */         case 6:
/* 167 */           newRow = h - row - 1;
/* 168 */           newCol = w - col - 1;
/*     */         }
/*     */ 
/* 171 */         int newIndex = newRow * newW + newCol;
/* 172 */         newPixels[newIndex] = inPixels[index];
/*     */       }
/*     */     }
/*     */ 
/* 176 */     if (dst == null) {
/* 177 */       ColorModel dstCM = src.getColorModel();
/* 178 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(newW, newH), dstCM.isAlphaPremultiplied(), null);
/*     */     }
/* 180 */     WritableRaster dstRaster = dst.getRaster();
/* 181 */     setRGB(dst, 0, 0, newW, newH, newPixels);
/*     */ 
/* 183 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 187 */     switch (this.operation) {
/*     */     case 1:
/* 189 */       return "Flip Horizontal";
/*     */     case 2:
/* 191 */       return "Flip Vertical";
/*     */     case 3:
/* 193 */       return "Flip Diagonal";
/*     */     case 4:
/* 195 */       return "Rotate 90";
/*     */     case 5:
/* 197 */       return "Rotate -90";
/*     */     case 6:
/* 199 */       return "Rotate 180";
/*     */     }
/* 201 */     return "Flip";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FlipFilter
 * JD-Core Version:    0.6.1
 */