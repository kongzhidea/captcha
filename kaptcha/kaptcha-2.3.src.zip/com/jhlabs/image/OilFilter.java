/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class OilFilter extends WholeImageFilter
/*     */ {
/*  27 */   private int range = 3;
/*  28 */   private int levels = 256;
/*     */ 
/*     */   public void setRange(int range)
/*     */   {
/*  39 */     this.range = range;
/*     */   }
/*     */ 
/*     */   public int getRange()
/*     */   {
/*  48 */     return this.range;
/*     */   }
/*     */ 
/*     */   public void setLevels(int levels)
/*     */   {
/*  57 */     this.levels = levels;
/*     */   }
/*     */ 
/*     */   public int getLevels()
/*     */   {
/*  66 */     return this.levels;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  70 */     int index = 0;
/*  71 */     int[] rHistogram = new int[this.levels];
/*  72 */     int[] gHistogram = new int[this.levels];
/*  73 */     int[] bHistogram = new int[this.levels];
/*  74 */     int[] rTotal = new int[this.levels];
/*  75 */     int[] gTotal = new int[this.levels];
/*  76 */     int[] bTotal = new int[this.levels];
/*  77 */     int[] outPixels = new int[width * height];
/*     */ 
/*  79 */     for (int y = 0; y < height; y++) {
/*  80 */       for (int x = 0; x < width; x++) {
/*  81 */         for (int i = 0; i < this.levels; i++)
/*     */         {
/*     */           int tmp121_120 = (bHistogram[i] = rTotal[i] = gTotal[i] = bTotal[i] = 0); gHistogram[i] = tmp121_120; rHistogram[i] = tmp121_120;
/*     */         }
/*  84 */         for (int row = -this.range; row <= this.range; row++) {
/*  85 */           int iy = y + row;
/*     */ 
/*  87 */           if ((0 <= iy) && (iy < height)) {
/*  88 */             int ioffset = iy * width;
/*  89 */             for (int col = -this.range; col <= this.range; col++) {
/*  90 */               int ix = x + col;
/*  91 */               if ((0 <= ix) && (ix < width)) {
/*  92 */                 int rgb = inPixels[(ioffset + ix)];
/*  93 */                 int r = rgb >> 16 & 0xFF;
/*  94 */                 int g = rgb >> 8 & 0xFF;
/*  95 */                 int b = rgb & 0xFF;
/*  96 */                 int ri = r * this.levels / 256;
/*  97 */                 int gi = g * this.levels / 256;
/*  98 */                 int bi = b * this.levels / 256;
/*  99 */                 rTotal[ri] += r;
/* 100 */                 gTotal[gi] += g;
/* 101 */                 bTotal[bi] += b;
/* 102 */                 rHistogram[ri] += 1;
/* 103 */                 gHistogram[gi] += 1;
/* 104 */                 bHistogram[bi] += 1;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 110 */         int r = 0; int g = 0; int b = 0;
/* 111 */         for (int i = 1; i < this.levels; i++) {
/* 112 */           if (rHistogram[i] > rHistogram[r])
/* 113 */             r = i;
/* 114 */           if (gHistogram[i] > gHistogram[g])
/* 115 */             g = i;
/* 116 */           if (bHistogram[i] > bHistogram[b])
/* 117 */             b = i;
/*     */         }
/* 119 */         r = rTotal[r] / rHistogram[r];
/* 120 */         g = gTotal[g] / gHistogram[g];
/* 121 */         b = bTotal[b] / bHistogram[b];
/* 122 */         outPixels[(index++)] = (0xFF000000 | r << 16 | g << 8 | b);
/*     */       }
/*     */     }
/* 125 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 129 */     return "Stylize/Oil...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.OilFilter
 * JD-Core Version:    0.6.1
 */