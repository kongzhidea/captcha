package com.jhlabs.image;

public abstract interface Quantizer
{
  public abstract void setup(int paramInt);

  public abstract void addPixels(int[] paramArrayOfInt, int paramInt1, int paramInt2);

  public abstract int[] buildColorTable();

  public abstract int getIndexForColor(int paramInt);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Quantizer
 * JD-Core Version:    0.6.1
 */