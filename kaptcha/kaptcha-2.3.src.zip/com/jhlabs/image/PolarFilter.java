/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class PolarFilter extends TransformFilter
/*     */ {
/*     */   public static final int RECT_TO_POLAR = 0;
/*     */   public static final int POLAR_TO_RECT = 1;
/*     */   public static final int INVERT_IN_CIRCLE = 2;
/*     */   private int type;
/*     */   private float width;
/*     */   private float height;
/*     */   private float centreX;
/*     */   private float centreY;
/*     */   private float radius;
/*     */ 
/*     */   public PolarFilter()
/*     */   {
/*  51 */     this(0);
/*     */   }
/*     */ 
/*     */   public PolarFilter(int type)
/*     */   {
/*  59 */     this.type = type;
/*  60 */     setEdgeAction(1);
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  64 */     this.width = src.getWidth();
/*  65 */     this.height = src.getHeight();
/*  66 */     this.centreX = (this.width / 2.0F);
/*  67 */     this.centreY = (this.height / 2.0F);
/*  68 */     this.radius = Math.max(this.centreY, this.centreX);
/*  69 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   public void setType(int type)
/*     */   {
/*  78 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/*  87 */     return this.type;
/*     */   }
/*     */ 
/*     */   private float sqr(float x) {
/*  91 */     return x * x;
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out)
/*     */   {
/*  97 */     float r = 0.0F;
/*     */     float theta;
/*     */     float m;
/*     */     float ymax;
/*     */     float xmax;
/*  99 */     switch (this.type) {
/*     */     case 0:
/* 101 */       theta = 0.0F;
/* 102 */       if (x >= this.centreX) {
/* 103 */         if (y > this.centreY) {
/* 104 */           theta = 3.141593F - (float)Math.atan((x - this.centreX) / (y - this.centreY));
/* 105 */           r = (float)Math.sqrt(sqr(x - this.centreX) + sqr(y - this.centreY));
/* 106 */         } else if (y < this.centreY) {
/* 107 */           theta = (float)Math.atan((x - this.centreX) / (this.centreY - y));
/* 108 */           r = (float)Math.sqrt(sqr(x - this.centreX) + sqr(this.centreY - y));
/*     */         } else {
/* 110 */           theta = 1.570796F;
/* 111 */           r = x - this.centreX;
/*     */         }
/* 113 */       } else if (x < this.centreX)
/* 114 */         if (y < this.centreY) {
/* 115 */           theta = 6.283186F - (float)Math.atan((this.centreX - x) / (this.centreY - y));
/* 116 */           r = (float)Math.sqrt(sqr(this.centreX - x) + sqr(this.centreY - y));
/* 117 */         } else if (y > this.centreY) {
/* 118 */           theta = 3.141593F + (float)Math.atan((this.centreX - x) / (y - this.centreY));
/* 119 */           r = (float)Math.sqrt(sqr(this.centreX - x) + sqr(y - this.centreY));
/*     */         } else {
/* 121 */           theta = 4.712389F;
/* 122 */           r = this.centreX - x;
/*     */         }
/*     */       float m;
/* 125 */       if (x != this.centreX)
/* 126 */         m = Math.abs((y - this.centreY) / (x - this.centreX));
/*     */       else
/* 128 */         m = 0.0F;
/*     */       float ymax;
/* 130 */       if (m <= this.height / this.width)
/*     */       {
/*     */         float ymax;
/* 131 */         if (x == this.centreX) {
/* 132 */           float xmax = 0.0F;
/* 133 */           ymax = this.centreY;
/*     */         } else {
/* 135 */           float xmax = this.centreX;
/* 136 */           ymax = m * xmax;
/*     */         }
/*     */       } else {
/* 139 */         ymax = this.centreY;
/* 140 */         xmax = ymax / m;
/*     */       }
/*     */ 
/* 143 */       out[0] = (this.width - 1.0F - (this.width - 1.0F) / 6.283186F * theta);
/* 144 */       out[1] = (this.height * r / this.radius);
/* 145 */       break;
/*     */     case 1:
/* 147 */       theta = x / this.width * 6.283186F;
/*     */       float theta2;
/*     */       float theta2;
/* 150 */       if (theta >= 4.712389F) {
/* 151 */         theta2 = 6.283186F - theta;
/*     */       }
/*     */       else
/*     */       {
/*     */         float theta2;
/* 152 */         if (theta >= 3.141593F) {
/* 153 */           theta2 = theta - 3.141593F;
/*     */         }
/*     */         else
/*     */         {
/*     */           float theta2;
/* 154 */           if (theta >= 1.570796F)
/* 155 */             theta2 = 3.141593F - theta;
/*     */           else
/* 157 */             theta2 = theta; 
/*     */         }
/*     */       }
/* 159 */       float t = (float)Math.tan(theta2);
/*     */       float m;
/* 160 */       if (t != 0.0F)
/* 161 */         m = 1.0F / t;
/*     */       else
/* 163 */         m = 0.0F;
/*     */       float ymax;
/*     */       float xmax;
/* 165 */       if (m <= this.height / this.width) {
/* 166 */         if (theta2 == 0.0F) {
/* 167 */           xmax = 0.0F;
/* 168 */           ymax = this.centreY;
/*     */         } else {
/* 170 */           float xmax = this.centreX;
/* 171 */           ymax = m * xmax;
/*     */         }
/*     */       } else {
/* 174 */         float ymax = this.centreY;
/* 175 */         xmax = ymax / m;
/*     */       }
/*     */ 
/* 178 */       r = this.radius * (y / this.height);
/*     */ 
/* 180 */       float nx = -r * (float)Math.sin(theta2);
/* 181 */       float ny = r * (float)Math.cos(theta2);
/*     */ 
/* 183 */       if (theta >= 4.712389F) {
/* 184 */         out[0] = (this.centreX - nx);
/* 185 */         out[1] = (this.centreY - ny);
/* 186 */       } else if (theta >= 3.141592653589793D) {
/* 187 */         out[0] = (this.centreX - nx);
/* 188 */         out[1] = (this.centreY + ny);
/* 189 */       } else if (theta >= 1.570796326794897D) {
/* 190 */         out[0] = (this.centreX + nx);
/* 191 */         out[1] = (this.centreY + ny);
/*     */       } else {
/* 193 */         out[0] = (this.centreX + nx);
/* 194 */         out[1] = (this.centreY - ny);
/*     */       }
/* 196 */       break;
/*     */     case 2:
/* 198 */       float dx = x - this.centreX;
/* 199 */       float dy = y - this.centreY;
/* 200 */       float distance2 = dx * dx + dy * dy;
/* 201 */       out[0] = (this.centreX + this.centreX * this.centreX * dx / distance2);
/* 202 */       out[1] = (this.centreY + this.centreY * this.centreY * dy / distance2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 208 */     return "Distort/Polar Coordinates...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PolarFilter
 * JD-Core Version:    0.6.1
 */