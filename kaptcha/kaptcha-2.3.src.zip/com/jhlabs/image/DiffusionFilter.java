/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class DiffusionFilter extends WholeImageFilter
/*     */ {
/*  27 */   private static final int[] diffusionMatrix = { 0, 0, 0, 0, 0, 7, 3, 5, 1 };
/*     */   private int[] matrix;
/*  34 */   private int sum = 16;
/*  35 */   private boolean serpentine = true;
/*  36 */   private boolean colorDither = true;
/*  37 */   private int levels = 6;
/*     */ 
/*     */   public DiffusionFilter()
/*     */   {
/*  43 */     setMatrix(diffusionMatrix);
/*     */   }
/*     */ 
/*     */   public void setSerpentine(boolean serpentine)
/*     */   {
/*  52 */     this.serpentine = serpentine;
/*     */   }
/*     */ 
/*     */   public boolean getSerpentine()
/*     */   {
/*  61 */     return this.serpentine;
/*     */   }
/*     */ 
/*     */   public void setColorDither(boolean colorDither)
/*     */   {
/*  70 */     this.colorDither = colorDither;
/*     */   }
/*     */ 
/*     */   public boolean getColorDither()
/*     */   {
/*  79 */     return this.colorDither;
/*     */   }
/*     */ 
/*     */   public void setMatrix(int[] matrix)
/*     */   {
/*  88 */     this.matrix = matrix;
/*  89 */     this.sum = 0;
/*  90 */     for (int i = 0; i < matrix.length; i++)
/*  91 */       this.sum += matrix[i];
/*     */   }
/*     */ 
/*     */   public int[] getMatrix()
/*     */   {
/* 100 */     return this.matrix;
/*     */   }
/*     */ 
/*     */   public void setLevels(int levels)
/*     */   {
/* 109 */     this.levels = levels;
/*     */   }
/*     */ 
/*     */   public int getLevels()
/*     */   {
/* 118 */     return this.levels;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 122 */     int[] outPixels = new int[width * height];
/*     */ 
/* 124 */     int index = 0;
/* 125 */     int[] map = new int[this.levels];
/* 126 */     for (int i = 0; i < this.levels; i++) {
/* 127 */       int v = 255 * i / (this.levels - 1);
/* 128 */       map[i] = v;
/*     */     }
/* 130 */     int[] div = new int[256];
/* 131 */     for (int i = 0; i < 256; i++) {
/* 132 */       div[i] = (this.levels * i / 256);
/*     */     }
/* 134 */     for (int y = 0; y < height; y++) {
/* 135 */       boolean reverse = (this.serpentine) && ((y & 0x1) == 1);
/*     */       int direction;
/*     */       int direction;
/* 137 */       if (reverse) {
/* 138 */         index = y * width + width - 1;
/* 139 */         direction = -1;
/*     */       } else {
/* 141 */         index = y * width;
/* 142 */         direction = 1;
/*     */       }
/* 144 */       for (int x = 0; x < width; x++) {
/* 145 */         int rgb1 = inPixels[index];
/*     */ 
/* 147 */         int r1 = rgb1 >> 16 & 0xFF;
/* 148 */         int g1 = rgb1 >> 8 & 0xFF;
/* 149 */         int b1 = rgb1 & 0xFF;
/*     */ 
/* 151 */         if (!this.colorDither) {
/* 152 */           r1 = g1 = b1 = (r1 + g1 + b1) / 3;
/*     */         }
/* 154 */         int r2 = map[div[r1]];
/* 155 */         int g2 = map[div[g1]];
/* 156 */         int b2 = map[div[b1]];
/*     */ 
/* 158 */         outPixels[index] = (0xFF000000 | r2 << 16 | g2 << 8 | b2);
/*     */ 
/* 160 */         int er = r1 - r2;
/* 161 */         int eg = g1 - g2;
/* 162 */         int eb = b1 - b2;
/*     */ 
/* 164 */         for (int i = -1; i <= 1; i++) {
/* 165 */           int iy = i + y;
/* 166 */           if ((0 <= iy) && (iy < height)) {
/* 167 */             for (int j = -1; j <= 1; j++) {
/* 168 */               int jx = j + x;
/* 169 */               if ((0 <= jx) && (jx < width))
/*     */               {
/*     */                 int w;
/*     */                 int w;
/* 171 */                 if (reverse)
/* 172 */                   w = this.matrix[((i + 1) * 3 - j + 1)];
/*     */                 else
/* 174 */                   w = this.matrix[((i + 1) * 3 + j + 1)];
/* 175 */                 if (w != 0) {
/* 176 */                   int k = reverse ? index - j : index + j;
/* 177 */                   rgb1 = inPixels[k];
/* 178 */                   r1 = rgb1 >> 16 & 0xFF;
/* 179 */                   g1 = rgb1 >> 8 & 0xFF;
/* 180 */                   b1 = rgb1 & 0xFF;
/* 181 */                   r1 += er * w / this.sum;
/* 182 */                   g1 += eg * w / this.sum;
/* 183 */                   b1 += eb * w / this.sum;
/* 184 */                   inPixels[k] = (PixelUtils.clamp(r1) << 16 | PixelUtils.clamp(g1) << 8 | PixelUtils.clamp(b1));
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 190 */         index += direction;
/*     */       }
/*     */     }
/*     */ 
/* 194 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 198 */     return "Colors/Diffusion Dither...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DiffusionFilter
 * JD-Core Version:    0.6.1
 */