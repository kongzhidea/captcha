/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.BufferedImageOp;
/*    */ 
/*    */ public class CompoundFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   private BufferedImageOp filter1;
/*    */   private BufferedImageOp filter2;
/*    */ 
/*    */   public CompoundFilter(BufferedImageOp filter1, BufferedImageOp filter2)
/*    */   {
/* 34 */     this.filter1 = filter1;
/* 35 */     this.filter2 = filter2;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 39 */     BufferedImage image = this.filter1.filter(src, dst);
/* 40 */     image = this.filter2.filter(image, dst);
/* 41 */     return image;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CompoundFilter
 * JD-Core Version:    0.6.1
 */