/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.CellularFunction2D;
/*     */ import com.jhlabs.math.FBM;
/*     */ import com.jhlabs.math.Function2D;
/*     */ import com.jhlabs.math.Noise;
/*     */ import com.jhlabs.math.RidgedFBM;
/*     */ import com.jhlabs.math.SCNoise;
/*     */ import com.jhlabs.math.VLNoise;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class FBMFilter extends PointFilter
/*     */   implements Cloneable
/*     */ {
/*     */   public static final int NOISE = 0;
/*     */   public static final int RIDGED = 1;
/*     */   public static final int VLNOISE = 2;
/*     */   public static final int SCNOISE = 3;
/*     */   public static final int CELLULAR = 4;
/*  34 */   private float scale = 32.0F;
/*  35 */   private float stretch = 1.0F;
/*  36 */   private float angle = 0.0F;
/*  37 */   private float amount = 1.0F;
/*  38 */   private float H = 1.0F;
/*  39 */   private float octaves = 4.0F;
/*  40 */   private float lacunarity = 2.0F;
/*  41 */   private float gain = 0.5F;
/*  42 */   private float bias = 0.5F;
/*     */   private int operation;
/*  44 */   private float m00 = 1.0F;
/*  45 */   private float m01 = 0.0F;
/*  46 */   private float m10 = 0.0F;
/*  47 */   private float m11 = 1.0F;
/*     */   private float min;
/*     */   private float max;
/*  50 */   private Colormap colormap = new Gradient();
/*     */   private boolean ridged;
/*     */   private FBM fBm;
/*  53 */   protected Random random = new Random();
/*  54 */   private int basisType = 0;
/*     */   private Function2D basis;
/*     */ 
/*     */   public FBMFilter()
/*     */   {
/*  58 */     setBasisType(0);
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  69 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  78 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setOperation(int operation) {
/*  82 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */   public int getOperation() {
/*  86 */     return this.operation;
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  97 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/* 106 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setStretch(float stretch)
/*     */   {
/* 117 */     this.stretch = stretch;
/*     */   }
/*     */ 
/*     */   public float getStretch()
/*     */   {
/* 126 */     return this.stretch;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 136 */     this.angle = angle;
/* 137 */     float cos = (float)Math.cos(this.angle);
/* 138 */     float sin = (float)Math.sin(this.angle);
/* 139 */     this.m00 = cos;
/* 140 */     this.m01 = sin;
/* 141 */     this.m10 = (-sin);
/* 142 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 151 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setOctaves(float octaves) {
/* 155 */     this.octaves = octaves;
/*     */   }
/*     */ 
/*     */   public float getOctaves() {
/* 159 */     return this.octaves;
/*     */   }
/*     */ 
/*     */   public void setH(float H) {
/* 163 */     this.H = H;
/*     */   }
/*     */ 
/*     */   public float getH() {
/* 167 */     return this.H;
/*     */   }
/*     */ 
/*     */   public void setLacunarity(float lacunarity) {
/* 171 */     this.lacunarity = lacunarity;
/*     */   }
/*     */ 
/*     */   public float getLacunarity() {
/* 175 */     return this.lacunarity;
/*     */   }
/*     */ 
/*     */   public void setGain(float gain) {
/* 179 */     this.gain = gain;
/*     */   }
/*     */ 
/*     */   public float getGain() {
/* 183 */     return this.gain;
/*     */   }
/*     */ 
/*     */   public void setBias(float bias) {
/* 187 */     this.bias = bias;
/*     */   }
/*     */ 
/*     */   public float getBias() {
/* 191 */     return this.bias;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 200 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 209 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public void setBasisType(int basisType) {
/* 213 */     this.basisType = basisType;
/* 214 */     switch (basisType) {
/*     */     case 0:
/*     */     default:
/* 217 */       this.basis = new Noise();
/* 218 */       break;
/*     */     case 1:
/* 220 */       this.basis = new RidgedFBM();
/* 221 */       break;
/*     */     case 2:
/* 223 */       this.basis = new VLNoise();
/* 224 */       break;
/*     */     case 3:
/* 226 */       this.basis = new SCNoise();
/* 227 */       break;
/*     */     case 4:
/* 229 */       this.basis = new CellularFunction2D();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getBasisType()
/*     */   {
/* 235 */     return this.basisType;
/*     */   }
/*     */ 
/*     */   public void setBasis(Function2D basis) {
/* 239 */     this.basis = basis;
/*     */   }
/*     */ 
/*     */   public Function2D getBasis() {
/* 243 */     return this.basis;
/*     */   }
/*     */ 
/*     */   protected FBM makeFBM(float H, float lacunarity, float octaves) {
/* 247 */     FBM fbm = new FBM(H, lacunarity, octaves, this.basis);
/* 248 */     float[] minmax = Noise.findRange(fbm, null);
/* 249 */     this.min = minmax[0];
/* 250 */     this.max = minmax[1];
/* 251 */     return fbm;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 255 */     this.fBm = makeFBM(this.H, this.lacunarity, this.octaves);
/* 256 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 260 */     float nx = this.m00 * x + this.m01 * y;
/* 261 */     float ny = this.m10 * x + this.m11 * y;
/* 262 */     nx /= this.scale;
/* 263 */     ny /= this.scale * this.stretch;
/* 264 */     float f = this.fBm.evaluate(nx, ny);
/*     */ 
/* 266 */     f = (f - this.min) / (this.max - this.min);
/* 267 */     f = ImageMath.gain(f, this.gain);
/* 268 */     f = ImageMath.bias(f, this.bias);
/* 269 */     f *= this.amount;
/* 270 */     int a = rgb & 0xFF000000;
/*     */     int v;
/*     */     int v;
/* 272 */     if (this.colormap != null) {
/* 273 */       v = this.colormap.getColor(f);
/*     */     } else {
/* 275 */       v = PixelUtils.clamp((int)(f * 255.0F));
/* 276 */       int r = v << 16;
/* 277 */       int g = v << 8;
/* 278 */       int b = v;
/* 279 */       v = a | r | g | b;
/*     */     }
/* 281 */     if (this.operation != 0)
/* 282 */       v = PixelUtils.combinePixels(rgb, v, this.operation);
/* 283 */     return v;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 287 */     return "Texture/Fractal Brownian Motion...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FBMFilter
 * JD-Core Version:    0.6.1
 */