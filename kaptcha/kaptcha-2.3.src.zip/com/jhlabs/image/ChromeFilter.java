/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class ChromeFilter extends LightFilter
/*    */ {
/* 25 */   private float amount = 0.5F;
/* 26 */   private float exposure = 1.0F;
/*    */ 
/*    */   public void setAmount(float amount)
/*    */   {
/* 36 */     this.amount = amount;
/*    */   }
/*    */ 
/*    */   public float getAmount()
/*    */   {
/* 45 */     return this.amount;
/*    */   }
/*    */ 
/*    */   public void setExposure(float exposure)
/*    */   {
/* 56 */     this.exposure = exposure;
/*    */   }
/*    */ 
/*    */   public float getExposure()
/*    */   {
/* 65 */     return this.exposure;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 69 */     setColorSource(1);
/* 70 */     dst = super.filter(src, dst);
/* 71 */     TransferFilter tf = new TransferFilter() {
/*    */       protected float transferFunction(float v) {
/* 73 */         v += ChromeFilter.this.amount * (float)Math.sin(v * 2.0F * 3.141592653589793D);
/* 74 */         return 1.0F - (float)Math.exp(-v * ChromeFilter.this.exposure);
/*    */       }
/*    */     };
/* 77 */     return tf.filter(dst, dst);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 81 */     return "Effects/Chrome...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ChromeFilter
 * JD-Core Version:    0.6.1
 */