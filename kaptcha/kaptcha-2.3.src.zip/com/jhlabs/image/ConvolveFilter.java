/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Kernel;
/*     */ 
/*     */ public class ConvolveFilter extends AbstractBufferedImageOp
/*     */ {
/*  32 */   public static int ZERO_EDGES = 0;
/*     */ 
/*  37 */   public static int CLAMP_EDGES = 1;
/*     */ 
/*  42 */   public static int WRAP_EDGES = 2;
/*     */ 
/*  47 */   protected Kernel kernel = null;
/*     */ 
/*  52 */   protected boolean alpha = true;
/*     */ 
/*  57 */   protected boolean premultiplyAlpha = true;
/*     */ 
/*  62 */   private int edgeAction = CLAMP_EDGES;
/*     */ 
/*     */   public ConvolveFilter()
/*     */   {
/*  68 */     this(new float[9]);
/*     */   }
/*     */ 
/*     */   public ConvolveFilter(float[] matrix)
/*     */   {
/*  76 */     this(new Kernel(3, 3, matrix));
/*     */   }
/*     */ 
/*     */   public ConvolveFilter(int rows, int cols, float[] matrix)
/*     */   {
/*  86 */     this(new Kernel(cols, rows, matrix));
/*     */   }
/*     */ 
/*     */   public ConvolveFilter(Kernel kernel)
/*     */   {
/*  94 */     this.kernel = kernel;
/*     */   }
/*     */ 
/*     */   public void setKernel(Kernel kernel)
/*     */   {
/* 103 */     this.kernel = kernel;
/*     */   }
/*     */ 
/*     */   public Kernel getKernel()
/*     */   {
/* 112 */     return this.kernel;
/*     */   }
/*     */ 
/*     */   public void setEdgeAction(int edgeAction)
/*     */   {
/* 121 */     this.edgeAction = edgeAction;
/*     */   }
/*     */ 
/*     */   public int getEdgeAction()
/*     */   {
/* 130 */     return this.edgeAction;
/*     */   }
/*     */ 
/*     */   public void setUseAlpha(boolean useAlpha)
/*     */   {
/* 139 */     this.alpha = useAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getUseAlpha()
/*     */   {
/* 148 */     return this.alpha;
/*     */   }
/*     */ 
/*     */   public void setPremultiplyAlpha(boolean premultiplyAlpha)
/*     */   {
/* 157 */     this.premultiplyAlpha = premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getPremultiplyAlpha()
/*     */   {
/* 166 */     return this.premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 170 */     int width = src.getWidth();
/* 171 */     int height = src.getHeight();
/*     */ 
/* 173 */     if (dst == null) {
/* 174 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/* 176 */     int[] inPixels = new int[width * height];
/* 177 */     int[] outPixels = new int[width * height];
/* 178 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */ 
/* 180 */     if (this.premultiplyAlpha)
/* 181 */       ImageMath.premultiply(inPixels, 0, inPixels.length);
/* 182 */     convolve(this.kernel, inPixels, outPixels, width, height, this.alpha, this.edgeAction);
/* 183 */     if (this.premultiplyAlpha) {
/* 184 */       ImageMath.unpremultiply(outPixels, 0, outPixels.length);
/*     */     }
/* 186 */     setRGB(dst, 0, 0, width, height, outPixels);
/* 187 */     return dst;
/*     */   }
/*     */ 
/*     */   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
/* 191 */     if (dstCM == null)
/* 192 */       dstCM = src.getColorModel();
/* 193 */     return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
/*     */   }
/*     */ 
/*     */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 197 */     return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/*     */   }
/*     */ 
/*     */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 201 */     if (dstPt == null)
/* 202 */       dstPt = new Point2D.Double();
/* 203 */     dstPt.setLocation(srcPt.getX(), srcPt.getY());
/* 204 */     return dstPt;
/*     */   }
/*     */ 
/*     */   public RenderingHints getRenderingHints() {
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */   public static void convolve(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, int edgeAction)
/*     */   {
/* 221 */     convolve(kernel, inPixels, outPixels, width, height, true, edgeAction);
/*     */   }
/*     */ 
/*     */   public static void convolve(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha, int edgeAction)
/*     */   {
/* 235 */     if (kernel.getHeight() == 1)
/* 236 */       convolveH(kernel, inPixels, outPixels, width, height, alpha, edgeAction);
/* 237 */     else if (kernel.getWidth() == 1)
/* 238 */       convolveV(kernel, inPixels, outPixels, width, height, alpha, edgeAction);
/*     */     else
/* 240 */       convolveHV(kernel, inPixels, outPixels, width, height, alpha, edgeAction);
/*     */   }
/*     */ 
/*     */   public static void convolveHV(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha, int edgeAction)
/*     */   {
/* 254 */     int index = 0;
/* 255 */     float[] matrix = kernel.getKernelData(null);
/* 256 */     int rows = kernel.getHeight();
/* 257 */     int cols = kernel.getWidth();
/* 258 */     int rows2 = rows / 2;
/* 259 */     int cols2 = cols / 2;
/*     */ 
/* 261 */     for (int y = 0; y < height; y++)
/* 262 */       for (int x = 0; x < width; x++) {
/* 263 */         float r = 0.0F; float g = 0.0F; float b = 0.0F; float a = 0.0F;
/*     */ 
/* 265 */         for (int row = -rows2; row <= rows2; row++) {
/* 266 */           int iy = y + row;
/*     */           int ioffset;
/*     */           int ioffset;
/* 268 */           if ((0 <= iy) && (iy < height)) {
/* 269 */             ioffset = iy * width;
/*     */           }
/*     */           else
/*     */           {
/*     */             int ioffset;
/* 270 */             if (edgeAction == CLAMP_EDGES) {
/* 271 */               ioffset = y * width; } else {
/* 272 */               if (edgeAction != WRAP_EDGES) continue;
/* 273 */               ioffset = (iy + height) % height * width;
/*     */             }
/*     */           }
/* 276 */           int moffset = cols * (row + rows2) + cols2;
/* 277 */           for (int col = -cols2; col <= cols2; col++) {
/* 278 */             float f = matrix[(moffset + col)];
/*     */ 
/* 280 */             if (f != 0.0F) {
/* 281 */               int ix = x + col;
/* 282 */               if ((0 > ix) || (ix >= width)) {
/* 283 */                 if (edgeAction == CLAMP_EDGES) {
/* 284 */                   ix = x; } else {
/* 285 */                   if (edgeAction != WRAP_EDGES) continue;
/* 286 */                   ix = (x + width) % width;
/*     */                 }
/*     */               }
/*     */ 
/* 290 */               int rgb = inPixels[(ioffset + ix)];
/* 291 */               a += f * rgb >> 24 & 0xFF;
/* 292 */               r += f * rgb >> 16 & 0xFF;
/* 293 */               g += f * rgb >> 8 & 0xFF;
/* 294 */               b += f * rgb & 0xFF;
/*     */             }
/*     */           }
/*     */         }
/* 298 */         int ia = alpha ? PixelUtils.clamp((int)(a + 0.5D)) : 255;
/* 299 */         int ir = PixelUtils.clamp((int)(r + 0.5D));
/* 300 */         int ig = PixelUtils.clamp((int)(g + 0.5D));
/* 301 */         int ib = PixelUtils.clamp((int)(b + 0.5D));
/* 302 */         outPixels[(index++)] = (ia << 24 | ir << 16 | ig << 8 | ib);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void convolveH(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha, int edgeAction)
/*     */   {
/* 318 */     int index = 0;
/* 319 */     float[] matrix = kernel.getKernelData(null);
/* 320 */     int cols = kernel.getWidth();
/* 321 */     int cols2 = cols / 2;
/*     */ 
/* 323 */     for (int y = 0; y < height; y++) {
/* 324 */       int ioffset = y * width;
/* 325 */       for (int x = 0; x < width; x++) {
/* 326 */         float r = 0.0F; float g = 0.0F; float b = 0.0F; float a = 0.0F;
/* 327 */         int moffset = cols2;
/* 328 */         for (int col = -cols2; col <= cols2; col++) {
/* 329 */           float f = matrix[(moffset + col)];
/*     */ 
/* 331 */           if (f != 0.0F) {
/* 332 */             int ix = x + col;
/* 333 */             if (ix < 0) {
/* 334 */               if (edgeAction == CLAMP_EDGES)
/* 335 */                 ix = 0;
/* 336 */               else if (edgeAction == WRAP_EDGES)
/* 337 */                 ix = (x + width) % width;
/* 338 */             } else if (ix >= width) {
/* 339 */               if (edgeAction == CLAMP_EDGES)
/* 340 */                 ix = width - 1;
/* 341 */               else if (edgeAction == WRAP_EDGES)
/* 342 */                 ix = (x + width) % width;
/*     */             }
/* 344 */             int rgb = inPixels[(ioffset + ix)];
/* 345 */             a += f * rgb >> 24 & 0xFF;
/* 346 */             r += f * rgb >> 16 & 0xFF;
/* 347 */             g += f * rgb >> 8 & 0xFF;
/* 348 */             b += f * rgb & 0xFF;
/*     */           }
/*     */         }
/* 351 */         int ia = alpha ? PixelUtils.clamp((int)(a + 0.5D)) : 255;
/* 352 */         int ir = PixelUtils.clamp((int)(r + 0.5D));
/* 353 */         int ig = PixelUtils.clamp((int)(g + 0.5D));
/* 354 */         int ib = PixelUtils.clamp((int)(b + 0.5D));
/* 355 */         outPixels[(index++)] = (ia << 24 | ir << 16 | ig << 8 | ib);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void convolveV(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha, int edgeAction)
/*     */   {
/* 371 */     int index = 0;
/* 372 */     float[] matrix = kernel.getKernelData(null);
/* 373 */     int rows = kernel.getHeight();
/* 374 */     int rows2 = rows / 2;
/*     */ 
/* 376 */     for (int y = 0; y < height; y++)
/* 377 */       for (int x = 0; x < width; x++) {
/* 378 */         float r = 0.0F; float g = 0.0F; float b = 0.0F; float a = 0.0F;
/*     */ 
/* 380 */         for (int row = -rows2; row <= rows2; row++) {
/* 381 */           int iy = y + row;
/*     */           int ioffset;
/*     */           int ioffset;
/* 383 */           if (iy < 0)
/*     */           {
/*     */             int ioffset;
/* 384 */             if (edgeAction == CLAMP_EDGES) {
/* 385 */               ioffset = 0;
/*     */             }
/*     */             else
/*     */             {
/*     */               int ioffset;
/* 386 */               if (edgeAction == WRAP_EDGES)
/* 387 */                 ioffset = (y + height) % height * width;
/*     */               else
/* 389 */                 ioffset = iy * width;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*     */             int ioffset;
/* 390 */             if (iy >= height)
/*     */             {
/*     */               int ioffset;
/* 391 */               if (edgeAction == CLAMP_EDGES) {
/* 392 */                 ioffset = (height - 1) * width;
/*     */               }
/*     */               else
/*     */               {
/*     */                 int ioffset;
/* 393 */                 if (edgeAction == WRAP_EDGES)
/* 394 */                   ioffset = (y + height) % height * width;
/*     */                 else
/* 396 */                   ioffset = iy * width; 
/*     */               }
/*     */             } else { ioffset = iy * width; }
/*     */           }
/* 400 */           float f = matrix[(row + rows2)];
/*     */ 
/* 402 */           if (f != 0.0F) {
/* 403 */             int rgb = inPixels[(ioffset + x)];
/* 404 */             a += f * rgb >> 24 & 0xFF;
/* 405 */             r += f * rgb >> 16 & 0xFF;
/* 406 */             g += f * rgb >> 8 & 0xFF;
/* 407 */             b += f * rgb & 0xFF;
/*     */           }
/*     */         }
/* 410 */         int ia = alpha ? PixelUtils.clamp((int)(a + 0.5D)) : 255;
/* 411 */         int ir = PixelUtils.clamp((int)(r + 0.5D));
/* 412 */         int ig = PixelUtils.clamp((int)(g + 0.5D));
/* 413 */         int ib = PixelUtils.clamp((int)(b + 0.5D));
/* 414 */         outPixels[(index++)] = (ia << 24 | ir << 16 | ig << 8 | ib);
/*     */       }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 420 */     return "Blur/Convolve...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ConvolveFilter
 * JD-Core Version:    0.6.1
 */