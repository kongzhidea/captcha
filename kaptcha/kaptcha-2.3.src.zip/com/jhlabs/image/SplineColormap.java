/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class SplineColormap extends ArrayColormap
/*     */ {
/*  30 */   private int numKnots = 4;
/*  31 */   private int[] xKnots = { 0, 0, 255, 255 };
/*     */ 
/*  34 */   private int[] yKnots = { -16777216, -16777216, -1, -1 };
/*     */ 
/*     */   public SplineColormap()
/*     */   {
/*  42 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   public SplineColormap(int[] xKnots, int[] yKnots)
/*     */   {
/*  51 */     this.xKnots = xKnots;
/*  52 */     this.yKnots = yKnots;
/*  53 */     this.numKnots = xKnots.length;
/*  54 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   public void setKnot(int n, int color)
/*     */   {
/*  64 */     this.yKnots[n] = color;
/*  65 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   public int getKnot(int n)
/*     */   {
/*  75 */     return this.yKnots[n];
/*     */   }
/*     */ 
/*     */   public void addKnot(int x, int color)
/*     */   {
/*  85 */     int[] nx = new int[this.numKnots + 1];
/*  86 */     int[] ny = new int[this.numKnots + 1];
/*  87 */     System.arraycopy(this.xKnots, 0, nx, 0, this.numKnots);
/*  88 */     System.arraycopy(this.yKnots, 0, ny, 0, this.numKnots);
/*  89 */     this.xKnots = nx;
/*  90 */     this.yKnots = ny;
/*  91 */     this.xKnots[this.numKnots] = x;
/*  92 */     this.yKnots[this.numKnots] = color;
/*  93 */     this.numKnots += 1;
/*  94 */     sortKnots();
/*  95 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   public void removeKnot(int n)
/*     */   {
/* 104 */     if (this.numKnots <= 4)
/* 105 */       return;
/* 106 */     if (n < this.numKnots - 1) {
/* 107 */       System.arraycopy(this.xKnots, n + 1, this.xKnots, n, this.numKnots - n - 1);
/* 108 */       System.arraycopy(this.yKnots, n + 1, this.yKnots, n, this.numKnots - n - 1);
/*     */     }
/* 110 */     this.numKnots -= 1;
/* 111 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   public void setKnotPosition(int n, int x)
/*     */   {
/* 120 */     this.xKnots[n] = PixelUtils.clamp(x);
/* 121 */     sortKnots();
/* 122 */     rebuildGradient();
/*     */   }
/*     */ 
/*     */   private void rebuildGradient() {
/* 126 */     this.xKnots[0] = -1;
/* 127 */     this.xKnots[(this.numKnots - 1)] = 256;
/* 128 */     this.yKnots[0] = this.yKnots[1];
/* 129 */     this.yKnots[(this.numKnots - 1)] = this.yKnots[(this.numKnots - 2)];
/* 130 */     for (int i = 0; i < 256; i++)
/* 131 */       this.map[i] = ImageMath.colorSpline(i, this.numKnots, this.xKnots, this.yKnots);
/*     */   }
/*     */ 
/*     */   private void sortKnots() {
/* 135 */     for (int i = 1; i < this.numKnots; i++)
/* 136 */       for (int j = 1; j < i; j++)
/* 137 */         if (this.xKnots[i] < this.xKnots[j]) {
/* 138 */           int t = this.xKnots[i];
/* 139 */           this.xKnots[i] = this.xKnots[j];
/* 140 */           this.xKnots[j] = t;
/* 141 */           t = this.yKnots[i];
/* 142 */           this.yKnots[i] = this.yKnots[j];
/* 143 */           this.yKnots[j] = t;
/*     */         }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SplineColormap
 * JD-Core Version:    0.6.1
 */