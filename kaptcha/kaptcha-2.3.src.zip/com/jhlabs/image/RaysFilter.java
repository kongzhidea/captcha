/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.composite.MiscComposite;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class RaysFilter extends MotionBlurOp
/*     */ {
/*  29 */   private float opacity = 1.0F;
/*  30 */   private float threshold = 0.0F;
/*  31 */   private float strength = 0.5F;
/*  32 */   private boolean raysOnly = false;
/*     */   private Colormap colormap;
/*     */ 
/*     */   public void setOpacity(float opacity)
/*     */   {
/*  44 */     this.opacity = opacity;
/*     */   }
/*     */ 
/*     */   public float getOpacity()
/*     */   {
/*  53 */     return this.opacity;
/*     */   }
/*     */ 
/*     */   public void setThreshold(float threshold)
/*     */   {
/*  62 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public float getThreshold()
/*     */   {
/*  71 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void setStrength(float strength)
/*     */   {
/*  80 */     this.strength = strength;
/*     */   }
/*     */ 
/*     */   public float getStrength()
/*     */   {
/*  89 */     return this.strength;
/*     */   }
/*     */ 
/*     */   public void setRaysOnly(boolean raysOnly)
/*     */   {
/*  98 */     this.raysOnly = raysOnly;
/*     */   }
/*     */ 
/*     */   public boolean getRaysOnly()
/*     */   {
/* 107 */     return this.raysOnly;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 116 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 125 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 129 */     int width = src.getWidth();
/* 130 */     int height = src.getHeight();
/* 131 */     int[] pixels = new int[width];
/* 132 */     int[] srcPixels = new int[width];
/*     */ 
/* 134 */     BufferedImage rays = new BufferedImage(width, height, 2);
/*     */ 
/* 136 */     int threshold3 = (int)(this.threshold * 3.0F * 255.0F);
/* 137 */     for (int y = 0; y < height; y++) {
/* 138 */       getRGB(src, 0, y, width, 1, pixels);
/* 139 */       for (int x = 0; x < width; x++) {
/* 140 */         int rgb = pixels[x];
/* 141 */         int a = rgb & 0xFF000000;
/* 142 */         int r = rgb >> 16 & 0xFF;
/* 143 */         int g = rgb >> 8 & 0xFF;
/* 144 */         int b = rgb & 0xFF;
/* 145 */         int l = r + g + b;
/* 146 */         if (l < threshold3) {
/* 147 */           pixels[x] = -16777216;
/*     */         } else {
/* 149 */           l /= 3;
/* 150 */           pixels[x] = (a | l << 16 | l << 8 | l);
/*     */         }
/*     */       }
/* 153 */       setRGB(rays, 0, y, width, 1, pixels);
/*     */     }
/*     */ 
/* 156 */     rays = super.filter(rays, null);
/*     */ 
/* 158 */     for (int y = 0; y < height; y++) {
/* 159 */       getRGB(rays, 0, y, width, 1, pixels);
/* 160 */       getRGB(src, 0, y, width, 1, srcPixels);
/* 161 */       for (int x = 0; x < width; x++) {
/* 162 */         int rgb = pixels[x];
/* 163 */         int a = rgb & 0xFF000000;
/* 164 */         int r = rgb >> 16 & 0xFF;
/* 165 */         int g = rgb >> 8 & 0xFF;
/* 166 */         int b = rgb & 0xFF;
/*     */ 
/* 168 */         if (this.colormap != null) {
/* 169 */           int l = r + g + b;
/* 170 */           rgb = this.colormap.getColor(l * this.strength * 0.3333333F);
/*     */         } else {
/* 172 */           r = PixelUtils.clamp((int)(r * this.strength));
/* 173 */           g = PixelUtils.clamp((int)(g * this.strength));
/* 174 */           b = PixelUtils.clamp((int)(b * this.strength));
/* 175 */           rgb = a | r << 16 | g << 8 | b;
/*     */         }
/*     */ 
/* 178 */         pixels[x] = rgb;
/*     */       }
/* 180 */       setRGB(rays, 0, y, width, 1, pixels);
/*     */     }
/*     */ 
/* 183 */     if (dst == null) {
/* 184 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/* 186 */     Graphics2D g = dst.createGraphics();
/* 187 */     if (!this.raysOnly) {
/* 188 */       g.setComposite(AlphaComposite.SrcOver);
/* 189 */       g.drawRenderedImage(src, null);
/*     */     }
/* 191 */     g.setComposite(MiscComposite.getInstance(1, this.opacity));
/* 192 */     g.drawRenderedImage(rays, null);
/* 193 */     g.dispose();
/*     */ 
/* 195 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 199 */     return "Stylize/Rays...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RaysFilter
 * JD-Core Version:    0.6.1
 */