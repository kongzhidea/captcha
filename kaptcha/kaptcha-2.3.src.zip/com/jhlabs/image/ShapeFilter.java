/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class ShapeFilter extends WholeImageFilter
/*     */ {
/*     */   public static final int LINEAR = 0;
/*     */   public static final int CIRCLE_UP = 1;
/*     */   public static final int CIRCLE_DOWN = 2;
/*     */   public static final int SMOOTH = 3;
/*  36 */   private float factor = 1.0F;
/*     */   protected Colormap colormap;
/*  38 */   private boolean useAlpha = true;
/*  39 */   private boolean invert = false;
/*  40 */   private boolean merge = false;
/*     */   private int type;
/*     */   private static final int one = 41;
/*  44 */   private static final int sqrt2 = (int)(41.0D * Math.sqrt(2.0D));
/*  45 */   private static final int sqrt5 = (int)(41.0D * Math.sqrt(5.0D));
/*     */ 
/*     */   public ShapeFilter() {
/*  48 */     this.colormap = new LinearColormap();
/*     */   }
/*     */ 
/*     */   public void setFactor(float factor) {
/*  52 */     this.factor = factor;
/*     */   }
/*     */ 
/*     */   public float getFactor() {
/*  56 */     return this.factor;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/*  65 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/*  74 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public void setUseAlpha(boolean useAlpha) {
/*  78 */     this.useAlpha = useAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getUseAlpha() {
/*  82 */     return this.useAlpha;
/*     */   }
/*     */ 
/*     */   public void setType(int type) {
/*  86 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  90 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setInvert(boolean invert) {
/*  94 */     this.invert = invert;
/*     */   }
/*     */ 
/*     */   public boolean getInvert() {
/*  98 */     return this.invert;
/*     */   }
/*     */ 
/*     */   public void setMerge(boolean merge) {
/* 102 */     this.merge = merge;
/*     */   }
/*     */ 
/*     */   public boolean getMerge() {
/* 106 */     return this.merge;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 110 */     int[] map = new int[width * height];
/* 111 */     makeMap(inPixels, map, width, height);
/* 112 */     int max = distanceMap(map, width, height);
/* 113 */     applyMap(map, inPixels, width, height, max);
/*     */ 
/* 115 */     return inPixels;
/*     */   }
/*     */ 
/*     */   public int distanceMap(int[] map, int width, int height) {
/* 119 */     int xmax = width - 3;
/* 120 */     int ymax = height - 3;
/* 121 */     int max = 0;
/*     */ 
/* 124 */     for (int y = 0; y < height; y++) {
/* 125 */       for (int x = 0; x < width; x++) {
/* 126 */         int offset = x + y * width;
/* 127 */         if (map[offset] > 0)
/*     */         {
/*     */           int v;
/*     */           int v;
/* 128 */           if ((x < 2) || (x > xmax) || (y < 2) || (y > ymax))
/* 129 */             v = setEdgeValue(x, y, map, width, offset, xmax, ymax);
/*     */           else
/* 131 */             v = setValue(map, width, offset);
/* 132 */           if (v > max)
/* 133 */             max = v;
/*     */         }
/*     */       }
/*     */     }
/* 137 */     for (int y = height - 1; y >= 0; y--) {
/* 138 */       for (int x = width - 1; x >= 0; x--) {
/* 139 */         int offset = x + y * width;
/* 140 */         if (map[offset] > 0)
/*     */         {
/*     */           int v;
/*     */           int v;
/* 141 */           if ((x < 2) || (x > xmax) || (y < 2) || (y > ymax))
/* 142 */             v = setEdgeValue(x, y, map, width, offset, xmax, ymax);
/*     */           else
/* 144 */             v = setValue(map, width, offset);
/* 145 */           if (v > max)
/* 146 */             max = v;
/*     */         }
/*     */       }
/*     */     }
/* 150 */     return max;
/*     */   }
/*     */ 
/*     */   private void makeMap(int[] pixels, int[] map, int width, int height) {
/* 154 */     for (int y = 0; y < height; y++)
/* 155 */       for (int x = 0; x < width; x++) {
/* 156 */         int offset = x + y * width;
/* 157 */         int b = this.useAlpha ? pixels[offset] >> 24 & 0xFF : PixelUtils.brightness(pixels[offset]);
/*     */ 
/* 159 */         map[offset] = (b * 41 / 10);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void applyMap(int[] map, int[] pixels, int width, int height, int max)
/*     */   {
/* 165 */     if (max == 0)
/* 166 */       max = 1;
/* 167 */     for (int y = 0; y < height; y++)
/* 168 */       for (int x = 0; x < width; x++) {
/* 169 */         int offset = x + y * width;
/* 170 */         int m = map[offset];
/* 171 */         float v = 0.0F;
/* 172 */         int sa = 0; int sr = 0; int sg = 0; int sb = 0;
/*     */ 
/* 174 */         if (m == 0)
/*     */         {
/* 176 */           sa = sr = sg = sb = 0;
/* 177 */           sa = pixels[offset] >> 24 & 0xFF;
/*     */         }
/*     */         else {
/* 180 */           v = ImageMath.clamp(this.factor * m / max, 0.0F, 1.0F);
/* 181 */           switch (this.type) {
/*     */           case 1:
/* 183 */             v = ImageMath.circleUp(v);
/* 184 */             break;
/*     */           case 2:
/* 186 */             v = ImageMath.circleDown(v);
/* 187 */             break;
/*     */           case 3:
/* 189 */             v = ImageMath.smoothStep(0.0F, 1.0F, v);
/*     */           }
/*     */ 
/* 193 */           if (this.colormap == null) {
/* 194 */             sr = sg = sb = (int)(v * 255.0F);
/*     */           } else {
/* 196 */             int c = this.colormap.getColor(v);
/*     */ 
/* 198 */             sr = c >> 16 & 0xFF;
/* 199 */             sg = c >> 8 & 0xFF;
/* 200 */             sb = c & 0xFF;
/*     */           }
/*     */ 
/* 203 */           sa = this.useAlpha ? pixels[offset] >> 24 & 0xFF : PixelUtils.brightness(pixels[offset]);
/*     */ 
/* 206 */           if (this.invert) {
/* 207 */             sr = 255 - sr;
/* 208 */             sg = 255 - sg;
/* 209 */             sb = 255 - sb;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 214 */         if (this.merge)
/*     */         {
/* 216 */           int transp = 255;
/* 217 */           int col = pixels[offset];
/*     */ 
/* 219 */           int a = (col & 0xFF000000) >> 24;
/* 220 */           int r = (col & 0xFF0000) >> 16;
/* 221 */           int g = (col & 0xFF00) >> 8;
/* 222 */           int b = col & 0xFF;
/*     */ 
/* 224 */           r = sr * r / transp;
/* 225 */           g = sg * g / transp;
/* 226 */           b = sb * b / transp;
/*     */ 
/* 229 */           if (r < 0)
/* 230 */             r = 0;
/* 231 */           if (r > 255)
/* 232 */             r = 255;
/* 233 */           if (g < 0)
/* 234 */             g = 0;
/* 235 */           if (g > 255)
/* 236 */             g = 255;
/* 237 */           if (b < 0)
/* 238 */             b = 0;
/* 239 */           if (b > 255) {
/* 240 */             b = 255;
/*     */           }
/* 242 */           pixels[offset] = (a << 24 | r << 16 | g << 8 | b);
/*     */         }
/*     */         else {
/* 245 */           pixels[offset] = (sa << 24 | sr << 16 | sg << 8 | sb);
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private int setEdgeValue(int x, int y, int[] map, int width, int offset, int xmax, int ymax)
/*     */   {
/* 255 */     int r1 = offset - width - width - 2;
/* 256 */     int r2 = r1 + width;
/* 257 */     int r3 = r2 + width;
/* 258 */     int r4 = r3 + width;
/* 259 */     int r5 = r4 + width;
/*     */ 
/* 261 */     if ((y == 0) || (x == 0) || (y == ymax + 2) || (x == xmax + 2)) {
/* 262 */       return map[offset] = 41;
/*     */     }
/* 264 */     int v = map[(r2 + 2)] + 41;
/* 265 */     int min = v;
/*     */ 
/* 267 */     v = map[(r3 + 1)] + 41;
/* 268 */     if (v < min) {
/* 269 */       min = v;
/*     */     }
/* 271 */     v = map[(r3 + 3)] + 41;
/* 272 */     if (v < min) {
/* 273 */       min = v;
/*     */     }
/* 275 */     v = map[(r4 + 2)] + 41;
/* 276 */     if (v < min) {
/* 277 */       min = v;
/*     */     }
/* 279 */     v = map[(r2 + 1)] + sqrt2;
/* 280 */     if (v < min) {
/* 281 */       min = v;
/*     */     }
/* 283 */     v = map[(r2 + 3)] + sqrt2;
/* 284 */     if (v < min) {
/* 285 */       min = v;
/*     */     }
/* 287 */     v = map[(r4 + 1)] + sqrt2;
/* 288 */     if (v < min) {
/* 289 */       min = v;
/*     */     }
/* 291 */     v = map[(r4 + 3)] + sqrt2;
/* 292 */     if (v < min) {
/* 293 */       min = v;
/*     */     }
/* 295 */     if ((y == 1) || (x == 1) || (y == ymax + 1) || (x == xmax + 1)) {
/* 296 */       return map[offset] = min;
/*     */     }
/* 298 */     v = map[(r1 + 1)] + sqrt5;
/* 299 */     if (v < min) {
/* 300 */       min = v;
/*     */     }
/* 302 */     v = map[(r1 + 3)] + sqrt5;
/* 303 */     if (v < min) {
/* 304 */       min = v;
/*     */     }
/* 306 */     v = map[(r2 + 4)] + sqrt5;
/* 307 */     if (v < min) {
/* 308 */       min = v;
/*     */     }
/* 310 */     v = map[(r4 + 4)] + sqrt5;
/* 311 */     if (v < min) {
/* 312 */       min = v;
/*     */     }
/* 314 */     v = map[(r5 + 3)] + sqrt5;
/* 315 */     if (v < min) {
/* 316 */       min = v;
/*     */     }
/* 318 */     v = map[(r5 + 1)] + sqrt5;
/* 319 */     if (v < min) {
/* 320 */       min = v;
/*     */     }
/* 322 */     v = map[r4] + sqrt5;
/* 323 */     if (v < min) {
/* 324 */       min = v;
/*     */     }
/* 326 */     v = map[r2] + sqrt5;
/* 327 */     if (v < min) {
/* 328 */       min = v;
/*     */     }
/* 330 */     return map[offset] = min;
/*     */   }
/*     */ 
/*     */   private int setValue(int[] map, int width, int offset)
/*     */   {
/* 337 */     int r1 = offset - width - width - 2;
/* 338 */     int r2 = r1 + width;
/* 339 */     int r3 = r2 + width;
/* 340 */     int r4 = r3 + width;
/* 341 */     int r5 = r4 + width;
/*     */ 
/* 343 */     int v = map[(r2 + 2)] + 41;
/* 344 */     int min = v;
/* 345 */     v = map[(r3 + 1)] + 41;
/* 346 */     if (v < min)
/* 347 */       min = v;
/* 348 */     v = map[(r3 + 3)] + 41;
/* 349 */     if (v < min)
/* 350 */       min = v;
/* 351 */     v = map[(r4 + 2)] + 41;
/* 352 */     if (v < min) {
/* 353 */       min = v;
/*     */     }
/* 355 */     v = map[(r2 + 1)] + sqrt2;
/* 356 */     if (v < min)
/* 357 */       min = v;
/* 358 */     v = map[(r2 + 3)] + sqrt2;
/* 359 */     if (v < min)
/* 360 */       min = v;
/* 361 */     v = map[(r4 + 1)] + sqrt2;
/* 362 */     if (v < min)
/* 363 */       min = v;
/* 364 */     v = map[(r4 + 3)] + sqrt2;
/* 365 */     if (v < min) {
/* 366 */       min = v;
/*     */     }
/* 368 */     v = map[(r1 + 1)] + sqrt5;
/* 369 */     if (v < min)
/* 370 */       min = v;
/* 371 */     v = map[(r1 + 3)] + sqrt5;
/* 372 */     if (v < min)
/* 373 */       min = v;
/* 374 */     v = map[(r2 + 4)] + sqrt5;
/* 375 */     if (v < min)
/* 376 */       min = v;
/* 377 */     v = map[(r4 + 4)] + sqrt5;
/* 378 */     if (v < min)
/* 379 */       min = v;
/* 380 */     v = map[(r5 + 3)] + sqrt5;
/* 381 */     if (v < min)
/* 382 */       min = v;
/* 383 */     v = map[(r5 + 1)] + sqrt5;
/* 384 */     if (v < min)
/* 385 */       min = v;
/* 386 */     v = map[r4] + sqrt5;
/* 387 */     if (v < min)
/* 388 */       min = v;
/* 389 */     v = map[r2] + sqrt5;
/* 390 */     if (v < min) {
/* 391 */       min = v;
/*     */     }
/* 393 */     return map[offset] = min;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 397 */     return "Stylize/Shapeburst...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ShapeFilter
 * JD-Core Version:    0.6.1
 */