/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class LinearColormap
/*    */   implements Colormap
/*    */ {
/*    */   private int color1;
/*    */   private int color2;
/*    */ 
/*    */   public LinearColormap()
/*    */   {
/* 31 */     this(-16777216, -1);
/*    */   }
/*    */ 
/*    */   public LinearColormap(int color1, int color2)
/*    */   {
/* 40 */     this.color1 = color1;
/* 41 */     this.color2 = color2;
/*    */   }
/*    */ 
/*    */   public void setColor1(int color1)
/*    */   {
/* 49 */     this.color1 = color1;
/*    */   }
/*    */ 
/*    */   public int getColor1()
/*    */   {
/* 57 */     return this.color1;
/*    */   }
/*    */ 
/*    */   public void setColor2(int color2)
/*    */   {
/* 65 */     this.color2 = color2;
/*    */   }
/*    */ 
/*    */   public int getColor2()
/*    */   {
/* 73 */     return this.color2;
/*    */   }
/*    */ 
/*    */   public int getColor(float v)
/*    */   {
/* 82 */     return ImageMath.mixColors(ImageMath.clamp(v, 0.0F, 1.0F), this.color1, this.color2);
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LinearColormap
 * JD-Core Version:    0.6.1
 */