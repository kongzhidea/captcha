/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public abstract class TransformFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   public static final int ZERO = 0;
/*     */   public static final int CLAMP = 1;
/*     */   public static final int WRAP = 2;
/*     */   public static final int RGB_CLAMP = 3;
/*     */   public static final int NEAREST_NEIGHBOUR = 0;
/*     */   public static final int BILINEAR = 1;
/*  61 */   protected int edgeAction = 3;
/*     */ 
/*  66 */   protected int interpolation = 1;
/*     */   protected Rectangle transformedSpace;
/*     */   protected Rectangle originalSpace;
/*     */ 
/*     */   public void setEdgeAction(int edgeAction)
/*     */   {
/*  84 */     this.edgeAction = edgeAction;
/*     */   }
/*     */ 
/*     */   public int getEdgeAction()
/*     */   {
/*  93 */     return this.edgeAction;
/*     */   }
/*     */ 
/*     */   public void setInterpolation(int interpolation)
/*     */   {
/* 102 */     this.interpolation = interpolation;
/*     */   }
/*     */ 
/*     */   public int getInterpolation()
/*     */   {
/* 111 */     return this.interpolation;
/*     */   }
/*     */ 
/*     */   protected abstract void transformInverse(int paramInt1, int paramInt2, float[] paramArrayOfFloat);
/*     */ 
/*     */   protected void transformSpace(Rectangle rect)
/*     */   {
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst)
/*     */   {
/* 130 */     int width = src.getWidth();
/* 131 */     int height = src.getHeight();
/* 132 */     int type = src.getType();
/* 133 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/* 135 */     this.originalSpace = new Rectangle(0, 0, width, height);
/* 136 */     this.transformedSpace = new Rectangle(0, 0, width, height);
/* 137 */     transformSpace(this.transformedSpace);
/*     */ 
/* 139 */     if (dst == null) {
/* 140 */       ColorModel dstCM = src.getColorModel();
/* 141 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(this.transformedSpace.width, this.transformedSpace.height), dstCM.isAlphaPremultiplied(), null);
/*     */     }
/* 143 */     WritableRaster dstRaster = dst.getRaster();
/*     */ 
/* 145 */     int[] inPixels = getRGB(src, 0, 0, width, height, null);
/*     */ 
/* 147 */     if (this.interpolation == 0) {
/* 148 */       return filterPixelsNN(dst, width, height, inPixels, this.transformedSpace);
/*     */     }
/* 150 */     int srcWidth = width;
/* 151 */     int srcHeight = height;
/* 152 */     int srcWidth1 = width - 1;
/* 153 */     int srcHeight1 = height - 1;
/* 154 */     int outWidth = this.transformedSpace.width;
/* 155 */     int outHeight = this.transformedSpace.height;
/*     */ 
/* 157 */     int index = 0;
/* 158 */     int[] outPixels = new int[outWidth];
/*     */ 
/* 160 */     int outX = this.transformedSpace.x;
/* 161 */     int outY = this.transformedSpace.y;
/* 162 */     float[] out = new float[2];
/*     */ 
/* 164 */     for (int y = 0; y < outHeight; y++) {
/* 165 */       for (int x = 0; x < outWidth; x++) {
/* 166 */         transformInverse(outX + x, outY + y, out);
/* 167 */         int srcX = (int)Math.floor(out[0]);
/* 168 */         int srcY = (int)Math.floor(out[1]);
/* 169 */         float xWeight = out[0] - srcX;
/* 170 */         float yWeight = out[1] - srcY;
/*     */         int se;
/*     */         int nw;
/*     */         int ne;
/*     */         int sw;
/*     */         int se;
/* 173 */         if ((srcX >= 0) && (srcX < srcWidth1) && (srcY >= 0) && (srcY < srcHeight1))
/*     */         {
/* 175 */           int i = srcWidth * srcY + srcX;
/* 176 */           int nw = inPixels[i];
/* 177 */           int ne = inPixels[(i + 1)];
/* 178 */           int sw = inPixels[(i + srcWidth)];
/* 179 */           se = inPixels[(i + srcWidth + 1)];
/*     */         }
/*     */         else {
/* 182 */           nw = getPixel(inPixels, srcX, srcY, srcWidth, srcHeight);
/* 183 */           ne = getPixel(inPixels, srcX + 1, srcY, srcWidth, srcHeight);
/* 184 */           sw = getPixel(inPixels, srcX, srcY + 1, srcWidth, srcHeight);
/* 185 */           se = getPixel(inPixels, srcX + 1, srcY + 1, srcWidth, srcHeight);
/*     */         }
/* 187 */         outPixels[x] = ImageMath.bilinearInterpolate(xWeight, yWeight, nw, ne, sw, se);
/*     */       }
/* 189 */       setRGB(dst, 0, y, this.transformedSpace.width, 1, outPixels);
/*     */     }
/* 191 */     return dst;
/*     */   }
/*     */ 
/*     */   private final int getPixel(int[] pixels, int x, int y, int width, int height) {
/* 195 */     if ((x < 0) || (x >= width) || (y < 0) || (y >= height)) {
/* 196 */       switch (this.edgeAction) {
/*     */       case 0:
/*     */       default:
/* 199 */         return 0;
/*     */       case 2:
/* 201 */         return pixels[(ImageMath.mod(y, height) * width + ImageMath.mod(x, width))];
/*     */       case 1:
/* 203 */         return pixels[(ImageMath.clamp(y, 0, height - 1) * width + ImageMath.clamp(x, 0, width - 1))];
/*     */       case 3:
/* 205 */       }return pixels[(ImageMath.clamp(y, 0, height - 1) * width + ImageMath.clamp(x, 0, width - 1))] & 0xFFFFFF;
/*     */     }
/*     */ 
/* 208 */     return pixels[(y * width + x)];
/*     */   }
/*     */ 
/*     */   protected BufferedImage filterPixelsNN(BufferedImage dst, int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 212 */     int srcWidth = width;
/* 213 */     int srcHeight = height;
/* 214 */     int outWidth = transformedSpace.width;
/* 215 */     int outHeight = transformedSpace.height;
/*     */ 
/* 217 */     int[] outPixels = new int[outWidth];
/*     */ 
/* 219 */     int outX = transformedSpace.x;
/* 220 */     int outY = transformedSpace.y;
/* 221 */     int[] rgb = new int[4];
/* 222 */     float[] out = new float[2];
/*     */ 
/* 224 */     for (int y = 0; y < outHeight; y++) {
/* 225 */       for (int x = 0; x < outWidth; x++) {
/* 226 */         transformInverse(outX + x, outY + y, out);
/* 227 */         int srcX = (int)out[0];
/* 228 */         int srcY = (int)out[1];
/*     */ 
/* 230 */         if ((out[0] < 0.0F) || (srcX >= srcWidth) || (out[1] < 0.0F) || (srcY >= srcHeight))
/*     */         {
/*     */           int p;
/* 232 */           switch (this.edgeAction) {
/*     */           case 0:
/*     */           default:
/* 235 */             p = 0;
/* 236 */             break;
/*     */           case 2:
/* 238 */             p = inPixels[(ImageMath.mod(srcY, srcHeight) * srcWidth + ImageMath.mod(srcX, srcWidth))];
/* 239 */             break;
/*     */           case 1:
/* 241 */             p = inPixels[(ImageMath.clamp(srcY, 0, srcHeight - 1) * srcWidth + ImageMath.clamp(srcX, 0, srcWidth - 1))];
/* 242 */             break;
/*     */           case 3:
/* 244 */             p = inPixels[(ImageMath.clamp(srcY, 0, srcHeight - 1) * srcWidth + ImageMath.clamp(srcX, 0, srcWidth - 1))] & 0xFFFFFF;
/*     */           }
/* 246 */           outPixels[x] = p;
/*     */         } else {
/* 248 */           int i = srcWidth * srcY + srcX;
/* 249 */           rgb[0] = inPixels[i];
/* 250 */           outPixels[x] = inPixels[i];
/*     */         }
/*     */       }
/* 253 */       setRGB(dst, 0, y, transformedSpace.width, 1, outPixels);
/*     */     }
/* 255 */     return dst;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TransformFilter
 * JD-Core Version:    0.6.1
 */