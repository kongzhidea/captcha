/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class ScratchFilter extends AbstractBufferedImageOp
/*     */ {
/*  13 */   private float density = 0.1F;
/*     */   private float angle;
/*  15 */   private float angleVariation = 1.0F;
/*  16 */   private float width = 0.5F;
/*  17 */   private float length = 0.5F;
/*  18 */   private int color = -1;
/*  19 */   private int seed = 0;
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  25 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle() {
/*  29 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setAngleVariation(float angleVariation) {
/*  33 */     this.angleVariation = angleVariation;
/*     */   }
/*     */ 
/*     */   public float getAngleVariation() {
/*  37 */     return this.angleVariation;
/*     */   }
/*     */ 
/*     */   public void setDensity(float density) {
/*  41 */     this.density = density;
/*     */   }
/*     */ 
/*     */   public float getDensity() {
/*  45 */     return this.density;
/*     */   }
/*     */ 
/*     */   public void setLength(float length) {
/*  49 */     this.length = length;
/*     */   }
/*     */ 
/*     */   public float getLength() {
/*  53 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void setWidth(float width) {
/*  57 */     this.width = width;
/*     */   }
/*     */ 
/*     */   public float getWidth() {
/*  61 */     return this.width;
/*     */   }
/*     */ 
/*     */   public void setColor(int color) {
/*  65 */     this.color = color;
/*     */   }
/*     */ 
/*     */   public int getColor() {
/*  69 */     return this.color;
/*     */   }
/*     */ 
/*     */   public void setSeed(int seed) {
/*  73 */     this.seed = seed;
/*     */   }
/*     */ 
/*     */   public int getSeed() {
/*  77 */     return this.seed;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  81 */     if (dst == null) {
/*  82 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  84 */     int width = src.getWidth();
/*  85 */     int height = src.getHeight();
/*  86 */     int numScratches = (int)(this.density * width * height / 100.0F);
/*  87 */     float l = this.length * width;
/*  88 */     Random random = new Random(this.seed);
/*  89 */     Graphics2D g = dst.createGraphics();
/*  90 */     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  91 */     g.setColor(new Color(this.color));
/*  92 */     g.setStroke(new BasicStroke(this.width));
/*  93 */     for (int i = 0; i < numScratches; i++) {
/*  94 */       float x = width * random.nextFloat();
/*  95 */       float y = height * random.nextFloat();
/*  96 */       float a = this.angle + 6.283186F * (this.angleVariation * (random.nextFloat() - 0.5F));
/*  97 */       float s = (float)Math.sin(a) * l;
/*  98 */       float c = (float)Math.cos(a) * l;
/*  99 */       float x1 = x - c;
/* 100 */       float y1 = y - s;
/* 101 */       float x2 = x + c;
/* 102 */       float y2 = y + s;
/* 103 */       g.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
/*     */     }
/* 105 */     g.dispose();
/*     */ 
/* 107 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 111 */     return "Render/Scratches...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ScratchFilter
 * JD-Core Version:    0.6.1
 */