/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class StampFilter extends PointFilter
/*     */ {
/*     */   private float threshold;
/*  27 */   private float softness = 0.0F;
/*  28 */   private float radius = 5.0F;
/*     */   private float lowerThreshold3;
/*     */   private float upperThreshold3;
/*  31 */   private int white = -1;
/*  32 */   private int black = -16777216;
/*     */ 
/*     */   public StampFilter()
/*     */   {
/*  38 */     this(0.5F);
/*     */   }
/*     */ 
/*     */   public StampFilter(float threshold)
/*     */   {
/*  46 */     setThreshold(threshold);
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/*  56 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/*  65 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setThreshold(float threshold)
/*     */   {
/*  74 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public float getThreshold()
/*     */   {
/*  83 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void setSoftness(float softness)
/*     */   {
/*  94 */     this.softness = softness;
/*     */   }
/*     */ 
/*     */   public float getSoftness()
/*     */   {
/* 103 */     return this.softness;
/*     */   }
/*     */ 
/*     */   public void setWhite(int white)
/*     */   {
/* 112 */     this.white = white;
/*     */   }
/*     */ 
/*     */   public int getWhite()
/*     */   {
/* 121 */     return this.white;
/*     */   }
/*     */ 
/*     */   public void setBlack(int black)
/*     */   {
/* 130 */     this.black = black;
/*     */   }
/*     */ 
/*     */   public int getBlack()
/*     */   {
/* 139 */     return this.black;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 143 */     dst = new GaussianFilter((int)this.radius).filter(src, null);
/* 144 */     this.lowerThreshold3 = (765.0F * (this.threshold - this.softness * 0.5F));
/* 145 */     this.upperThreshold3 = (765.0F * (this.threshold + this.softness * 0.5F));
/* 146 */     return super.filter(dst, dst);
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 150 */     int a = rgb & 0xFF000000;
/* 151 */     int r = rgb >> 16 & 0xFF;
/* 152 */     int g = rgb >> 8 & 0xFF;
/* 153 */     int b = rgb & 0xFF;
/* 154 */     int l = r + g + b;
/* 155 */     float f = ImageMath.smoothStep(this.lowerThreshold3, this.upperThreshold3, l);
/* 156 */     return ImageMath.mixColors(f, this.black, this.white);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 160 */     return "Stylize/Stamp...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.StampFilter
 * JD-Core Version:    0.6.1
 */