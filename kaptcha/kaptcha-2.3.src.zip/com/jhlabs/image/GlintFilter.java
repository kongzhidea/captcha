/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class GlintFilter extends AbstractBufferedImageOp
/*     */ {
/*  29 */   private float threshold = 1.0F;
/*  30 */   private int length = 5;
/*  31 */   private float blur = 0.0F;
/*  32 */   private float amount = 0.1F;
/*  33 */   private boolean glintOnly = false;
/*  34 */   private Colormap colormap = new LinearColormap(-1, -16777216);
/*     */ 
/*     */   public void setThreshold(float threshold)
/*     */   {
/*  45 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public float getThreshold()
/*     */   {
/*  54 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  65 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  74 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setLength(int length)
/*     */   {
/*  83 */     this.length = length;
/*     */   }
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  92 */     return this.length;
/*     */   }
/*     */ 
/*     */   public void setBlur(float blur)
/*     */   {
/* 101 */     this.blur = blur;
/*     */   }
/*     */ 
/*     */   public float getBlur()
/*     */   {
/* 110 */     return this.blur;
/*     */   }
/*     */ 
/*     */   public void setGlintOnly(boolean glintOnly)
/*     */   {
/* 119 */     this.glintOnly = glintOnly;
/*     */   }
/*     */ 
/*     */   public boolean getGlintOnly()
/*     */   {
/* 128 */     return this.glintOnly;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 137 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 146 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 150 */     int width = src.getWidth();
/* 151 */     int height = src.getHeight();
/* 152 */     int[] pixels = new int[width];
/* 153 */     int length2 = (int)(this.length / 1.414F);
/* 154 */     int[] colors = new int[this.length + 1];
/* 155 */     int[] colors2 = new int[length2 + 1];
/*     */ 
/* 157 */     if (this.colormap != null) {
/* 158 */       for (int i = 0; i <= this.length; i++) {
/* 159 */         int argb = this.colormap.getColor(i / this.length);
/* 160 */         int r = argb >> 16 & 0xFF;
/* 161 */         int g = argb >> 8 & 0xFF;
/* 162 */         int b = argb & 0xFF;
/* 163 */         argb = argb & 0xFF000000 | (int)(this.amount * r) << 16 | (int)(this.amount * g) << 8 | (int)(this.amount * b);
/* 164 */         colors[i] = argb;
/*     */       }
/* 166 */       for (int i = 0; i <= length2; i++) {
/* 167 */         int argb = this.colormap.getColor(i / length2);
/* 168 */         int r = argb >> 16 & 0xFF;
/* 169 */         int g = argb >> 8 & 0xFF;
/* 170 */         int b = argb & 0xFF;
/* 171 */         argb = argb & 0xFF000000 | (int)(this.amount * r) << 16 | (int)(this.amount * g) << 8 | (int)(this.amount * b);
/* 172 */         colors2[i] = argb;
/*     */       }
/*     */     }
/*     */ 
/* 176 */     BufferedImage mask = new BufferedImage(width, height, 2);
/*     */ 
/* 178 */     int threshold3 = (int)(this.threshold * 3.0F * 255.0F);
/* 179 */     for (int y = 0; y < height; y++) {
/* 180 */       getRGB(src, 0, y, width, 1, pixels);
/* 181 */       for (int x = 0; x < width; x++) {
/* 182 */         int rgb = pixels[x];
/* 183 */         int a = rgb & 0xFF000000;
/* 184 */         int r = rgb >> 16 & 0xFF;
/* 185 */         int g = rgb >> 8 & 0xFF;
/* 186 */         int b = rgb & 0xFF;
/* 187 */         int l = r + g + b;
/* 188 */         if (l < threshold3) {
/* 189 */           pixels[x] = -16777216;
/*     */         } else {
/* 191 */           l /= 3;
/* 192 */           pixels[x] = (a | l << 16 | l << 8 | l);
/*     */         }
/*     */       }
/* 195 */       setRGB(mask, 0, y, width, 1, pixels);
/*     */     }
/*     */ 
/* 198 */     if (this.blur != 0.0F) {
/* 199 */       mask = new GaussianFilter(this.blur).filter(mask, null);
/*     */     }
/* 201 */     if (dst == null)
/* 202 */       dst = createCompatibleDestImage(src, null);
/*     */     int[] dstPixels;
/*     */     int[] dstPixels;
/* 204 */     if (this.glintOnly)
/* 205 */       dstPixels = new int[width * height];
/*     */     else {
/* 207 */       dstPixels = getRGB(src, 0, 0, width, height, null);
/*     */     }
/* 209 */     for (int y = 0; y < height; y++) {
/* 210 */       int index = y * width;
/* 211 */       getRGB(mask, 0, y, width, 1, pixels);
/* 212 */       int ymin = Math.max(y - this.length, 0) - y;
/* 213 */       int ymax = Math.min(y + this.length, height - 1) - y;
/* 214 */       int ymin2 = Math.max(y - length2, 0) - y;
/* 215 */       int ymax2 = Math.min(y + length2, height - 1) - y;
/* 216 */       for (int x = 0; x < width; x++) {
/* 217 */         if (pixels[x] & 0xFF > this.threshold * 255.0F) {
/* 218 */           int xmin = Math.max(x - this.length, 0) - x;
/* 219 */           int xmax = Math.min(x + this.length, width - 1) - x;
/* 220 */           int xmin2 = Math.max(x - length2, 0) - x;
/* 221 */           int xmax2 = Math.min(x + length2, width - 1) - x;
/*     */ 
/* 224 */           int i = 0; for (int k = 0; i <= xmax; k++) {
/* 225 */             dstPixels[(index + i)] = PixelUtils.combinePixels(dstPixels[(index + i)], colors[k], 4);
/*     */ 
/* 224 */             i++;
/*     */           }
/* 226 */           int i = -1; for (int k = 1; i >= xmin; k++) {
/* 227 */             dstPixels[(index + i)] = PixelUtils.combinePixels(dstPixels[(index + i)], colors[k], 4);
/*     */ 
/* 226 */             i--;
/*     */           }
/*     */ 
/* 229 */           int i = 1; int j = index + width; for (int k = 0; i <= ymax; k++) {
/* 230 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors[k], 4);
/*     */ 
/* 229 */             i++; j += width;
/*     */           }
/* 231 */           int i = -1; int j = index - width; for (int k = 0; i >= ymin; k++) {
/* 232 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors[k], 4);
/*     */ 
/* 231 */             i--; j -= width;
/*     */           }
/*     */ 
/* 235 */           int xymin = Math.max(xmin2, ymin2);
/* 236 */           int xymax = Math.min(xmax2, ymax2);
/*     */ 
/* 238 */           int count = Math.min(xmax2, ymax2);
/* 239 */           int i = 1; int j = index + width + 1; for (int k = 0; i <= count; k++) {
/* 240 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors2[k], 4);
/*     */ 
/* 239 */             i++; j += width + 1;
/*     */           }
/*     */ 
/* 242 */           count = Math.min(-xmin2, -ymin2);
/* 243 */           int i = 1; int j = index - width - 1; for (int k = 0; i <= count; k++) {
/* 244 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors2[k], 4);
/*     */ 
/* 243 */             i++; j -= width + 1;
/*     */           }
/*     */ 
/* 246 */           count = Math.min(xmax2, -ymin2);
/* 247 */           int i = 1; int j = index - width + 1; for (int k = 0; i <= count; k++) {
/* 248 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors2[k], 4);
/*     */ 
/* 247 */             i++; j += -width + 1;
/*     */           }
/*     */ 
/* 250 */           count = Math.min(-xmin2, ymax2);
/* 251 */           int i = 1; int j = index + width - 1; for (int k = 0; i <= count; k++) {
/* 252 */             dstPixels[j] = PixelUtils.combinePixels(dstPixels[j], colors2[k], 4);
/*     */ 
/* 251 */             i++; j += width - 1;
/*     */           }
/*     */         }
/* 254 */         index++;
/*     */       }
/*     */     }
/* 257 */     setRGB(dst, 0, 0, width, height, dstPixels);
/*     */ 
/* 259 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 263 */     return "Effects/Glint...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GlintFilter
 * JD-Core Version:    0.6.1
 */