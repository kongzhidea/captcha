/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class SwizzleFilter extends PointFilter
/*    */ {
/* 17 */   private int[] matrix = { 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0 };
/*    */ 
/*    */   public void setMatrix(int[] matrix)
/*    */   {
/* 33 */     this.matrix = matrix;
/*    */   }
/*    */ 
/*    */   public int[] getMatrix()
/*    */   {
/* 42 */     return this.matrix;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 46 */     int a = rgb >> 24 & 0xFF;
/* 47 */     int r = rgb >> 16 & 0xFF;
/* 48 */     int g = rgb >> 8 & 0xFF;
/* 49 */     int b = rgb & 0xFF;
/*    */ 
/* 51 */     a = this.matrix[0] * a + this.matrix[1] * r + this.matrix[2] * g + this.matrix[3] * b + this.matrix[4] * 255;
/* 52 */     r = this.matrix[5] * a + this.matrix[6] * r + this.matrix[7] * g + this.matrix[8] * b + this.matrix[9] * 255;
/* 53 */     g = this.matrix[10] * a + this.matrix[11] * r + this.matrix[12] * g + this.matrix[13] * b + this.matrix[14] * 255;
/* 54 */     b = this.matrix[15] * a + this.matrix[16] * r + this.matrix[17] * g + this.matrix[18] * b + this.matrix[19] * 255;
/*    */ 
/* 56 */     a = PixelUtils.clamp(a);
/* 57 */     r = PixelUtils.clamp(r);
/* 58 */     g = PixelUtils.clamp(g);
/* 59 */     b = PixelUtils.clamp(b);
/*    */ 
/* 61 */     return a << 24 | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return "Channels/Swizzle...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SwizzleFilter
 * JD-Core Version:    0.6.1
 */