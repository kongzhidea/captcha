/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class ColorHalftoneFilter extends AbstractBufferedImageOp
/*     */ {
/*  28 */   private float dotRadius = 8.0F;
/*  29 */   private float cyanScreenAngle = (float)Math.toRadians(108.0D);
/*  30 */   private float magentaScreenAngle = (float)Math.toRadians(162.0D);
/*  31 */   private float yellowScreenAngle = (float)Math.toRadians(90.0D);
/*     */ 
/*     */   public void setdotRadius(float dotRadius)
/*     */   {
/*  44 */     this.dotRadius = dotRadius;
/*     */   }
/*     */ 
/*     */   public float getdotRadius()
/*     */   {
/*  53 */     return this.dotRadius;
/*     */   }
/*     */ 
/*     */   public float getCyanScreenAngle()
/*     */   {
/*  62 */     return this.cyanScreenAngle;
/*     */   }
/*     */ 
/*     */   public void setCyanScreenAngle(float cyanScreenAngle)
/*     */   {
/*  71 */     this.cyanScreenAngle = cyanScreenAngle;
/*     */   }
/*     */ 
/*     */   public float getMagentaScreenAngle()
/*     */   {
/*  80 */     return this.magentaScreenAngle;
/*     */   }
/*     */ 
/*     */   public void setMagentaScreenAngle(float magentaScreenAngle)
/*     */   {
/*  89 */     this.magentaScreenAngle = magentaScreenAngle;
/*     */   }
/*     */ 
/*     */   public float getYellowScreenAngle()
/*     */   {
/*  98 */     return this.yellowScreenAngle;
/*     */   }
/*     */ 
/*     */   public void setYellowScreenAngle(float yellowScreenAngle)
/*     */   {
/* 107 */     this.yellowScreenAngle = yellowScreenAngle;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 111 */     int width = src.getWidth();
/* 112 */     int height = src.getHeight();
/* 113 */     int type = src.getType();
/* 114 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/* 116 */     if (dst == null) {
/* 117 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/* 119 */     float gridSize = 2.0F * this.dotRadius * 1.414F;
/* 120 */     float[] angles = { this.cyanScreenAngle, this.magentaScreenAngle, this.yellowScreenAngle };
/* 121 */     float[] mx = { 0.0F, -1.0F, 1.0F, 0.0F, 0.0F };
/* 122 */     float[] my = { 0.0F, 0.0F, 0.0F, -1.0F, 1.0F };
/* 123 */     float halfGridSize = gridSize / 2.0F;
/* 124 */     int[] outPixels = new int[width];
/* 125 */     int[] inPixels = getRGB(src, 0, 0, width, height, null);
/* 126 */     for (int y = 0; y < height; y++) {
/* 127 */       for (int x = 0; x < width; x++)
/* 128 */         outPixels[x] = (inPixels[x] & 0xFF000000 | 0xFFFFFF);
/* 129 */       for (int channel = 0; channel < 3; channel++) {
/* 130 */         int shift = 16 - 8 * channel;
/* 131 */         int mask = 255 << shift;
/* 132 */         float angle = angles[channel];
/* 133 */         float sin = (float)Math.sin(angle);
/* 134 */         float cos = (float)Math.cos(angle);
/*     */ 
/* 136 */         for (int x = 0; x < width; x++)
/*     */         {
/* 138 */           float tx = x * cos + y * sin;
/* 139 */           float ty = -x * sin + y * cos;
/*     */ 
/* 142 */           tx = tx - ImageMath.mod(tx - halfGridSize, gridSize) + halfGridSize;
/* 143 */           ty = ty - ImageMath.mod(ty - halfGridSize, gridSize) + halfGridSize;
/*     */ 
/* 145 */           float f = 1.0F;
/*     */ 
/* 149 */           for (int i = 0; i < 5; i++)
/*     */           {
/* 151 */             float ttx = tx + mx[i] * gridSize;
/* 152 */             float tty = ty + my[i] * gridSize;
/*     */ 
/* 154 */             float ntx = ttx * cos - tty * sin;
/* 155 */             float nty = ttx * sin + tty * cos;
/*     */ 
/* 157 */             int nx = ImageMath.clamp((int)ntx, 0, width - 1);
/* 158 */             int ny = ImageMath.clamp((int)nty, 0, height - 1);
/* 159 */             int argb = inPixels[(ny * width + nx)];
/* 160 */             int nr = argb >> shift & 0xFF;
/* 161 */             float l = nr / 255.0F;
/* 162 */             l = 1.0F - l * l;
/* 163 */             l = (float)(l * (halfGridSize * 1.414D));
/* 164 */             float dx = x - ntx;
/* 165 */             float dy = y - nty;
/* 166 */             float dx2 = dx * dx;
/* 167 */             float dy2 = dy * dy;
/* 168 */             float R = (float)Math.sqrt(dx2 + dy2);
/* 169 */             float f2 = 1.0F - ImageMath.smoothStep(R, R + 1.0F, l);
/* 170 */             f = Math.min(f, f2);
/*     */           }
/*     */ 
/* 173 */           int v = (int)(255.0F * f);
/* 174 */           v <<= shift;
/* 175 */           v ^= mask ^ 0xFFFFFFFF;
/* 176 */           outPixels[x] &= v;
/*     */         }
/*     */       }
/* 179 */       for (int x = 0; x < width; x++)
/* 180 */         outPixels[x] |= -16777216;
/* 181 */       setRGB(dst, 0, y, width, 1, outPixels);
/*     */     }
/*     */ 
/* 184 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 188 */     return "Pixellate/Color Halftone...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ColorHalftoneFilter
 * JD-Core Version:    0.6.1
 */