/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class BumpFilter extends ConvolveFilter
/*    */ {
/* 26 */   private static float[] embossMatrix = { -1.0F, -1.0F, 0.0F, -1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F };
/*    */ 
/*    */   public BumpFilter()
/*    */   {
/* 33 */     super(embossMatrix);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 37 */     return "Blur/Emboss Edges";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BumpFilter
 * JD-Core Version:    0.6.1
 */