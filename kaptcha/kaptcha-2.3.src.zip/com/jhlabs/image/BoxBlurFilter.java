/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class BoxBlurFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private float hRadius;
/*     */   private float vRadius;
/*  31 */   private int iterations = 1;
/*  32 */   private boolean premultiplyAlpha = true;
/*     */ 
/*     */   public BoxBlurFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BoxBlurFilter(float hRadius, float vRadius, int iterations)
/*     */   {
/*  47 */     this.hRadius = hRadius;
/*  48 */     this.vRadius = vRadius;
/*  49 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */   public void setPremultiplyAlpha(boolean premultiplyAlpha)
/*     */   {
/*  58 */     this.premultiplyAlpha = premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getPremultiplyAlpha()
/*     */   {
/*  67 */     return this.premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  71 */     int width = src.getWidth();
/*  72 */     int height = src.getHeight();
/*     */ 
/*  74 */     if (dst == null) {
/*  75 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  77 */     int[] inPixels = new int[width * height];
/*  78 */     int[] outPixels = new int[width * height];
/*  79 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */ 
/*  81 */     if (this.premultiplyAlpha)
/*  82 */       ImageMath.premultiply(inPixels, 0, inPixels.length);
/*  83 */     for (int i = 0; i < this.iterations; i++) {
/*  84 */       blur(inPixels, outPixels, width, height, this.hRadius);
/*  85 */       blur(outPixels, inPixels, height, width, this.vRadius);
/*     */     }
/*  87 */     blurFractional(inPixels, outPixels, width, height, this.hRadius);
/*  88 */     blurFractional(outPixels, inPixels, height, width, this.vRadius);
/*  89 */     if (this.premultiplyAlpha) {
/*  90 */       ImageMath.unpremultiply(inPixels, 0, inPixels.length);
/*     */     }
/*  92 */     setRGB(dst, 0, 0, width, height, inPixels);
/*  93 */     return dst;
/*     */   }
/*     */ 
/*     */   public static void blur(int[] in, int[] out, int width, int height, float radius)
/*     */   {
/* 105 */     int widthMinus1 = width - 1;
/* 106 */     int r = (int)radius;
/* 107 */     int tableSize = 2 * r + 1;
/* 108 */     int[] divide = new int[256 * tableSize];
/*     */ 
/* 110 */     for (int i = 0; i < 256 * tableSize; i++) {
/* 111 */       divide[i] = (i / tableSize);
/*     */     }
/* 113 */     int inIndex = 0;
/*     */ 
/* 115 */     for (int y = 0; y < height; y++) {
/* 116 */       int outIndex = y;
/* 117 */       int ta = 0; int tr = 0; int tg = 0; int tb = 0;
/*     */ 
/* 119 */       for (int i = -r; i <= r; i++) {
/* 120 */         int rgb = in[(inIndex + ImageMath.clamp(i, 0, width - 1))];
/* 121 */         ta += (rgb >> 24 & 0xFF);
/* 122 */         tr += (rgb >> 16 & 0xFF);
/* 123 */         tg += (rgb >> 8 & 0xFF);
/* 124 */         tb += (rgb & 0xFF);
/*     */       }
/*     */ 
/* 127 */       for (int x = 0; x < width; x++) {
/* 128 */         out[outIndex] = (divide[ta] << 24 | divide[tr] << 16 | divide[tg] << 8 | divide[tb]);
/*     */ 
/* 130 */         int i1 = x + r + 1;
/* 131 */         if (i1 > widthMinus1)
/* 132 */           i1 = widthMinus1;
/* 133 */         int i2 = x - r;
/* 134 */         if (i2 < 0)
/* 135 */           i2 = 0;
/* 136 */         int rgb1 = in[(inIndex + i1)];
/* 137 */         int rgb2 = in[(inIndex + i2)];
/*     */ 
/* 139 */         ta += (rgb1 >> 24 & 0xFF) - (rgb2 >> 24 & 0xFF);
/* 140 */         tr += ((rgb1 & 0xFF0000) - (rgb2 & 0xFF0000) >> 16);
/* 141 */         tg += ((rgb1 & 0xFF00) - (rgb2 & 0xFF00) >> 8);
/* 142 */         tb += (rgb1 & 0xFF) - (rgb2 & 0xFF);
/* 143 */         outIndex += height;
/*     */       }
/* 145 */       inIndex += width;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void blurFractional(int[] in, int[] out, int width, int height, float radius) {
/* 150 */     radius -= (int)radius;
/* 151 */     float f = 1.0F / (1.0F + 2.0F * radius);
/* 152 */     int inIndex = 0;
/*     */ 
/* 154 */     for (int y = 0; y < height; y++) {
/* 155 */       int outIndex = y;
/*     */ 
/* 157 */       out[outIndex] = in[0];
/* 158 */       outIndex += height;
/* 159 */       for (int x = 1; x < width - 1; x++) {
/* 160 */         int i = inIndex + x;
/* 161 */         int rgb1 = in[(i - 1)];
/* 162 */         int rgb2 = in[i];
/* 163 */         int rgb3 = in[(i + 1)];
/*     */ 
/* 165 */         int a1 = rgb1 >> 24 & 0xFF;
/* 166 */         int r1 = rgb1 >> 16 & 0xFF;
/* 167 */         int g1 = rgb1 >> 8 & 0xFF;
/* 168 */         int b1 = rgb1 & 0xFF;
/* 169 */         int a2 = rgb2 >> 24 & 0xFF;
/* 170 */         int r2 = rgb2 >> 16 & 0xFF;
/* 171 */         int g2 = rgb2 >> 8 & 0xFF;
/* 172 */         int b2 = rgb2 & 0xFF;
/* 173 */         int a3 = rgb3 >> 24 & 0xFF;
/* 174 */         int r3 = rgb3 >> 16 & 0xFF;
/* 175 */         int g3 = rgb3 >> 8 & 0xFF;
/* 176 */         int b3 = rgb3 & 0xFF;
/* 177 */         a1 = a2 + (int)(a1 + a3 * radius);
/* 178 */         r1 = r2 + (int)(r1 + r3 * radius);
/* 179 */         g1 = g2 + (int)(g1 + g3 * radius);
/* 180 */         b1 = b2 + (int)(b1 + b3 * radius);
/* 181 */         a1 = (int)(a1 * f);
/* 182 */         r1 = (int)(r1 * f);
/* 183 */         g1 = (int)(g1 * f);
/* 184 */         b1 = (int)(b1 * f);
/* 185 */         out[outIndex] = (a1 << 24 | r1 << 16 | g1 << 8 | b1);
/* 186 */         outIndex += height;
/*     */       }
/* 188 */       out[outIndex] = in[(width - 1)];
/* 189 */       inIndex += width;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHRadius(float hRadius)
/*     */   {
/* 200 */     this.hRadius = hRadius;
/*     */   }
/*     */ 
/*     */   public float getHRadius()
/*     */   {
/* 209 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setVRadius(float vRadius)
/*     */   {
/* 219 */     this.vRadius = vRadius;
/*     */   }
/*     */ 
/*     */   public float getVRadius()
/*     */   {
/* 228 */     return this.vRadius;
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/* 238 */     this.hRadius = (this.vRadius = radius);
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 247 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setIterations(int iterations)
/*     */   {
/* 257 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */   public int getIterations()
/*     */   {
/* 266 */     return this.iterations;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 270 */     return "Blur/Box Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BoxBlurFilter
 * JD-Core Version:    0.6.1
 */