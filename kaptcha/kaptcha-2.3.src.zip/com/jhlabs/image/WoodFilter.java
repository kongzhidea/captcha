/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ 
/*     */ public class WoodFilter extends PointFilter
/*     */ {
/*  27 */   private float scale = 200.0F;
/*  28 */   private float stretch = 10.0F;
/*  29 */   private float angle = 1.570796F;
/*  30 */   private float rings = 0.5F;
/*  31 */   private float turbulence = 0.0F;
/*  32 */   private float fibres = 0.5F;
/*  33 */   private float gain = 0.8F;
/*  34 */   private float m00 = 1.0F;
/*  35 */   private float m01 = 0.0F;
/*  36 */   private float m10 = 0.0F;
/*  37 */   private float m11 = 1.0F;
/*  38 */   private Colormap colormap = new LinearColormap(-1719148, -6784175);
/*     */ 
/*     */   public void setRings(float rings)
/*     */   {
/*  54 */     this.rings = rings;
/*     */   }
/*     */ 
/*     */   public float getRings()
/*     */   {
/*  63 */     return this.rings;
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  74 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  83 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setStretch(float stretch)
/*     */   {
/*  94 */     this.stretch = stretch;
/*     */   }
/*     */ 
/*     */   public float getStretch()
/*     */   {
/* 103 */     return this.stretch;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 113 */     this.angle = angle;
/* 114 */     float cos = (float)Math.cos(angle);
/* 115 */     float sin = (float)Math.sin(angle);
/* 116 */     this.m00 = cos;
/* 117 */     this.m01 = sin;
/* 118 */     this.m10 = (-sin);
/* 119 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 128 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/* 139 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 148 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   public void setFibres(float fibres)
/*     */   {
/* 159 */     this.fibres = fibres;
/*     */   }
/*     */ 
/*     */   public float getFibres()
/*     */   {
/* 168 */     return this.fibres;
/*     */   }
/*     */ 
/*     */   public void setGain(float gain)
/*     */   {
/* 179 */     this.gain = gain;
/*     */   }
/*     */ 
/*     */   public float getGain()
/*     */   {
/* 188 */     return this.gain;
/*     */   }
/*     */ 
/*     */   public void setColormap(Colormap colormap)
/*     */   {
/* 197 */     this.colormap = colormap;
/*     */   }
/*     */ 
/*     */   public Colormap getColormap()
/*     */   {
/* 206 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 210 */     float nx = this.m00 * x + this.m01 * y;
/* 211 */     float ny = this.m10 * x + this.m11 * y;
/* 212 */     nx /= this.scale;
/* 213 */     ny /= this.scale * this.stretch;
/* 214 */     float f = Noise.noise2(nx, ny);
/* 215 */     f += 0.1F * this.turbulence * Noise.noise2(nx * 0.05F, ny * 20.0F);
/* 216 */     f = f * 0.5F + 0.5F;
/*     */ 
/* 218 */     f *= this.rings * 50.0F;
/* 219 */     f -= (int)f;
/* 220 */     f *= (1.0F - ImageMath.smoothStep(this.gain, 1.0F, f));
/*     */ 
/* 222 */     f += this.fibres * Noise.noise2(nx * this.scale, ny * 50.0F);
/*     */ 
/* 224 */     int a = rgb & 0xFF000000;
/*     */     int v;
/*     */     int v;
/* 226 */     if (this.colormap != null) {
/* 227 */       v = this.colormap.getColor(f);
/*     */     } else {
/* 229 */       v = PixelUtils.clamp((int)(f * 255.0F));
/* 230 */       int r = v << 16;
/* 231 */       int g = v << 8;
/* 232 */       int b = v;
/* 233 */       v = a | r | g | b;
/*     */     }
/*     */ 
/* 236 */     return v;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 240 */     return "Texture/Wood...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.WoodFilter
 * JD-Core Version:    0.6.1
 */