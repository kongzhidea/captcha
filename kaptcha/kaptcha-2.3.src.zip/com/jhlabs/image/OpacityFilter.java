/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class OpacityFilter extends PointFilter
/*    */ {
/*    */   private int opacity;
/*    */   private int opacity24;
/*    */ 
/*    */   public OpacityFilter()
/*    */   {
/* 34 */     this(136);
/*    */   }
/*    */ 
/*    */   public OpacityFilter(int opacity)
/*    */   {
/* 42 */     setOpacity(opacity);
/*    */   }
/*    */ 
/*    */   public void setOpacity(int opacity)
/*    */   {
/* 51 */     this.opacity = opacity;
/* 52 */     this.opacity24 = (opacity << 24);
/*    */   }
/*    */ 
/*    */   public int getOpacity()
/*    */   {
/* 61 */     return this.opacity;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 65 */     if ((rgb & 0xFF000000) != 0)
/* 66 */       return rgb & 0xFFFFFF | this.opacity24;
/* 67 */     return rgb;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 71 */     return "Colors/Transparency...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.OpacityFilter
 * JD-Core Version:    0.6.1
 */