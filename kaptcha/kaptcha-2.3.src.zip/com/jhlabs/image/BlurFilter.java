/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class BlurFilter extends ConvolveFilter
/*    */ {
/* 29 */   protected static float[] blurMatrix = { 0.07142858F, 0.1428572F, 0.07142858F, 0.1428572F, 0.1428572F, 0.1428572F, 0.07142858F, 0.1428572F, 0.07142858F };
/*    */ 
/*    */   public BlurFilter()
/*    */   {
/* 36 */     super(blurMatrix);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 40 */     return "Blur/Simple Blur";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BlurFilter
 * JD-Core Version:    0.6.1
 */