/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class MinimumFilter extends WholeImageFilter
/*    */ {
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace)
/*    */   {
/* 31 */     int index = 0;
/* 32 */     int[] outPixels = new int[width * height];
/*    */ 
/* 34 */     for (int y = 0; y < height; y++) {
/* 35 */       for (int x = 0; x < width; x++) {
/* 36 */         int pixel = -1;
/* 37 */         for (int dy = -1; dy <= 1; dy++) {
/* 38 */           int iy = y + dy;
/*    */ 
/* 40 */           if ((0 <= iy) && (iy < height)) {
/* 41 */             int ioffset = iy * width;
/* 42 */             for (int dx = -1; dx <= 1; dx++) {
/* 43 */               int ix = x + dx;
/* 44 */               if ((0 <= ix) && (ix < width)) {
/* 45 */                 pixel = PixelUtils.combinePixels(pixel, inPixels[(ioffset + ix)], 2);
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/* 50 */         outPixels[(index++)] = pixel;
/*    */       }
/*    */     }
/* 53 */     return outPixels;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 57 */     return "Blur/Minimum";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MinimumFilter
 * JD-Core Version:    0.6.1
 */