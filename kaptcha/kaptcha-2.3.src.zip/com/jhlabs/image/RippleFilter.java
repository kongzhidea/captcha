/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class RippleFilter extends TransformFilter
/*     */ {
/*     */   public static final int SINE = 0;
/*     */   public static final int SAWTOOTH = 1;
/*     */   public static final int TRIANGLE = 2;
/*     */   public static final int NOISE = 3;
/*     */   private float xAmplitude;
/*     */   private float yAmplitude;
/*     */   private float xWavelength;
/*     */   private float yWavelength;
/*     */   private int waveType;
/*     */ 
/*     */   public RippleFilter()
/*     */   {
/*  58 */     this.xAmplitude = 5.0F;
/*  59 */     this.yAmplitude = 0.0F;
/*  60 */     this.xWavelength = (this.yWavelength = 16.0F);
/*     */   }
/*     */ 
/*     */   public void setXAmplitude(float xAmplitude)
/*     */   {
/*  69 */     this.xAmplitude = xAmplitude;
/*     */   }
/*     */ 
/*     */   public float getXAmplitude()
/*     */   {
/*  78 */     return this.xAmplitude;
/*     */   }
/*     */ 
/*     */   public void setXWavelength(float xWavelength)
/*     */   {
/*  87 */     this.xWavelength = xWavelength;
/*     */   }
/*     */ 
/*     */   public float getXWavelength()
/*     */   {
/*  96 */     return this.xWavelength;
/*     */   }
/*     */ 
/*     */   public void setYAmplitude(float yAmplitude)
/*     */   {
/* 105 */     this.yAmplitude = yAmplitude;
/*     */   }
/*     */ 
/*     */   public float getYAmplitude()
/*     */   {
/* 114 */     return this.yAmplitude;
/*     */   }
/*     */ 
/*     */   public void setYWavelength(float yWavelength)
/*     */   {
/* 123 */     this.yWavelength = yWavelength;
/*     */   }
/*     */ 
/*     */   public float getYWavelength()
/*     */   {
/* 132 */     return this.yWavelength;
/*     */   }
/*     */ 
/*     */   public void setWaveType(int waveType)
/*     */   {
/* 142 */     this.waveType = waveType;
/*     */   }
/*     */ 
/*     */   public int getWaveType()
/*     */   {
/* 151 */     return this.waveType;
/*     */   }
/*     */ 
/*     */   protected void transformSpace(Rectangle r) {
/* 155 */     if (this.edgeAction == 0) {
/* 156 */       r.x -= (int)this.xAmplitude;
/* 157 */       r.width += (int)(2.0F * this.xAmplitude);
/* 158 */       r.y -= (int)this.yAmplitude;
/* 159 */       r.height += (int)(2.0F * this.yAmplitude);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 164 */     float nx = y / this.xWavelength;
/* 165 */     float ny = x / this.yWavelength;
/*     */     float fx;
/*     */     float fy;
/* 167 */     switch (this.waveType) {
/*     */     case 0:
/*     */     default:
/* 170 */       fx = (float)Math.sin(nx);
/* 171 */       fy = (float)Math.sin(ny);
/* 172 */       break;
/*     */     case 1:
/* 174 */       fx = ImageMath.mod(nx, 1.0F);
/* 175 */       fy = ImageMath.mod(ny, 1.0F);
/* 176 */       break;
/*     */     case 2:
/* 178 */       fx = ImageMath.triangle(nx);
/* 179 */       fy = ImageMath.triangle(ny);
/* 180 */       break;
/*     */     case 3:
/* 182 */       fx = Noise.noise1(nx);
/* 183 */       fy = Noise.noise1(ny);
/*     */     }
/*     */ 
/* 186 */     out[0] = (x + this.xAmplitude * fx);
/* 187 */     out[1] = (y + this.yAmplitude * fy);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 191 */     return "Distort/Ripple...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RippleFilter
 * JD-Core Version:    0.6.1
 */