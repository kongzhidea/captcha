/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class ImageMath
/*     */ {
/*     */   public static final float PI = 3.141593F;
/*     */   public static final float HALF_PI = 1.570796F;
/*     */   public static final float QUARTER_PI = 0.7853982F;
/*     */   public static final float TWO_PI = 6.283186F;
/*     */   private static final float m00 = -0.5F;
/*     */   private static final float m01 = 1.5F;
/*     */   private static final float m02 = -1.5F;
/*     */   private static final float m03 = 0.5F;
/*     */   private static final float m10 = 1.0F;
/*     */   private static final float m11 = -2.5F;
/*     */   private static final float m12 = 2.0F;
/*     */   private static final float m13 = -0.5F;
/*     */   private static final float m20 = -0.5F;
/*     */   private static final float m21 = 0.0F;
/*     */   private static final float m22 = 0.5F;
/*     */   private static final float m23 = 0.0F;
/*     */   private static final float m30 = 0.0F;
/*     */   private static final float m31 = 1.0F;
/*     */   private static final float m32 = 0.0F;
/*     */   private static final float m33 = 0.0F;
/*     */ 
/*     */   public static float bias(float a, float b)
/*     */   {
/*  53 */     return a / ((1.0F / b - 2.0F) * (1.0F - a) + 1.0F);
/*     */   }
/*     */ 
/*     */   public static float gain(float a, float b)
/*     */   {
/*  75 */     float c = (1.0F / b - 2.0F) * (1.0F - 2.0F * a);
/*  76 */     if (a < 0.5D) {
/*  77 */       return a / (c + 1.0F);
/*     */     }
/*  79 */     return (c - a) / (c - 1.0F);
/*     */   }
/*     */ 
/*     */   public static float step(float a, float x)
/*     */   {
/*  89 */     return x < a ? 0.0F : 1.0F;
/*     */   }
/*     */ 
/*     */   public static float pulse(float a, float b, float x)
/*     */   {
/* 100 */     return (x < a) || (x >= b) ? 0.0F : 1.0F;
/*     */   }
/*     */ 
/*     */   public static float smoothPulse(float a1, float a2, float b1, float b2, float x)
/*     */   {
/* 113 */     if ((x < a1) || (x >= b2))
/* 114 */       return 0.0F;
/* 115 */     if (x >= a2) {
/* 116 */       if (x < b1)
/* 117 */         return 1.0F;
/* 118 */       x = (x - b1) / (b2 - b1);
/* 119 */       return 1.0F - x * x * (3.0F - 2.0F * x);
/*     */     }
/* 121 */     x = (x - a1) / (a2 - a1);
/* 122 */     return x * x * (3.0F - 2.0F * x);
/*     */   }
/*     */ 
/*     */   public static float smoothStep(float a, float b, float x)
/*     */   {
/* 133 */     if (x < a)
/* 134 */       return 0.0F;
/* 135 */     if (x >= b)
/* 136 */       return 1.0F;
/* 137 */     x = (x - a) / (b - a);
/* 138 */     return x * x * (3.0F - 2.0F * x);
/*     */   }
/*     */ 
/*     */   public static float circleUp(float x)
/*     */   {
/* 147 */     x = 1.0F - x;
/* 148 */     return (float)Math.sqrt(1.0F - x * x);
/*     */   }
/*     */ 
/*     */   public static float circleDown(float x)
/*     */   {
/* 157 */     return 1.0F - (float)Math.sqrt(1.0F - x * x);
/*     */   }
/*     */ 
/*     */   public static float clamp(float x, float a, float b)
/*     */   {
/* 168 */     return x > b ? b : x < a ? a : x;
/*     */   }
/*     */ 
/*     */   public static int clamp(int x, int a, int b)
/*     */   {
/* 179 */     return x > b ? b : x < a ? a : x;
/*     */   }
/*     */ 
/*     */   public static double mod(double a, double b)
/*     */   {
/* 189 */     int n = (int)(a / b);
/*     */ 
/* 191 */     a -= n * b;
/* 192 */     if (a < 0.0D)
/* 193 */       return a + b;
/* 194 */     return a;
/*     */   }
/*     */ 
/*     */   public static float mod(float a, float b)
/*     */   {
/* 204 */     int n = (int)(a / b);
/*     */ 
/* 206 */     a -= n * b;
/* 207 */     if (a < 0.0F)
/* 208 */       return a + b;
/* 209 */     return a;
/*     */   }
/*     */ 
/*     */   public static int mod(int a, int b)
/*     */   {
/* 219 */     int n = a / b;
/*     */ 
/* 221 */     a -= n * b;
/* 222 */     if (a < 0)
/* 223 */       return a + b;
/* 224 */     return a;
/*     */   }
/*     */ 
/*     */   public static float triangle(float x)
/*     */   {
/* 233 */     float r = mod(x, 1.0F);
/* 234 */     return 2.0F * (r < 0.5D ? r : 1.0F - r);
/*     */   }
/*     */ 
/*     */   public static float lerp(float t, float a, float b)
/*     */   {
/* 245 */     return a + t * (b - a);
/*     */   }
/*     */ 
/*     */   public static int lerp(float t, int a, int b)
/*     */   {
/* 256 */     return (int)(a + t * b - a);
/*     */   }
/*     */ 
/*     */   public static int mixColors(float t, int rgb1, int rgb2)
/*     */   {
/* 267 */     int a1 = rgb1 >> 24 & 0xFF;
/* 268 */     int r1 = rgb1 >> 16 & 0xFF;
/* 269 */     int g1 = rgb1 >> 8 & 0xFF;
/* 270 */     int b1 = rgb1 & 0xFF;
/* 271 */     int a2 = rgb2 >> 24 & 0xFF;
/* 272 */     int r2 = rgb2 >> 16 & 0xFF;
/* 273 */     int g2 = rgb2 >> 8 & 0xFF;
/* 274 */     int b2 = rgb2 & 0xFF;
/* 275 */     a1 = lerp(t, a1, a2);
/* 276 */     r1 = lerp(t, r1, r2);
/* 277 */     g1 = lerp(t, g1, g2);
/* 278 */     b1 = lerp(t, b1, b2);
/* 279 */     return a1 << 24 | r1 << 16 | g1 << 8 | b1;
/*     */   }
/*     */ 
/*     */   public static int bilinearInterpolate(float x, float y, int nw, int ne, int sw, int se)
/*     */   {
/* 291 */     int a0 = nw >> 24 & 0xFF;
/* 292 */     int r0 = nw >> 16 & 0xFF;
/* 293 */     int g0 = nw >> 8 & 0xFF;
/* 294 */     int b0 = nw & 0xFF;
/* 295 */     int a1 = ne >> 24 & 0xFF;
/* 296 */     int r1 = ne >> 16 & 0xFF;
/* 297 */     int g1 = ne >> 8 & 0xFF;
/* 298 */     int b1 = ne & 0xFF;
/* 299 */     int a2 = sw >> 24 & 0xFF;
/* 300 */     int r2 = sw >> 16 & 0xFF;
/* 301 */     int g2 = sw >> 8 & 0xFF;
/* 302 */     int b2 = sw & 0xFF;
/* 303 */     int a3 = se >> 24 & 0xFF;
/* 304 */     int r3 = se >> 16 & 0xFF;
/* 305 */     int g3 = se >> 8 & 0xFF;
/* 306 */     int b3 = se & 0xFF;
/*     */ 
/* 308 */     float cx = 1.0F - x;
/* 309 */     float cy = 1.0F - y;
/*     */ 
/* 311 */     float m0 = cx * a0 + x * a1;
/* 312 */     float m1 = cx * a2 + x * a3;
/* 313 */     int a = (int)(cy * m0 + y * m1);
/*     */ 
/* 315 */     m0 = cx * r0 + x * r1;
/* 316 */     m1 = cx * r2 + x * r3;
/* 317 */     int r = (int)(cy * m0 + y * m1);
/*     */ 
/* 319 */     m0 = cx * g0 + x * g1;
/* 320 */     m1 = cx * g2 + x * g3;
/* 321 */     int g = (int)(cy * m0 + y * m1);
/*     */ 
/* 323 */     m0 = cx * b0 + x * b1;
/* 324 */     m1 = cx * b2 + x * b3;
/* 325 */     int b = (int)(cy * m0 + y * m1);
/*     */ 
/* 327 */     return a << 24 | r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */   public static int brightnessNTSC(int rgb)
/*     */   {
/* 336 */     int r = rgb >> 16 & 0xFF;
/* 337 */     int g = rgb >> 8 & 0xFF;
/* 338 */     int b = rgb & 0xFF;
/* 339 */     return (int)(r * 0.299F + g * 0.587F + b * 0.114F);
/*     */   }
/*     */ 
/*     */   public static float spline(float x, int numKnots, float[] knots)
/*     */   {
/* 369 */     int numSpans = numKnots - 3;
/*     */ 
/* 373 */     if (numSpans < 1) {
/* 374 */       throw new IllegalArgumentException("Too few knots in spline");
/*     */     }
/* 376 */     x = clamp(x, 0.0F, 1.0F) * numSpans;
/* 377 */     int span = (int)x;
/* 378 */     if (span > numKnots - 4)
/* 379 */       span = numKnots - 4;
/* 380 */     x -= span;
/*     */ 
/* 382 */     float k0 = knots[span];
/* 383 */     float k1 = knots[(span + 1)];
/* 384 */     float k2 = knots[(span + 2)];
/* 385 */     float k3 = knots[(span + 3)];
/*     */ 
/* 387 */     float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
/* 388 */     float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
/* 389 */     float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
/* 390 */     float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
/*     */ 
/* 392 */     return ((c3 * x + c2) * x + c1) * x + c0;
/*     */   }
/*     */ 
/*     */   public static float spline(float x, int numKnots, int[] xknots, int[] yknots)
/*     */   {
/* 405 */     int numSpans = numKnots - 3;
/*     */ 
/* 409 */     if (numSpans < 1) {
/* 410 */       throw new IllegalArgumentException("Too few knots in spline");
/*     */     }
/* 412 */     for (int span = 0; (span < numSpans) && 
/* 413 */       (xknots[(span + 1)] <= x); span++);
/* 415 */     if (span > numKnots - 3)
/* 416 */       span = numKnots - 3;
/* 417 */     float t = (x - xknots[span]) / xknots[(span + 1)] - xknots[span];
/* 418 */     span--;
/* 419 */     if (span < 0) {
/* 420 */       span = 0;
/* 421 */       t = 0.0F;
/*     */     }
/*     */ 
/* 424 */     float k0 = yknots[span];
/* 425 */     float k1 = yknots[(span + 1)];
/* 426 */     float k2 = yknots[(span + 2)];
/* 427 */     float k3 = yknots[(span + 3)];
/*     */ 
/* 429 */     float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
/* 430 */     float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
/* 431 */     float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
/* 432 */     float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
/*     */ 
/* 434 */     return ((c3 * t + c2) * t + c1) * t + c0;
/*     */   }
/*     */ 
/*     */   public static int colorSpline(float x, int numKnots, int[] knots)
/*     */   {
/* 446 */     int numSpans = numKnots - 3;
/*     */ 
/* 450 */     if (numSpans < 1) {
/* 451 */       throw new IllegalArgumentException("Too few knots in spline");
/*     */     }
/* 453 */     x = clamp(x, 0.0F, 1.0F) * numSpans;
/* 454 */     int span = (int)x;
/* 455 */     if (span > numKnots - 4)
/* 456 */       span = numKnots - 4;
/* 457 */     x -= span;
/*     */ 
/* 459 */     int v = 0;
/* 460 */     for (int i = 0; i < 4; i++) {
/* 461 */       int shift = i * 8;
/*     */ 
/* 463 */       float k0 = knots[span] >> shift & 0xFF;
/* 464 */       float k1 = knots[(span + 1)] >> shift & 0xFF;
/* 465 */       float k2 = knots[(span + 2)] >> shift & 0xFF;
/* 466 */       float k3 = knots[(span + 3)] >> shift & 0xFF;
/*     */ 
/* 468 */       float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
/* 469 */       float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
/* 470 */       float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
/* 471 */       float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
/* 472 */       int n = (int)(((c3 * x + c2) * x + c1) * x + c0);
/* 473 */       if (n < 0)
/* 474 */         n = 0;
/* 475 */       else if (n > 255)
/* 476 */         n = 255;
/* 477 */       v |= n << shift;
/*     */     }
/*     */ 
/* 480 */     return v;
/*     */   }
/*     */ 
/*     */   public static int colorSpline(int x, int numKnots, int[] xknots, int[] yknots)
/*     */   {
/* 493 */     int numSpans = numKnots - 3;
/*     */ 
/* 497 */     if (numSpans < 1) {
/* 498 */       throw new IllegalArgumentException("Too few knots in spline");
/*     */     }
/* 500 */     for (int span = 0; (span < numSpans) && 
/* 501 */       (xknots[(span + 1)] <= x); span++);
/* 503 */     if (span > numKnots - 3)
/* 504 */       span = numKnots - 3;
/* 505 */     float t = x - xknots[span] / xknots[(span + 1)] - xknots[span];
/* 506 */     span--;
/* 507 */     if (span < 0) {
/* 508 */       span = 0;
/* 509 */       t = 0.0F;
/*     */     }
/*     */ 
/* 512 */     int v = 0;
/* 513 */     for (int i = 0; i < 4; i++) {
/* 514 */       int shift = i * 8;
/*     */ 
/* 516 */       float k0 = yknots[span] >> shift & 0xFF;
/* 517 */       float k1 = yknots[(span + 1)] >> shift & 0xFF;
/* 518 */       float k2 = yknots[(span + 2)] >> shift & 0xFF;
/* 519 */       float k3 = yknots[(span + 3)] >> shift & 0xFF;
/*     */ 
/* 521 */       float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
/* 522 */       float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
/* 523 */       float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
/* 524 */       float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
/* 525 */       int n = (int)(((c3 * t + c2) * t + c1) * t + c0);
/* 526 */       if (n < 0)
/* 527 */         n = 0;
/* 528 */       else if (n > 255)
/* 529 */         n = 255;
/* 530 */       v |= n << shift;
/*     */     }
/*     */ 
/* 533 */     return v;
/*     */   }
/*     */ 
/*     */   public static void resample(int[] source, int[] dest, int length, int offset, int stride, float[] out)
/*     */   {
/* 553 */     int srcIndex = offset;
/* 554 */     int destIndex = offset;
/* 555 */     int lastIndex = source.length;
/*     */ 
/* 558 */     float[] in = new float[length + 2];
/* 559 */     int i = 0;
/* 560 */     for (int j = 0; j < length; j++) {
/* 561 */       while (out[(i + 1)] < j)
/* 562 */         i++;
/* 563 */       in[j] = (i + (j - out[i]) / (out[(i + 1)] - out[i]));
/*     */     }
/*     */ 
/* 566 */     in[length] = length;
/* 567 */     in[(length + 1)] = length;
/*     */ 
/* 569 */     float inSegment = 1.0F;
/* 570 */     float outSegment = in[1];
/* 571 */     float sizfac = outSegment;
/*     */     float bSum;
/*     */     float gSum;
/*     */     float rSum;
/* 572 */     float aSum = rSum = gSum = bSum = 0.0F;
/* 573 */     int rgb = source[srcIndex];
/* 574 */     int a = rgb >> 24 & 0xFF;
/* 575 */     int r = rgb >> 16 & 0xFF;
/* 576 */     int g = rgb >> 8 & 0xFF;
/* 577 */     int b = rgb & 0xFF;
/* 578 */     srcIndex += stride;
/* 579 */     rgb = source[srcIndex];
/* 580 */     int nextA = rgb >> 24 & 0xFF;
/* 581 */     int nextR = rgb >> 16 & 0xFF;
/* 582 */     int nextG = rgb >> 8 & 0xFF;
/* 583 */     int nextB = rgb & 0xFF;
/* 584 */     srcIndex += stride;
/* 585 */     i = 1;
/*     */ 
/* 587 */     while (i <= length) {
/* 588 */       float aIntensity = inSegment * a + (1.0F - inSegment) * nextA;
/* 589 */       float rIntensity = inSegment * r + (1.0F - inSegment) * nextR;
/* 590 */       float gIntensity = inSegment * g + (1.0F - inSegment) * nextG;
/* 591 */       float bIntensity = inSegment * b + (1.0F - inSegment) * nextB;
/* 592 */       if (inSegment < outSegment) {
/* 593 */         aSum += aIntensity * inSegment;
/* 594 */         rSum += rIntensity * inSegment;
/* 595 */         gSum += gIntensity * inSegment;
/* 596 */         bSum += bIntensity * inSegment;
/* 597 */         outSegment -= inSegment;
/* 598 */         inSegment = 1.0F;
/* 599 */         a = nextA;
/* 600 */         r = nextR;
/* 601 */         g = nextG;
/* 602 */         b = nextB;
/* 603 */         if (srcIndex < lastIndex)
/* 604 */           rgb = source[srcIndex];
/* 605 */         nextA = rgb >> 24 & 0xFF;
/* 606 */         nextR = rgb >> 16 & 0xFF;
/* 607 */         nextG = rgb >> 8 & 0xFF;
/* 608 */         nextB = rgb & 0xFF;
/* 609 */         srcIndex += stride;
/*     */       } else {
/* 611 */         aSum += aIntensity * outSegment;
/* 612 */         rSum += rIntensity * outSegment;
/* 613 */         gSum += gIntensity * outSegment;
/* 614 */         bSum += bIntensity * outSegment;
/* 615 */         dest[destIndex] = ((int)Math.min(aSum / sizfac, 255.0F) << 24 | (int)Math.min(rSum / sizfac, 255.0F) << 16 | (int)Math.min(gSum / sizfac, 255.0F) << 8 | (int)Math.min(bSum / sizfac, 255.0F));
/*     */ 
/* 620 */         destIndex += stride;
/* 621 */         aSum = rSum = gSum = bSum = 0.0F;
/* 622 */         inSegment -= outSegment;
/* 623 */         outSegment = in[(i + 1)] - in[i];
/* 624 */         sizfac = outSegment;
/* 625 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void premultiply(int[] p, int offset, int length)
/*     */   {
/* 634 */     length += offset;
/* 635 */     for (int i = offset; i < length; i++) {
/* 636 */       int rgb = p[i];
/* 637 */       int a = rgb >> 24 & 0xFF;
/* 638 */       int r = rgb >> 16 & 0xFF;
/* 639 */       int g = rgb >> 8 & 0xFF;
/* 640 */       int b = rgb & 0xFF;
/* 641 */       float f = a * 0.003921569F;
/* 642 */       r = (int)(r * f);
/* 643 */       g = (int)(g * f);
/* 644 */       b = (int)(b * f);
/* 645 */       p[i] = (a << 24 | r << 16 | g << 8 | b);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void unpremultiply(int[] p, int offset, int length)
/*     */   {
/* 653 */     length += offset;
/* 654 */     for (int i = offset; i < length; i++) {
/* 655 */       int rgb = p[i];
/* 656 */       int a = rgb >> 24 & 0xFF;
/* 657 */       int r = rgb >> 16 & 0xFF;
/* 658 */       int g = rgb >> 8 & 0xFF;
/* 659 */       int b = rgb & 0xFF;
/* 660 */       if ((a != 0) && (a != 255)) {
/* 661 */         float f = 255.0F / a;
/* 662 */         r = (int)(r * f);
/* 663 */         g = (int)(g * f);
/* 664 */         b = (int)(b * f);
/* 665 */         if (r > 255)
/* 666 */           r = 255;
/* 667 */         if (g > 255)
/* 668 */           g = 255;
/* 669 */         if (b > 255)
/* 670 */           b = 255;
/* 671 */         p[i] = (a << 24 | r << 16 | g << 8 | b);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ImageMath
 * JD-Core Version:    0.6.1
 */