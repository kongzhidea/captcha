/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class GrayFilter extends PointFilter
/*    */ {
/*    */   public GrayFilter()
/*    */   {
/* 28 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 32 */     int a = rgb & 0xFF000000;
/* 33 */     int r = rgb >> 16 & 0xFF;
/* 34 */     int g = rgb >> 8 & 0xFF;
/* 35 */     int b = rgb & 0xFF;
/* 36 */     r = (r + 255) / 2;
/* 37 */     g = (g + 255) / 2;
/* 38 */     b = (b + 255) / 2;
/* 39 */     return a | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 43 */     return "Colors/Gray Out";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GrayFilter
 * JD-Core Version:    0.6.1
 */