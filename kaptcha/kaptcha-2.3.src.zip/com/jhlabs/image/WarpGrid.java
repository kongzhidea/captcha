/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class WarpGrid
/*     */ {
/*  28 */   public float[] xGrid = null;
/*  29 */   public float[] yGrid = null;
/*     */   public int rows;
/*     */   public int cols;
/*     */   private static final float m00 = -0.5F;
/*     */   private static final float m01 = 1.5F;
/*     */   private static final float m02 = -1.5F;
/*     */   private static final float m03 = 0.5F;
/*     */   private static final float m10 = 1.0F;
/*     */   private static final float m11 = -2.5F;
/*     */   private static final float m12 = 2.0F;
/*     */   private static final float m13 = -0.5F;
/*     */   private static final float m20 = -0.5F;
/*     */   private static final float m22 = 0.5F;
/*     */   private static final float m31 = 1.0F;
/*     */ 
/*     */   public WarpGrid(int rows, int cols, int w, int h)
/*     */   {
/*  33 */     this.rows = rows;
/*  34 */     this.cols = cols;
/*  35 */     this.xGrid = new float[rows * cols];
/*  36 */     this.yGrid = new float[rows * cols];
/*  37 */     int index = 0;
/*  38 */     for (int row = 0; row < rows; row++)
/*  39 */       for (int col = 0; col < cols; col++) {
/*  40 */         this.xGrid[index] = (col * w - 1 / cols - 1);
/*  41 */         this.yGrid[index] = (row * h - 1 / rows - 1);
/*  42 */         index++;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void addRow(int before)
/*     */   {
/*  51 */     int size = (this.rows + 1) * this.cols;
/*  52 */     float[] x = new float[size];
/*  53 */     float[] y = new float[size];
/*     */ 
/*  55 */     this.rows += 1;
/*  56 */     int i = 0;
/*  57 */     int j = 0;
/*  58 */     for (int row = 0; row < this.rows; row++) {
/*  59 */       for (int col = 0; col < this.cols; col++) {
/*  60 */         int k = j + col;
/*  61 */         int l = i + col;
/*  62 */         if (row == before) {
/*  63 */           x[k] = ((this.xGrid[l] + this.xGrid[k]) / 2.0F);
/*  64 */           y[k] = ((this.yGrid[l] + this.yGrid[k]) / 2.0F);
/*     */         } else {
/*  66 */           x[k] = this.xGrid[l];
/*  67 */           y[k] = this.yGrid[l];
/*     */         }
/*     */       }
/*  70 */       if (row != before - 1)
/*  71 */         i += this.cols;
/*  72 */       j += this.cols;
/*     */     }
/*  74 */     this.xGrid = x;
/*  75 */     this.yGrid = y;
/*     */   }
/*     */ 
/*     */   public void addCol(int before)
/*     */   {
/*  82 */     int size = this.rows * (this.cols + 1);
/*  83 */     float[] x = new float[size];
/*  84 */     float[] y = new float[size];
/*     */ 
/*  86 */     this.cols += 1;
/*  87 */     int i = 0;
/*  88 */     int j = 0;
/*  89 */     for (int row = 0; row < this.rows; row++)
/*     */     {
/*  92 */       for (int col = 0; col < this.cols; col++) {
/*  93 */         if (col == before) {
/*  94 */           x[j] = ((this.xGrid[i] + this.xGrid[(i - 1)]) / 2.0F);
/*  95 */           y[j] = ((this.yGrid[i] + this.yGrid[(i - 1)]) / 2.0F);
/*     */         } else {
/*  97 */           x[j] = this.xGrid[i];
/*  98 */           y[j] = this.yGrid[i];
/*  99 */           i++;
/*     */         }
/* 101 */         j++;
/*     */       }
/*     */     }
/* 104 */     this.xGrid = x;
/* 105 */     this.yGrid = y;
/*     */   }
/*     */ 
/*     */   public void removeRow(int r)
/*     */   {
/* 112 */     int size = (this.rows - 1) * this.cols;
/* 113 */     float[] x = new float[size];
/* 114 */     float[] y = new float[size];
/*     */ 
/* 116 */     this.rows -= 1;
/* 117 */     int i = 0;
/* 118 */     int j = 0;
/* 119 */     for (int row = 0; row < this.rows; row++) {
/* 120 */       for (int col = 0; col < this.cols; col++) {
/* 121 */         int k = j + col;
/* 122 */         int l = i + col;
/* 123 */         x[k] = this.xGrid[l];
/* 124 */         y[k] = this.yGrid[l];
/*     */       }
/* 126 */       if (row == r - 1)
/* 127 */         i += this.cols;
/* 128 */       i += this.cols;
/* 129 */       j += this.cols;
/*     */     }
/* 131 */     this.xGrid = x;
/* 132 */     this.yGrid = y;
/*     */   }
/*     */ 
/*     */   public void removeCol(int r)
/*     */   {
/* 139 */     int size = this.rows * (this.cols + 1);
/* 140 */     float[] x = new float[size];
/* 141 */     float[] y = new float[size];
/*     */ 
/* 143 */     this.cols -= 1;
/* 144 */     for (int row = 0; row < this.rows; row++) {
/* 145 */       int i = row * (this.cols + 1);
/* 146 */       int j = row * this.cols;
/* 147 */       for (int col = 0; col < this.cols; col++) {
/* 148 */         x[j] = this.xGrid[i];
/* 149 */         y[j] = this.yGrid[i];
/* 150 */         if (col == r - 1)
/* 151 */           i++;
/* 152 */         i++;
/* 153 */         j++;
/*     */       }
/*     */     }
/* 156 */     this.xGrid = x;
/* 157 */     this.yGrid = y;
/*     */   }
/*     */ 
/*     */   public void lerp(float t, WarpGrid destination, WarpGrid intermediate) {
/* 161 */     if ((this.rows != destination.rows) || (this.cols != destination.cols))
/* 162 */       throw new IllegalArgumentException("source and destination are different sizes");
/* 163 */     if ((this.rows != intermediate.rows) || (this.cols != intermediate.cols))
/* 164 */       throw new IllegalArgumentException("source and intermediate are different sizes");
/* 165 */     int index = 0;
/* 166 */     for (int row = 0; row < this.rows; row++)
/* 167 */       for (int col = 0; col < this.cols; col++) {
/* 168 */         intermediate.xGrid[index] = ImageMath.lerp(t, this.xGrid[index], destination.xGrid[index]);
/* 169 */         intermediate.yGrid[index] = ImageMath.lerp(t, this.yGrid[index], destination.yGrid[index]);
/* 170 */         index++;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void warp(int[] inPixels, int cols, int rows, WarpGrid sourceGrid, WarpGrid destGrid, int[] outPixels)
/*     */   {
/*     */     try
/*     */     {
/* 182 */       if ((sourceGrid.rows != destGrid.rows) || (sourceGrid.cols != destGrid.cols)) {
/* 183 */         throw new IllegalArgumentException("source and destination grids are different sizes");
/*     */       }
/* 185 */       int size = Math.max(cols, rows);
/* 186 */       float[] xrow = new float[size];
/* 187 */       float[] yrow = new float[size];
/* 188 */       float[] scale = new float[size + 1];
/* 189 */       float[] interpolated = new float[size + 1];
/*     */ 
/* 191 */       int gridCols = sourceGrid.cols;
/* 192 */       int gridRows = sourceGrid.rows;
/*     */ 
/* 194 */       WarpGrid splines = new WarpGrid(rows, gridCols, 1, 1);
/*     */ 
/* 196 */       for (int u = 0; u < gridCols; u++) {
/* 197 */         int i = u;
/*     */ 
/* 199 */         for (int v = 0; v < gridRows; v++) {
/* 200 */           xrow[v] = sourceGrid.xGrid[i];
/* 201 */           yrow[v] = sourceGrid.yGrid[i];
/* 202 */           i += gridCols;
/*     */         }
/*     */ 
/* 205 */         interpolateSpline(yrow, xrow, 0, gridRows, interpolated, 0, rows);
/*     */ 
/* 207 */         i = u;
/* 208 */         for (int y = 0; y < rows; y++) {
/* 209 */           splines.xGrid[i] = interpolated[y];
/* 210 */           i += gridCols;
/*     */         }
/*     */       }
/*     */ 
/* 214 */       for (u = 0; u < gridCols; u++) {
/* 215 */         int i = u;
/*     */ 
/* 217 */         for (int v = 0; v < gridRows; v++) {
/* 218 */           xrow[v] = destGrid.xGrid[i];
/* 219 */           yrow[v] = destGrid.yGrid[i];
/* 220 */           i += gridCols;
/*     */         }
/*     */ 
/* 223 */         interpolateSpline(yrow, xrow, 0, gridRows, interpolated, 0, rows);
/*     */ 
/* 225 */         i = u;
/* 226 */         for (int y = 0; y < rows; y++) {
/* 227 */           splines.yGrid[i] = interpolated[y];
/* 228 */           i += gridCols;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 233 */       int[] intermediate = new int[rows * cols];
/*     */ 
/* 235 */       int offset = 0;
/* 236 */       for (int y = 0; y < rows; y++)
/*     */       {
/* 238 */         interpolateSpline(splines.xGrid, splines.yGrid, offset, gridCols, scale, 0, cols);
/* 239 */         scale[cols] = cols;
/* 240 */         ImageMath.resample(inPixels, intermediate, cols, y * cols, 1, scale);
/* 241 */         offset += gridCols;
/*     */       }
/*     */ 
/* 245 */       splines = new WarpGrid(gridRows, cols, 1, 1);
/*     */ 
/* 247 */       offset = 0;
/* 248 */       int offset2 = 0;
/* 249 */       for (int v = 0; v < gridRows; v++) {
/* 250 */         interpolateSpline(sourceGrid.xGrid, sourceGrid.yGrid, offset, gridCols, splines.xGrid, offset2, cols);
/* 251 */         offset += gridCols;
/* 252 */         offset2 += cols;
/*     */       }
/*     */ 
/* 255 */       offset = 0;
/* 256 */       offset2 = 0;
/* 257 */       for (v = 0; v < gridRows; v++) {
/* 258 */         interpolateSpline(destGrid.xGrid, destGrid.yGrid, offset, gridCols, splines.yGrid, offset2, cols);
/* 259 */         offset += gridCols;
/* 260 */         offset2 += cols;
/*     */       }
/*     */ 
/* 265 */       for (int x = 0; x < cols; x++) {
/* 266 */         int i = x;
/*     */ 
/* 268 */         for (v = 0; v < gridRows; v++) {
/* 269 */           xrow[v] = splines.xGrid[i];
/* 270 */           yrow[v] = splines.yGrid[i];
/* 271 */           i += cols;
/*     */         }
/*     */ 
/* 274 */         interpolateSpline(xrow, yrow, 0, gridRows, scale, 0, rows);
/* 275 */         scale[rows] = rows;
/* 276 */         ImageMath.resample(intermediate, outPixels, rows, x, cols, scale);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 280 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void interpolateSpline(float[] xKnots, float[] yKnots, int offset, int length, float[] splineY, int splineOffset, int splineLength)
/*     */   {
/* 297 */     int index = offset;
/* 298 */     int end = offset + length - 1;
/*     */ 
/* 303 */     float x0 = xKnots[index];
/*     */     float k2;
/*     */     float k1;
/* 304 */     float k0 = k1 = k2 = yKnots[index];
/* 305 */     float x1 = xKnots[(index + 1)];
/* 306 */     float k3 = yKnots[(index + 1)];
/*     */ 
/* 308 */     for (int i = 0; i < splineLength; i++) {
/* 309 */       if ((index <= end) && (i > xKnots[index])) {
/* 310 */         k0 = k1;
/* 311 */         k1 = k2;
/* 312 */         k2 = k3;
/* 313 */         x0 = xKnots[index];
/* 314 */         index++;
/* 315 */         if (index <= end)
/* 316 */           x1 = xKnots[index];
/* 317 */         if (index < end)
/* 318 */           k3 = yKnots[(index + 1)];
/*     */         else
/* 320 */           k3 = k2;
/*     */       }
/* 322 */       float t = (i - x0) / (x1 - x0);
/* 323 */       float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
/* 324 */       float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
/* 325 */       float c1 = -0.5F * k0 + 0.5F * k2;
/* 326 */       float c0 = 1.0F * k1;
/*     */ 
/* 328 */       splineY[(splineOffset + i)] = (((c3 * t + c2) * t + c1) * t + c0);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void interpolateSpline2(float[] xKnots, float[] yKnots, int offset, float[] splineY, int splineOffset, int splineLength) {
/* 333 */     int index = offset;
/*     */ 
/* 337 */     float leftX = xKnots[index];
/* 338 */     float leftY = yKnots[index];
/* 339 */     float rightX = xKnots[(index + 1)];
/* 340 */     float rightY = yKnots[(index + 1)];
/*     */ 
/* 342 */     for (int i = 0; i < splineLength; i++) {
/* 343 */       if (i > xKnots[index]) {
/* 344 */         leftX = xKnots[index];
/* 345 */         leftY = yKnots[index];
/* 346 */         index++;
/* 347 */         rightX = xKnots[index];
/* 348 */         rightY = yKnots[index];
/*     */       }
/* 350 */       float f = (i - leftX) / (rightX - leftX);
/* 351 */       splineY[(splineOffset + i)] = (leftY + f * (rightY - leftY));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.WarpGrid
 * JD-Core Version:    0.6.1
 */