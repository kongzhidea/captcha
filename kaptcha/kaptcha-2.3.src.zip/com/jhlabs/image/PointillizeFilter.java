/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class PointillizeFilter extends CellularFilter
/*    */ {
/* 25 */   private float edgeThickness = 0.4F;
/* 26 */   private boolean fadeEdges = false;
/* 27 */   private int edgeColor = -16777216;
/* 28 */   private float fuzziness = 0.1F;
/*    */ 
/*    */   public PointillizeFilter() {
/* 31 */     setScale(16.0F);
/* 32 */     setRandomness(0.0F);
/*    */   }
/*    */ 
/*    */   public void setEdgeThickness(float edgeThickness) {
/* 36 */     this.edgeThickness = edgeThickness;
/*    */   }
/*    */ 
/*    */   public float getEdgeThickness() {
/* 40 */     return this.edgeThickness;
/*    */   }
/*    */ 
/*    */   public void setFadeEdges(boolean fadeEdges) {
/* 44 */     this.fadeEdges = fadeEdges;
/*    */   }
/*    */ 
/*    */   public boolean getFadeEdges() {
/* 48 */     return this.fadeEdges;
/*    */   }
/*    */ 
/*    */   public void setEdgeColor(int edgeColor) {
/* 52 */     this.edgeColor = edgeColor;
/*    */   }
/*    */ 
/*    */   public int getEdgeColor() {
/* 56 */     return this.edgeColor;
/*    */   }
/*    */ 
/*    */   public void setFuzziness(float fuzziness) {
/* 60 */     this.fuzziness = fuzziness;
/*    */   }
/*    */ 
/*    */   public float getFuzziness() {
/* 64 */     return this.fuzziness;
/*    */   }
/*    */ 
/*    */   public int getPixel(int x, int y, int[] inPixels, int width, int height) {
/* 68 */     float nx = this.m00 * x + this.m01 * y;
/* 69 */     float ny = this.m10 * x + this.m11 * y;
/* 70 */     nx /= this.scale;
/* 71 */     ny /= this.scale * this.stretch;
/* 72 */     nx += 1000.0F;
/* 73 */     ny += 1000.0F;
/* 74 */     float f = evaluate(nx, ny);
/*    */ 
/* 76 */     float f1 = this.results[0].distance;
/* 77 */     int srcx = ImageMath.clamp((int)((this.results[0].x - 1000.0F) * this.scale), 0, width - 1);
/* 78 */     int srcy = ImageMath.clamp((int)((this.results[0].y - 1000.0F) * this.scale), 0, height - 1);
/* 79 */     int v = inPixels[(srcy * width + srcx)];
/*    */ 
/* 81 */     if (this.fadeEdges) {
/* 82 */       float f2 = this.results[1].distance;
/* 83 */       srcx = ImageMath.clamp((int)((this.results[1].x - 1000.0F) * this.scale), 0, width - 1);
/* 84 */       srcy = ImageMath.clamp((int)((this.results[1].y - 1000.0F) * this.scale), 0, height - 1);
/* 85 */       int v2 = inPixels[(srcy * width + srcx)];
/* 86 */       v = ImageMath.mixColors(0.5F * f1 / f2, v, v2);
/*    */     } else {
/* 88 */       f = 1.0F - ImageMath.smoothStep(this.edgeThickness, this.edgeThickness + this.fuzziness, f1);
/* 89 */       v = ImageMath.mixColors(f, this.edgeColor, v);
/*    */     }
/* 91 */     return v;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 95 */     return "Pixellate/Pointillize...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PointillizeFilter
 * JD-Core Version:    0.6.1
 */