/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class QuantizeFilter extends WholeImageFilter
/*     */ {
/*  37 */   protected static final int[] matrix = { 0, 0, 0, 0, 0, 7, 3, 5, 1 };
/*     */ 
/*  42 */   private int sum = 16;
/*     */   private boolean dither;
/*  45 */   private int numColors = 256;
/*  46 */   private boolean serpentine = true;
/*     */ 
/*     */   public void setNumColors(int numColors)
/*     */   {
/*  53 */     this.numColors = Math.min(Math.max(numColors, 8), 256);
/*     */   }
/*     */ 
/*     */   public int getNumColors()
/*     */   {
/*  61 */     return this.numColors;
/*     */   }
/*     */ 
/*     */   public void setDither(boolean dither)
/*     */   {
/*  69 */     this.dither = dither;
/*     */   }
/*     */ 
/*     */   public boolean getDither()
/*     */   {
/*  77 */     return this.dither;
/*     */   }
/*     */ 
/*     */   public void setSerpentine(boolean serpentine)
/*     */   {
/*  85 */     this.serpentine = serpentine;
/*     */   }
/*     */ 
/*     */   public boolean getSerpentine()
/*     */   {
/*  93 */     return this.serpentine;
/*     */   }
/*     */ 
/*     */   public void quantize(int[] inPixels, int[] outPixels, int width, int height, int numColors, boolean dither, boolean serpentine) {
/*  97 */     int count = width * height;
/*  98 */     Quantizer quantizer = new OctTreeQuantizer();
/*  99 */     quantizer.setup(numColors);
/* 100 */     quantizer.addPixels(inPixels, 0, count);
/* 101 */     int[] table = quantizer.buildColorTable();
/*     */ 
/* 103 */     if (!dither) {
/* 104 */       for (int i = 0; i < count; i++)
/* 105 */         outPixels[i] = table[quantizer.getIndexForColor(inPixels[i])];
/*     */     } else {
/* 107 */       int index = 0;
/* 108 */       for (int y = 0; y < height; y++) {
/* 109 */         boolean reverse = (serpentine) && ((y & 0x1) == 1);
/*     */         int direction;
/*     */         int direction;
/* 111 */         if (reverse) {
/* 112 */           index = y * width + width - 1;
/* 113 */           direction = -1;
/*     */         } else {
/* 115 */           index = y * width;
/* 116 */           direction = 1;
/*     */         }
/* 118 */         for (int x = 0; x < width; x++) {
/* 119 */           int rgb1 = inPixels[index];
/* 120 */           int rgb2 = table[quantizer.getIndexForColor(rgb1)];
/*     */ 
/* 122 */           outPixels[index] = rgb2;
/*     */ 
/* 124 */           int r1 = rgb1 >> 16 & 0xFF;
/* 125 */           int g1 = rgb1 >> 8 & 0xFF;
/* 126 */           int b1 = rgb1 & 0xFF;
/*     */ 
/* 128 */           int r2 = rgb2 >> 16 & 0xFF;
/* 129 */           int g2 = rgb2 >> 8 & 0xFF;
/* 130 */           int b2 = rgb2 & 0xFF;
/*     */ 
/* 132 */           int er = r1 - r2;
/* 133 */           int eg = g1 - g2;
/* 134 */           int eb = b1 - b2;
/*     */ 
/* 136 */           for (int i = -1; i <= 1; i++) {
/* 137 */             int iy = i + y;
/* 138 */             if ((0 <= iy) && (iy < height)) {
/* 139 */               for (int j = -1; j <= 1; j++) {
/* 140 */                 int jx = j + x;
/* 141 */                 if ((0 <= jx) && (jx < width))
/*     */                 {
/*     */                   int w;
/*     */                   int w;
/* 143 */                   if (reverse)
/* 144 */                     w = matrix[((i + 1) * 3 - j + 1)];
/*     */                   else
/* 146 */                     w = matrix[((i + 1) * 3 + j + 1)];
/* 147 */                   if (w != 0) {
/* 148 */                     int k = reverse ? index - j : index + j;
/* 149 */                     rgb1 = inPixels[k];
/* 150 */                     r1 = rgb1 >> 16 & 0xFF;
/* 151 */                     g1 = rgb1 >> 8 & 0xFF;
/* 152 */                     b1 = rgb1 & 0xFF;
/* 153 */                     r1 += er * w / this.sum;
/* 154 */                     g1 += eg * w / this.sum;
/* 155 */                     b1 += eb * w / this.sum;
/* 156 */                     inPixels[k] = (PixelUtils.clamp(r1) << 16 | PixelUtils.clamp(g1) << 8 | PixelUtils.clamp(b1));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 162 */           index += direction;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 169 */     int[] outPixels = new int[width * height];
/*     */ 
/* 171 */     quantize(inPixels, outPixels, width, height, this.numColors, this.dither, this.serpentine);
/*     */ 
/* 173 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 177 */     return "Colors/Quantize...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.QuantizeFilter
 * JD-Core Version:    0.6.1
 */