/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Composite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class CompositeFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private Composite composite;
/*     */   private AffineTransform transform;
/*     */ 
/*     */   public CompositeFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompositeFilter(Composite composite)
/*     */   {
/*  42 */     this.composite = composite;
/*     */   }
/*     */ 
/*     */   public CompositeFilter(Composite composite, AffineTransform transform)
/*     */   {
/*  51 */     this.composite = composite;
/*  52 */     this.transform = transform;
/*     */   }
/*     */ 
/*     */   public void setComposite(Composite composite)
/*     */   {
/*  61 */     this.composite = composite;
/*     */   }
/*     */ 
/*     */   public Composite getComposite()
/*     */   {
/*  70 */     return this.composite;
/*     */   }
/*     */ 
/*     */   public void setTransform(AffineTransform transform)
/*     */   {
/*  79 */     this.transform = transform;
/*     */   }
/*     */ 
/*     */   public AffineTransform getTransform()
/*     */   {
/*  88 */     return this.transform;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  92 */     if (dst == null) {
/*  93 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  95 */     Graphics2D g = dst.createGraphics();
/*  96 */     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  97 */     g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*  98 */     g.setComposite(this.composite);
/*  99 */     g.drawRenderedImage(src, this.transform);
/* 100 */     g.dispose();
/* 101 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 105 */     return "Composite";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CompositeFilter
 * JD-Core Version:    0.6.1
 */