/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ public class VariableBlurFilter extends AbstractBufferedImageOp
/*     */ {
/*  29 */   private int hRadius = 1;
/*  30 */   private int vRadius = 1;
/*  31 */   private int iterations = 1;
/*     */   private BufferedImage blurMask;
/*  33 */   private boolean premultiplyAlpha = true;
/*     */ 
/*     */   public void setPremultiplyAlpha(boolean premultiplyAlpha)
/*     */   {
/*  41 */     this.premultiplyAlpha = premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getPremultiplyAlpha()
/*     */   {
/*  50 */     return this.premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  54 */     int width = src.getWidth();
/*  55 */     int height = src.getHeight();
/*     */ 
/*  57 */     if (dst == null) {
/*  58 */       dst = new BufferedImage(width, height, 2);
/*     */     }
/*  60 */     int[] inPixels = new int[width * height];
/*  61 */     int[] outPixels = new int[width * height];
/*  62 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */ 
/*  64 */     if (this.premultiplyAlpha)
/*  65 */       ImageMath.premultiply(inPixels, 0, inPixels.length);
/*  66 */     for (int i = 0; i < this.iterations; i++) {
/*  67 */       blur(inPixels, outPixels, width, height, this.hRadius, 1);
/*  68 */       blur(outPixels, inPixels, height, width, this.vRadius, 2);
/*     */     }
/*  70 */     if (this.premultiplyAlpha) {
/*  71 */       ImageMath.unpremultiply(inPixels, 0, inPixels.length);
/*     */     }
/*  73 */     setRGB(dst, 0, 0, width, height, inPixels);
/*  74 */     return dst;
/*     */   }
/*     */ 
/*     */   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
/*  78 */     if (dstCM == null)
/*  79 */       dstCM = src.getColorModel();
/*  80 */     return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
/*     */   }
/*     */ 
/*     */   public Rectangle2D getBounds2D(BufferedImage src) {
/*  84 */     return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/*     */   }
/*     */ 
/*     */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/*  88 */     if (dstPt == null)
/*  89 */       dstPt = new Point2D.Double();
/*  90 */     dstPt.setLocation(srcPt.getX(), srcPt.getY());
/*  91 */     return dstPt;
/*     */   }
/*     */ 
/*     */   public RenderingHints getRenderingHints() {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */   public void blur(int[] in, int[] out, int width, int height, int radius, int pass) {
/*  99 */     int widthMinus1 = width - 1;
/* 100 */     int[] r = new int[width];
/* 101 */     int[] g = new int[width];
/* 102 */     int[] b = new int[width];
/* 103 */     int[] a = new int[width];
/* 104 */     int[] mask = new int[width];
/*     */ 
/* 106 */     int inIndex = 0;
/*     */ 
/* 108 */     for (int y = 0; y < height; y++) {
/* 109 */       int outIndex = y;
/*     */ 
/* 111 */       if (this.blurMask != null) {
/* 112 */         if (pass == 1)
/* 113 */           getRGB(this.blurMask, 0, y, width, 1, mask);
/*     */         else {
/* 115 */           getRGB(this.blurMask, y, 0, 1, width, mask);
/*     */         }
/*     */       }
/* 118 */       for (int x = 0; x < width; x++) {
/* 119 */         int argb = in[(inIndex + x)];
/* 120 */         a[x] = (argb >> 24 & 0xFF);
/* 121 */         r[x] = (argb >> 16 & 0xFF);
/* 122 */         g[x] = (argb >> 8 & 0xFF);
/* 123 */         b[x] = (argb & 0xFF);
/* 124 */         if (x != 0) {
/* 125 */           a[x] += a[(x - 1)];
/* 126 */           r[x] += r[(x - 1)];
/* 127 */           g[x] += g[(x - 1)];
/* 128 */           b[x] += b[(x - 1)];
/*     */         }
/*     */       }
/*     */ 
/* 132 */       for (int x = 0; x < width; x++)
/*     */       {
/*     */         int ra;
/*     */         int ra;
/* 135 */         if (this.blurMask != null)
/*     */         {
/*     */           int ra;
/* 136 */           if (pass == 1)
/* 137 */             ra = (int)((mask[x] & 0xFF) * this.hRadius / 255.0F);
/*     */           else
/* 139 */             ra = (int)((mask[x] & 0xFF) * this.vRadius / 255.0F);
/*     */         }
/*     */         else
/*     */         {
/*     */           int ra;
/* 141 */           if (pass == 1)
/* 142 */             ra = (int)(blurRadiusAt(x, y, width, height) * this.hRadius);
/*     */           else {
/* 144 */             ra = (int)(blurRadiusAt(y, x, height, width) * this.vRadius);
/*     */           }
/*     */         }
/* 147 */         int divisor = 2 * ra + 1;
/* 148 */         int ta = 0; int tr = 0; int tg = 0; int tb = 0;
/* 149 */         int i1 = x + ra;
/* 150 */         if (i1 > widthMinus1) {
/* 151 */           int f = i1 - widthMinus1;
/* 152 */           int l = widthMinus1;
/* 153 */           ta += (a[l] - a[(l - 1)]) * f;
/* 154 */           tr += (r[l] - r[(l - 1)]) * f;
/* 155 */           tg += (g[l] - g[(l - 1)]) * f;
/* 156 */           tb += (b[l] - b[(l - 1)]) * f;
/* 157 */           i1 = widthMinus1;
/*     */         }
/* 159 */         int i2 = x - ra - 1;
/* 160 */         if (i2 < 0) {
/* 161 */           ta -= a[0] * i2;
/* 162 */           tr -= r[0] * i2;
/* 163 */           tg -= g[0] * i2;
/* 164 */           tb -= b[0] * i2;
/* 165 */           i2 = 0;
/*     */         }
/*     */ 
/* 168 */         ta += a[i1] - a[i2];
/* 169 */         tr += r[i1] - r[i2];
/* 170 */         tg += g[i1] - g[i2];
/* 171 */         tb += b[i1] - b[i2];
/* 172 */         out[outIndex] = (ta / divisor << 24 | tr / divisor << 16 | tg / divisor << 8 | tb / divisor);
/*     */ 
/* 174 */         outIndex += height;
/*     */       }
/* 176 */       inIndex += width;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected float blurRadiusAt(int x, int y, int width, int height)
/*     */   {
/* 189 */     return x / width;
/*     */   }
/*     */ 
/*     */   public void setHRadius(int hRadius)
/*     */   {
/* 199 */     this.hRadius = hRadius;
/*     */   }
/*     */ 
/*     */   public int getHRadius()
/*     */   {
/* 208 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setVRadius(int vRadius)
/*     */   {
/* 218 */     this.vRadius = vRadius;
/*     */   }
/*     */ 
/*     */   public int getVRadius()
/*     */   {
/* 227 */     return this.vRadius;
/*     */   }
/*     */ 
/*     */   public void setRadius(int radius)
/*     */   {
/* 237 */     this.hRadius = (this.vRadius = radius);
/*     */   }
/*     */ 
/*     */   public int getRadius()
/*     */   {
/* 246 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setIterations(int iterations)
/*     */   {
/* 256 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */   public int getIterations()
/*     */   {
/* 265 */     return this.iterations;
/*     */   }
/*     */ 
/*     */   public void setBlurMask(BufferedImage blurMask)
/*     */   {
/* 274 */     this.blurMask = blurMask;
/*     */   }
/*     */ 
/*     */   public BufferedImage getBlurMask()
/*     */   {
/* 283 */     return this.blurMask;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 287 */     return "Blur/Variable Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.VariableBlurFilter
 * JD-Core Version:    0.6.1
 */