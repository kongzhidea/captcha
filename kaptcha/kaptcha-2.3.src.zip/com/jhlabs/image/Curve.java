/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class Curve
/*     */ {
/*     */   public float[] x;
/*     */   public float[] y;
/*     */ 
/*     */   public Curve()
/*     */   {
/*  15 */     this.x = new float[] { 0.0F, 1.0F };
/*  16 */     this.y = new float[] { 0.0F, 1.0F };
/*     */   }
/*     */ 
/*     */   public Curve(Curve curve) {
/*  20 */     this.x = ((float[])curve.x.clone());
/*  21 */     this.y = ((float[])curve.y.clone());
/*     */   }
/*     */ 
/*     */   public int addKnot(float kx, float ky) {
/*  25 */     int pos = -1;
/*  26 */     int numKnots = this.x.length;
/*  27 */     float[] nx = new float[numKnots + 1];
/*  28 */     float[] ny = new float[numKnots + 1];
/*  29 */     int j = 0;
/*  30 */     for (int i = 0; i < numKnots; i++) {
/*  31 */       if ((pos == -1) && (this.x[i] > kx)) {
/*  32 */         pos = j;
/*  33 */         nx[j] = kx;
/*  34 */         ny[j] = ky;
/*  35 */         j++;
/*     */       }
/*  37 */       nx[j] = this.x[i];
/*  38 */       ny[j] = this.y[i];
/*  39 */       j++;
/*     */     }
/*  41 */     if (pos == -1) {
/*  42 */       pos = j;
/*  43 */       nx[j] = kx;
/*  44 */       ny[j] = ky;
/*     */     }
/*  46 */     this.x = nx;
/*  47 */     this.y = ny;
/*  48 */     return pos;
/*     */   }
/*     */ 
/*     */   public void removeKnot(int n) {
/*  52 */     int numKnots = this.x.length;
/*  53 */     if (numKnots <= 2)
/*  54 */       return;
/*  55 */     float[] nx = new float[numKnots - 1];
/*  56 */     float[] ny = new float[numKnots - 1];
/*  57 */     int j = 0;
/*  58 */     for (int i = 0; i < numKnots - 1; i++) {
/*  59 */       if (i == n)
/*  60 */         j++;
/*  61 */       nx[i] = this.x[j];
/*  62 */       ny[i] = this.y[j];
/*  63 */       j++;
/*     */     }
/*  65 */     this.x = nx;
/*  66 */     this.y = ny;
/*     */   }
/*     */ 
/*     */   private void sortKnots() {
/*  70 */     int numKnots = this.x.length;
/*  71 */     for (int i = 1; i < numKnots - 1; i++)
/*  72 */       for (int j = 1; j < i; j++)
/*  73 */         if (this.x[i] < this.x[j]) {
/*  74 */           float t = this.x[i];
/*  75 */           this.x[i] = this.x[j];
/*  76 */           this.x[j] = t;
/*  77 */           t = this.y[i];
/*  78 */           this.y[i] = this.y[j];
/*  79 */           this.y[j] = t;
/*     */         }
/*     */   }
/*     */ 
/*     */   protected int[] makeTable()
/*     */   {
/*  86 */     int numKnots = this.x.length;
/*  87 */     float[] nx = new float[numKnots + 2];
/*  88 */     float[] ny = new float[numKnots + 2];
/*  89 */     System.arraycopy(this.x, 0, nx, 1, numKnots);
/*  90 */     System.arraycopy(this.y, 0, ny, 1, numKnots);
/*  91 */     nx[0] = nx[1];
/*  92 */     ny[0] = ny[1];
/*  93 */     nx[(numKnots + 1)] = nx[numKnots];
/*  94 */     ny[(numKnots + 1)] = ny[numKnots];
/*     */ 
/*  96 */     int[] table = new int[256];
/*  97 */     for (int i = 0; i < 1024; i++) {
/*  98 */       float f = i / 1024.0F;
/*  99 */       int x = (int)(255.0F * ImageMath.spline(f, nx.length, nx) + 0.5F);
/* 100 */       int y = (int)(255.0F * ImageMath.spline(f, nx.length, ny) + 0.5F);
/* 101 */       x = ImageMath.clamp(x, 0, 255);
/* 102 */       y = ImageMath.clamp(y, 0, 255);
/* 103 */       table[x] = y;
/*     */     }
/* 105 */     return table;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Curve
 * JD-Core Version:    0.6.1
 */