/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class HighPassFilter extends GaussianFilter
/*    */ {
/*    */   public HighPassFilter()
/*    */   {
/* 28 */     this.radius = 10.0F;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 32 */     int width = src.getWidth();
/* 33 */     int height = src.getHeight();
/*    */ 
/* 35 */     if (dst == null) {
/* 36 */       dst = createCompatibleDestImage(src, null);
/*    */     }
/* 38 */     int[] inPixels = new int[width * height];
/* 39 */     int[] outPixels = new int[width * height];
/* 40 */     src.getRGB(0, 0, width, height, inPixels, 0, width);
/*    */ 
/* 42 */     if (this.radius > 0.0F) {
/* 43 */       convolveAndTranspose(this.kernel, inPixels, outPixels, width, height, this.alpha, (this.alpha) && (this.premultiplyAlpha), false, CLAMP_EDGES);
/* 44 */       convolveAndTranspose(this.kernel, outPixels, inPixels, height, width, this.alpha, false, (this.alpha) && (this.premultiplyAlpha), CLAMP_EDGES);
/*    */     }
/*    */ 
/* 47 */     src.getRGB(0, 0, width, height, outPixels, 0, width);
/*    */ 
/* 49 */     int index = 0;
/* 50 */     for (int y = 0; y < height; y++) {
/* 51 */       for (int x = 0; x < width; x++) {
/* 52 */         int rgb1 = outPixels[index];
/* 53 */         int r1 = rgb1 >> 16 & 0xFF;
/* 54 */         int g1 = rgb1 >> 8 & 0xFF;
/* 55 */         int b1 = rgb1 & 0xFF;
/*    */ 
/* 57 */         int rgb2 = inPixels[index];
/* 58 */         int r2 = rgb2 >> 16 & 0xFF;
/* 59 */         int g2 = rgb2 >> 8 & 0xFF;
/* 60 */         int b2 = rgb2 & 0xFF;
/*    */ 
/* 62 */         r1 = (r1 + 255 - r2) / 2;
/* 63 */         g1 = (g1 + 255 - g2) / 2;
/* 64 */         b1 = (b1 + 255 - b2) / 2;
/*    */ 
/* 66 */         inPixels[index] = (rgb1 & 0xFF000000 | r1 << 16 | g1 << 8 | b1);
/* 67 */         index++;
/*    */       }
/*    */     }
/*    */ 
/* 71 */     dst.setRGB(0, 0, width, height, inPixels, 0, width);
/* 72 */     return dst;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 76 */     return "Blur/High Pass...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.HighPassFilter
 * JD-Core Version:    0.6.1
 */