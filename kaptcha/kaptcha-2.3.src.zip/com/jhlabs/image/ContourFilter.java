/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class ContourFilter extends WholeImageFilter
/*     */ {
/*  27 */   private float levels = 5.0F;
/*  28 */   private float scale = 1.0F;
/*  29 */   private float offset = 0.0F;
/*  30 */   private int contourColor = -16777216;
/*     */ 
/*     */   public void setLevels(float levels)
/*     */   {
/*  36 */     this.levels = levels;
/*     */   }
/*     */ 
/*     */   public float getLevels() {
/*  40 */     return this.levels;
/*     */   }
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  51 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  60 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setOffset(float offset) {
/*  64 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   public float getOffset() {
/*  68 */     return this.offset;
/*     */   }
/*     */ 
/*     */   public void setContourColor(int contourColor) {
/*  72 */     this.contourColor = contourColor;
/*     */   }
/*     */ 
/*     */   public int getContourColor() {
/*  76 */     return this.contourColor;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  80 */     int index = 0;
/*  81 */     short[][] r = new short[3][width];
/*  82 */     int[] outPixels = new int[width * height];
/*     */ 
/*  84 */     short[] table = new short[256];
/*  85 */     int offsetl = (int)(this.offset * 256.0F / this.levels);
/*  86 */     for (int i = 0; i < 256; i++) {
/*  87 */       table[i] = (short)PixelUtils.clamp((int)(255.0D * Math.floor(this.levels * i + offsetl / 256.0F) / this.levels - 1.0F - offsetl));
/*     */     }
/*  89 */     for (int x = 0; x < width; x++) {
/*  90 */       int rgb = inPixels[x];
/*  91 */       r[1][x] = (short)PixelUtils.brightness(rgb);
/*     */     }
/*  93 */     for (int y = 0; y < height; y++) {
/*  94 */       boolean yIn = (y > 0) && (y < height - 1);
/*  95 */       int nextRowIndex = index + width;
/*  96 */       if (y < height - 1) {
/*  97 */         for (int x = 0; x < width; x++) {
/*  98 */           int rgb = inPixels[(nextRowIndex++)];
/*  99 */           r[2][x] = (short)PixelUtils.brightness(rgb);
/*     */         }
/*     */       }
/* 102 */       for (int x = 0; x < width; x++) {
/* 103 */         boolean xIn = (x > 0) && (x < width - 1);
/* 104 */         int w = x - 1;
/* 105 */         int e = x + 1;
/* 106 */         int v = 0;
/*     */ 
/* 108 */         if ((yIn) && (xIn)) {
/* 109 */           short nwb = r[0][w];
/* 110 */           short neb = r[0][x];
/* 111 */           short swb = r[1][w];
/* 112 */           short seb = r[1][x];
/* 113 */           short nw = table[nwb];
/* 114 */           short ne = table[neb];
/* 115 */           short sw = table[swb];
/* 116 */           short se = table[seb];
/*     */ 
/* 118 */           if ((nw != ne) || (nw != sw) || (ne != se) || (sw != se)) {
/* 119 */             v = (int)(this.scale * Math.abs(nwb - neb) + Math.abs(nwb - swb) + Math.abs(neb - seb) + Math.abs(swb - seb));
/*     */ 
/* 121 */             if (v > 255) {
/* 122 */               v = 255;
/*     */             }
/*     */           }
/*     */         }
/* 126 */         if (v != 0) {
/* 127 */           outPixels[index] = PixelUtils.combinePixels(inPixels[index], this.contourColor, 1, v);
/*     */         }
/*     */         else
/* 130 */           outPixels[index] = inPixels[index];
/* 131 */         index++;
/*     */       }
/*     */ 
/* 134 */       short[] t = r[0];
/* 135 */       r[0] = r[1];
/* 136 */       r[1] = r[2];
/* 137 */       r[2] = t;
/*     */     }
/*     */ 
/* 140 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 144 */     return "Stylize/Contour...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ContourFilter
 * JD-Core Version:    0.6.1
 */