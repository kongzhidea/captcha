/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class DeinterlaceFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   public static final int EVEN = 0;
/*    */   public static final int ODD = 1;
/*    */   public static final int AVERAGE = 2;
/* 30 */   private int mode = 0;
/*    */ 
/*    */   public void setMode(int mode) {
/* 33 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   public int getMode() {
/* 37 */     return this.mode;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 41 */     int width = src.getWidth();
/* 42 */     int height = src.getHeight();
/*    */ 
/* 44 */     if (dst == null) {
/* 45 */       dst = createCompatibleDestImage(src, null);
/*    */     }
/* 47 */     int[] pixels = null;
/*    */ 
/* 49 */     if (this.mode == 0) {
/* 50 */       for (int y = 0; y < height - 1; y += 2) {
/* 51 */         pixels = getRGB(src, 0, y, width, 1, pixels);
/* 52 */         if (src != dst)
/* 53 */           setRGB(dst, 0, y, width, 1, pixels);
/* 54 */         setRGB(dst, 0, y + 1, width, 1, pixels);
/*    */       }
/* 56 */     } else if (this.mode == 1) {
/* 57 */       for (int y = 1; y < height; y += 2) {
/* 58 */         pixels = getRGB(src, 0, y, width, 1, pixels);
/* 59 */         if (src != dst)
/* 60 */           setRGB(dst, 0, y, width, 1, pixels);
/* 61 */         setRGB(dst, 0, y - 1, width, 1, pixels);
/*    */       }
/* 63 */     } else if (this.mode == 2) {
/* 64 */       int[] pixels2 = null;
/* 65 */       for (int y = 0; y < height - 1; y += 2) {
/* 66 */         pixels = getRGB(src, 0, y, width, 1, pixels);
/* 67 */         pixels2 = getRGB(src, 0, y + 1, width, 1, pixels2);
/* 68 */         for (int x = 0; x < width; x++) {
/* 69 */           int rgb1 = pixels[x];
/* 70 */           int rgb2 = pixels2[x];
/* 71 */           int a1 = rgb1 >> 24 & 0xFF;
/* 72 */           int r1 = rgb1 >> 16 & 0xFF;
/* 73 */           int g1 = rgb1 >> 8 & 0xFF;
/* 74 */           int b1 = rgb1 & 0xFF;
/* 75 */           int a2 = rgb2 >> 24 & 0xFF;
/* 76 */           int r2 = rgb2 >> 16 & 0xFF;
/* 77 */           int g2 = rgb2 >> 8 & 0xFF;
/* 78 */           int b2 = rgb2 & 0xFF;
/* 79 */           a1 = (a1 + a2) / 2;
/* 80 */           r1 = (r1 + r2) / 2;
/* 81 */           g1 = (g1 + g2) / 2;
/* 82 */           b1 = (b1 + b2) / 2;
/* 83 */           pixels[x] = (a1 << 24 | r1 << 16 | g1 << 8 | b1);
/*    */         }
/* 85 */         setRGB(dst, 0, y, width, 1, pixels);
/* 86 */         setRGB(dst, 0, y + 1, width, 1, pixels);
/*    */       }
/*    */     }
/*    */ 
/* 90 */     return dst;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 94 */     return "Video/De-Interlace";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DeinterlaceFilter
 * JD-Core Version:    0.6.1
 */