/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.BufferedImageOp;
/*    */ 
/*    */ public class IteratedFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   private BufferedImageOp filter;
/*    */   private int iterations;
/*    */ 
/*    */   public IteratedFilter(BufferedImageOp filter, int iterations)
/*    */   {
/* 34 */     this.filter = filter;
/* 35 */     this.iterations = iterations;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 39 */     BufferedImage image = src;
/*    */ 
/* 41 */     for (int i = 0; i < this.iterations; i++) {
/* 42 */       image = this.filter.filter(image, dst);
/*    */     }
/* 44 */     return image;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.IteratedFilter
 * JD-Core Version:    0.6.1
 */