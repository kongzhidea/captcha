/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class MotionBlurFilter extends AbstractBufferedImageOp
/*     */ {
/*  27 */   private float angle = 0.0F;
/*  28 */   private float falloff = 1.0F;
/*  29 */   private float distance = 1.0F;
/*  30 */   private float zoom = 0.0F;
/*  31 */   private float rotation = 0.0F;
/*  32 */   private boolean wrapEdges = false;
/*  33 */   private boolean premultiplyAlpha = true;
/*     */ 
/*     */   public MotionBlurFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MotionBlurFilter(float distance, float angle, float rotation, float zoom)
/*     */   {
/*  49 */     this.distance = distance;
/*  50 */     this.angle = angle;
/*  51 */     this.rotation = rotation;
/*  52 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  62 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  71 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setDistance(float distance)
/*     */   {
/*  80 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public float getDistance()
/*     */   {
/*  89 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setRotation(float rotation)
/*     */   {
/*  98 */     this.rotation = rotation;
/*     */   }
/*     */ 
/*     */   public float getRotation()
/*     */   {
/* 107 */     return this.rotation;
/*     */   }
/*     */ 
/*     */   public void setZoom(float zoom)
/*     */   {
/* 116 */     this.zoom = zoom;
/*     */   }
/*     */ 
/*     */   public float getZoom()
/*     */   {
/* 125 */     return this.zoom;
/*     */   }
/*     */ 
/*     */   public void setWrapEdges(boolean wrapEdges)
/*     */   {
/* 134 */     this.wrapEdges = wrapEdges;
/*     */   }
/*     */ 
/*     */   public boolean getWrapEdges()
/*     */   {
/* 143 */     return this.wrapEdges;
/*     */   }
/*     */ 
/*     */   public void setPremultiplyAlpha(boolean premultiplyAlpha)
/*     */   {
/* 152 */     this.premultiplyAlpha = premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public boolean getPremultiplyAlpha()
/*     */   {
/* 161 */     return this.premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 165 */     int width = src.getWidth();
/* 166 */     int height = src.getHeight();
/*     */ 
/* 168 */     if (dst == null) {
/* 169 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/* 171 */     int[] inPixels = new int[width * height];
/* 172 */     int[] outPixels = new int[width * height];
/* 173 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */ 
/* 175 */     float sinAngle = (float)Math.sin(this.angle);
/* 176 */     float cosAngle = (float)Math.cos(this.angle);
/*     */ 
/* 179 */     int cx = width / 2;
/* 180 */     int cy = height / 2;
/* 181 */     int index = 0;
/*     */ 
/* 183 */     float imageRadius = (float)Math.sqrt(cx * cx + cy * cy);
/* 184 */     float translateX = (float)(this.distance * Math.cos(this.angle));
/* 185 */     float translateY = (float)(this.distance * -Math.sin(this.angle));
/* 186 */     float maxDistance = this.distance + Math.abs(this.rotation * imageRadius) + this.zoom * imageRadius;
/* 187 */     int repetitions = (int)maxDistance;
/* 188 */     AffineTransform t = new AffineTransform();
/* 189 */     Point2D.Float p = new Point2D.Float();
/*     */ 
/* 191 */     if (this.premultiplyAlpha)
/* 192 */       ImageMath.premultiply(inPixels, 0, inPixels.length);
/* 193 */     for (int y = 0; y < height; y++) {
/* 194 */       for (int x = 0; x < width; x++) {
/* 195 */         int a = 0; int r = 0; int g = 0; int b = 0;
/* 196 */         int count = 0;
/* 197 */         for (int i = 0; i < repetitions; i++) {
/* 198 */           int newX = x; int newY = y;
/* 199 */           float f = i / repetitions;
/*     */ 
/* 201 */           p.x = x;
/* 202 */           p.y = y;
/* 203 */           t.setToIdentity();
/* 204 */           t.translate(cx + f * translateX, cy + f * translateY);
/* 205 */           float s = 1.0F - this.zoom * f;
/* 206 */           t.scale(s, s);
/* 207 */           if (this.rotation != 0.0F)
/* 208 */             t.rotate(-this.rotation * f);
/* 209 */           t.translate(-cx, -cy);
/* 210 */           t.transform(p, p);
/* 211 */           newX = (int)p.x;
/* 212 */           newY = (int)p.y;
/*     */ 
/* 214 */           if ((newX < 0) || (newX >= width)) {
/* 215 */             if (!this.wrapEdges) break;
/* 216 */             newX = ImageMath.mod(newX, width);
/*     */           }
/*     */ 
/* 220 */           if ((newY < 0) || (newY >= height)) {
/* 221 */             if (!this.wrapEdges) break;
/* 222 */             newY = ImageMath.mod(newY, height);
/*     */           }
/*     */ 
/* 227 */           count++;
/* 228 */           int rgb = inPixels[(newY * width + newX)];
/* 229 */           a += (rgb >> 24 & 0xFF);
/* 230 */           r += (rgb >> 16 & 0xFF);
/* 231 */           g += (rgb >> 8 & 0xFF);
/* 232 */           b += (rgb & 0xFF);
/*     */         }
/* 234 */         if (count == 0) {
/* 235 */           outPixels[index] = inPixels[index];
/*     */         } else {
/* 237 */           a = PixelUtils.clamp(a / count);
/* 238 */           r = PixelUtils.clamp(r / count);
/* 239 */           g = PixelUtils.clamp(g / count);
/* 240 */           b = PixelUtils.clamp(b / count);
/* 241 */           outPixels[index] = (a << 24 | r << 16 | g << 8 | b);
/*     */         }
/* 243 */         index++;
/*     */       }
/*     */     }
/* 246 */     if (this.premultiplyAlpha) {
/* 247 */       ImageMath.unpremultiply(outPixels, 0, inPixels.length);
/*     */     }
/* 249 */     setRGB(dst, 0, 0, width, height, outPixels);
/* 250 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 254 */     return "Blur/Motion Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MotionBlurFilter
 * JD-Core Version:    0.6.1
 */