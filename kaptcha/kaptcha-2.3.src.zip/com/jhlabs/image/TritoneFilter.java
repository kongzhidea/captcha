/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class TritoneFilter extends PointFilter
/*     */ {
/*  28 */   private int shadowColor = -16777216;
/*  29 */   private int midColor = -7829368;
/*  30 */   private int highColor = -1;
/*     */   private int[] lut;
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst)
/*     */   {
/*  34 */     this.lut = new int[256];
/*  35 */     for (int i = 0; i < 128; i++) {
/*  36 */       float t = i / 127.0F;
/*  37 */       this.lut[i] = ImageMath.mixColors(t, this.shadowColor, this.midColor);
/*     */     }
/*  39 */     for (int i = 128; i < 256; i++) {
/*  40 */       float t = i - 127 / 128.0F;
/*  41 */       this.lut[i] = ImageMath.mixColors(t, this.midColor, this.highColor);
/*     */     }
/*  43 */     dst = super.filter(src, dst);
/*  44 */     this.lut = null;
/*  45 */     return dst;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/*  49 */     return this.lut[PixelUtils.brightness(rgb)];
/*     */   }
/*     */ 
/*     */   public void setShadowColor(int shadowColor)
/*     */   {
/*  58 */     this.shadowColor = shadowColor;
/*     */   }
/*     */ 
/*     */   public int getShadowColor()
/*     */   {
/*  67 */     return this.shadowColor;
/*     */   }
/*     */ 
/*     */   public void setMidColor(int midColor)
/*     */   {
/*  76 */     this.midColor = midColor;
/*     */   }
/*     */ 
/*     */   public int getMidColor()
/*     */   {
/*  85 */     return this.midColor;
/*     */   }
/*     */ 
/*     */   public void setHighColor(int highColor)
/*     */   {
/*  94 */     this.highColor = highColor;
/*     */   }
/*     */ 
/*     */   public int getHighColor()
/*     */   {
/* 103 */     return this.highColor;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 108 */     return "Colors/Tritone...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TritoneFilter
 * JD-Core Version:    0.6.1
 */