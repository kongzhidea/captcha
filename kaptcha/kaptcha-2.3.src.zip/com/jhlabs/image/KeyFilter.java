/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class KeyFilter extends AbstractBufferedImageOp
/*     */ {
/*  29 */   private float hTolerance = 0.0F;
/*  30 */   private float sTolerance = 0.0F;
/*  31 */   private float bTolerance = 0.0F;
/*     */   private BufferedImage destination;
/*     */   private BufferedImage cleanImage;
/*     */ 
/*     */   public void setHTolerance(float hTolerance)
/*     */   {
/*  47 */     this.hTolerance = hTolerance;
/*     */   }
/*     */ 
/*     */   public float getHTolerance()
/*     */   {
/*  56 */     return this.hTolerance;
/*     */   }
/*     */ 
/*     */   public void setSTolerance(float sTolerance)
/*     */   {
/*  65 */     this.sTolerance = sTolerance;
/*     */   }
/*     */ 
/*     */   public float getSTolerance()
/*     */   {
/*  74 */     return this.sTolerance;
/*     */   }
/*     */ 
/*     */   public void setBTolerance(float bTolerance)
/*     */   {
/*  83 */     this.bTolerance = bTolerance;
/*     */   }
/*     */ 
/*     */   public float getBTolerance()
/*     */   {
/*  92 */     return this.bTolerance;
/*     */   }
/*     */ 
/*     */   public void setDestination(BufferedImage destination)
/*     */   {
/* 101 */     this.destination = destination;
/*     */   }
/*     */ 
/*     */   public BufferedImage getDestination()
/*     */   {
/* 110 */     return this.destination;
/*     */   }
/*     */ 
/*     */   public void setCleanImage(BufferedImage cleanImage)
/*     */   {
/* 119 */     this.cleanImage = cleanImage;
/*     */   }
/*     */ 
/*     */   public BufferedImage getCleanImage()
/*     */   {
/* 128 */     return this.cleanImage;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 132 */     int width = src.getWidth();
/* 133 */     int height = src.getHeight();
/* 134 */     int type = src.getType();
/* 135 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/* 137 */     if (dst == null)
/* 138 */       dst = createCompatibleDestImage(src, null);
/* 139 */     WritableRaster dstRaster = dst.getRaster();
/*     */ 
/* 141 */     if ((this.destination != null) && (this.cleanImage != null)) {
/* 142 */       float[] hsb1 = null;
/* 143 */       float[] hsb2 = null;
/* 144 */       int[] inPixels = null;
/* 145 */       int[] outPixels = null;
/* 146 */       int[] cleanPixels = null;
/* 147 */       for (int y = 0; y < height; y++) {
/* 148 */         inPixels = getRGB(src, 0, y, width, 1, inPixels);
/* 149 */         outPixels = getRGB(this.destination, 0, y, width, 1, outPixels);
/* 150 */         cleanPixels = getRGB(this.cleanImage, 0, y, width, 1, cleanPixels);
/* 151 */         for (int x = 0; x < width; x++) {
/* 152 */           int rgb1 = inPixels[x];
/* 153 */           int out = outPixels[x];
/* 154 */           int rgb2 = cleanPixels[x];
/*     */ 
/* 156 */           int r1 = rgb1 >> 16 & 0xFF;
/* 157 */           int g1 = rgb1 >> 8 & 0xFF;
/* 158 */           int b1 = rgb1 & 0xFF;
/* 159 */           int r2 = rgb2 >> 16 & 0xFF;
/* 160 */           int g2 = rgb2 >> 8 & 0xFF;
/* 161 */           int b2 = rgb2 & 0xFF;
/* 162 */           hsb1 = Color.RGBtoHSB(r1, b1, g1, hsb1);
/* 163 */           hsb2 = Color.RGBtoHSB(r2, b2, g2, hsb2);
/*     */ 
/* 168 */           if ((Math.abs(hsb1[0] - hsb2[0]) < this.hTolerance) && (Math.abs(hsb1[1] - hsb2[1]) < this.sTolerance) && (Math.abs(hsb1[2] - hsb2[2]) < this.bTolerance))
/* 169 */             inPixels[x] = out;
/*     */           else
/* 171 */             inPixels[x] = rgb1;
/*     */         }
/* 173 */         setRGB(dst, 0, y, width, 1, inPixels);
/*     */       }
/*     */     }
/*     */ 
/* 177 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 181 */     return "Keying/Key...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.KeyFilter
 * JD-Core Version:    0.6.1
 */