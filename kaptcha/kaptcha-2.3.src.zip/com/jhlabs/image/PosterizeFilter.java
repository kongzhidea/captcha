/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class PosterizeFilter extends PointFilter
/*    */ {
/*    */   private int numLevels;
/*    */   private int[] levels;
/* 29 */   private boolean initialized = false;
/*    */ 
/*    */   public PosterizeFilter() {
/* 32 */     setNumLevels(6);
/*    */   }
/*    */ 
/*    */   public void setNumLevels(int numLevels)
/*    */   {
/* 41 */     this.numLevels = numLevels;
/* 42 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public int getNumLevels()
/*    */   {
/* 51 */     return this.numLevels;
/*    */   }
/*    */ 
/*    */   protected void initialize()
/*    */   {
/* 58 */     this.levels = new int[256];
/* 59 */     if (this.numLevels != 1)
/* 60 */       for (int i = 0; i < 256; i++)
/* 61 */         this.levels[i] = (255 * (this.numLevels * i / 256) / (this.numLevels - 1));
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 65 */     if (!this.initialized) {
/* 66 */       this.initialized = true;
/* 67 */       initialize();
/*    */     }
/* 69 */     int a = rgb & 0xFF000000;
/* 70 */     int r = rgb >> 16 & 0xFF;
/* 71 */     int g = rgb >> 8 & 0xFF;
/* 72 */     int b = rgb & 0xFF;
/* 73 */     r = this.levels[r];
/* 74 */     g = this.levels[g];
/* 75 */     b = this.levels[b];
/* 76 */     return a | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 80 */     return "Colors/Posterize...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PosterizeFilter
 * JD-Core Version:    0.6.1
 */