/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class FourColorFilter extends PointFilter
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*     */   private int colorNW;
/*     */   private int colorNE;
/*     */   private int colorSW;
/*     */   private int colorSE;
/*     */   private int rNW;
/*     */   private int gNW;
/*     */   private int bNW;
/*     */   private int rNE;
/*     */   private int gNE;
/*     */   private int bNE;
/*     */   private int rSW;
/*     */   private int gSW;
/*     */   private int bSW;
/*     */   private int rSE;
/*     */   private int gSE;
/*     */   private int bSE;
/*     */ 
/*     */   public FourColorFilter()
/*     */   {
/*  40 */     setColorNW(-65536);
/*  41 */     setColorNE(-65281);
/*  42 */     setColorSW(-16776961);
/*  43 */     setColorSE(-16711681);
/*     */   }
/*     */ 
/*     */   public void setColorNW(int color) {
/*  47 */     this.colorNW = color;
/*  48 */     this.rNW = (color >> 16 & 0xFF);
/*  49 */     this.gNW = (color >> 8 & 0xFF);
/*  50 */     this.bNW = (color & 0xFF);
/*     */   }
/*     */ 
/*     */   public int getColorNW() {
/*  54 */     return this.colorNW;
/*     */   }
/*     */ 
/*     */   public void setColorNE(int color) {
/*  58 */     this.colorNE = color;
/*  59 */     this.rNE = (color >> 16 & 0xFF);
/*  60 */     this.gNE = (color >> 8 & 0xFF);
/*  61 */     this.bNE = (color & 0xFF);
/*     */   }
/*     */ 
/*     */   public int getColorNE() {
/*  65 */     return this.colorNE;
/*     */   }
/*     */ 
/*     */   public void setColorSW(int color) {
/*  69 */     this.colorSW = color;
/*  70 */     this.rSW = (color >> 16 & 0xFF);
/*  71 */     this.gSW = (color >> 8 & 0xFF);
/*  72 */     this.bSW = (color & 0xFF);
/*     */   }
/*     */ 
/*     */   public int getColorSW() {
/*  76 */     return this.colorSW;
/*     */   }
/*     */ 
/*     */   public void setColorSE(int color) {
/*  80 */     this.colorSE = color;
/*  81 */     this.rSE = (color >> 16 & 0xFF);
/*  82 */     this.gSE = (color >> 8 & 0xFF);
/*  83 */     this.bSE = (color & 0xFF);
/*     */   }
/*     */ 
/*     */   public int getColorSE() {
/*  87 */     return this.colorSE;
/*     */   }
/*     */ 
/*     */   public void setDimensions(int width, int height) {
/*  91 */     this.width = width;
/*  92 */     this.height = height;
/*  93 */     super.setDimensions(width, height);
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/*  97 */     float fx = x / this.width;
/*  98 */     float fy = y / this.height;
/*     */ 
/* 101 */     float p = this.rNW + this.rNE - this.rNW * fx;
/* 102 */     float q = this.rSW + this.rSE - this.rSW * fx;
/* 103 */     int r = (int)(p + (q - p) * fy + 0.5F);
/*     */ 
/* 105 */     p = this.gNW + this.gNE - this.gNW * fx;
/* 106 */     q = this.gSW + this.gSE - this.gSW * fx;
/* 107 */     int g = (int)(p + (q - p) * fy + 0.5F);
/*     */ 
/* 109 */     p = this.bNW + this.bNE - this.bNW * fx;
/* 110 */     q = this.bSW + this.bSE - this.bSW * fx;
/* 111 */     int b = (int)(p + (q - p) * fy + 0.5F);
/*     */ 
/* 113 */     return 0xFF000000 | r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 117 */     return "Texture/Four Color Fill...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FourColorFilter
 * JD-Core Version:    0.6.1
 */