/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class ReduceNoiseFilter extends WholeImageFilter
/*     */ {
/*     */   private int smooth(int[] v)
/*     */   {
/*  32 */     int minindex = 0; int maxindex = 0; int min = 2147483647; int max = -2147483648;
/*     */ 
/*  34 */     for (int i = 0; i < 9; i++) {
/*  35 */       if (i != 4) {
/*  36 */         if (v[i] < min) {
/*  37 */           min = v[i];
/*  38 */           minindex = i;
/*     */         }
/*  40 */         if (v[i] > max) {
/*  41 */           max = v[i];
/*  42 */           maxindex = i;
/*     */         }
/*     */       }
/*     */     }
/*  46 */     if (v[4] < min)
/*  47 */       return v[minindex];
/*  48 */     if (v[4] > max)
/*  49 */       return v[maxindex];
/*  50 */     return v[4];
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  54 */     int index = 0;
/*  55 */     int[] r = new int[9];
/*  56 */     int[] g = new int[9];
/*  57 */     int[] b = new int[9];
/*  58 */     int[] outPixels = new int[width * height];
/*     */ 
/*  60 */     for (int y = 0; y < height; y++) {
/*  61 */       for (int x = 0; x < width; x++) {
/*  62 */         int k = 0;
/*  63 */         int irgb = inPixels[index];
/*  64 */         int ir = irgb >> 16 & 0xFF;
/*  65 */         int ig = irgb >> 8 & 0xFF;
/*  66 */         int ib = irgb & 0xFF;
/*  67 */         for (int dy = -1; dy <= 1; dy++) {
/*  68 */           int iy = y + dy;
/*  69 */           if ((0 <= iy) && (iy < height)) {
/*  70 */             int ioffset = iy * width;
/*  71 */             for (int dx = -1; dx <= 1; dx++) {
/*  72 */               int ix = x + dx;
/*  73 */               if ((0 <= ix) && (ix < width)) {
/*  74 */                 int rgb = inPixels[(ioffset + ix)];
/*  75 */                 r[k] = (rgb >> 16 & 0xFF);
/*  76 */                 g[k] = (rgb >> 8 & 0xFF);
/*  77 */                 b[k] = (rgb & 0xFF);
/*     */               } else {
/*  79 */                 r[k] = ir;
/*  80 */                 g[k] = ig;
/*  81 */                 b[k] = ib;
/*     */               }
/*  83 */               k++;
/*     */             }
/*     */           } else {
/*  86 */             for (int dx = -1; dx <= 1; dx++) {
/*  87 */               r[k] = ir;
/*  88 */               g[k] = ig;
/*  89 */               b[k] = ib;
/*  90 */               k++;
/*     */             }
/*     */           }
/*     */         }
/*  94 */         outPixels[index] = (inPixels[index] & 0xFF000000 | smooth(r) << 16 | smooth(g) << 8 | smooth(b));
/*  95 */         index++;
/*     */       }
/*     */     }
/*  98 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 102 */     return "Blur/Smooth";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ReduceNoiseFilter
 * JD-Core Version:    0.6.1
 */