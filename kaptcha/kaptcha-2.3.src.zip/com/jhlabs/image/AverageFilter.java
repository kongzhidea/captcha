/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class AverageFilter extends ConvolveFilter
/*    */ {
/* 29 */   protected static float[] theMatrix = { 0.1F, 0.1F, 0.1F, 0.1F, 0.2F, 0.1F, 0.1F, 0.1F, 0.1F };
/*    */ 
/*    */   public AverageFilter() {
/* 32 */     super(theMatrix);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 36 */     return "Blur/Average Blur";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.AverageFilter
 * JD-Core Version:    0.6.1
 */