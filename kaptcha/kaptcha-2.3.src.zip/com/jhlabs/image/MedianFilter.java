/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class MedianFilter extends WholeImageFilter
/*     */ {
/*     */   private int median(int[] array)
/*     */   {
/*  33 */     for (int i = 0; i < 4; i++) {
/*  34 */       int max = 0;
/*  35 */       int maxIndex = 0;
/*  36 */       for (int j = 0; j < 9; j++) {
/*  37 */         if (array[j] > max) {
/*  38 */           max = array[j];
/*  39 */           maxIndex = j;
/*     */         }
/*     */       }
/*  42 */       array[maxIndex] = 0;
/*     */     }
/*  44 */     int max = 0;
/*  45 */     for (int i = 0; i < 9; i++) {
/*  46 */       if (array[i] > max)
/*  47 */         max = array[i];
/*     */     }
/*  49 */     return max;
/*     */   }
/*     */ 
/*     */   private int rgbMedian(int[] r, int[] g, int[] b) {
/*  53 */     int index = 0; int min = 2147483647;
/*     */ 
/*  55 */     for (int i = 0; i < 9; i++) {
/*  56 */       int sum = 0;
/*  57 */       for (int j = 0; j < 9; j++) {
/*  58 */         sum += Math.abs(r[i] - r[j]);
/*  59 */         sum += Math.abs(g[i] - g[j]);
/*  60 */         sum += Math.abs(b[i] - b[j]);
/*     */       }
/*  62 */       if (sum < min) {
/*  63 */         min = sum;
/*  64 */         index = i;
/*     */       }
/*     */     }
/*  67 */     return index;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  71 */     int index = 0;
/*  72 */     int[] argb = new int[9];
/*  73 */     int[] r = new int[9];
/*  74 */     int[] g = new int[9];
/*  75 */     int[] b = new int[9];
/*  76 */     int[] outPixels = new int[width * height];
/*     */ 
/*  78 */     for (int y = 0; y < height; y++) {
/*  79 */       for (int x = 0; x < width; x++) {
/*  80 */         int k = 0;
/*  81 */         for (int dy = -1; dy <= 1; dy++) {
/*  82 */           int iy = y + dy;
/*  83 */           if ((0 <= iy) && (iy < height)) {
/*  84 */             int ioffset = iy * width;
/*  85 */             for (int dx = -1; dx <= 1; dx++) {
/*  86 */               int ix = x + dx;
/*  87 */               if ((0 <= ix) && (ix < width)) {
/*  88 */                 int rgb = inPixels[(ioffset + ix)];
/*  89 */                 argb[k] = rgb;
/*  90 */                 r[k] = (rgb >> 16 & 0xFF);
/*  91 */                 g[k] = (rgb >> 8 & 0xFF);
/*  92 */                 b[k] = (rgb & 0xFF);
/*  93 */                 k++;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*  98 */         while (k < 9) {
/*  99 */           argb[k] = -16777216;
/*     */           int tmp216_215 = (b[k] = 0); g[k] = tmp216_215; r[k] = tmp216_215;
/* 101 */           k++;
/*     */         }
/* 103 */         outPixels[(index++)] = argb[rgbMedian(r, g, b)];
/*     */       }
/*     */     }
/* 106 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 110 */     return "Blur/Median";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MedianFilter
 * JD-Core Version:    0.6.1
 */