/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class MaskFilter extends PointFilter
/*    */ {
/*    */   private int mask;
/*    */ 
/*    */   public MaskFilter()
/*    */   {
/* 31 */     this(-16711681);
/*    */   }
/*    */ 
/*    */   public MaskFilter(int mask) {
/* 35 */     this.canFilterIndexColorModel = true;
/* 36 */     setMask(mask);
/*    */   }
/*    */ 
/*    */   public void setMask(int mask) {
/* 40 */     this.mask = mask;
/*    */   }
/*    */ 
/*    */   public int getMask() {
/* 44 */     return this.mask;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 48 */     return rgb & this.mask;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 52 */     return "Mask";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MaskFilter
 * JD-Core Version:    0.6.1
 */