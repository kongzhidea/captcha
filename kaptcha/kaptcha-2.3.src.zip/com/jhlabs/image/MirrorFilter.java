/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Shape;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class MirrorFilter extends AbstractBufferedImageOp
/*     */ {
/*  24 */   private float opacity = 1.0F;
/*  25 */   private float centreY = 0.5F;
/*     */   private float distance;
/*     */   private float angle;
/*     */   private float rotation;
/*     */   private float gap;
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  41 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  50 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setDistance(float distance) {
/*  54 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public float getDistance() {
/*  58 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setRotation(float rotation) {
/*  62 */     this.rotation = rotation;
/*     */   }
/*     */ 
/*     */   public float getRotation() {
/*  66 */     return this.rotation;
/*     */   }
/*     */ 
/*     */   public void setGap(float gap) {
/*  70 */     this.gap = gap;
/*     */   }
/*     */ 
/*     */   public float getGap() {
/*  74 */     return this.gap;
/*     */   }
/*     */ 
/*     */   public void setOpacity(float opacity)
/*     */   {
/*  83 */     this.opacity = opacity;
/*     */   }
/*     */ 
/*     */   public float getOpacity()
/*     */   {
/*  92 */     return this.opacity;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY) {
/*  96 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY() {
/* 100 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 104 */     if (dst == null)
/* 105 */       dst = createCompatibleDestImage(src, null);
/* 106 */     BufferedImage tsrc = src;
/*     */ 
/* 108 */     int width = src.getWidth();
/* 109 */     int height = src.getHeight();
/* 110 */     int h = (int)(this.centreY * height);
/* 111 */     int d = (int)(this.gap * height);
/*     */ 
/* 113 */     Graphics2D g = dst.createGraphics();
/* 114 */     Shape clip = g.getClip();
/* 115 */     g.clipRect(0, 0, width, h);
/* 116 */     g.drawRenderedImage(src, null);
/* 117 */     g.setClip(clip);
/* 118 */     g.clipRect(0, h + d, width, height - h - d);
/* 119 */     g.translate(0, 2 * h + d);
/* 120 */     g.scale(1.0D, -1.0D);
/* 121 */     g.drawRenderedImage(src, null);
/* 122 */     g.setPaint(new GradientPaint(0.0F, 0.0F, new Color(1.0F, 0.0F, 0.0F, 0.0F), 0.0F, h, new Color(0.0F, 1.0F, 0.0F, this.opacity)));
/* 123 */     g.setComposite(AlphaComposite.getInstance(6));
/* 124 */     g.fillRect(0, 0, width, h);
/* 125 */     g.setClip(clip);
/* 126 */     g.dispose();
/*     */ 
/* 128 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 132 */     return "Effects/Mirror...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MirrorFilter
 * JD-Core Version:    0.6.1
 */