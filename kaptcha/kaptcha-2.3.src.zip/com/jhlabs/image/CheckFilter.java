/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class CheckFilter extends PointFilter
/*     */ {
/*  27 */   private int xScale = 8;
/*  28 */   private int yScale = 8;
/*  29 */   private int foreground = -1;
/*  30 */   private int background = -16777216;
/*  31 */   private int fuzziness = 0;
/*  32 */   private float angle = 0.0F;
/*  33 */   private float m00 = 1.0F;
/*  34 */   private float m01 = 0.0F;
/*  35 */   private float m10 = 0.0F;
/*  36 */   private float m11 = 1.0F;
/*     */ 
/*     */   public void setForeground(int foreground)
/*     */   {
/*  47 */     this.foreground = foreground;
/*     */   }
/*     */ 
/*     */   public int getForeground()
/*     */   {
/*  56 */     return this.foreground;
/*     */   }
/*     */ 
/*     */   public void setBackground(int background)
/*     */   {
/*  65 */     this.background = background;
/*     */   }
/*     */ 
/*     */   public int getBackground()
/*     */   {
/*  74 */     return this.background;
/*     */   }
/*     */ 
/*     */   public void setXScale(int xScale)
/*     */   {
/*  83 */     this.xScale = xScale;
/*     */   }
/*     */ 
/*     */   public int getXScale()
/*     */   {
/*  92 */     return this.xScale;
/*     */   }
/*     */ 
/*     */   public void setYScale(int yScale)
/*     */   {
/* 101 */     this.yScale = yScale;
/*     */   }
/*     */ 
/*     */   public int getYScale()
/*     */   {
/* 110 */     return this.yScale;
/*     */   }
/*     */ 
/*     */   public void setFuzziness(int fuzziness)
/*     */   {
/* 119 */     this.fuzziness = fuzziness;
/*     */   }
/*     */ 
/*     */   public int getFuzziness()
/*     */   {
/* 128 */     return this.fuzziness;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/* 138 */     this.angle = angle;
/* 139 */     float cos = (float)Math.cos(angle);
/* 140 */     float sin = (float)Math.sin(angle);
/* 141 */     this.m00 = cos;
/* 142 */     this.m01 = sin;
/* 143 */     this.m10 = (-sin);
/* 144 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/* 153 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 157 */     float nx = (this.m00 * x + this.m01 * y) / this.xScale;
/* 158 */     float ny = (this.m10 * x + this.m11 * y) / this.yScale;
/* 159 */     float f = (int)(nx + 100000.0F) % 2 != (int)(ny + 100000.0F) % 2 ? 1.0F : 0.0F;
/* 160 */     if (this.fuzziness != 0) {
/* 161 */       float fuzz = this.fuzziness / 100.0F;
/* 162 */       float fx = ImageMath.smoothPulse(0.0F, fuzz, 1.0F - fuzz, 1.0F, ImageMath.mod(nx, 1.0F));
/* 163 */       float fy = ImageMath.smoothPulse(0.0F, fuzz, 1.0F - fuzz, 1.0F, ImageMath.mod(ny, 1.0F));
/* 164 */       f *= fx * fy;
/*     */     }
/* 166 */     return ImageMath.mixColors(f, this.foreground, this.background);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 170 */     return "Texture/Checkerboard...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CheckFilter
 * JD-Core Version:    0.6.1
 */