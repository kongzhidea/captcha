/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class SharpenFilter extends ConvolveFilter
/*    */ {
/* 26 */   private static float[] sharpenMatrix = { 0.0F, -0.2F, 0.0F, -0.2F, 1.8F, -0.2F, 0.0F, -0.2F, 0.0F };
/*    */ 
/*    */   public SharpenFilter()
/*    */   {
/* 33 */     super(sharpenMatrix);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 37 */     return "Blur/Sharpen";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SharpenFilter
 * JD-Core Version:    0.6.1
 */