/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ public abstract class WholeImageFilter extends AbstractBufferedImageOp
/*    */ {
/*    */   protected Rectangle transformedSpace;
/*    */   protected Rectangle originalSpace;
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst)
/*    */   {
/* 45 */     int width = src.getWidth();
/* 46 */     int height = src.getHeight();
/* 47 */     int type = src.getType();
/* 48 */     WritableRaster srcRaster = src.getRaster();
/*    */ 
/* 50 */     this.originalSpace = new Rectangle(0, 0, width, height);
/* 51 */     this.transformedSpace = new Rectangle(0, 0, width, height);
/* 52 */     transformSpace(this.transformedSpace);
/*    */ 
/* 54 */     if (dst == null) {
/* 55 */       ColorModel dstCM = src.getColorModel();
/* 56 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(this.transformedSpace.width, this.transformedSpace.height), dstCM.isAlphaPremultiplied(), null);
/*    */     }
/* 58 */     WritableRaster dstRaster = dst.getRaster();
/*    */ 
/* 60 */     int[] inPixels = getRGB(src, 0, 0, width, height, null);
/* 61 */     inPixels = filterPixels(width, height, inPixels, this.transformedSpace);
/* 62 */     setRGB(dst, 0, 0, this.transformedSpace.width, this.transformedSpace.height, inPixels);
/*    */ 
/* 64 */     return dst;
/*    */   }
/*    */ 
/*    */   protected void transformSpace(Rectangle rect)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected abstract int[] filterPixels(int paramInt1, int paramInt2, int[] paramArrayOfInt, Rectangle paramRectangle);
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.WholeImageFilter
 * JD-Core Version:    0.6.1
 */