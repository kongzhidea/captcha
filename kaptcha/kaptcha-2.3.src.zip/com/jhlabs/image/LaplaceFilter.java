/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class LaplaceFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private void brightness(int[] row)
/*     */   {
/*  30 */     for (int i = 0; i < row.length; i++) {
/*  31 */       int rgb = row[i];
/*  32 */       int r = rgb >> 16 & 0xFF;
/*  33 */       int g = rgb >> 8 & 0xFF;
/*  34 */       int b = rgb & 0xFF;
/*  35 */       row[i] = ((r + g + b) / 3);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  40 */     int width = src.getWidth();
/*  41 */     int height = src.getHeight();
/*     */ 
/*  43 */     if (dst == null) {
/*  44 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  46 */     int[] row1 = null;
/*  47 */     int[] row2 = null;
/*  48 */     int[] row3 = null;
/*  49 */     int[] pixels = new int[width];
/*  50 */     row1 = getRGB(src, 0, 0, width, 1, row1);
/*  51 */     row2 = getRGB(src, 0, 0, width, 1, row2);
/*  52 */     brightness(row1);
/*  53 */     brightness(row2);
/*  54 */     for (int y = 0; y < height; y++) {
/*  55 */       if (y < height - 1) {
/*  56 */         row3 = getRGB(src, 0, y + 1, width, 1, row3);
/*  57 */         brightness(row3);
/*     */       }
/*     */       int tmp125_123 = -16777216; pixels[(width - 1)] = tmp125_123; pixels[0] = tmp125_123;
/*  60 */       for (int x = 1; x < width - 1; x++) {
/*  61 */         int l1 = row2[(x - 1)];
/*  62 */         int l2 = row1[x];
/*  63 */         int l3 = row3[x];
/*  64 */         int l4 = row2[(x + 1)];
/*     */ 
/*  66 */         int l = row2[x];
/*  67 */         int max = Math.max(Math.max(l1, l2), Math.max(l3, l4));
/*  68 */         int min = Math.min(Math.min(l1, l2), Math.min(l3, l4));
/*     */ 
/*  70 */         int gradient = (int)(0.5F * Math.max(max - l, l - min));
/*     */ 
/*  72 */         int r = row1[(x - 1)] + row1[x] + row1[(x + 1)] + row2[(x - 1)] - 8 * row2[x] + row2[(x + 1)] + row3[(x - 1)] + row3[x] + row3[(x + 1)] > 0 ? gradient : 128 + gradient;
/*     */ 
/*  76 */         pixels[x] = r;
/*     */       }
/*  78 */       setRGB(dst, 0, y, width, 1, pixels);
/*  79 */       int[] t = row1; row1 = row2; row2 = row3; row3 = t;
/*     */     }
/*     */ 
/*  82 */     row1 = getRGB(dst, 0, 0, width, 1, row1);
/*  83 */     row2 = getRGB(dst, 0, 0, width, 1, row2);
/*  84 */     for (int y = 0; y < height; y++) {
/*  85 */       if (y < height - 1)
/*  86 */         row3 = getRGB(dst, 0, y + 1, width, 1, row3);
/*     */       int tmp438_436 = -16777216; pixels[(width - 1)] = tmp438_436; pixels[0] = tmp438_436;
/*  89 */       for (int x = 1; x < width - 1; x++) {
/*  90 */         int r = row2[x];
/*  91 */         r = (r <= 128) && ((row1[(x - 1)] > 128) || (row1[x] > 128) || (row1[(x + 1)] > 128) || (row2[(x - 1)] > 128) || (row2[(x + 1)] > 128) || (row3[(x - 1)] > 128) || (row3[x] > 128) || (row3[(x + 1)] > 128)) ? r : r >= 128 ? r - 128 : 0;
/*     */ 
/* 102 */         pixels[x] = (0xFF000000 | r << 16 | r << 8 | r);
/*     */       }
/* 104 */       setRGB(dst, 0, y, width, 1, pixels);
/* 105 */       int[] t = row1; row1 = row2; row2 = row3; row3 = t;
/*     */     }
/*     */ 
/* 108 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 112 */     return "Edges/Laplace...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LaplaceFilter
 * JD-Core Version:    0.6.1
 */