/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ public class TransitionFilter extends AbstractBufferedImageOp
/*     */ {
/*  31 */   private float transition = 0.0F;
/*     */   private BufferedImage destination;
/*     */   private String property;
/*     */   private Method method;
/*     */   protected BufferedImageOp filter;
/*     */   protected float minValue;
/*     */   protected float maxValue;
/*     */ 
/*     */   private TransitionFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TransitionFilter(BufferedImageOp filter, String property, float minValue, float maxValue)
/*     */   {
/*  65 */     this.filter = filter;
/*  66 */     this.property = property;
/*  67 */     this.minValue = minValue;
/*  68 */     this.maxValue = maxValue;
/*     */     try {
/*  70 */       BeanInfo info = Introspector.getBeanInfo(filter.getClass());
/*  71 */       PropertyDescriptor[] pds = info.getPropertyDescriptors();
/*  72 */       for (int i = 0; i < pds.length; i++) {
/*  73 */         PropertyDescriptor pd = pds[i];
/*  74 */         if (property.equals(pd.getName())) {
/*  75 */           this.method = pd.getWriteMethod();
/*  76 */           break;
/*     */         }
/*     */       }
/*  79 */       if (this.method == null)
/*  80 */         throw new IllegalArgumentException("No such property in object: " + property);
/*     */     }
/*     */     catch (IntrospectionException e) {
/*  83 */       throw new IllegalArgumentException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTransition(float transition)
/*     */   {
/*  95 */     this.transition = transition;
/*     */   }
/*     */ 
/*     */   public float getTransition()
/*     */   {
/* 104 */     return this.transition;
/*     */   }
/*     */ 
/*     */   public void setDestination(BufferedImage destination)
/*     */   {
/* 113 */     this.destination = destination;
/*     */   }
/*     */ 
/*     */   public BufferedImage getDestination()
/*     */   {
/* 122 */     return this.destination;
/*     */   }
/*     */ 
/*     */   public void prepareFilter(float transition)
/*     */   {
/*     */     try
/*     */     {
/* 142 */       this.method.invoke(this.filter, new Object[] { new Float(transition) });
/*     */     }
/*     */     catch (Exception e) {
/* 145 */       throw new IllegalArgumentException("Error setting value for property: " + this.property);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 150 */     if (dst == null)
/* 151 */       dst = createCompatibleDestImage(src, null);
/* 152 */     if (this.destination == null) {
/* 153 */       return dst;
/*     */     }
/* 155 */     float itransition = 1.0F - this.transition;
/*     */ 
/* 157 */     Graphics2D g = dst.createGraphics();
/* 158 */     if (this.transition != 1.0F) {
/* 159 */       float t = this.minValue + this.transition * (this.maxValue - this.minValue);
/* 160 */       prepareFilter(t);
/* 161 */       g.drawImage(src, this.filter, 0, 0);
/*     */     }
/* 163 */     if (this.transition != 0.0F) {
/* 164 */       g.setComposite(AlphaComposite.getInstance(3, this.transition));
/* 165 */       float t = this.minValue + itransition * (this.maxValue - this.minValue);
/* 166 */       prepareFilter(t);
/* 167 */       g.drawImage(this.destination, this.filter, 0, 0);
/*     */     }
/* 169 */     g.dispose();
/*     */ 
/* 171 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 175 */     return "Transitions/Transition...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TransitionFilter
 * JD-Core Version:    0.6.1
 */