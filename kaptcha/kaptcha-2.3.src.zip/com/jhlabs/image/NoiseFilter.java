/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ public class NoiseFilter extends PointFilter
/*     */ {
/*     */   public static final int GAUSSIAN = 0;
/*     */   public static final int UNIFORM = 1;
/*  37 */   private int amount = 25;
/*  38 */   private int distribution = 1;
/*  39 */   private boolean monochrome = false;
/*  40 */   private float density = 1.0F;
/*  41 */   private Random randomNumbers = new Random();
/*     */ 
/*     */   public void setAmount(int amount)
/*     */   {
/*  54 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public int getAmount()
/*     */   {
/*  63 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setDistribution(int distribution)
/*     */   {
/*  72 */     this.distribution = distribution;
/*     */   }
/*     */ 
/*     */   public int getDistribution()
/*     */   {
/*  81 */     return this.distribution;
/*     */   }
/*     */ 
/*     */   public void setMonochrome(boolean monochrome)
/*     */   {
/*  90 */     this.monochrome = monochrome;
/*     */   }
/*     */ 
/*     */   public boolean getMonochrome()
/*     */   {
/*  99 */     return this.monochrome;
/*     */   }
/*     */ 
/*     */   public void setDensity(float density)
/*     */   {
/* 108 */     this.density = density;
/*     */   }
/*     */ 
/*     */   public float getDensity()
/*     */   {
/* 117 */     return this.density;
/*     */   }
/*     */ 
/*     */   private int random(int x) {
/* 121 */     x += (int)((this.distribution == 0 ? this.randomNumbers.nextGaussian() : 2.0F * this.randomNumbers.nextFloat() - 1.0F) * this.amount);
/* 122 */     if (x < 0)
/* 123 */       x = 0;
/* 124 */     else if (x > 255)
/* 125 */       x = 255;
/* 126 */     return x;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 130 */     if (this.randomNumbers.nextFloat() <= this.density) {
/* 131 */       int a = rgb & 0xFF000000;
/* 132 */       int r = rgb >> 16 & 0xFF;
/* 133 */       int g = rgb >> 8 & 0xFF;
/* 134 */       int b = rgb & 0xFF;
/* 135 */       if (this.monochrome) {
/* 136 */         int n = (int)((this.distribution == 0 ? this.randomNumbers.nextGaussian() : 2.0F * this.randomNumbers.nextFloat() - 1.0F) * this.amount);
/* 137 */         r = PixelUtils.clamp(r + n);
/* 138 */         g = PixelUtils.clamp(g + n);
/* 139 */         b = PixelUtils.clamp(b + n);
/*     */       } else {
/* 141 */         r = random(r);
/* 142 */         g = random(g);
/* 143 */         b = random(b);
/*     */       }
/* 145 */       return a | r << 16 | g << 8 | b;
/*     */     }
/* 147 */     return rgb;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 151 */     return "Stylize/Add Noise...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.NoiseFilter
 * JD-Core Version:    0.6.1
 */