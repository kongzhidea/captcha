/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.FFT;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class LensBlurFilter extends AbstractBufferedImageOp
/*     */ {
/*  30 */   private float radius = 10.0F;
/*  31 */   private float bloom = 2.0F;
/*  32 */   private float bloomThreshold = 192.0F;
/*  33 */   private float angle = 0.0F;
/*  34 */   private int sides = 5;
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/*  42 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/*  51 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setSides(int sides)
/*     */   {
/*  60 */     this.sides = sides;
/*     */   }
/*     */ 
/*     */   public int getSides()
/*     */   {
/*  69 */     return this.sides;
/*     */   }
/*     */ 
/*     */   public void setBloom(float bloom)
/*     */   {
/*  78 */     this.bloom = bloom;
/*     */   }
/*     */ 
/*     */   public float getBloom()
/*     */   {
/*  87 */     return this.bloom;
/*     */   }
/*     */ 
/*     */   public void setBloomThreshold(float bloomThreshold)
/*     */   {
/*  96 */     this.bloomThreshold = bloomThreshold;
/*     */   }
/*     */ 
/*     */   public float getBloomThreshold()
/*     */   {
/* 105 */     return this.bloomThreshold;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst)
/*     */   {
/* 110 */     int width = src.getWidth();
/* 111 */     int height = src.getHeight();
/* 112 */     int rows = 1; int cols = 1;
/* 113 */     int log2rows = 0; int log2cols = 0;
/* 114 */     int iradius = (int)Math.ceil(this.radius);
/* 115 */     int tileWidth = 128;
/* 116 */     int tileHeight = tileWidth;
/*     */ 
/* 118 */     int adjustedWidth = width + iradius * 2;
/* 119 */     int adjustedHeight = height + iradius * 2;
/*     */ 
/* 121 */     tileWidth = iradius < 32 ? Math.min(128, width + 2 * iradius) : Math.min(256, width + 2 * iradius);
/* 122 */     tileHeight = iradius < 32 ? Math.min(128, height + 2 * iradius) : Math.min(256, height + 2 * iradius);
/*     */ 
/* 124 */     if (dst == null) {
/* 125 */       dst = new BufferedImage(width, height, 2);
/*     */     }
/* 127 */     while (rows < tileHeight) {
/* 128 */       rows *= 2;
/* 129 */       log2rows++;
/*     */     }
/* 131 */     while (cols < tileWidth) {
/* 132 */       cols *= 2;
/* 133 */       log2cols++;
/*     */     }
/* 135 */     int w = cols;
/* 136 */     int h = rows;
/*     */ 
/* 138 */     tileWidth = w;
/* 139 */     tileHeight = h;
/*     */ 
/* 141 */     FFT fft = new FFT(Math.max(log2rows, log2cols));
/*     */ 
/* 143 */     int[] rgb = new int[w * h];
/* 144 */     float[][] mask = new float[2][w * h];
/* 145 */     float[][] gb = new float[2][w * h];
/* 146 */     float[][] ar = new float[2][w * h];
/*     */ 
/* 149 */     double polyAngle = 3.141592653589793D / this.sides;
/* 150 */     double polyScale = 1.0D / Math.cos(polyAngle);
/* 151 */     double r2 = this.radius * this.radius;
/* 152 */     double rangle = Math.toRadians(this.angle);
/* 153 */     float total = 0.0F;
/* 154 */     int i = 0;
/* 155 */     for (int y = 0; y < h; y++) {
/* 156 */       for (int x = 0; x < w; x++) {
/* 157 */         double dx = x - w / 2.0F;
/* 158 */         double dy = y - h / 2.0F;
/* 159 */         double r = dx * dx + dy * dy;
/* 160 */         double f = r < r2 ? 1.0D : 0.0D;
/* 161 */         if (f != 0.0D) {
/* 162 */           r = Math.sqrt(r);
/* 163 */           if (this.sides != 0) {
/* 164 */             double a = Math.atan2(dy, dx) + rangle;
/* 165 */             a = ImageMath.mod(a, polyAngle * 2.0D) - polyAngle;
/* 166 */             f = Math.cos(a) * polyScale;
/*     */           } else {
/* 168 */             f = 1.0D;
/* 169 */           }f = f * r < this.radius ? 1.0D : 0.0D;
/*     */         }
/* 171 */         total += (float)f;
/*     */ 
/* 173 */         mask[0][i] = (float)f;
/* 174 */         mask[1][i] = 0.0F;
/* 175 */         i++;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 180 */     i = 0;
/* 181 */     for (int y = 0; y < h; y++) {
/* 182 */       for (int x = 0; x < w; x++) {
/* 183 */         mask[0][i] /= total;
/* 184 */         i++;
/*     */       }
/*     */     }
/*     */ 
/* 188 */     fft.transform2D(mask[0], mask[1], w, h, true);
/*     */ 
/* 190 */     for (int tileY = -iradius; tileY < height; tileY += tileHeight - 2 * iradius) {
/* 191 */       for (int tileX = -iradius; tileX < width; tileX += tileWidth - 2 * iradius)
/*     */       {
/* 195 */         int tx = tileX; int ty = tileY; int tw = tileWidth; int th = tileHeight;
/* 196 */         int fx = 0; int fy = 0;
/* 197 */         if (tx < 0) {
/* 198 */           tw += tx;
/* 199 */           fx -= tx;
/* 200 */           tx = 0;
/*     */         }
/* 202 */         if (ty < 0) {
/* 203 */           th += ty;
/* 204 */           fy -= ty;
/* 205 */           ty = 0;
/*     */         }
/* 207 */         if (tx + tw > width)
/* 208 */           tw = width - tx;
/* 209 */         if (ty + th > height)
/* 210 */           th = height - ty;
/* 211 */         src.getRGB(tx, ty, tw, th, rgb, fy * w + fx, w);
/*     */ 
/* 214 */         i = 0;
/* 215 */         for (int y = 0; y < h; y++) {
/* 216 */           int imageY = y + tileY;
/*     */           int j;
/*     */           int j;
/* 218 */           if (imageY < 0) {
/* 219 */             j = fy;
/*     */           }
/*     */           else
/*     */           {
/*     */             int j;
/* 220 */             if (imageY > height)
/* 221 */               j = fy + th - 1;
/*     */             else
/* 223 */               j = y; 
/*     */           }
/* 224 */           j *= w;
/* 225 */           for (int x = 0; x < w; x++) {
/* 226 */             int imageX = x + tileX;
/*     */             int k;
/*     */             int k;
/* 228 */             if (imageX < 0) {
/* 229 */               k = fx;
/*     */             }
/*     */             else
/*     */             {
/*     */               int k;
/* 230 */               if (imageX > width)
/* 231 */                 k = fx + tw - 1;
/*     */               else
/* 233 */                 k = x; 
/*     */             }
/* 234 */             k += j;
/*     */ 
/* 236 */             ar[0][i] = rgb[k] >> 24 & 0xFF;
/* 237 */             float r = rgb[k] >> 16 & 0xFF;
/* 238 */             float g = rgb[k] >> 8 & 0xFF;
/* 239 */             float b = rgb[k] & 0xFF;
/*     */ 
/* 242 */             if (r > this.bloomThreshold) {
/* 243 */               r *= this.bloom;
/*     */             }
/* 245 */             if (g > this.bloomThreshold) {
/* 246 */               g *= this.bloom;
/*     */             }
/* 248 */             if (b > this.bloomThreshold) {
/* 249 */               b *= this.bloom;
/*     */             }
/*     */ 
/* 252 */             ar[1][i] = r;
/* 253 */             gb[0][i] = g;
/* 254 */             gb[1][i] = b;
/*     */ 
/* 256 */             i++;
/* 257 */             k++;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 262 */         fft.transform2D(ar[0], ar[1], cols, rows, true);
/* 263 */         fft.transform2D(gb[0], gb[1], cols, rows, true);
/*     */ 
/* 266 */         i = 0;
/* 267 */         for (int y = 0; y < h; y++) {
/* 268 */           for (int x = 0; x < w; x++) {
/* 269 */             float re = ar[0][i];
/* 270 */             float im = ar[1][i];
/* 271 */             float rem = mask[0][i];
/* 272 */             float imm = mask[1][i];
/* 273 */             ar[0][i] = (re * rem - im * imm);
/* 274 */             ar[1][i] = (re * imm + im * rem);
/*     */ 
/* 276 */             re = gb[0][i];
/* 277 */             im = gb[1][i];
/* 278 */             gb[0][i] = (re * rem - im * imm);
/* 279 */             gb[1][i] = (re * imm + im * rem);
/* 280 */             i++;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 285 */         fft.transform2D(ar[0], ar[1], cols, rows, false);
/* 286 */         fft.transform2D(gb[0], gb[1], cols, rows, false);
/*     */ 
/* 289 */         int row_flip = w >> 1;
/* 290 */         int col_flip = h >> 1;
/* 291 */         int index = 0;
/*     */ 
/* 294 */         for (int y = 0; y < w; y++) {
/* 295 */           int ym = y ^ row_flip;
/* 296 */           int yi = ym * cols;
/* 297 */           for (int x = 0; x < w; x++) {
/* 298 */             int xm = yi + (x ^ col_flip);
/* 299 */             int a = (int)ar[0][xm];
/* 300 */             int r = (int)ar[1][xm];
/* 301 */             int g = (int)gb[0][xm];
/* 302 */             int b = (int)gb[1][xm];
/*     */ 
/* 305 */             if (r > 255)
/* 306 */               r = 255;
/* 307 */             if (g > 255)
/* 308 */               g = 255;
/* 309 */             if (b > 255)
/* 310 */               b = 255;
/* 311 */             int argb = a << 24 | r << 16 | g << 8 | b;
/* 312 */             rgb[(index++)] = argb;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 317 */         tx = tileX + iradius;
/* 318 */         ty = tileY + iradius;
/* 319 */         tw = tileWidth - 2 * iradius;
/* 320 */         th = tileHeight - 2 * iradius;
/* 321 */         if (tx + tw > width)
/* 322 */           tw = width - tx;
/* 323 */         if (ty + th > height)
/* 324 */           th = height - ty;
/* 325 */         dst.setRGB(tx, ty, tw, th, rgb, iradius * w + iradius, w);
/*     */       }
/*     */     }
/* 328 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 332 */     return "Blur/Lens Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LensBlurFilter
 * JD-Core Version:    0.6.1
 */