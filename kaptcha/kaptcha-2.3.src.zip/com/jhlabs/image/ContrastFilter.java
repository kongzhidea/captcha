/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class ContrastFilter extends TransferFilter
/*    */ {
/* 27 */   private float brightness = 1.0F;
/* 28 */   private float contrast = 1.0F;
/*    */ 
/*    */   protected float transferFunction(float f) {
/* 31 */     f *= this.brightness;
/* 32 */     f = (f - 0.5F) * this.contrast + 0.5F;
/* 33 */     return f;
/*    */   }
/*    */ 
/*    */   public void setBrightness(float brightness)
/*    */   {
/* 44 */     this.brightness = brightness;
/* 45 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getBrightness()
/*    */   {
/* 54 */     return this.brightness;
/*    */   }
/*    */ 
/*    */   public void setContrast(float contrast)
/*    */   {
/* 65 */     this.contrast = contrast;
/* 66 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getContrast()
/*    */   {
/* 75 */     return this.contrast;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 79 */     return "Colors/Contrast...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ContrastFilter
 * JD-Core Version:    0.6.1
 */