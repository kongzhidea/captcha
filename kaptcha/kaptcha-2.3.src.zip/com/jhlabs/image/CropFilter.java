/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ public class CropFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private int x;
/*     */   private int y;
/*     */   private int width;
/*     */   private int height;
/*     */ 
/*     */   public CropFilter()
/*     */   {
/*  37 */     this(0, 0, 32, 32);
/*     */   }
/*     */ 
/*     */   public CropFilter(int x, int y, int width, int height)
/*     */   {
/*  48 */     this.x = x;
/*  49 */     this.y = y;
/*  50 */     this.width = width;
/*  51 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public void setX(int x)
/*     */   {
/*  60 */     this.x = x;
/*     */   }
/*     */ 
/*     */   public int getX()
/*     */   {
/*  69 */     return this.x;
/*     */   }
/*     */ 
/*     */   public void setY(int y)
/*     */   {
/*  78 */     this.y = y;
/*     */   }
/*     */ 
/*     */   public int getY()
/*     */   {
/*  87 */     return this.y;
/*     */   }
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/*  96 */     this.width = width;
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 105 */     return this.width;
/*     */   }
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 114 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 123 */     return this.height;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 127 */     int w = src.getWidth();
/* 128 */     int h = src.getHeight();
/*     */ 
/* 130 */     if (dst == null) {
/* 131 */       ColorModel dstCM = src.getColorModel();
/* 132 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(this.width, this.height), dstCM.isAlphaPremultiplied(), null);
/*     */     }
/*     */ 
/* 135 */     Graphics2D g = dst.createGraphics();
/* 136 */     g.drawRenderedImage(src, AffineTransform.getTranslateInstance(-this.x, -this.y));
/* 137 */     g.dispose();
/*     */ 
/* 139 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 143 */     return "Distort/Crop";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CropFilter
 * JD-Core Version:    0.6.1
 */