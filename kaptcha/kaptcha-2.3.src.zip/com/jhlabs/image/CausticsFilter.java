/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class CausticsFilter extends WholeImageFilter
/*     */ {
/*  29 */   private float scale = 32.0F;
/*  30 */   private float angle = 0.0F;
/*  31 */   private int brightness = 10;
/*  32 */   private float amount = 1.0F;
/*  33 */   private float turbulence = 1.0F;
/*  34 */   private float dispersion = 0.0F;
/*  35 */   private float time = 0.0F;
/*  36 */   private int samples = 2;
/*  37 */   private int bgColor = -8806401;
/*     */   private float s;
/*     */   private float c;
/*     */ 
/*     */   public void setScale(float scale)
/*     */   {
/*  52 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   public float getScale()
/*     */   {
/*  61 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public void setBrightness(int brightness)
/*     */   {
/*  72 */     this.brightness = brightness;
/*     */   }
/*     */ 
/*     */   public int getBrightness()
/*     */   {
/*  81 */     return this.brightness;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/*  92 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 101 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/* 112 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/* 121 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setDispersion(float dispersion)
/*     */   {
/* 132 */     this.dispersion = dispersion;
/*     */   }
/*     */ 
/*     */   public float getDispersion()
/*     */   {
/* 141 */     return this.dispersion;
/*     */   }
/*     */ 
/*     */   public void setTime(float time)
/*     */   {
/* 150 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public float getTime()
/*     */   {
/* 159 */     return this.time;
/*     */   }
/*     */ 
/*     */   public void setSamples(int samples)
/*     */   {
/* 168 */     this.samples = samples;
/*     */   }
/*     */ 
/*     */   public int getSamples()
/*     */   {
/* 177 */     return this.samples;
/*     */   }
/*     */ 
/*     */   public void setBgColor(int c)
/*     */   {
/* 186 */     this.bgColor = c;
/*     */   }
/*     */ 
/*     */   public int getBgColor()
/*     */   {
/* 195 */     return this.bgColor;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 199 */     Random random = new Random(0L);
/*     */ 
/* 201 */     this.s = (float)Math.sin(0.1D);
/* 202 */     this.c = (float)Math.cos(0.1D);
/*     */ 
/* 204 */     int srcWidth = this.originalSpace.width;
/* 205 */     int srcHeight = this.originalSpace.height;
/* 206 */     int outWidth = transformedSpace.width;
/* 207 */     int outHeight = transformedSpace.height;
/* 208 */     int index = 0;
/* 209 */     int[] pixels = new int[outWidth * outHeight];
/*     */ 
/* 211 */     for (int y = 0; y < outHeight; y++) {
/* 212 */       for (int x = 0; x < outWidth; x++) {
/* 213 */         pixels[(index++)] = this.bgColor;
/*     */       }
/*     */     }
/*     */ 
/* 217 */     int v = this.brightness / this.samples;
/* 218 */     if (v == 0) {
/* 219 */       v = 1;
/*     */     }
/* 221 */     float rs = 1.0F / this.scale;
/* 222 */     float d = 0.95F;
/* 223 */     index = 0;
/* 224 */     for (int y = 0; y < outHeight; y++) {
/* 225 */       for (int x = 0; x < outWidth; x++) {
/* 226 */         for (int s = 0; s < this.samples; s++) {
/* 227 */           float sx = x + random.nextFloat();
/* 228 */           float sy = y + random.nextFloat();
/* 229 */           float nx = sx * rs;
/* 230 */           float ny = sy * rs;
/*     */ 
/* 232 */           float focus = 0.1F + this.amount;
/* 233 */           float xDisplacement = evaluate(nx - d, ny) - evaluate(nx + d, ny);
/* 234 */           float yDisplacement = evaluate(nx, ny + d) - evaluate(nx, ny - d);
/*     */ 
/* 236 */           if (this.dispersion > 0.0F) {
/* 237 */             for (int c = 0; c < 3; c++) {
/* 238 */               float ca = 1.0F + c * this.dispersion;
/* 239 */               float srcX = sx + this.scale * focus * xDisplacement * ca;
/* 240 */               float srcY = sy + this.scale * focus * yDisplacement * ca;
/*     */ 
/* 242 */               if ((srcX >= 0.0F) && (srcX < outWidth - 1) && (srcY >= 0.0F) && (srcY < outHeight - 1))
/*     */               {
/* 244 */                 int i = (int)srcY * outWidth + (int)srcX;
/* 245 */                 int rgb = pixels[i];
/* 246 */                 int r = rgb >> 16 & 0xFF;
/* 247 */                 int g = rgb >> 8 & 0xFF;
/* 248 */                 int b = rgb & 0xFF;
/* 249 */                 if (c == 2)
/* 250 */                   r += v;
/* 251 */                 else if (c == 1)
/* 252 */                   g += v;
/*     */                 else
/* 254 */                   b += v;
/* 255 */                 if (r > 255)
/* 256 */                   r = 255;
/* 257 */                 if (g > 255)
/* 258 */                   g = 255;
/* 259 */                 if (b > 255)
/* 260 */                   b = 255;
/* 261 */                 pixels[i] = (0xFF000000 | r << 16 | g << 8 | b);
/*     */               }
/*     */             }
/*     */           } else {
/* 265 */             float srcX = sx + this.scale * focus * xDisplacement;
/* 266 */             float srcY = sy + this.scale * focus * yDisplacement;
/*     */ 
/* 268 */             if ((srcX >= 0.0F) && (srcX < outWidth - 1) && (srcY >= 0.0F) && (srcY < outHeight - 1))
/*     */             {
/* 270 */               int i = (int)srcY * outWidth + (int)srcX;
/* 271 */               int rgb = pixels[i];
/* 272 */               int r = rgb >> 16 & 0xFF;
/* 273 */               int g = rgb >> 8 & 0xFF;
/* 274 */               int b = rgb & 0xFF;
/* 275 */               r += v;
/* 276 */               g += v;
/* 277 */               b += v;
/* 278 */               if (r > 255)
/* 279 */                 r = 255;
/* 280 */               if (g > 255)
/* 281 */                 g = 255;
/* 282 */               if (b > 255)
/* 283 */                 b = 255;
/* 284 */               pixels[i] = (0xFF000000 | r << 16 | g << 8 | b);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 290 */     return pixels;
/*     */   }
/*     */ 
/*     */   private static int add(int rgb, float brightness) {
/* 294 */     int r = rgb >> 16 & 0xFF;
/* 295 */     int g = rgb >> 8 & 0xFF;
/* 296 */     int b = rgb & 0xFF;
/* 297 */     r = (int)(r + brightness);
/* 298 */     g = (int)(g + brightness);
/* 299 */     b = (int)(b + brightness);
/* 300 */     if (r > 255)
/* 301 */       r = 255;
/* 302 */     if (g > 255)
/* 303 */       g = 255;
/* 304 */     if (b > 255)
/* 305 */       b = 255;
/* 306 */     return 0xFF000000 | r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */   private static int add(int rgb, float brightness, int c) {
/* 310 */     int r = rgb >> 16 & 0xFF;
/* 311 */     int g = rgb >> 8 & 0xFF;
/* 312 */     int b = rgb & 0xFF;
/* 313 */     if (c == 2)
/* 314 */       r = (int)(r + brightness);
/* 315 */     else if (c == 1)
/* 316 */       g = (int)(g + brightness);
/*     */     else
/* 318 */       b = (int)(b + brightness);
/* 319 */     if (r > 255)
/* 320 */       r = 255;
/* 321 */     if (g > 255)
/* 322 */       g = 255;
/* 323 */     if (b > 255)
/* 324 */       b = 255;
/* 325 */     return 0xFF000000 | r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */   private static float turbulence2(float x, float y, float time, float octaves) {
/* 329 */     float value = 0.0F;
/*     */ 
/* 331 */     float lacunarity = 2.0F;
/* 332 */     float f = 1.0F;
/*     */ 
/* 336 */     x += 371.0F;
/* 337 */     y += 529.0F;
/*     */ 
/* 339 */     for (int i = 0; i < (int)octaves; i++) {
/* 340 */       value += Noise.noise3(x, y, time) / f;
/* 341 */       x *= lacunarity;
/* 342 */       y *= lacunarity;
/* 343 */       f *= 2.0F;
/*     */     }
/*     */ 
/* 346 */     float remainder = octaves - (int)octaves;
/* 347 */     if (remainder != 0.0F) {
/* 348 */       value += remainder * Noise.noise3(x, y, time) / f;
/*     */     }
/* 350 */     return value;
/*     */   }
/*     */ 
/*     */   private float evaluate(float x, float y) {
/* 354 */     float xt = this.s * x + this.c * this.time;
/* 355 */     float tt = this.c * x - this.c * this.time;
/* 356 */     float f = this.turbulence == 0.0D ? Noise.noise3(xt, y, tt) : turbulence2(xt, y, tt, this.turbulence);
/* 357 */     return f;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 361 */     return "Texture/Caustics...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CausticsFilter
 * JD-Core Version:    0.6.1
 */