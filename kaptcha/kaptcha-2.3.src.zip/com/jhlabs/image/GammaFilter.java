/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class GammaFilter extends TransferFilter
/*     */ {
/*     */   private float rGamma;
/*     */   private float gGamma;
/*     */   private float bGamma;
/*     */ 
/*     */   public GammaFilter()
/*     */   {
/*  33 */     this(1.0F);
/*     */   }
/*     */ 
/*     */   public GammaFilter(float gamma)
/*     */   {
/*  41 */     this(gamma, gamma, gamma);
/*     */   }
/*     */ 
/*     */   public GammaFilter(float rGamma, float gGamma, float bGamma)
/*     */   {
/*  51 */     setGamma(rGamma, gGamma, bGamma);
/*     */   }
/*     */ 
/*     */   public void setGamma(float rGamma, float gGamma, float bGamma)
/*     */   {
/*  62 */     this.rGamma = rGamma;
/*  63 */     this.gGamma = gGamma;
/*  64 */     this.bGamma = bGamma;
/*  65 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */   public void setGamma(float gamma)
/*     */   {
/*  74 */     setGamma(gamma, gamma, gamma);
/*     */   }
/*     */ 
/*     */   public float getGamma()
/*     */   {
/*  83 */     return this.rGamma;
/*     */   }
/*     */ 
/*     */   protected void initialize() {
/*  87 */     this.rTable = makeTable(this.rGamma);
/*     */ 
/*  89 */     if (this.gGamma == this.rGamma)
/*  90 */       this.gTable = this.rTable;
/*     */     else {
/*  92 */       this.gTable = makeTable(this.gGamma);
/*     */     }
/*  94 */     if (this.bGamma == this.rGamma)
/*  95 */       this.bTable = this.rTable;
/*  96 */     else if (this.bGamma == this.gGamma)
/*  97 */       this.bTable = this.gTable;
/*     */     else
/*  99 */       this.bTable = makeTable(this.bGamma);
/*     */   }
/*     */ 
/*     */   private int[] makeTable(float gamma) {
/* 103 */     int[] table = new int[256];
/* 104 */     for (int i = 0; i < 256; i++) {
/* 105 */       int v = (int)(255.0D * Math.pow(i / 255.0D, 1.0D / gamma) + 0.5D);
/* 106 */       if (v > 255)
/* 107 */         v = 255;
/* 108 */       table[i] = v;
/*     */     }
/* 110 */     return table;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 114 */     return "Colors/Gamma...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GammaFilter
 * JD-Core Version:    0.6.1
 */