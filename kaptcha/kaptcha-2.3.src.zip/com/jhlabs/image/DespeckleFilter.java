/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class DespeckleFilter extends WholeImageFilter
/*     */ {
/*     */   private short pepperAndSalt(short c, short v1, short v2)
/*     */   {
/*  31 */     if (c < v1)
/*  32 */       c = (short)(c + 1);
/*  33 */     if (c < v2)
/*  34 */       c = (short)(c + 1);
/*  35 */     if (c > v1)
/*  36 */       c = (short)(c - 1);
/*  37 */     if (c > v2)
/*  38 */       c = (short)(c - 1);
/*  39 */     return c;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  43 */     int index = 0;
/*  44 */     short[][] r = new short[3][width];
/*  45 */     short[][] g = new short[3][width];
/*  46 */     short[][] b = new short[3][width];
/*  47 */     int[] outPixels = new int[width * height];
/*     */ 
/*  49 */     for (int x = 0; x < width; x++) {
/*  50 */       int rgb = inPixels[x];
/*  51 */       r[1][x] = (short)(rgb >> 16 & 0xFF);
/*  52 */       g[1][x] = (short)(rgb >> 8 & 0xFF);
/*  53 */       b[1][x] = (short)(rgb & 0xFF);
/*     */     }
/*  55 */     for (int y = 0; y < height; y++) {
/*  56 */       boolean yIn = (y > 0) && (y < height - 1);
/*  57 */       int nextRowIndex = index + width;
/*  58 */       if (y < height - 1) {
/*  59 */         for (int x = 0; x < width; x++) {
/*  60 */           int rgb = inPixels[(nextRowIndex++)];
/*  61 */           r[2][x] = (short)(rgb >> 16 & 0xFF);
/*  62 */           g[2][x] = (short)(rgb >> 8 & 0xFF);
/*  63 */           b[2][x] = (short)(rgb & 0xFF);
/*     */         }
/*     */       }
/*  66 */       for (int x = 0; x < width; x++) {
/*  67 */         boolean xIn = (x > 0) && (x < width - 1);
/*  68 */         short or = r[1][x];
/*  69 */         short og = g[1][x];
/*  70 */         short ob = b[1][x];
/*  71 */         int w = x - 1;
/*  72 */         int e = x + 1;
/*     */ 
/*  74 */         if (yIn) {
/*  75 */           or = pepperAndSalt(or, r[0][x], r[2][x]);
/*  76 */           og = pepperAndSalt(og, g[0][x], g[2][x]);
/*  77 */           ob = pepperAndSalt(ob, b[0][x], b[2][x]);
/*     */         }
/*     */ 
/*  80 */         if (xIn) {
/*  81 */           or = pepperAndSalt(or, r[1][w], r[1][e]);
/*  82 */           og = pepperAndSalt(og, g[1][w], g[1][e]);
/*  83 */           ob = pepperAndSalt(ob, b[1][w], b[1][e]);
/*     */         }
/*     */ 
/*  86 */         if ((yIn) && (xIn)) {
/*  87 */           or = pepperAndSalt(or, r[0][w], r[2][e]);
/*  88 */           og = pepperAndSalt(og, g[0][w], g[2][e]);
/*  89 */           ob = pepperAndSalt(ob, b[0][w], b[2][e]);
/*     */ 
/*  91 */           or = pepperAndSalt(or, r[2][w], r[0][e]);
/*  92 */           og = pepperAndSalt(og, g[2][w], g[0][e]);
/*  93 */           ob = pepperAndSalt(ob, b[2][w], b[0][e]);
/*     */         }
/*     */ 
/*  96 */         outPixels[index] = (inPixels[index] & 0xFF000000 | or << 16 | og << 8 | ob);
/*  97 */         index++;
/*     */       }
/*     */ 
/* 100 */       short[] t = r[0];
/* 101 */       r[0] = r[1];
/* 102 */       r[1] = r[2];
/* 103 */       r[2] = t;
/* 104 */       t = g[0];
/* 105 */       g[0] = g[1];
/* 106 */       g[1] = g[2];
/* 107 */       g[2] = t;
/* 108 */       t = b[0];
/* 109 */       b[0] = b[1];
/* 110 */       b[1] = b[2];
/* 111 */       b[2] = t;
/*     */     }
/*     */ 
/* 114 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 118 */     return "Blur/Despeckle...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DespeckleFilter
 * JD-Core Version:    0.6.1
 */