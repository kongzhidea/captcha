/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class DissolveFilter extends PointFilter
/*    */ {
/* 27 */   private float density = 1.0F;
/* 28 */   private float softness = 0.0F;
/*    */   private float minDensity;
/*    */   private float maxDensity;
/*    */   private Random randomNumbers;
/*    */ 
/*    */   public void setDensity(float density)
/*    */   {
/* 43 */     this.density = density;
/*    */   }
/*    */ 
/*    */   public float getDensity()
/*    */   {
/* 52 */     return this.density;
/*    */   }
/*    */ 
/*    */   public void setSoftness(float softness)
/*    */   {
/* 63 */     this.softness = softness;
/*    */   }
/*    */ 
/*    */   public float getSoftness()
/*    */   {
/* 72 */     return this.softness;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 76 */     float d = (1.0F - this.density) * (1.0F + this.softness);
/* 77 */     this.minDensity = (d - this.softness);
/* 78 */     this.maxDensity = d;
/* 79 */     this.randomNumbers = new Random(0L);
/* 80 */     return super.filter(src, dst);
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 84 */     int a = rgb >> 24 & 0xFF;
/* 85 */     float v = this.randomNumbers.nextFloat();
/* 86 */     float f = ImageMath.smoothStep(this.minDensity, this.maxDensity, v);
/* 87 */     return (int)(a * f) << 24 | rgb & 0xFFFFFF;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 91 */     return "Stylize/Dissolve...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DissolveFilter
 * JD-Core Version:    0.6.1
 */