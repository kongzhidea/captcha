/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class OctTreeQuantizer
/*     */   implements Quantizer
/*     */ {
/*     */   static final int MAX_LEVEL = 5;
/*  67 */   private int nodes = 0;
/*     */   private OctTreeNode root;
/*     */   private int reduceColors;
/*     */   private int maximumColors;
/*  71 */   private int colors = 0;
/*     */   private Vector[] colorList;
/*     */ 
/*     */   public OctTreeQuantizer()
/*     */   {
/*  75 */     setup(256);
/*  76 */     this.colorList = new Vector[6];
/*  77 */     for (int i = 0; i < 6; i++)
/*  78 */       this.colorList[i] = new Vector();
/*  79 */     this.root = new OctTreeNode();
/*     */   }
/*     */ 
/*     */   public void setup(int numColors)
/*     */   {
/*  87 */     this.maximumColors = numColors;
/*  88 */     this.reduceColors = Math.max(512, numColors * 2);
/*     */   }
/*     */ 
/*     */   public void addPixels(int[] pixels, int offset, int count)
/*     */   {
/*  98 */     for (int i = 0; i < count; i++) {
/*  99 */       insertColor(pixels[(i + offset)]);
/* 100 */       if (this.colors > this.reduceColors)
/* 101 */         reduceTree(this.reduceColors);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getIndexForColor(int rgb)
/*     */   {
/* 111 */     int red = rgb >> 16 & 0xFF;
/* 112 */     int green = rgb >> 8 & 0xFF;
/* 113 */     int blue = rgb & 0xFF;
/*     */ 
/* 115 */     OctTreeNode node = this.root;
/*     */ 
/* 117 */     for (int level = 0; level <= 5; level++)
/*     */     {
/* 119 */       int bit = 128 >> level;
/*     */ 
/* 121 */       int index = 0;
/* 122 */       if ((red & bit) != 0)
/* 123 */         index += 4;
/* 124 */       if ((green & bit) != 0)
/* 125 */         index += 2;
/* 126 */       if ((blue & bit) != 0) {
/* 127 */         index++;
/*     */       }
/* 129 */       OctTreeNode child = node.leaf[index];
/*     */ 
/* 131 */       if (child == null)
/* 132 */         return node.index;
/* 133 */       if (child.isLeaf) {
/* 134 */         return child.index;
/*     */       }
/* 136 */       node = child;
/*     */     }
/* 138 */     System.out.println("getIndexForColor failed");
/* 139 */     return 0;
/*     */   }
/*     */ 
/*     */   private void insertColor(int rgb) {
/* 143 */     int red = rgb >> 16 & 0xFF;
/* 144 */     int green = rgb >> 8 & 0xFF;
/* 145 */     int blue = rgb & 0xFF;
/*     */ 
/* 147 */     OctTreeNode node = this.root;
/*     */ 
/* 150 */     for (int level = 0; level <= 5; level++)
/*     */     {
/* 152 */       int bit = 128 >> level;
/*     */ 
/* 154 */       int index = 0;
/* 155 */       if ((red & bit) != 0)
/* 156 */         index += 4;
/* 157 */       if ((green & bit) != 0)
/* 158 */         index += 2;
/* 159 */       if ((blue & bit) != 0) {
/* 160 */         index++;
/*     */       }
/* 162 */       OctTreeNode child = node.leaf[index];
/*     */ 
/* 164 */       if (child == null) {
/* 165 */         node.children += 1;
/*     */ 
/* 167 */         child = new OctTreeNode();
/* 168 */         child.parent = node;
/* 169 */         node.leaf[index] = child;
/* 170 */         node.isLeaf = false;
/* 171 */         this.nodes += 1;
/* 172 */         this.colorList[level].addElement(child);
/*     */ 
/* 174 */         if (level == 5) {
/* 175 */           child.isLeaf = true;
/* 176 */           child.count = 1;
/* 177 */           child.totalRed = red;
/* 178 */           child.totalGreen = green;
/* 179 */           child.totalBlue = blue;
/* 180 */           child.level = level;
/* 181 */           this.colors += 1;
/* 182 */           return;
/*     */         }
/*     */ 
/* 185 */         node = child; } else {
/* 186 */         if (child.isLeaf) {
/* 187 */           child.count += 1;
/* 188 */           child.totalRed += red;
/* 189 */           child.totalGreen += green;
/* 190 */           child.totalBlue += blue;
/* 191 */           return;
/*     */         }
/* 193 */         node = child;
/*     */       }
/*     */     }
/* 195 */     System.out.println("insertColor failed");
/*     */   }
/*     */ 
/*     */   private void reduceTree(int numColors) {
/* 199 */     for (int level = 4; level >= 0; level--) {
/* 200 */       Vector v = this.colorList[level];
/* 201 */       if ((v != null) && (v.size() > 0)) {
/* 202 */         for (int j = 0; j < v.size(); j++) {
/* 203 */           OctTreeNode node = (OctTreeNode)v.elementAt(j);
/* 204 */           if (node.children > 0) {
/* 205 */             for (int i = 0; i < 8; i++) {
/* 206 */               OctTreeNode child = node.leaf[i];
/* 207 */               if (child != null) {
/* 208 */                 if (!child.isLeaf)
/* 209 */                   System.out.println("not a leaf!");
/* 210 */                 node.count += child.count;
/* 211 */                 node.totalRed += child.totalRed;
/* 212 */                 node.totalGreen += child.totalGreen;
/* 213 */                 node.totalBlue += child.totalBlue;
/* 214 */                 node.leaf[i] = null;
/* 215 */                 node.children -= 1;
/* 216 */                 this.colors -= 1;
/* 217 */                 this.nodes -= 1;
/* 218 */                 this.colorList[(level + 1)].removeElement(child);
/*     */               }
/*     */             }
/* 221 */             node.isLeaf = true;
/* 222 */             this.colors += 1;
/* 223 */             if (this.colors <= numColors) {
/* 224 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 230 */     System.out.println("Unable to reduce the OctTree");
/*     */   }
/*     */ 
/*     */   public int[] buildColorTable()
/*     */   {
/* 238 */     int[] table = new int[this.colors];
/* 239 */     buildColorTable(this.root, table, 0);
/* 240 */     return table;
/*     */   }
/*     */ 
/*     */   public void buildColorTable(int[] inPixels, int[] table)
/*     */   {
/* 249 */     int count = inPixels.length;
/* 250 */     this.maximumColors = table.length;
/* 251 */     for (int i = 0; i < count; i++) {
/* 252 */       insertColor(inPixels[i]);
/* 253 */       if (this.colors > this.reduceColors)
/* 254 */         reduceTree(this.reduceColors);
/*     */     }
/* 256 */     if (this.colors > this.maximumColors)
/* 257 */       reduceTree(this.maximumColors);
/* 258 */     buildColorTable(this.root, table, 0);
/*     */   }
/*     */ 
/*     */   private int buildColorTable(OctTreeNode node, int[] table, int index) {
/* 262 */     if (this.colors > this.maximumColors) {
/* 263 */       reduceTree(this.maximumColors);
/*     */     }
/* 265 */     if (node.isLeaf) {
/* 266 */       int count = node.count;
/* 267 */       table[index] = (0xFF000000 | node.totalRed / count << 16 | node.totalGreen / count << 8 | node.totalBlue / count);
/*     */ 
/* 271 */       node.index = (index++);
/*     */     } else {
/* 273 */       for (int i = 0; i < 8; i++) {
/* 274 */         if (node.leaf[i] != null) {
/* 275 */           node.index = index;
/* 276 */           index = buildColorTable(node.leaf[i], table, index);
/*     */         }
/*     */       }
/*     */     }
/* 280 */     return index;
/*     */   }
/*     */ 
/*     */   class OctTreeNode
/*     */   {
/*     */     int children;
/*     */     int level;
/*     */     OctTreeNode parent;
/*  43 */     OctTreeNode[] leaf = new OctTreeNode[8];
/*     */     boolean isLeaf;
/*     */     int count;
/*     */     int totalRed;
/*     */     int totalGreen;
/*     */     int totalBlue;
/*     */     int index;
/*     */ 
/*     */     OctTreeNode()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void list(PrintStream s, int level)
/*     */     {
/*  55 */       for (int i = 0; i < level; i++)
/*  56 */         System.out.print(' ');
/*  57 */       if (this.count == 0)
/*  58 */         System.out.println(this.index + ": count=" + this.count);
/*     */       else
/*  60 */         System.out.println(this.index + ": count=" + this.count + " red=" + this.totalRed / this.count + " green=" + this.totalGreen / this.count + " blue=" + this.totalBlue / this.count);
/*  61 */       for (int i = 0; i < 8; i++)
/*  62 */         if (this.leaf[i] != null)
/*  63 */           this.leaf[i].list(s, level + 2);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.OctTreeQuantizer
 * JD-Core Version:    0.6.1
 */