/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class PixelUtils
/*     */ {
/*     */   public static final int REPLACE = 0;
/*     */   public static final int NORMAL = 1;
/*     */   public static final int MIN = 2;
/*     */   public static final int MAX = 3;
/*     */   public static final int ADD = 4;
/*     */   public static final int SUBTRACT = 5;
/*     */   public static final int DIFFERENCE = 6;
/*     */   public static final int MULTIPLY = 7;
/*     */   public static final int HUE = 8;
/*     */   public static final int SATURATION = 9;
/*     */   public static final int VALUE = 10;
/*     */   public static final int COLOR = 11;
/*     */   public static final int SCREEN = 12;
/*     */   public static final int AVERAGE = 13;
/*     */   public static final int OVERLAY = 14;
/*     */   public static final int CLEAR = 15;
/*     */   public static final int EXCHANGE = 16;
/*     */   public static final int DISSOLVE = 17;
/*     */   public static final int DST_IN = 18;
/*     */   public static final int ALPHA = 19;
/*     */   public static final int ALPHA_TO_GRAY = 20;
/*  50 */   private static Random randomGenerator = new Random();
/*     */ 
/*  84 */   private static final float[] hsb1 = new float[3];
/*  85 */   private static final float[] hsb2 = new float[3];
/*     */ 
/*     */   public static int clamp(int c)
/*     */   {
/*  56 */     if (c < 0)
/*  57 */       return 0;
/*  58 */     if (c > 255)
/*  59 */       return 255;
/*  60 */     return c;
/*     */   }
/*     */ 
/*     */   public static int interpolate(int v1, int v2, float f) {
/*  64 */     return clamp((int)(v1 + f * v2 - v1));
/*     */   }
/*     */ 
/*     */   public static int brightness(int rgb) {
/*  68 */     int r = rgb >> 16 & 0xFF;
/*  69 */     int g = rgb >> 8 & 0xFF;
/*  70 */     int b = rgb & 0xFF;
/*  71 */     return (r + g + b) / 3;
/*     */   }
/*     */ 
/*     */   public static boolean nearColors(int rgb1, int rgb2, int tolerance) {
/*  75 */     int r1 = rgb1 >> 16 & 0xFF;
/*  76 */     int g1 = rgb1 >> 8 & 0xFF;
/*  77 */     int b1 = rgb1 & 0xFF;
/*  78 */     int r2 = rgb2 >> 16 & 0xFF;
/*  79 */     int g2 = rgb2 >> 8 & 0xFF;
/*  80 */     int b2 = rgb2 & 0xFF;
/*  81 */     return (Math.abs(r1 - r2) <= tolerance) && (Math.abs(g1 - g2) <= tolerance) && (Math.abs(b1 - b2) <= tolerance);
/*     */   }
/*     */ 
/*     */   public static int combinePixels(int rgb1, int rgb2, int op)
/*     */   {
/*  89 */     return combinePixels(rgb1, rgb2, op, 255);
/*     */   }
/*     */ 
/*     */   public static int combinePixels(int rgb1, int rgb2, int op, int extraAlpha, int channelMask) {
/*  93 */     return rgb2 & (channelMask ^ 0xFFFFFFFF) | combinePixels(rgb1 & channelMask, rgb2, op, extraAlpha);
/*     */   }
/*     */ 
/*     */   public static int combinePixels(int rgb1, int rgb2, int op, int extraAlpha) {
/*  97 */     if (op == 0)
/*  98 */       return rgb1;
/*  99 */     int a1 = rgb1 >> 24 & 0xFF;
/* 100 */     int r1 = rgb1 >> 16 & 0xFF;
/* 101 */     int g1 = rgb1 >> 8 & 0xFF;
/* 102 */     int b1 = rgb1 & 0xFF;
/* 103 */     int a2 = rgb2 >> 24 & 0xFF;
/* 104 */     int r2 = rgb2 >> 16 & 0xFF;
/* 105 */     int g2 = rgb2 >> 8 & 0xFF;
/* 106 */     int b2 = rgb2 & 0xFF;
/*     */ 
/* 108 */     switch (op) {
/*     */     case 1:
/* 110 */       break;
/*     */     case 2:
/* 112 */       r1 = Math.min(r1, r2);
/* 113 */       g1 = Math.min(g1, g2);
/* 114 */       b1 = Math.min(b1, b2);
/* 115 */       break;
/*     */     case 3:
/* 117 */       r1 = Math.max(r1, r2);
/* 118 */       g1 = Math.max(g1, g2);
/* 119 */       b1 = Math.max(b1, b2);
/* 120 */       break;
/*     */     case 4:
/* 122 */       r1 = clamp(r1 + r2);
/* 123 */       g1 = clamp(g1 + g2);
/* 124 */       b1 = clamp(b1 + b2);
/* 125 */       break;
/*     */     case 5:
/* 127 */       r1 = clamp(r2 - r1);
/* 128 */       g1 = clamp(g2 - g1);
/* 129 */       b1 = clamp(b2 - b1);
/* 130 */       break;
/*     */     case 6:
/* 132 */       r1 = clamp(Math.abs(r1 - r2));
/* 133 */       g1 = clamp(Math.abs(g1 - g2));
/* 134 */       b1 = clamp(Math.abs(b1 - b2));
/* 135 */       break;
/*     */     case 7:
/* 137 */       r1 = clamp(r1 * r2 / 255);
/* 138 */       g1 = clamp(g1 * g2 / 255);
/* 139 */       b1 = clamp(b1 * b2 / 255);
/* 140 */       break;
/*     */     case 17:
/* 142 */       if ((randomGenerator.nextInt() & 0xFF) <= a1) {
/* 143 */         r1 = r2;
/* 144 */         g1 = g2;
/* 145 */         b1 = b2;
/* 146 */       }break;
/*     */     case 13:
/* 149 */       r1 = (r1 + r2) / 2;
/* 150 */       g1 = (g1 + g2) / 2;
/* 151 */       b1 = (b1 + b2) / 2;
/* 152 */       break;
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/* 157 */       Color.RGBtoHSB(r1, g1, b1, hsb1);
/* 158 */       Color.RGBtoHSB(r2, g2, b2, hsb2);
/* 159 */       switch (op) {
/*     */       case 8:
/* 161 */         hsb2[0] = hsb1[0];
/* 162 */         break;
/*     */       case 9:
/* 164 */         hsb2[1] = hsb1[1];
/* 165 */         break;
/*     */       case 10:
/* 167 */         hsb2[2] = hsb1[2];
/* 168 */         break;
/*     */       case 11:
/* 170 */         hsb2[0] = hsb1[0];
/* 171 */         hsb2[1] = hsb1[1];
/*     */       }
/*     */ 
/* 174 */       rgb1 = Color.HSBtoRGB(hsb2[0], hsb2[1], hsb2[2]);
/* 175 */       r1 = rgb1 >> 16 & 0xFF;
/* 176 */       g1 = rgb1 >> 8 & 0xFF;
/* 177 */       b1 = rgb1 & 0xFF;
/* 178 */       break;
/*     */     case 12:
/* 180 */       r1 = 255 - (255 - r1) * (255 - r2) / 255;
/* 181 */       g1 = 255 - (255 - g1) * (255 - g2) / 255;
/* 182 */       b1 = 255 - (255 - b1) * (255 - b2) / 255;
/* 183 */       break;
/*     */     case 14:
/* 186 */       int s = 255 - (255 - r1) * (255 - r2) / 255;
/* 187 */       int m = r1 * r2 / 255;
/* 188 */       r1 = (s * r1 + m * (255 - r1)) / 255;
/* 189 */       s = 255 - (255 - g1) * (255 - g2) / 255;
/* 190 */       m = g1 * g2 / 255;
/* 191 */       g1 = (s * g1 + m * (255 - g1)) / 255;
/* 192 */       s = 255 - (255 - b1) * (255 - b2) / 255;
/* 193 */       m = b1 * b2 / 255;
/* 194 */       b1 = (s * b1 + m * (255 - b1)) / 255;
/* 195 */       break;
/*     */     case 15:
/* 197 */       r1 = g1 = b1 = 'ÿ';
/* 198 */       break;
/*     */     case 18:
/* 200 */       r1 = clamp(r2 * a1 / 255);
/* 201 */       g1 = clamp(g2 * a1 / 255);
/* 202 */       b1 = clamp(b2 * a1 / 255);
/* 203 */       a1 = clamp(a2 * a1 / 255);
/* 204 */       return a1 << 24 | r1 << 16 | g1 << 8 | b1;
/*     */     case 19:
/* 206 */       a1 = a1 * a2 / 255;
/* 207 */       return a1 << 24 | r2 << 16 | g2 << 8 | b2;
/*     */     case 20:
/* 209 */       int na = 255 - a1;
/* 210 */       return a1 << 24 | na << 16 | na << 8 | na;
/*     */     case 16:
/* 212 */     }if ((extraAlpha != 255) || (a1 != 255)) {
/* 213 */       a1 = a1 * extraAlpha / 255;
/* 214 */       int a3 = (255 - a1) * a2 / 255;
/* 215 */       r1 = clamp((r1 * a1 + r2 * a3) / 255);
/* 216 */       g1 = clamp((g1 * a1 + g2 * a3) / 255);
/* 217 */       b1 = clamp((b1 * a1 + b2 * a3) / 255);
/* 218 */       a1 = clamp(a1 + a3);
/*     */     }
/* 220 */     return a1 << 24 | r1 << 16 | g1 << 8 | b1;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PixelUtils
 * JD-Core Version:    0.6.1
 */