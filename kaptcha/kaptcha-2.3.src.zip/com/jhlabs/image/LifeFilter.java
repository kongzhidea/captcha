/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import com.jhlabs.math.BinaryFunction;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class LifeFilter extends BinaryFilter
/*    */ {
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace)
/*    */   {
/* 31 */     int index = 0;
/* 32 */     int[] outPixels = new int[width * height];
/*    */ 
/* 34 */     for (int y = 0; y < height; y++) {
/* 35 */       for (int x = 0; x < width; x++) {
/* 36 */         int r = 0; int g = 0; int b = 0;
/* 37 */         int pixel = inPixels[(y * width + x)];
/* 38 */         int a = pixel & 0xFF000000;
/* 39 */         int neighbours = 0;
/*    */ 
/* 41 */         for (int row = -1; row <= 1; row++) {
/* 42 */           int iy = y + row;
/*    */ 
/* 44 */           if ((0 <= iy) && (iy < height)) {
/* 45 */             int ioffset = iy * width;
/* 46 */             for (int col = -1; col <= 1; col++) {
/* 47 */               int ix = x + col;
/* 48 */               if (((row != 0) || (col != 0)) && (0 <= ix) && (ix < width)) {
/* 49 */                 int rgb = inPixels[(ioffset + ix)];
/* 50 */                 if (this.blackFunction.isBlack(rgb)) {
/* 51 */                   neighbours++;
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/* 57 */         if (this.blackFunction.isBlack(pixel))
/* 58 */           outPixels[(index++)] = ((neighbours == 2) || (neighbours == 3) ? pixel : -1);
/*    */         else {
/* 60 */           outPixels[(index++)] = (neighbours == 3 ? -16777216 : pixel);
/*    */         }
/*    */       }
/*    */     }
/* 64 */     return outPixels;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 68 */     return "Binary/Life";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.LifeFilter
 * JD-Core Version:    0.6.1
 */