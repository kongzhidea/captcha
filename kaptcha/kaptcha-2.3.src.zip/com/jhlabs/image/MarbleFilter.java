/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.Noise;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class MarbleFilter extends TransformFilter
/*     */ {
/*     */   private float[] sinTable;
/*     */   private float[] cosTable;
/*  29 */   private float xScale = 4.0F;
/*  30 */   private float yScale = 4.0F;
/*  31 */   private float amount = 1.0F;
/*  32 */   private float turbulence = 1.0F;
/*     */ 
/*     */   public MarbleFilter() {
/*  35 */     setEdgeAction(1);
/*     */   }
/*     */ 
/*     */   public void setXScale(float xScale)
/*     */   {
/*  44 */     this.xScale = xScale;
/*     */   }
/*     */ 
/*     */   public float getXScale()
/*     */   {
/*  53 */     return this.xScale;
/*     */   }
/*     */ 
/*     */   public void setYScale(float yScale)
/*     */   {
/*  62 */     this.yScale = yScale;
/*     */   }
/*     */ 
/*     */   public float getYScale()
/*     */   {
/*  71 */     return this.yScale;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  82 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  91 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setTurbulence(float turbulence)
/*     */   {
/* 102 */     this.turbulence = turbulence;
/*     */   }
/*     */ 
/*     */   public float getTurbulence()
/*     */   {
/* 111 */     return this.turbulence;
/*     */   }
/*     */ 
/*     */   private void initialize() {
/* 115 */     this.sinTable = new float[256];
/* 116 */     this.cosTable = new float[256];
/* 117 */     for (int i = 0; i < 256; i++) {
/* 118 */       float angle = 6.283186F * i / 256.0F * this.turbulence;
/* 119 */       this.sinTable[i] = (float)(-this.yScale * Math.sin(angle));
/* 120 */       this.cosTable[i] = (float)(this.yScale * Math.cos(angle));
/*     */     }
/*     */   }
/*     */ 
/*     */   private int displacementMap(int x, int y) {
/* 125 */     return PixelUtils.clamp((int)(127.0F * (1.0F + Noise.noise2(x / this.xScale, y / this.xScale))));
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 129 */     int displacement = displacementMap(x, y);
/* 130 */     out[0] = (x + this.sinTable[displacement]);
/* 131 */     out[1] = (y + this.cosTable[displacement]);
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 135 */     initialize();
/* 136 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 140 */     return "Distort/Marble...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.MarbleFilter
 * JD-Core Version:    0.6.1
 */