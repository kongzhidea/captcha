/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class GlowFilter extends GaussianFilter
/*     */ {
/*  27 */   private float amount = 0.5F;
/*     */ 
/*     */   public GlowFilter() {
/*  30 */     this.radius = 2.0F;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/*  41 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/*  50 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  54 */     int width = src.getWidth();
/*  55 */     int height = src.getHeight();
/*     */ 
/*  57 */     if (dst == null) {
/*  58 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  60 */     int[] inPixels = new int[width * height];
/*  61 */     int[] outPixels = new int[width * height];
/*  62 */     src.getRGB(0, 0, width, height, inPixels, 0, width);
/*     */ 
/*  64 */     if (this.radius > 0.0F) {
/*  65 */       convolveAndTranspose(this.kernel, inPixels, outPixels, width, height, this.alpha, (this.alpha) && (this.premultiplyAlpha), false, CLAMP_EDGES);
/*  66 */       convolveAndTranspose(this.kernel, outPixels, inPixels, height, width, this.alpha, false, (this.alpha) && (this.premultiplyAlpha), CLAMP_EDGES);
/*     */     }
/*     */ 
/*  69 */     src.getRGB(0, 0, width, height, outPixels, 0, width);
/*     */ 
/*  71 */     float a = 4.0F * this.amount;
/*     */ 
/*  73 */     int index = 0;
/*  74 */     for (int y = 0; y < height; y++) {
/*  75 */       for (int x = 0; x < width; x++) {
/*  76 */         int rgb1 = outPixels[index];
/*  77 */         int r1 = rgb1 >> 16 & 0xFF;
/*  78 */         int g1 = rgb1 >> 8 & 0xFF;
/*  79 */         int b1 = rgb1 & 0xFF;
/*     */ 
/*  81 */         int rgb2 = inPixels[index];
/*  82 */         int r2 = rgb2 >> 16 & 0xFF;
/*  83 */         int g2 = rgb2 >> 8 & 0xFF;
/*  84 */         int b2 = rgb2 & 0xFF;
/*     */ 
/*  86 */         r1 = PixelUtils.clamp((int)(r1 + a * r2));
/*  87 */         g1 = PixelUtils.clamp((int)(g1 + a * g2));
/*  88 */         b1 = PixelUtils.clamp((int)(b1 + a * b2));
/*     */ 
/*  90 */         inPixels[index] = (rgb1 & 0xFF000000 | r1 << 16 | g1 << 8 | b1);
/*  91 */         index++;
/*     */       }
/*     */     }
/*     */ 
/*  95 */     dst.setRGB(0, 0, width, height, inPixels, 0, width);
/*  96 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 100 */     return "Blur/Glow...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GlowFilter
 * JD-Core Version:    0.6.1
 */