/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class CurvesFilter extends TransferFilter
/*    */ {
/* 12 */   private Curve[] curves = new Curve[1];
/*    */ 
/*    */   public CurvesFilter() {
/* 15 */     this.curves = new Curve[3];
/* 16 */     this.curves[0] = new Curve();
/* 17 */     this.curves[1] = new Curve();
/* 18 */     this.curves[2] = new Curve();
/*    */   }
/*    */ 
/*    */   protected void initialize() {
/* 22 */     this.initialized = true;
/* 23 */     if (this.curves.length == 1) {
/* 24 */       this.rTable = (this.gTable = this.bTable = this.curves[0].makeTable());
/*    */     } else {
/* 26 */       this.rTable = this.curves[0].makeTable();
/* 27 */       this.gTable = this.curves[1].makeTable();
/* 28 */       this.bTable = this.curves[2].makeTable();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setCurve(Curve curve) {
/* 33 */     this.curves = new Curve[] { curve };
/* 34 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public void setCurves(Curve[] curves) {
/* 38 */     if ((curves == null) || ((curves.length != 1) && (curves.length != 3)))
/* 39 */       throw new IllegalArgumentException("Curves must be length 1 or 3");
/* 40 */     this.curves = curves;
/* 41 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public Curve[] getCurves() {
/* 45 */     return this.curves;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 49 */     return "Colors/Curves...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CurvesFilter
 * JD-Core Version:    0.6.1
 */