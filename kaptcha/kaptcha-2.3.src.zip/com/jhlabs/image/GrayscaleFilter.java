/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class GrayscaleFilter extends PointFilter
/*    */ {
/*    */   public GrayscaleFilter()
/*    */   {
/* 28 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 32 */     int a = rgb & 0xFF000000;
/* 33 */     int r = rgb >> 16 & 0xFF;
/* 34 */     int g = rgb >> 8 & 0xFF;
/* 35 */     int b = rgb & 0xFF;
/*    */ 
/* 37 */     rgb = r * 77 + g * 151 + b * 28 >> 8;
/* 38 */     return a | rgb << 16 | rgb << 8 | rgb;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 42 */     return "Colors/Grayscale";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GrayscaleFilter
 * JD-Core Version:    0.6.1
 */