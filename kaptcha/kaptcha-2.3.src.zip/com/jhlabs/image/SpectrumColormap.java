/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class SpectrumColormap
/*    */   implements Colormap
/*    */ {
/*    */   public int getColor(float v)
/*    */   {
/* 36 */     return Spectrum.wavelengthToRGB(380.0F + 400.0F * ImageMath.clamp(v, 0.0F, 1.0F));
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SpectrumColormap
 * JD-Core Version:    0.6.1
 */