/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class SolarizeFilter extends TransferFilter
/*    */ {
/*    */   protected float transferFunction(float v)
/*    */   {
/* 27 */     return v > 0.5F ? 2.0F * (v - 0.5F) : 2.0F * (0.5F - v);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 31 */     return "Colors/Solarize";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SolarizeFilter
 * JD-Core Version:    0.6.1
 */