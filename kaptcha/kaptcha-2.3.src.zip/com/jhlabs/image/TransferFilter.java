/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public abstract class TransferFilter extends PointFilter
/*    */ {
/*    */   protected int[] rTable;
/*    */   protected int[] gTable;
/*    */   protected int[] bTable;
/* 25 */   protected boolean initialized = false;
/*    */ 
/*    */   public TransferFilter() {
/* 28 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 32 */     int a = rgb & 0xFF000000;
/* 33 */     int r = rgb >> 16 & 0xFF;
/* 34 */     int g = rgb >> 8 & 0xFF;
/* 35 */     int b = rgb & 0xFF;
/* 36 */     r = this.rTable[r];
/* 37 */     g = this.gTable[g];
/* 38 */     b = this.bTable[b];
/* 39 */     return a | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 43 */     if (!this.initialized)
/* 44 */       initialize();
/* 45 */     return super.filter(src, dst);
/*    */   }
/*    */ 
/*    */   protected void initialize() {
/* 49 */     this.initialized = true;
/* 50 */     this.rTable = (this.gTable = this.bTable = makeTable());
/*    */   }
/*    */ 
/*    */   protected int[] makeTable() {
/* 54 */     int[] table = new int[256];
/* 55 */     for (int i = 0; i < 256; i++)
/* 56 */       table[i] = PixelUtils.clamp((int)(255.0F * transferFunction(i / 255.0F)));
/* 57 */     return table;
/*    */   }
/*    */ 
/*    */   protected float transferFunction(float v) {
/* 61 */     return 0.0F;
/*    */   }
/*    */ 
/*    */   public int[] getLUT() {
/* 65 */     if (!this.initialized)
/* 66 */       initialize();
/* 67 */     int[] lut = new int[256];
/* 68 */     for (int i = 0; i < 256; i++) {
/* 69 */       lut[i] = filterRGB(0, 0, i << 24 | i << 16 | i << 8 | i);
/*    */     }
/* 71 */     return lut;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TransferFilter
 * JD-Core Version:    0.6.1
 */