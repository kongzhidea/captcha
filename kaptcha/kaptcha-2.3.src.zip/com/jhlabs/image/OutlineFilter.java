/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import com.jhlabs.math.BinaryFunction;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class OutlineFilter extends BinaryFilter
/*    */ {
/*    */   public OutlineFilter()
/*    */   {
/* 28 */     this.newColor = -1;
/*    */   }
/*    */ 
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 32 */     int index = 0;
/* 33 */     int[] outPixels = new int[width * height];
/*    */ 
/* 35 */     for (int y = 0; y < height; y++) {
/* 36 */       for (int x = 0; x < width; x++) {
/* 37 */         int pixel = inPixels[(y * width + x)];
/* 38 */         if (this.blackFunction.isBlack(pixel)) {
/* 39 */           int neighbours = 0;
/*    */ 
/* 41 */           for (int dy = -1; dy <= 1; dy++) {
/* 42 */             int iy = y + dy;
/*    */ 
/* 44 */             if ((0 <= iy) && (iy < height)) {
/* 45 */               int ioffset = iy * width;
/* 46 */               for (int dx = -1; dx <= 1; dx++) {
/* 47 */                 int ix = x + dx;
/* 48 */                 if (((dy != 0) || (dx != 0)) && (0 <= ix) && (ix < width)) {
/* 49 */                   int rgb = inPixels[(ioffset + ix)];
/* 50 */                   if (this.blackFunction.isBlack(rgb))
/* 51 */                     neighbours++;
/*    */                 } else {
/* 53 */                   neighbours++;
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/* 58 */           if (neighbours == 9)
/* 59 */             pixel = this.newColor;
/*    */         }
/* 61 */         outPixels[(index++)] = pixel;
/*    */       }
/*    */     }
/*    */ 
/* 65 */     return outPixels;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 69 */     return "Binary/Outline...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.OutlineFilter
 * JD-Core Version:    0.6.1
 */