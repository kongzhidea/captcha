/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class SkeletonFilter extends BinaryFilter
/*     */ {
/*  29 */   private static final byte[] skeletonTable = { 0, 0, 0, 1, 0, 0, 1, 3, 0, 0, 3, 1, 1, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 3, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 3, 0, 2, 0, 0, 1, 3, 1, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 3, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0, 1, 0, 0, 0, 0, 2, 2, 0, 0, 2, 0, 0, 0 };
/*     */ 
/*     */   public SkeletonFilter()
/*     */   {
/*  49 */     this.newColor = -1;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  53 */     int[] outPixels = new int[width * height];
/*     */ 
/*  55 */     int count = 0;
/*  56 */     int black = -16777216;
/*  57 */     int white = -1;
/*  58 */     for (int i = 0; i < this.iterations; i++) {
/*  59 */       count = 0;
/*  60 */       for (int pass = 0; pass < 2; pass++) {
/*  61 */         for (int y = 1; y < height - 1; y++) {
/*  62 */           int offset = y * width + 1;
/*  63 */           for (int x = 1; x < width - 1; x++) {
/*  64 */             int pixel = inPixels[offset];
/*  65 */             if (pixel == black) {
/*  66 */               int tableIndex = 0;
/*     */ 
/*  68 */               if (inPixels[(offset - width - 1)] == black)
/*  69 */                 tableIndex |= 1;
/*  70 */               if (inPixels[(offset - width)] == black)
/*  71 */                 tableIndex |= 2;
/*  72 */               if (inPixels[(offset - width + 1)] == black)
/*  73 */                 tableIndex |= 4;
/*  74 */               if (inPixels[(offset + 1)] == black)
/*  75 */                 tableIndex |= 8;
/*  76 */               if (inPixels[(offset + width + 1)] == black)
/*  77 */                 tableIndex |= 16;
/*  78 */               if (inPixels[(offset + width)] == black)
/*  79 */                 tableIndex |= 32;
/*  80 */               if (inPixels[(offset + width - 1)] == black)
/*  81 */                 tableIndex |= 64;
/*  82 */               if (inPixels[(offset - 1)] == black)
/*  83 */                 tableIndex |= 128;
/*  84 */               int code = skeletonTable[tableIndex];
/*  85 */               if (pass == 1) {
/*  86 */                 if ((code == 2) || (code == 3)) {
/*  87 */                   if (this.colormap != null)
/*  88 */                     pixel = this.colormap.getColor(i / this.iterations);
/*     */                   else
/*  90 */                     pixel = this.newColor;
/*  91 */                   count++;
/*     */                 }
/*     */               }
/*  94 */               else if ((code == 1) || (code == 3)) {
/*  95 */                 if (this.colormap != null)
/*  96 */                   pixel = this.colormap.getColor(i / this.iterations);
/*     */                 else
/*  98 */                   pixel = this.newColor;
/*  99 */                 count++;
/*     */               }
/*     */             }
/*     */ 
/* 103 */             outPixels[(offset++)] = pixel;
/*     */           }
/*     */         }
/* 106 */         if (pass == 0) {
/* 107 */           inPixels = outPixels;
/* 108 */           outPixels = new int[width * height];
/*     */         }
/*     */       }
/* 111 */       if (count == 0)
/*     */         break;
/*     */     }
/* 114 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 118 */     return "Binary/Skeletonize...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SkeletonFilter
 * JD-Core Version:    0.6.1
 */