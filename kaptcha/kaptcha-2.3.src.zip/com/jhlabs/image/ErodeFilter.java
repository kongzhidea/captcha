/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.math.BinaryFunction;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class ErodeFilter extends BinaryFilter
/*     */ {
/*  27 */   private int threshold = 2;
/*     */ 
/*     */   public ErodeFilter() {
/*  30 */     this.newColor = -1;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int threshold)
/*     */   {
/*  39 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public int getThreshold()
/*     */   {
/*  48 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  52 */     int[] outPixels = new int[width * height];
/*     */ 
/*  54 */     for (int i = 0; i < this.iterations; i++) {
/*  55 */       int index = 0;
/*     */ 
/*  57 */       if (i > 0) {
/*  58 */         int[] t = inPixels;
/*  59 */         inPixels = outPixels;
/*  60 */         outPixels = t;
/*     */       }
/*  62 */       for (int y = 0; y < height; y++) {
/*  63 */         for (int x = 0; x < width; x++) {
/*  64 */           int pixel = inPixels[(y * width + x)];
/*  65 */           if (this.blackFunction.isBlack(pixel)) {
/*  66 */             int neighbours = 0;
/*     */ 
/*  68 */             for (int dy = -1; dy <= 1; dy++) {
/*  69 */               int iy = y + dy;
/*     */ 
/*  71 */               if ((0 <= iy) && (iy < height)) {
/*  72 */                 int ioffset = iy * width;
/*  73 */                 for (int dx = -1; dx <= 1; dx++) {
/*  74 */                   int ix = x + dx;
/*  75 */                   if (((dy != 0) || (dx != 0)) && (0 <= ix) && (ix < width)) {
/*  76 */                     int rgb = inPixels[(ioffset + ix)];
/*  77 */                     if (!this.blackFunction.isBlack(rgb)) {
/*  78 */                       neighbours++;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*  84 */             if (neighbours >= this.threshold) {
/*  85 */               if (this.colormap != null)
/*  86 */                 pixel = this.colormap.getColor(i / this.iterations);
/*     */               else
/*  88 */                 pixel = this.newColor;
/*     */             }
/*     */           }
/*  91 */           outPixels[(index++)] = pixel;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  96 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 100 */     return "Binary/Erode...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ErodeFilter
 * JD-Core Version:    0.6.1
 */