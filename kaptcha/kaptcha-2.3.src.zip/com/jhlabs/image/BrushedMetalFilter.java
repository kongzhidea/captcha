/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class BrushedMetalFilter
/*     */   implements BufferedImageOp
/*     */ {
/*  29 */   private int radius = 10;
/*  30 */   private float amount = 0.1F;
/*  31 */   private int color = -7829368;
/*  32 */   private float shine = 0.1F;
/*  33 */   private boolean monochrome = true;
/*     */   private Random randomNumbers;
/*     */ 
/*     */   public BrushedMetalFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BrushedMetalFilter(int color, int radius, float amount, boolean monochrome, float shine)
/*     */   {
/*  52 */     this.color = color;
/*  53 */     this.radius = radius;
/*  54 */     this.amount = amount;
/*  55 */     this.monochrome = monochrome;
/*  56 */     this.shine = shine;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  60 */     int width = src.getWidth();
/*  61 */     int height = src.getHeight();
/*     */ 
/*  63 */     if (dst == null) {
/*  64 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  66 */     int[] inPixels = new int[width];
/*  67 */     int[] outPixels = new int[width];
/*     */ 
/*  69 */     this.randomNumbers = new Random(0L);
/*  70 */     int a = this.color & 0xFF000000;
/*  71 */     int r = this.color >> 16 & 0xFF;
/*  72 */     int g = this.color >> 8 & 0xFF;
/*  73 */     int b = this.color & 0xFF;
/*  74 */     for (int y = 0; y < height; y++) {
/*  75 */       for (int x = 0; x < width; x++) {
/*  76 */         int tr = r;
/*  77 */         int tg = g;
/*  78 */         int tb = b;
/*  79 */         if (this.shine != 0.0F) {
/*  80 */           int f = (int)(255.0F * this.shine * Math.sin(x / width * 3.141592653589793D));
/*  81 */           tr += f;
/*  82 */           tg += f;
/*  83 */           tb += f;
/*     */         }
/*  85 */         if (this.monochrome) {
/*  86 */           int n = (int)(255.0F * (2.0F * this.randomNumbers.nextFloat() - 1.0F) * this.amount);
/*  87 */           inPixels[x] = (a | clamp(tr + n) << 16 | clamp(tg + n) << 8 | clamp(tb + n));
/*     */         } else {
/*  89 */           inPixels[x] = (a | random(tr) << 16 | random(tg) << 8 | random(tb));
/*     */         }
/*     */       }
/*     */ 
/*  93 */       if (this.radius != 0) {
/*  94 */         blur(inPixels, outPixels, width, this.radius);
/*  95 */         setRGB(dst, 0, y, width, 1, outPixels);
/*     */       } else {
/*  97 */         setRGB(dst, 0, y, width, 1, inPixels);
/*     */       }
/*     */     }
/*  99 */     return dst;
/*     */   }
/*     */ 
/*     */   private int random(int x) {
/* 103 */     x += (int)(255.0F * (2.0F * this.randomNumbers.nextFloat() - 1.0F) * this.amount);
/* 104 */     if (x < 0)
/* 105 */       x = 0;
/* 106 */     else if (x > 255)
/* 107 */       x = 255;
/* 108 */     return x;
/*     */   }
/*     */ 
/*     */   private static int clamp(int c) {
/* 112 */     if (c < 0)
/* 113 */       return 0;
/* 114 */     if (c > 255)
/* 115 */       return 255;
/* 116 */     return c;
/*     */   }
/*     */ 
/*     */   private static int mod(int a, int b)
/*     */   {
/* 126 */     int n = a / b;
/*     */ 
/* 128 */     a -= n * b;
/* 129 */     if (a < 0)
/* 130 */       return a + b;
/* 131 */     return a;
/*     */   }
/*     */ 
/*     */   private void blur(int[] in, int[] out, int width, int radius) {
/* 135 */     int widthMinus1 = width - 1;
/* 136 */     int r2 = 2 * radius + 1;
/* 137 */     int tr = 0; int tg = 0; int tb = 0;
/*     */ 
/* 139 */     for (int i = -radius; i <= radius; i++) {
/* 140 */       int rgb = in[mod(i, width)];
/* 141 */       tr += (rgb >> 16 & 0xFF);
/* 142 */       tg += (rgb >> 8 & 0xFF);
/* 143 */       tb += (rgb & 0xFF);
/*     */     }
/*     */ 
/* 146 */     for (int x = 0; x < width; x++) {
/* 147 */       out[x] = (0xFF000000 | tr / r2 << 16 | tg / r2 << 8 | tb / r2);
/*     */ 
/* 149 */       int i1 = x + radius + 1;
/* 150 */       if (i1 > widthMinus1)
/* 151 */         i1 = mod(i1, width);
/* 152 */       int i2 = x - radius;
/* 153 */       if (i2 < 0)
/* 154 */         i2 = mod(i2, width);
/* 155 */       int rgb1 = in[i1];
/* 156 */       int rgb2 = in[i2];
/*     */ 
/* 158 */       tr += ((rgb1 & 0xFF0000) - (rgb2 & 0xFF0000) >> 16);
/* 159 */       tg += ((rgb1 & 0xFF00) - (rgb2 & 0xFF00) >> 8);
/* 160 */       tb += (rgb1 & 0xFF) - (rgb2 & 0xFF);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setRadius(int radius)
/*     */   {
/* 172 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public int getRadius()
/*     */   {
/* 181 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/* 192 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/* 201 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public void setShine(float shine)
/*     */   {
/* 212 */     this.shine = shine;
/*     */   }
/*     */ 
/*     */   public float getShine()
/*     */   {
/* 221 */     return this.shine;
/*     */   }
/*     */ 
/*     */   public void setColor(int color)
/*     */   {
/* 230 */     this.color = color;
/*     */   }
/*     */ 
/*     */   public int getColor()
/*     */   {
/* 239 */     return this.color;
/*     */   }
/*     */ 
/*     */   public void setMonochrome(boolean monochrome)
/*     */   {
/* 248 */     this.monochrome = monochrome;
/*     */   }
/*     */ 
/*     */   public boolean getMonochrome()
/*     */   {
/* 257 */     return this.monochrome;
/*     */   }
/*     */ 
/*     */   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
/* 261 */     if (dstCM == null)
/* 262 */       dstCM = src.getColorModel();
/* 263 */     return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
/*     */   }
/*     */ 
/*     */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 267 */     return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/*     */   }
/*     */ 
/*     */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 271 */     if (dstPt == null)
/* 272 */       dstPt = new Point2D.Double();
/* 273 */     dstPt.setLocation(srcPt.getX(), srcPt.getY());
/* 274 */     return dstPt;
/*     */   }
/*     */ 
/*     */   public RenderingHints getRenderingHints() {
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */   private void setRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*     */   {
/* 286 */     int type = image.getType();
/* 287 */     if ((type == 2) || (type == 1))
/* 288 */       image.getRaster().setDataElements(x, y, width, height, pixels);
/*     */     else
/* 290 */       image.setRGB(x, y, width, height, pixels, 0, width);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 294 */     return "Texture/Brushed Metal...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BrushedMetalFilter
 * JD-Core Version:    0.6.1
 */