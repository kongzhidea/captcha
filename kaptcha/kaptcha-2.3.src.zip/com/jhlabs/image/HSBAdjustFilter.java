/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class HSBAdjustFilter extends PointFilter
/*    */ {
/*    */   public float hFactor;
/*    */   public float sFactor;
/*    */   public float bFactor;
/* 25 */   private float[] hsb = new float[3];
/*    */ 
/*    */   public HSBAdjustFilter() {
/* 28 */     this(0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public HSBAdjustFilter(float r, float g, float b) {
/* 32 */     this.hFactor = r;
/* 33 */     this.sFactor = g;
/* 34 */     this.bFactor = b;
/* 35 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public void setHFactor(float hFactor) {
/* 39 */     this.hFactor = hFactor;
/*    */   }
/*    */ 
/*    */   public float getHFactor() {
/* 43 */     return this.hFactor;
/*    */   }
/*    */ 
/*    */   public void setSFactor(float sFactor) {
/* 47 */     this.sFactor = sFactor;
/*    */   }
/*    */ 
/*    */   public float getSFactor() {
/* 51 */     return this.sFactor;
/*    */   }
/*    */ 
/*    */   public void setBFactor(float bFactor) {
/* 55 */     this.bFactor = bFactor;
/*    */   }
/*    */ 
/*    */   public float getBFactor() {
/* 59 */     return this.bFactor; } 
/*    */   public int filterRGB(int x, int y, int rgb) { // Byte code:
/*    */     //   0: iload_3
/*    */     //   1: ldc 8
/*    */     //   3: iand
/*    */     //   4: istore 4
/*    */     //   6: iload_3
/*    */     //   7: bipush 16
/*    */     //   9: ishr
/*    */     //   10: sipush 255
/*    */     //   13: iand
/*    */     //   14: istore 5
/*    */     //   16: iload_3
/*    */     //   17: bipush 8
/*    */     //   19: ishr
/*    */     //   20: sipush 255
/*    */     //   23: iand
/*    */     //   24: istore 6
/*    */     //   26: iload_3
/*    */     //   27: sipush 255
/*    */     //   30: iand
/*    */     //   31: istore 7
/*    */     //   33: iload 5
/*    */     //   35: iload 6
/*    */     //   37: iload 7
/*    */     //   39: aload_0
/*    */     //   40: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   43: invokestatic 9	java/awt/Color:RGBtoHSB	(III[F)[F
/*    */     //   46: pop
/*    */     //   47: aload_0
/*    */     //   48: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   51: iconst_0
/*    */     //   52: dup2
/*    */     //   53: faload
/*    */     //   54: aload_0
/*    */     //   55: getfield 4	com/jhlabs/image/HSBAdjustFilter:hFactor	F
/*    */     //   58: fadd
/*    */     //   59: fastore
/*    */     //   60: aload_0
/*    */     //   61: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   64: iconst_0
/*    */     //   65: faload
/*    */     //   66: fconst_0
/*    */     //   67: fcmpg
/*    */     //   68: ifge +20 -> 88
/*    */     //   71: aload_0
/*    */     //   72: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   75: iconst_0
/*    */     //   76: dup2
/*    */     //   77: faload
/*    */     //   78: f2d
/*    */     //   79: ldc2_w 10
/*    */     //   82: dadd
/*    */     //   83: d2f
/*    */     //   84: fastore
/*    */     //   85: goto -25 -> 60
/*    */     //   88: aload_0
/*    */     //   89: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   92: iconst_1
/*    */     //   93: dup2
/*    */     //   94: faload
/*    */     //   95: aload_0
/*    */     //   96: getfield 5	com/jhlabs/image/HSBAdjustFilter:sFactor	F
/*    */     //   99: fadd
/*    */     //   100: fastore
/*    */     //   101: aload_0
/*    */     //   102: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   105: iconst_1
/*    */     //   106: faload
/*    */     //   107: fconst_0
/*    */     //   108: fcmpg
/*    */     //   109: ifge +13 -> 122
/*    */     //   112: aload_0
/*    */     //   113: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   116: iconst_1
/*    */     //   117: fconst_0
/*    */     //   118: fastore
/*    */     //   119: goto +22 -> 141
/*    */     //   122: aload_0
/*    */     //   123: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   126: iconst_1
/*    */     //   127: faload
/*    */     //   128: f2d
/*    */     //   129: dconst_1
/*    */     //   130: dcmpl
/*    */     //   131: ifle +10 -> 141
/*    */     //   134: aload_0
/*    */     //   135: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   138: iconst_1
/*    */     //   139: fconst_1
/*    */     //   140: fastore
/*    */     //   141: aload_0
/*    */     //   142: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   145: iconst_2
/*    */     //   146: dup2
/*    */     //   147: faload
/*    */     //   148: aload_0
/*    */     //   149: getfield 6	com/jhlabs/image/HSBAdjustFilter:bFactor	F
/*    */     //   152: fadd
/*    */     //   153: fastore
/*    */     //   154: aload_0
/*    */     //   155: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   158: iconst_2
/*    */     //   159: faload
/*    */     //   160: fconst_0
/*    */     //   161: fcmpg
/*    */     //   162: ifge +13 -> 175
/*    */     //   165: aload_0
/*    */     //   166: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   169: iconst_2
/*    */     //   170: fconst_0
/*    */     //   171: fastore
/*    */     //   172: goto +22 -> 194
/*    */     //   175: aload_0
/*    */     //   176: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   179: iconst_2
/*    */     //   180: faload
/*    */     //   181: f2d
/*    */     //   182: dconst_1
/*    */     //   183: dcmpl
/*    */     //   184: ifle +10 -> 194
/*    */     //   187: aload_0
/*    */     //   188: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   191: iconst_2
/*    */     //   192: fconst_1
/*    */     //   193: fastore
/*    */     //   194: aload_0
/*    */     //   195: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   198: iconst_0
/*    */     //   199: faload
/*    */     //   200: aload_0
/*    */     //   201: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   204: iconst_1
/*    */     //   205: faload
/*    */     //   206: aload_0
/*    */     //   207: getfield 3	com/jhlabs/image/HSBAdjustFilter:hsb	[F
/*    */     //   210: iconst_2
/*    */     //   211: faload
/*    */     //   212: invokestatic 12	java/awt/Color:HSBtoRGB	(FFF)I
/*    */     //   215: istore_3
/*    */     //   216: iload 4
/*    */     //   218: iload_3
/*    */     //   219: ldc 13
/*    */     //   221: iand
/*    */     //   222: ior
/*    */     //   223: ireturn } 
/* 86 */   public String toString() { return "Colors/Adjust HSB..."; }
/*    */ 
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.HSBAdjustFilter
 * JD-Core Version:    0.6.1
 */