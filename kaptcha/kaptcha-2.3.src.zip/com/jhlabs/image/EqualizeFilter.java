/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class EqualizeFilter extends WholeImageFilter
/*    */ {
/*    */   private int[][] lut;
/*    */ 
/*    */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace)
/*    */   {
/* 33 */     Histogram histogram = new Histogram(inPixels, width, height, 0, width);
/*    */ 
/* 37 */     if (histogram.getNumSamples() > 0) {
/* 38 */       float scale = 255.0F / histogram.getNumSamples();
/* 39 */       this.lut = new int[3][256];
/* 40 */       for (int i = 0; i < 3; i++) {
/* 41 */         this.lut[i][0] = histogram.getFrequency(i, 0);
/* 42 */         for (int j = 1; j < 256; j++)
/* 43 */           this.lut[i][j] = (this.lut[i][(j - 1)] + histogram.getFrequency(i, j));
/* 44 */         for (j = 0; j < 256; j++)
/* 45 */           this.lut[i][j] = Math.round(this.lut[i][j] * scale);
/*    */       }
/*    */     } else {
/* 48 */       this.lut = ((int[][])null);
/*    */     }
/* 50 */     int i = 0;
/* 51 */     for (int y = 0; y < height; y++)
/* 52 */       for (int x = 0; x < width; x++) {
/* 53 */         inPixels[i] = filterRGB(x, y, inPixels[i]);
/* 54 */         i++;
/*    */       }
/* 56 */     this.lut = ((int[][])null);
/*    */ 
/* 58 */     return inPixels;
/*    */   }
/*    */ 
/*    */   private int filterRGB(int x, int y, int rgb) {
/* 62 */     if (this.lut != null) {
/* 63 */       int a = rgb & 0xFF000000;
/* 64 */       int r = this.lut[0][(rgb >> 16 & 0xFF)];
/* 65 */       int g = this.lut[1][(rgb >> 8 & 0xFF)];
/* 66 */       int b = this.lut[2][(rgb & 0xFF)];
/*    */ 
/* 68 */       return a | r << 16 | g << 8 | b;
/*    */     }
/* 70 */     return rgb;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 74 */     return "Colors/Equalize";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.EqualizeFilter
 * JD-Core Version:    0.6.1
 */