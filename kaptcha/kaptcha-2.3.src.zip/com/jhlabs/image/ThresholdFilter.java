/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class ThresholdFilter extends PointFilter
/*     */ {
/*     */   private int lowerThreshold;
/*     */   private int upperThreshold;
/*  28 */   private int white = 16777215;
/*  29 */   private int black = 0;
/*     */ 
/*     */   public ThresholdFilter()
/*     */   {
/*  35 */     this(127);
/*     */   }
/*     */ 
/*     */   public ThresholdFilter(int t)
/*     */   {
/*  43 */     setLowerThreshold(t);
/*  44 */     setUpperThreshold(t);
/*     */   }
/*     */ 
/*     */   public void setLowerThreshold(int lowerThreshold)
/*     */   {
/*  53 */     this.lowerThreshold = lowerThreshold;
/*     */   }
/*     */ 
/*     */   public int getLowerThreshold()
/*     */   {
/*  62 */     return this.lowerThreshold;
/*     */   }
/*     */ 
/*     */   public void setUpperThreshold(int upperThreshold)
/*     */   {
/*  71 */     this.upperThreshold = upperThreshold;
/*     */   }
/*     */ 
/*     */   public int getUpperThreshold()
/*     */   {
/*  80 */     return this.upperThreshold;
/*     */   }
/*     */ 
/*     */   public void setWhite(int white)
/*     */   {
/*  89 */     this.white = white;
/*     */   }
/*     */ 
/*     */   public int getWhite()
/*     */   {
/*  98 */     return this.white;
/*     */   }
/*     */ 
/*     */   public void setBlack(int black)
/*     */   {
/* 107 */     this.black = black;
/*     */   }
/*     */ 
/*     */   public int getBlack()
/*     */   {
/* 116 */     return this.black;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 120 */     int v = PixelUtils.brightness(rgb);
/* 121 */     float f = ImageMath.smoothStep(this.lowerThreshold, this.upperThreshold, v);
/* 122 */     return rgb & 0xFF000000 | ImageMath.mixColors(f, this.black, this.white) & 0xFFFFFF;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 126 */     return "Stylize/Threshold...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ThresholdFilter
 * JD-Core Version:    0.6.1
 */