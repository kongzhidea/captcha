/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class RGBAdjustFilter extends PointFilter
/*    */ {
/*    */   public float rFactor;
/*    */   public float gFactor;
/*    */   public float bFactor;
/*    */ 
/*    */   public RGBAdjustFilter()
/*    */   {
/* 27 */     this(0.0F, 0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */   public RGBAdjustFilter(float r, float g, float b) {
/* 31 */     this.rFactor = (1.0F + r);
/* 32 */     this.gFactor = (1.0F + g);
/* 33 */     this.bFactor = (1.0F + b);
/* 34 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public void setRFactor(float rFactor) {
/* 38 */     this.rFactor = (1.0F + rFactor);
/*    */   }
/*    */ 
/*    */   public float getRFactor() {
/* 42 */     return this.rFactor - 1.0F;
/*    */   }
/*    */ 
/*    */   public void setGFactor(float gFactor) {
/* 46 */     this.gFactor = (1.0F + gFactor);
/*    */   }
/*    */ 
/*    */   public float getGFactor() {
/* 50 */     return this.gFactor - 1.0F;
/*    */   }
/*    */ 
/*    */   public void setBFactor(float bFactor) {
/* 54 */     this.bFactor = (1.0F + bFactor);
/*    */   }
/*    */ 
/*    */   public float getBFactor() {
/* 58 */     return this.bFactor - 1.0F;
/*    */   }
/*    */ 
/*    */   public int[] getLUT() {
/* 62 */     int[] lut = new int[256];
/* 63 */     for (int i = 0; i < 256; i++) {
/* 64 */       lut[i] = filterRGB(0, 0, i << 24 | i << 16 | i << 8 | i);
/*    */     }
/* 66 */     return lut;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 70 */     int a = rgb & 0xFF000000;
/* 71 */     int r = rgb >> 16 & 0xFF;
/* 72 */     int g = rgb >> 8 & 0xFF;
/* 73 */     int b = rgb & 0xFF;
/* 74 */     r = PixelUtils.clamp((int)(r * this.rFactor));
/* 75 */     g = PixelUtils.clamp((int)(g * this.gFactor));
/* 76 */     b = PixelUtils.clamp((int)(b * this.bFactor));
/* 77 */     return a | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 81 */     return "Colors/Adjust RGB...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RGBAdjustFilter
 * JD-Core Version:    0.6.1
 */