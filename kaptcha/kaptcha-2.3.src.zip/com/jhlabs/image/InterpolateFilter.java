/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class InterpolateFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private BufferedImage destination;
/*     */   private float interpolation;
/*     */ 
/*     */   public void setDestination(BufferedImage destination)
/*     */   {
/*  41 */     this.destination = destination;
/*     */   }
/*     */ 
/*     */   public BufferedImage getDestination()
/*     */   {
/*  50 */     return this.destination;
/*     */   }
/*     */ 
/*     */   public void setInterpolation(float interpolation)
/*     */   {
/*  59 */     this.interpolation = interpolation;
/*     */   }
/*     */ 
/*     */   public float getInterpolation()
/*     */   {
/*  68 */     return this.interpolation;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  72 */     int width = src.getWidth();
/*  73 */     int height = src.getHeight();
/*  74 */     int type = src.getType();
/*  75 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/*  77 */     if (dst == null)
/*  78 */       dst = createCompatibleDestImage(src, null);
/*  79 */     WritableRaster dstRaster = dst.getRaster();
/*     */ 
/*  81 */     if (this.destination != null) {
/*  82 */       width = Math.min(width, this.destination.getWidth());
/*  83 */       height = Math.min(height, this.destination.getWidth());
/*  84 */       int[] pixels1 = null;
/*  85 */       int[] pixels2 = null;
/*     */ 
/*  87 */       for (int y = 0; y < height; y++) {
/*  88 */         pixels1 = getRGB(src, 0, y, width, 1, pixels1);
/*  89 */         pixels2 = getRGB(this.destination, 0, y, width, 1, pixels2);
/*  90 */         for (int x = 0; x < width; x++) {
/*  91 */           int rgb1 = pixels1[x];
/*  92 */           int rgb2 = pixels2[x];
/*  93 */           int a1 = rgb1 >> 24 & 0xFF;
/*  94 */           int r1 = rgb1 >> 16 & 0xFF;
/*  95 */           int g1 = rgb1 >> 8 & 0xFF;
/*  96 */           int b1 = rgb1 & 0xFF;
/*  97 */           int a2 = rgb2 >> 24 & 0xFF;
/*  98 */           int r2 = rgb2 >> 16 & 0xFF;
/*  99 */           int g2 = rgb2 >> 8 & 0xFF;
/* 100 */           int b2 = rgb2 & 0xFF;
/* 101 */           r1 = PixelUtils.clamp(ImageMath.lerp(this.interpolation, r1, r2));
/* 102 */           g1 = PixelUtils.clamp(ImageMath.lerp(this.interpolation, g1, g2));
/* 103 */           b1 = PixelUtils.clamp(ImageMath.lerp(this.interpolation, b1, b2));
/* 104 */           pixels1[x] = (a1 << 24 | r1 << 16 | g1 << 8 | b1);
/*     */         }
/* 106 */         setRGB(dst, 0, y, width, 1, pixels1);
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 114 */     return "Effects/Interpolate...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.InterpolateFilter
 * JD-Core Version:    0.6.1
 */