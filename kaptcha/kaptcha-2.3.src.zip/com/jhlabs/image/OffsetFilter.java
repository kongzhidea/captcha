/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class OffsetFilter extends TransformFilter
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   private int xOffset;
/*    */   private int yOffset;
/*    */   private boolean wrap;
/*    */ 
/*    */   public OffsetFilter()
/*    */   {
/* 29 */     this(0, 0, true);
/*    */   }
/*    */ 
/*    */   public OffsetFilter(int xOffset, int yOffset, boolean wrap) {
/* 33 */     this.xOffset = xOffset;
/* 34 */     this.yOffset = yOffset;
/* 35 */     this.wrap = wrap;
/* 36 */     setEdgeAction(0);
/*    */   }
/*    */ 
/*    */   public void setXOffset(int xOffset) {
/* 40 */     this.xOffset = xOffset;
/*    */   }
/*    */ 
/*    */   public int getXOffset() {
/* 44 */     return this.xOffset;
/*    */   }
/*    */ 
/*    */   public void setYOffset(int yOffset) {
/* 48 */     this.yOffset = yOffset;
/*    */   }
/*    */ 
/*    */   public int getYOffset() {
/* 52 */     return this.yOffset;
/*    */   }
/*    */ 
/*    */   public void setWrap(boolean wrap) {
/* 56 */     this.wrap = wrap;
/*    */   }
/*    */ 
/*    */   public boolean getWrap() {
/* 60 */     return this.wrap;
/*    */   }
/*    */ 
/*    */   protected void transformInverse(int x, int y, float[] out) {
/* 64 */     if (this.wrap) {
/* 65 */       out[0] = (x + this.width - this.xOffset) % this.width;
/* 66 */       out[1] = (y + this.height - this.yOffset) % this.height;
/*    */     } else {
/* 68 */       out[0] = x - this.xOffset;
/* 69 */       out[1] = y - this.yOffset;
/*    */     }
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 74 */     this.width = src.getWidth();
/* 75 */     this.height = src.getHeight();
/* 76 */     if (this.wrap) {
/* 77 */       while (this.xOffset < 0)
/* 78 */         this.xOffset += this.width;
/* 79 */       while (this.yOffset < 0)
/* 80 */         this.yOffset += this.height;
/* 81 */       this.xOffset %= this.width;
/* 82 */       this.yOffset %= this.height;
/*    */     }
/* 84 */     return super.filter(src, dst);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 88 */     return "Distort/Offset...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.OffsetFilter
 * JD-Core Version:    0.6.1
 */