/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class CircleFilter extends TransformFilter
/*     */ {
/*  28 */   private float radius = 10.0F;
/*  29 */   private float height = 20.0F;
/*  30 */   private float angle = 0.0F;
/*  31 */   private float spreadAngle = 3.141593F;
/*  32 */   private float centreX = 0.5F;
/*  33 */   private float centreY = 0.5F;
/*     */   private float icentreX;
/*     */   private float icentreY;
/*     */   private float iWidth;
/*     */   private float iHeight;
/*     */ 
/*     */   public CircleFilter()
/*     */   {
/*  44 */     setEdgeAction(0);
/*     */   }
/*     */ 
/*     */   public void setHeight(float height)
/*     */   {
/*  53 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public float getHeight()
/*     */   {
/*  62 */     return this.height;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  72 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  81 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setSpreadAngle(float spreadAngle)
/*     */   {
/*  91 */     this.spreadAngle = spreadAngle;
/*     */   }
/*     */ 
/*     */   public float getSpreadAngle()
/*     */   {
/* 101 */     return this.spreadAngle;
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/* 111 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 120 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/* 129 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/* 138 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/* 147 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/* 156 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 165 */     this.centreX = (float)centre.getX();
/* 166 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 175 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 179 */     this.iWidth = src.getWidth();
/* 180 */     this.iHeight = src.getHeight();
/* 181 */     this.icentreX = (this.iWidth * this.centreX);
/* 182 */     this.icentreY = (this.iHeight * this.centreY);
/* 183 */     this.iWidth -= 1.0F;
/* 184 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 188 */     float dx = x - this.icentreX;
/* 189 */     float dy = y - this.icentreY;
/* 190 */     float theta = (float)Math.atan2(-dy, -dx) + this.angle;
/* 191 */     float r = (float)Math.sqrt(dx * dx + dy * dy);
/*     */ 
/* 193 */     theta = ImageMath.mod(theta, 6.283186F);
/*     */ 
/* 195 */     out[0] = (this.iWidth * theta / (this.spreadAngle + 1.0E-005F));
/* 196 */     out[1] = (this.iHeight * (1.0F - (r - this.radius) / (this.height + 1.0E-005F)));
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 200 */     return "Distort/Circle...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.CircleFilter
 * JD-Core Version:    0.6.1
 */