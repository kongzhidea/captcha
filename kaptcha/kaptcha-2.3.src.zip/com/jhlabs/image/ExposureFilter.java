/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class ExposureFilter extends TransferFilter
/*    */ {
/* 27 */   private float exposure = 1.0F;
/*    */ 
/*    */   protected float transferFunction(float f) {
/* 30 */     return 1.0F - (float)Math.exp(-f * this.exposure);
/*    */   }
/*    */ 
/*    */   public void setExposure(float exposure)
/*    */   {
/* 41 */     this.exposure = exposure;
/* 42 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getExposure()
/*    */   {
/* 51 */     return this.exposure;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 55 */     return "Colors/Exposure...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ExposureFilter
 * JD-Core Version:    0.6.1
 */