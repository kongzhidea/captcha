/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class FadeFilter extends PointFilter
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*  26 */   private float angle = 0.0F;
/*  27 */   private float fadeStart = 1.0F;
/*  28 */   private float fadeWidth = 10.0F;
/*     */   private int sides;
/*     */   private boolean invert;
/*  31 */   private float m00 = 1.0F;
/*  32 */   private float m01 = 0.0F;
/*  33 */   private float m10 = 0.0F;
/*  34 */   private float m11 = 1.0F;
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  43 */     this.angle = angle;
/*  44 */     float cos = (float)Math.cos(angle);
/*  45 */     float sin = (float)Math.sin(angle);
/*  46 */     this.m00 = cos;
/*  47 */     this.m01 = sin;
/*  48 */     this.m10 = (-sin);
/*  49 */     this.m11 = cos;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  58 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setSides(int sides) {
/*  62 */     this.sides = sides;
/*     */   }
/*     */ 
/*     */   public int getSides() {
/*  66 */     return this.sides;
/*     */   }
/*     */ 
/*     */   public void setFadeStart(float fadeStart) {
/*  70 */     this.fadeStart = fadeStart;
/*     */   }
/*     */ 
/*     */   public float getFadeStart() {
/*  74 */     return this.fadeStart;
/*     */   }
/*     */ 
/*     */   public void setFadeWidth(float fadeWidth) {
/*  78 */     this.fadeWidth = fadeWidth;
/*     */   }
/*     */ 
/*     */   public float getFadeWidth() {
/*  82 */     return this.fadeWidth;
/*     */   }
/*     */ 
/*     */   public void setInvert(boolean invert) {
/*  86 */     this.invert = invert;
/*     */   }
/*     */ 
/*     */   public boolean getInvert() {
/*  90 */     return this.invert;
/*     */   }
/*     */ 
/*     */   public void setDimensions(int width, int height) {
/*  94 */     this.width = width;
/*  95 */     this.height = height;
/*  96 */     super.setDimensions(width, height);
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 100 */     float nx = this.m00 * x + this.m01 * y;
/* 101 */     float ny = this.m10 * x + this.m11 * y;
/* 102 */     if (this.sides == 2)
/* 103 */       nx = (float)Math.sqrt(nx * nx + ny * ny);
/* 104 */     else if (this.sides == 3)
/* 105 */       nx = ImageMath.mod(nx, 16.0F);
/* 106 */     else if (this.sides == 4)
/* 107 */       nx = symmetry(nx, 16.0F);
/* 108 */     int alpha = (int)(ImageMath.smoothStep(this.fadeStart, this.fadeStart + this.fadeWidth, nx) * 255.0F);
/* 109 */     if (this.invert)
/* 110 */       alpha = 255 - alpha;
/* 111 */     return alpha << 24 | rgb & 0xFFFFFF;
/*     */   }
/*     */ 
/*     */   public float symmetry(float x, float b)
/*     */   {
/* 122 */     x = ImageMath.mod(x, 2.0F * b);
/* 123 */     if (x > b)
/* 124 */       return 2.0F * b - x;
/* 125 */     return x;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 140 */     return "Fade...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.FadeFilter
 * JD-Core Version:    0.6.1
 */