package com.jhlabs.image;

public abstract interface Colormap
{
  public abstract int getColor(float paramFloat);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Colormap
 * JD-Core Version:    0.6.1
 */