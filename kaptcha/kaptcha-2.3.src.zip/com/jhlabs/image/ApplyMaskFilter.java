/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public class ApplyMaskFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private BufferedImage destination;
/*     */   private BufferedImage maskImage;
/*     */ 
/*     */   public ApplyMaskFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ApplyMaskFilter(BufferedImage maskImage, BufferedImage destination)
/*     */   {
/*  43 */     this.maskImage = maskImage;
/*  44 */     this.destination = destination;
/*     */   }
/*     */ 
/*     */   public void setDestination(BufferedImage destination)
/*     */   {
/*  53 */     this.destination = destination;
/*     */   }
/*     */ 
/*     */   public BufferedImage getDestination()
/*     */   {
/*  62 */     return this.destination;
/*     */   }
/*     */ 
/*     */   public void setMaskImage(BufferedImage maskImage)
/*     */   {
/*  71 */     this.maskImage = maskImage;
/*     */   }
/*     */ 
/*     */   public BufferedImage getMaskImage()
/*     */   {
/*  80 */     return this.maskImage;
/*     */   }
/*     */ 
/*     */   public static void composeThroughMask(Raster src, WritableRaster dst, Raster sel)
/*     */   {
/*  90 */     int x = src.getMinX();
/*  91 */     int y = src.getMinY();
/*  92 */     int w = src.getWidth();
/*  93 */     int h = src.getHeight();
/*     */ 
/*  95 */     int[] srcRGB = null;
/*  96 */     int[] selRGB = null;
/*  97 */     int[] dstRGB = null;
/*     */ 
/*  99 */     for (int i = 0; i < h; i++) {
/* 100 */       srcRGB = src.getPixels(x, y, w, 1, srcRGB);
/* 101 */       selRGB = sel.getPixels(x, y, w, 1, selRGB);
/* 102 */       dstRGB = dst.getPixels(x, y, w, 1, dstRGB);
/*     */ 
/* 104 */       int k = x;
/* 105 */       for (int j = 0; j < w; j++) {
/* 106 */         int sr = srcRGB[k];
/* 107 */         int dir = dstRGB[k];
/* 108 */         int sg = srcRGB[(k + 1)];
/* 109 */         int dig = dstRGB[(k + 1)];
/* 110 */         int sb = srcRGB[(k + 2)];
/* 111 */         int dib = dstRGB[(k + 2)];
/* 112 */         int sa = srcRGB[(k + 3)];
/* 113 */         int dia = dstRGB[(k + 3)];
/*     */ 
/* 115 */         float a = selRGB[(k + 3)] / 255.0F;
/* 116 */         float ac = 1.0F - a;
/*     */ 
/* 118 */         dstRGB[k] = (int)(a * sr + ac * dir);
/* 119 */         dstRGB[(k + 1)] = (int)(a * sg + ac * dig);
/* 120 */         dstRGB[(k + 2)] = (int)(a * sb + ac * dib);
/* 121 */         dstRGB[(k + 3)] = (int)(a * sa + ac * dia);
/* 122 */         k += 4;
/*     */       }
/*     */ 
/* 125 */       dst.setPixels(x, y, w, 1, dstRGB);
/* 126 */       y++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 131 */     int width = src.getWidth();
/* 132 */     int height = src.getHeight();
/* 133 */     int type = src.getType();
/* 134 */     WritableRaster srcRaster = src.getRaster();
/*     */ 
/* 136 */     if (dst == null)
/* 137 */       dst = createCompatibleDestImage(src, null);
/* 138 */     WritableRaster dstRaster = dst.getRaster();
/*     */ 
/* 140 */     if ((this.destination != null) && (this.maskImage != null)) {
/* 141 */       composeThroughMask(src.getRaster(), dst.getRaster(), this.maskImage.getRaster());
/*     */     }
/* 143 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 147 */     return "Keying/Key...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ApplyMaskFilter
 * JD-Core Version:    0.6.1
 */