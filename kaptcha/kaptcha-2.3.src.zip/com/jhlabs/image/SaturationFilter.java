/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class SaturationFilter extends PointFilter
/*    */ {
/* 16 */   public float amount = 1.0F;
/*    */ 
/*    */   public SaturationFilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SaturationFilter(float amount)
/*    */   {
/* 29 */     this.amount = amount;
/* 30 */     this.canFilterIndexColorModel = true;
/*    */   }
/*    */ 
/*    */   public void setAmount(float amount)
/*    */   {
/* 39 */     this.amount = amount;
/*    */   }
/*    */ 
/*    */   public float getAmount()
/*    */   {
/* 47 */     return this.amount;
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 51 */     if (this.amount != 1.0F) {
/* 52 */       int a = rgb & 0xFF000000;
/* 53 */       int r = rgb >> 16 & 0xFF;
/* 54 */       int g = rgb >> 8 & 0xFF;
/* 55 */       int b = rgb & 0xFF;
/* 56 */       int v = (r + g + b) / 3;
/* 57 */       r = PixelUtils.clamp((int)(v + this.amount * r - v));
/* 58 */       g = PixelUtils.clamp((int)(v + this.amount * g - v));
/* 59 */       b = PixelUtils.clamp((int)(v + this.amount * b - v));
/* 60 */       return a | r << 16 | g << 8 | b;
/*    */     }
/* 62 */     return rgb;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 66 */     return "Colors/Saturation...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SaturationFilter
 * JD-Core Version:    0.6.1
 */