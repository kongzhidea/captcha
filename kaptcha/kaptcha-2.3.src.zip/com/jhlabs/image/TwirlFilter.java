/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class TwirlFilter extends TransformFilter
/*     */ {
/*  30 */   private float angle = 0.0F;
/*  31 */   private float centreX = 0.5F;
/*  32 */   private float centreY = 0.5F;
/*  33 */   private float radius = 100.0F;
/*     */ 
/*  35 */   private float radius2 = 0.0F;
/*     */   private float icentreX;
/*     */   private float icentreY;
/*     */ 
/*     */   public TwirlFilter()
/*     */   {
/*  43 */     setEdgeAction(1);
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  52 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  61 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/*  70 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/*  79 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/*  88 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/*  97 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 106 */     this.centreX = (float)centre.getX();
/* 107 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 116 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/* 126 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 135 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 139 */     this.icentreX = (src.getWidth() * this.centreX);
/* 140 */     this.icentreY = (src.getHeight() * this.centreY);
/* 141 */     if (this.radius == 0.0F)
/* 142 */       this.radius = Math.min(this.icentreX, this.icentreY);
/* 143 */     this.radius2 = (this.radius * this.radius);
/* 144 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 148 */     float dx = x - this.icentreX;
/* 149 */     float dy = y - this.icentreY;
/* 150 */     float distance = dx * dx + dy * dy;
/* 151 */     if (distance > this.radius2) {
/* 152 */       out[0] = x;
/* 153 */       out[1] = y;
/*     */     } else {
/* 155 */       distance = (float)Math.sqrt(distance);
/* 156 */       float a = (float)Math.atan2(dy, dx) + this.angle * (this.radius - distance) / this.radius;
/* 157 */       out[0] = (this.icentreX + distance * (float)Math.cos(a));
/* 158 */       out[1] = (this.icentreY + distance * (float)Math.sin(a));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 163 */     return "Distort/Twirl...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.TwirlFilter
 * JD-Core Version:    0.6.1
 */