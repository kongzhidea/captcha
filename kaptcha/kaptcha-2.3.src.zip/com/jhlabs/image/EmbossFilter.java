/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class EmbossFilter extends WholeImageFilter
/*     */ {
/*     */   private static final float pixelScale = 255.89999F;
/*  29 */   private float azimuth = 2.356195F; private float elevation = 0.5235988F;
/*  30 */   private boolean emboss = false;
/*  31 */   private float width45 = 3.0F;
/*     */ 
/*     */   public void setAzimuth(float azimuth)
/*     */   {
/*  37 */     this.azimuth = azimuth;
/*     */   }
/*     */ 
/*     */   public float getAzimuth() {
/*  41 */     return this.azimuth;
/*     */   }
/*     */ 
/*     */   public void setElevation(float elevation) {
/*  45 */     this.elevation = elevation;
/*     */   }
/*     */ 
/*     */   public float getElevation() {
/*  49 */     return this.elevation;
/*     */   }
/*     */ 
/*     */   public void setBumpHeight(float bumpHeight) {
/*  53 */     this.width45 = (3.0F * bumpHeight);
/*     */   }
/*     */ 
/*     */   public float getBumpHeight() {
/*  57 */     return this.width45 / 3.0F;
/*     */   }
/*     */ 
/*     */   public void setEmboss(boolean emboss) {
/*  61 */     this.emboss = emboss;
/*     */   }
/*     */ 
/*     */   public boolean getEmboss() {
/*  65 */     return this.emboss;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/*  69 */     int index = 0;
/*  70 */     int[] outPixels = new int[width * height];
/*     */ 
/*  75 */     int bumpMapWidth = width;
/*  76 */     int bumpMapHeight = height;
/*  77 */     int[] bumpPixels = new int[bumpMapWidth * bumpMapHeight];
/*  78 */     for (int i = 0; i < inPixels.length; i++) {
/*  79 */       bumpPixels[i] = PixelUtils.brightness(inPixels[i]);
/*     */     }
/*     */ 
/*  84 */     int Lx = (int)(Math.cos(this.azimuth) * Math.cos(this.elevation) * 255.89999389648437D);
/*  85 */     int Ly = (int)(Math.sin(this.azimuth) * Math.cos(this.elevation) * 255.89999389648437D);
/*  86 */     int Lz = (int)(Math.sin(this.elevation) * 255.89999389648437D);
/*     */ 
/*  88 */     int Nz = (int)(1530.0F / this.width45);
/*  89 */     int Nz2 = Nz * Nz;
/*  90 */     int NzLz = Nz * Lz;
/*     */ 
/*  92 */     int background = Lz;
/*     */ 
/*  94 */     int bumpIndex = 0;
/*     */ 
/*  96 */     for (int y = 0; y < height; bumpIndex += bumpMapWidth) {
/*  97 */       int s1 = bumpIndex;
/*  98 */       int s2 = s1 + bumpMapWidth;
/*  99 */       int s3 = s2 + bumpMapWidth;
/*     */ 
/* 101 */       for (int x = 0; x < width; s3++)
/*     */       {
/*     */         int shade;
/*     */         int shade;
/* 102 */         if ((y != 0) && (y < height - 2) && (x != 0) && (x < width - 2)) {
/* 103 */           int Nx = bumpPixels[(s1 - 1)] + bumpPixels[(s2 - 1)] + bumpPixels[(s3 - 1)] - bumpPixels[(s1 + 1)] - bumpPixels[(s2 + 1)] - bumpPixels[(s3 + 1)];
/* 104 */           int Ny = bumpPixels[(s3 - 1)] + bumpPixels[s3] + bumpPixels[(s3 + 1)] - bumpPixels[(s1 - 1)] - bumpPixels[s1] - bumpPixels[(s1 + 1)];
/*     */           int shade;
/* 106 */           if ((Nx == 0) && (Ny == 0)) {
/* 107 */             shade = background;
/*     */           }
/*     */           else
/*     */           {
/*     */             int NdotL;
/*     */             int shade;
/* 108 */             if ((NdotL = Nx * Lx + Ny * Ly + NzLz) < 0)
/* 109 */               shade = 0;
/*     */             else
/* 111 */               shade = (int)(NdotL / Math.sqrt(Nx * Nx + Ny * Ny + Nz2)); 
/*     */           }
/*     */         } else { shade = background; }
/*     */ 
/* 115 */         if (this.emboss) {
/* 116 */           int rgb = inPixels[index];
/* 117 */           int a = rgb & 0xFF000000;
/* 118 */           int r = rgb >> 16 & 0xFF;
/* 119 */           int g = rgb >> 8 & 0xFF;
/* 120 */           int b = rgb & 0xFF;
/* 121 */           r = r * shade >> 8;
/* 122 */           g = g * shade >> 8;
/* 123 */           b = b * shade >> 8;
/* 124 */           outPixels[(index++)] = (a | r << 16 | g << 8 | b);
/*     */         } else {
/* 126 */           outPixels[(index++)] = (0xFF000000 | shade << 16 | shade << 8 | shade);
/*     */         }
/* 101 */         x++; s1++; s2++;
/*     */       }
/*  96 */       y++;
/*     */     }
/*     */ 
/* 130 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 134 */     return "Stylize/Emboss...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.EmbossFilter
 * JD-Core Version:    0.6.1
 */