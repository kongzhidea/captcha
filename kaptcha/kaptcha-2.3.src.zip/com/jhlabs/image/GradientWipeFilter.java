/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class GradientWipeFilter extends AbstractBufferedImageOp
/*     */ {
/*  27 */   private float density = 0.0F;
/*  28 */   private float softness = 0.0F;
/*     */   private boolean invert;
/*     */   private BufferedImage mask;
/*     */ 
/*     */   public void setDensity(float density)
/*     */   {
/*  40 */     this.density = density;
/*     */   }
/*     */ 
/*     */   public float getDensity() {
/*  44 */     return this.density;
/*     */   }
/*     */ 
/*     */   public void setSoftness(float softness)
/*     */   {
/*  55 */     this.softness = softness;
/*     */   }
/*     */ 
/*     */   public float getSoftness()
/*     */   {
/*  64 */     return this.softness;
/*     */   }
/*     */ 
/*     */   public void setMask(BufferedImage mask) {
/*  68 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */   public BufferedImage getMask() {
/*  72 */     return this.mask;
/*     */   }
/*     */ 
/*     */   public void setInvert(boolean invert) {
/*  76 */     this.invert = invert;
/*     */   }
/*     */ 
/*     */   public boolean getInvert() {
/*  80 */     return this.invert;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  84 */     int width = src.getWidth();
/*  85 */     int height = src.getHeight();
/*     */ 
/*  87 */     if (dst == null)
/*  88 */       dst = createCompatibleDestImage(src, null);
/*  89 */     if (this.mask == null) {
/*  90 */       return dst;
/*     */     }
/*  92 */     int maskWidth = this.mask.getWidth();
/*  93 */     int maskHeight = this.mask.getHeight();
/*     */ 
/*  95 */     float d = this.density * (1.0F + this.softness);
/*  96 */     float lower = 255.0F * (d - this.softness);
/*  97 */     float upper = 255.0F * d;
/*     */ 
/*  99 */     int[] inPixels = new int[width];
/* 100 */     int[] maskPixels = new int[maskWidth];
/*     */ 
/* 102 */     for (int y = 0; y < height; y++) {
/* 103 */       getRGB(src, 0, y, width, 1, inPixels);
/* 104 */       getRGB(this.mask, 0, y % maskHeight, maskWidth, 1, maskPixels);
/*     */ 
/* 106 */       for (int x = 0; x < width; x++) {
/* 107 */         int maskRGB = maskPixels[(x % maskWidth)];
/* 108 */         int inRGB = inPixels[x];
/* 109 */         int v = PixelUtils.brightness(maskRGB);
/* 110 */         float f = ImageMath.smoothStep(lower, upper, v);
/* 111 */         int a = (int)(255.0F * f);
/*     */ 
/* 113 */         if (this.invert)
/* 114 */           a = 255 - a;
/* 115 */         inPixels[x] = (a << 24 | inRGB & 0xFFFFFF);
/*     */       }
/*     */ 
/* 118 */       setRGB(dst, 0, y, width, 1, inPixels);
/*     */     }
/*     */ 
/* 121 */     return dst;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 125 */     return "Transitions/Gradient Wipe...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GradientWipeFilter
 * JD-Core Version:    0.6.1
 */