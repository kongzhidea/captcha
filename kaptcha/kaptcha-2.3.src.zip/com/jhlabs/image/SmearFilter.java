/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Date;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class SmearFilter extends WholeImageFilter
/*     */ {
/*     */   public static final int CROSSES = 0;
/*     */   public static final int LINES = 1;
/*     */   public static final int CIRCLES = 2;
/*     */   public static final int SQUARES = 3;
/*  31 */   private Colormap colormap = new LinearColormap();
/*  32 */   private float angle = 0.0F;
/*  33 */   private float density = 0.5F;
/*  34 */   private float scatter = 0.0F;
/*  35 */   private int distance = 8;
/*     */   private Random randomGenerator;
/*  37 */   private long seed = 567L;
/*  38 */   private int shape = 1;
/*  39 */   private float mix = 0.5F;
/*  40 */   private int fadeout = 0;
/*  41 */   private boolean background = false;
/*     */ 
/*     */   public SmearFilter() {
/*  44 */     this.randomGenerator = new Random();
/*     */   }
/*     */ 
/*     */   public void setShape(int shape) {
/*  48 */     this.shape = shape;
/*     */   }
/*     */ 
/*     */   public int getShape() {
/*  52 */     return this.shape;
/*     */   }
/*     */ 
/*     */   public void setDistance(int distance) {
/*  56 */     this.distance = distance;
/*     */   }
/*     */ 
/*     */   public int getDistance() {
/*  60 */     return this.distance;
/*     */   }
/*     */ 
/*     */   public void setDensity(float density) {
/*  64 */     this.density = density;
/*     */   }
/*     */ 
/*     */   public float getDensity() {
/*  68 */     return this.density;
/*     */   }
/*     */ 
/*     */   public void setScatter(float scatter) {
/*  72 */     this.scatter = scatter;
/*     */   }
/*     */ 
/*     */   public float getScatter() {
/*  76 */     return this.scatter;
/*     */   }
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  86 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  95 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setMix(float mix) {
/*  99 */     this.mix = mix;
/*     */   }
/*     */ 
/*     */   public float getMix() {
/* 103 */     return this.mix;
/*     */   }
/*     */ 
/*     */   public void setFadeout(int fadeout) {
/* 107 */     this.fadeout = fadeout;
/*     */   }
/*     */ 
/*     */   public int getFadeout() {
/* 111 */     return this.fadeout;
/*     */   }
/*     */ 
/*     */   public void setBackground(boolean background) {
/* 115 */     this.background = background;
/*     */   }
/*     */ 
/*     */   public boolean getBackground() {
/* 119 */     return this.background;
/*     */   }
/*     */ 
/*     */   public void randomize() {
/* 123 */     this.seed = new Date().getTime();
/*     */   }
/*     */ 
/*     */   private float random(float low, float high) {
/* 127 */     return low + (high - low) * this.randomGenerator.nextFloat();
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 131 */     int[] outPixels = new int[width * height];
/*     */ 
/* 133 */     this.randomGenerator.setSeed(this.seed);
/* 134 */     float sinAngle = (float)Math.sin(this.angle);
/* 135 */     float cosAngle = (float)Math.cos(this.angle);
/*     */ 
/* 137 */     int i = 0;
/*     */ 
/* 140 */     for (int y = 0; y < height; y++)
/* 141 */       for (int x = 0; x < width; x++) {
/* 142 */         outPixels[i] = (this.background ? -1 : inPixels[i]);
/* 143 */         i++;
/*     */       }
/*     */     int numShapes;
/* 146 */     switch (this.shape)
/*     */     {
/*     */     case 0:
/* 149 */       numShapes = (int)(2.0F * this.density * width * height / this.distance + 1);
/* 150 */       for (i = 0; i < numShapes; ) {
/* 151 */         int x = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % width;
/* 152 */         int y = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % height;
/* 153 */         int length = this.randomGenerator.nextInt() % this.distance + 1;
/* 154 */         int rgb = inPixels[(y * width + x)];
/* 155 */         for (int x1 = x - length; x1 < x + length + 1; x1++) {
/* 156 */           if ((x1 >= 0) && (x1 < width)) {
/* 157 */             int rgb2 = this.background ? -1 : outPixels[(y * width + x1)];
/* 158 */             outPixels[(y * width + x1)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */           }
/*     */         }
/* 161 */         for (int y1 = y - length; y1 < y + length + 1; y1++)
/* 162 */           if ((y1 >= 0) && (y1 < height)) {
/* 163 */             int rgb2 = this.background ? -1 : outPixels[(y1 * width + x)];
/* 164 */             outPixels[(y1 * width + x)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */           }
/* 150 */         i++; continue;
/*     */ 
/* 170 */         numShapes = (int)(2.0F * this.density * width * height / 2.0F);
/*     */ 
/* 172 */         for (i = 0; i < numShapes; ) {
/* 173 */           int sx = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % width;
/* 174 */           int sy = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % height;
/* 175 */           int rgb = inPixels[(sy * width + sx)];
/* 176 */           int length = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % this.distance;
/* 177 */           int dx = (int)(length * cosAngle);
/* 178 */           int dy = (int)(length * sinAngle);
/*     */ 
/* 180 */           int x0 = sx - dx;
/* 181 */           int y0 = sy - dy;
/* 182 */           int x1 = sx + dx;
/* 183 */           int y1 = sy + dy;
/*     */           int ddx;
/*     */           int ddx;
/* 186 */           if (x1 < x0)
/* 187 */             ddx = -1;
/*     */           else
/* 189 */             ddx = 1;
/*     */           int ddy;
/*     */           int ddy;
/* 190 */           if (y1 < y0)
/* 191 */             ddy = -1;
/*     */           else
/* 193 */             ddy = 1;
/* 194 */           dx = x1 - x0;
/* 195 */           dy = y1 - y0;
/* 196 */           dx = Math.abs(dx);
/* 197 */           dy = Math.abs(dy);
/* 198 */           int x = x0;
/* 199 */           int y = y0;
/*     */ 
/* 201 */           if ((x < width) && (x >= 0) && (y < height) && (y >= 0)) {
/* 202 */             int rgb2 = this.background ? -1 : outPixels[(y * width + x)];
/* 203 */             outPixels[(y * width + x)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */           }
/* 205 */           if (Math.abs(dx) > Math.abs(dy)) {
/* 206 */             int d = 2 * dy - dx;
/* 207 */             int incrE = 2 * dy;
/* 208 */             int incrNE = 2 * (dy - dx);
/*     */ 
/* 210 */             while (x != x1) {
/* 211 */               if (d <= 0) {
/* 212 */                 d += incrE;
/*     */               } else {
/* 214 */                 d += incrNE;
/* 215 */                 y += ddy;
/*     */               }
/* 217 */               x += ddx;
/* 218 */               if ((x < width) && (x >= 0) && (y < height) && (y >= 0)) {
/* 219 */                 int rgb2 = this.background ? -1 : outPixels[(y * width + x)];
/* 220 */                 outPixels[(y * width + x)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */               }
/*     */             }
/*     */           }
/* 224 */           int d = 2 * dx - dy;
/* 225 */           int incrE = 2 * dx;
/* 226 */           int incrNE = 2 * (dx - dy);
/*     */ 
/* 228 */           while (y != y1) {
/* 229 */             if (d <= 0) {
/* 230 */               d += incrE;
/*     */             } else {
/* 232 */               d += incrNE;
/* 233 */               x += ddx;
/*     */             }
/* 235 */             y += ddy;
/* 236 */             if ((x < width) && (x >= 0) && (y < height) && (y >= 0)) {
/* 237 */               int rgb2 = this.background ? -1 : outPixels[(y * width + x)];
/* 238 */               outPixels[(y * width + x)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */             }
/*     */           }
/* 172 */           i++; continue;
/*     */ 
/* 246 */           int radius = this.distance + 1;
/* 247 */           int radius2 = radius * radius;
/* 248 */           numShapes = (int)(2.0F * this.density * width * height / radius);
/* 249 */           for (i = 0; i < numShapes; i++) {
/* 250 */             int sx = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % width;
/* 251 */             int sy = (this.randomGenerator.nextInt() & 0x7FFFFFFF) % height;
/* 252 */             int rgb = inPixels[(sy * width + sx)];
/* 253 */             for (int x = sx - radius; x < sx + radius + 1; x++)
/* 254 */               for (int y = sy - radius; y < sy + radius + 1; y++)
/*     */               {
/*     */                 int f;
/*     */                 int f;
/* 256 */                 if (this.shape == 2)
/* 257 */                   f = (x - sx) * (x - sx) + (y - sy) * (y - sy);
/*     */                 else
/* 259 */                   f = 0;
/* 260 */                 if ((x >= 0) && (x < width) && (y >= 0) && (y < height) && (f <= radius2)) {
/* 261 */                   int rgb2 = this.background ? -1 : outPixels[(y * width + x)];
/* 262 */                   outPixels[(y * width + x)] = ImageMath.mixColors(this.mix, rgb2, rgb);
/*     */                 }
/*     */               } 
/*     */           }
/*     */         }
/*     */       }
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     }
/* 269 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 273 */     return "Effects/Smear...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SmearFilter
 * JD-Core Version:    0.6.1
 */