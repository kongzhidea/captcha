/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ public abstract class ImageUtils
/*     */ {
/*  30 */   private static BufferedImage backgroundImage = null;
/*     */ 
/*     */   public static BufferedImage createImage(ImageProducer producer)
/*     */   {
/*  38 */     PixelGrabber pg = new PixelGrabber(producer, 0, 0, -1, -1, null, 0, 0);
/*     */     try {
/*  40 */       pg.grabPixels();
/*     */     } catch (InterruptedException e) {
/*  42 */       throw new RuntimeException("Image fetch interrupted");
/*     */     }
/*  44 */     if ((pg.status() & 0x80) != 0)
/*  45 */       throw new RuntimeException("Image fetch aborted");
/*  46 */     if ((pg.status() & 0x40) != 0)
/*  47 */       throw new RuntimeException("Image fetch error");
/*  48 */     BufferedImage p = new BufferedImage(pg.getWidth(), pg.getHeight(), 2);
/*  49 */     p.setRGB(0, 0, pg.getWidth(), pg.getHeight(), (int[])pg.getPixels(), 0, pg.getWidth());
/*  50 */     return p;
/*     */   }
/*     */ 
/*     */   public static BufferedImage convertImageToARGB(Image image)
/*     */   {
/*  59 */     if (((image instanceof BufferedImage)) && (((BufferedImage)image).getType() == 2))
/*  60 */       return (BufferedImage)image;
/*  61 */     BufferedImage p = new BufferedImage(image.getWidth(null), image.getHeight(null), 2);
/*  62 */     Graphics2D g = p.createGraphics();
/*  63 */     g.drawImage(image, 0, 0, null);
/*  64 */     g.dispose();
/*  65 */     return p;
/*     */   }
/*     */ 
/*     */   public static BufferedImage getSubimage(BufferedImage image, int x, int y, int w, int h)
/*     */   {
/*  78 */     BufferedImage newImage = new BufferedImage(w, h, 2);
/*  79 */     Graphics2D g = newImage.createGraphics();
/*  80 */     g.drawRenderedImage(image, AffineTransform.getTranslateInstance(-x, -y));
/*  81 */     g.dispose();
/*  82 */     return newImage;
/*     */   }
/*     */ 
/*     */   public static BufferedImage cloneImage(BufferedImage image)
/*     */   {
/*  91 */     BufferedImage newImage = new BufferedImage(image.getWidth(), image.getHeight(), 2);
/*  92 */     Graphics2D g = newImage.createGraphics();
/*  93 */     g.drawRenderedImage(image, null);
/*  94 */     g.dispose();
/*  95 */     return newImage;
/*     */   }
/*     */ 
/*     */   public static void paintCheckedBackground(Component c, Graphics g, int x, int y, int width, int height)
/*     */   {
/* 108 */     if (backgroundImage == null) {
/* 109 */       backgroundImage = new BufferedImage(64, 64, 2);
/* 110 */       Graphics bg = backgroundImage.createGraphics();
/* 111 */       for (int by = 0; by < 64; by += 8) {
/* 112 */         for (int bx = 0; bx < 64; bx += 8) {
/* 113 */           bg.setColor(((bx ^ by) & 0x8) != 0 ? Color.lightGray : Color.white);
/* 114 */           bg.fillRect(bx, by, 8, 8);
/*     */         }
/*     */       }
/* 117 */       bg.dispose();
/*     */     }
/*     */ 
/* 120 */     if (backgroundImage != null) {
/* 121 */       Shape saveClip = g.getClip();
/* 122 */       Rectangle r = g.getClipBounds();
/* 123 */       if (r == null)
/* 124 */         r = new Rectangle(c.getSize());
/* 125 */       r = r.intersection(new Rectangle(x, y, width, height));
/* 126 */       g.setClip(r);
/* 127 */       int w = backgroundImage.getWidth();
/* 128 */       int h = backgroundImage.getHeight();
/* 129 */       if ((w != -1) && (h != -1)) {
/* 130 */         int x1 = r.x / w * w;
/* 131 */         int y1 = r.y / h * h;
/* 132 */         int x2 = (r.x + r.width + w - 1) / w * w;
/* 133 */         int y2 = (r.y + r.height + h - 1) / h * h;
/* 134 */         for (y = y1; y < y2; y += h)
/* 135 */           for (x = x1; x < x2; x += w)
/* 136 */             g.drawImage(backgroundImage, x, y, c);
/*     */       }
/* 138 */       g.setClip(saveClip);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Rectangle getSelectedBounds(BufferedImage p)
/*     */   {
/* 148 */     int width = p.getWidth();
/* 149 */     int height = p.getHeight();
/* 150 */     int maxX = 0; int maxY = 0; int minX = width; int minY = height;
/* 151 */     boolean anySelected = false;
/*     */ 
/* 153 */     int[] pixels = null;
/*     */ 
/* 155 */     for (int y1 = height - 1; y1 >= 0; y1--) {
/* 156 */       pixels = getRGB(p, 0, y1, width, 1, pixels);
/* 157 */       for (int x = 0; x < minX; x++) {
/* 158 */         if ((pixels[x] & 0xFF000000) != 0) {
/* 159 */           minX = x;
/* 160 */           maxY = y1;
/* 161 */           anySelected = true;
/* 162 */           break;
/*     */         }
/*     */       }
/* 165 */       for (int x = width - 1; x >= maxX; x--) {
/* 166 */         if ((pixels[x] & 0xFF000000) != 0) {
/* 167 */           maxX = x;
/* 168 */           maxY = y1;
/* 169 */           anySelected = true;
/* 170 */           break;
/*     */         }
/*     */       }
/* 173 */       if (anySelected)
/*     */         break;
/*     */     }
/* 176 */     pixels = null;
/* 177 */     for (int y = 0; y < y1; y++) {
/* 178 */       pixels = getRGB(p, 0, y, width, 1, pixels);
/* 179 */       for (int x = 0; x < minX; x++) {
/* 180 */         if ((pixels[x] & 0xFF000000) != 0) {
/* 181 */           minX = x;
/* 182 */           if (y < minY)
/* 183 */             minY = y;
/* 184 */           anySelected = true;
/* 185 */           break;
/*     */         }
/*     */       }
/* 188 */       for (int x = width - 1; x >= maxX; x--) {
/* 189 */         if ((pixels[x] & 0xFF000000) != 0) {
/* 190 */           maxX = x;
/* 191 */           if (y < minY)
/* 192 */             minY = y;
/* 193 */           anySelected = true;
/* 194 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 198 */     if (anySelected)
/* 199 */       return new Rectangle(minX, minY, maxX - minX + 1, maxY - minY + 1);
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */   public static void composeThroughMask(Raster src, WritableRaster dst, Raster sel)
/*     */   {
/* 211 */     int x = src.getMinX();
/* 212 */     int y = src.getMinY();
/* 213 */     int w = src.getWidth();
/* 214 */     int h = src.getHeight();
/*     */ 
/* 216 */     int[] srcRGB = null;
/* 217 */     int[] selRGB = null;
/* 218 */     int[] dstRGB = null;
/*     */ 
/* 220 */     for (int i = 0; i < h; i++) {
/* 221 */       srcRGB = src.getPixels(x, y, w, 1, srcRGB);
/* 222 */       selRGB = sel.getPixels(x, y, w, 1, selRGB);
/* 223 */       dstRGB = dst.getPixels(x, y, w, 1, dstRGB);
/*     */ 
/* 225 */       int k = x;
/* 226 */       for (int j = 0; j < w; j++) {
/* 227 */         int sr = srcRGB[k];
/* 228 */         int dir = dstRGB[k];
/* 229 */         int sg = srcRGB[(k + 1)];
/* 230 */         int dig = dstRGB[(k + 1)];
/* 231 */         int sb = srcRGB[(k + 2)];
/* 232 */         int dib = dstRGB[(k + 2)];
/* 233 */         int sa = srcRGB[(k + 3)];
/* 234 */         int dia = dstRGB[(k + 3)];
/*     */ 
/* 236 */         float a = selRGB[(k + 3)] / 255.0F;
/* 237 */         float ac = 1.0F - a;
/*     */ 
/* 239 */         dstRGB[k] = (int)(a * sr + ac * dir);
/* 240 */         dstRGB[(k + 1)] = (int)(a * sg + ac * dig);
/* 241 */         dstRGB[(k + 2)] = (int)(a * sb + ac * dib);
/* 242 */         dstRGB[(k + 3)] = (int)(a * sa + ac * dia);
/* 243 */         k += 4;
/*     */       }
/*     */ 
/* 246 */       dst.setPixels(x, y, w, 1, dstRGB);
/* 247 */       y++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int[] getRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*     */   {
/* 264 */     int type = image.getType();
/* 265 */     if ((type == 2) || (type == 1))
/* 266 */       return (int[])image.getRaster().getDataElements(x, y, width, height, pixels);
/* 267 */     return image.getRGB(x, y, width, height, pixels, 0, width);
/*     */   }
/*     */ 
/*     */   public static void setRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels)
/*     */   {
/* 282 */     int type = image.getType();
/* 283 */     if ((type == 2) || (type == 1))
/* 284 */       image.getRaster().setDataElements(x, y, width, height, pixels);
/*     */     else
/* 286 */       image.setRGB(x, y, width, height, pixels, 0, width);
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ImageUtils
 * JD-Core Version:    0.6.1
 */