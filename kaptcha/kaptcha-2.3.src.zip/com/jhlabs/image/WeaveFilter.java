/*     */ package com.jhlabs.image;
/*     */ 
/*     */ public class WeaveFilter extends PointFilter
/*     */ {
/*  24 */   private float xWidth = 16.0F;
/*  25 */   private float yWidth = 16.0F;
/*  26 */   private float xGap = 6.0F;
/*  27 */   private float yGap = 6.0F;
/*  28 */   private int rows = 4;
/*  29 */   private int cols = 4;
/*  30 */   private int rgbX = -32640;
/*  31 */   private int rgbY = -8355585;
/*  32 */   private boolean useImageColors = true;
/*  33 */   private boolean roundThreads = false;
/*  34 */   private boolean shadeCrossings = true;
/*     */ 
/*  36 */   public int[][] matrix = { { 0, 1, 0, 1 }, { 1, 0, 1, 0 }, { 0, 1, 0, 1 }, { 1, 0, 1, 0 } };
/*     */ 
/*     */   public void setXGap(float xGap)
/*     */   {
/*  47 */     this.xGap = xGap;
/*     */   }
/*     */ 
/*     */   public void setXWidth(float xWidth) {
/*  51 */     this.xWidth = xWidth;
/*     */   }
/*     */ 
/*     */   public float getXWidth() {
/*  55 */     return this.xWidth;
/*     */   }
/*     */ 
/*     */   public void setYWidth(float yWidth) {
/*  59 */     this.yWidth = yWidth;
/*     */   }
/*     */ 
/*     */   public float getYWidth() {
/*  63 */     return this.yWidth;
/*     */   }
/*     */ 
/*     */   public float getXGap() {
/*  67 */     return this.xGap;
/*     */   }
/*     */ 
/*     */   public void setYGap(float yGap) {
/*  71 */     this.yGap = yGap;
/*     */   }
/*     */ 
/*     */   public float getYGap() {
/*  75 */     return this.yGap;
/*     */   }
/*     */ 
/*     */   public void setCrossings(int[][] matrix) {
/*  79 */     this.matrix = matrix;
/*     */   }
/*     */ 
/*     */   public int[][] getCrossings() {
/*  83 */     return this.matrix;
/*     */   }
/*     */ 
/*     */   public void setUseImageColors(boolean useImageColors) {
/*  87 */     this.useImageColors = useImageColors;
/*     */   }
/*     */ 
/*     */   public boolean getUseImageColors() {
/*  91 */     return this.useImageColors;
/*     */   }
/*     */ 
/*     */   public void setRoundThreads(boolean roundThreads) {
/*  95 */     this.roundThreads = roundThreads;
/*     */   }
/*     */ 
/*     */   public boolean getRoundThreads() {
/*  99 */     return this.roundThreads;
/*     */   }
/*     */ 
/*     */   public void setShadeCrossings(boolean shadeCrossings) {
/* 103 */     this.shadeCrossings = shadeCrossings;
/*     */   }
/*     */ 
/*     */   public boolean getShadeCrossings() {
/* 107 */     return this.shadeCrossings;
/*     */   }
/*     */ 
/*     */   public int filterRGB(int x, int y, int rgb) {
/* 111 */     x = (int)(x + (this.xWidth + this.xGap / 2.0F));
/* 112 */     y = (int)(y + (this.yWidth + this.yGap / 2.0F));
/* 113 */     float nx = ImageMath.mod(x, this.xWidth + this.xGap);
/* 114 */     float ny = ImageMath.mod(y, this.yWidth + this.yGap);
/* 115 */     int ix = (int)(x / (this.xWidth + this.xGap));
/* 116 */     int iy = (int)(y / (this.yWidth + this.yGap));
/* 117 */     boolean inX = nx < this.xWidth;
/* 118 */     boolean inY = ny < this.yWidth;
/*     */     float dY;
/*     */     float dY;
/*     */     float dX;
/* 123 */     if (this.roundThreads) {
/* 124 */       float dX = Math.abs(this.xWidth / 2.0F - nx) / this.xWidth / 2.0F;
/* 125 */       dY = Math.abs(this.yWidth / 2.0F - ny) / this.yWidth / 2.0F;
/*     */     } else {
/* 127 */       dX = dY = 0.0F;
/*     */     }
/*     */     float cY;
/*     */     float cY;
/*     */     float cX;
/* 130 */     if (this.shadeCrossings) {
/* 131 */       float cX = ImageMath.smoothStep(this.xWidth / 2.0F, this.xWidth / 2.0F + this.xGap, Math.abs(this.xWidth / 2.0F - nx));
/* 132 */       cY = ImageMath.smoothStep(this.yWidth / 2.0F, this.yWidth / 2.0F + this.yGap, Math.abs(this.yWidth / 2.0F - ny));
/*     */     } else {
/* 134 */       cX = cY = 0.0F;
/*     */     }
/*     */     int lrgbX;
/*     */     int lrgbX;
/*     */     int lrgbY;
/* 137 */     if (this.useImageColors)
/*     */     {
/*     */       int lrgbY;
/* 138 */       lrgbX = lrgbY = rgb;
/*     */     } else {
/* 140 */       lrgbX = this.rgbX;
/* 141 */       lrgbY = this.rgbY;
/*     */     }
/*     */ 
/* 144 */     int ixc = ix % this.cols;
/* 145 */     int iyr = iy % this.rows;
/* 146 */     int m = this.matrix[iyr][ixc];
/*     */     int v;
/*     */     int v;
/* 147 */     if (inX) {
/* 148 */       if (inY) {
/* 149 */         int v = m == 1 ? lrgbX : lrgbY;
/* 150 */         v = ImageMath.mixColors(2.0F * (m == 1 ? dX : dY), v, -16777216);
/*     */       } else {
/* 152 */         if (this.shadeCrossings)
/* 153 */           if (m != this.matrix[((iy + 1) % this.rows)][ixc]) {
/* 154 */             if (m == 0)
/* 155 */               cY = 1.0F - cY;
/* 156 */             cY *= 0.5F;
/* 157 */             lrgbX = ImageMath.mixColors(cY, lrgbX, -16777216);
/* 158 */           } else if (m == 0) {
/* 159 */             lrgbX = ImageMath.mixColors(0.5F, lrgbX, -16777216);
/*     */           }
/* 161 */         v = ImageMath.mixColors(2.0F * dX, lrgbX, -16777216);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       int v;
/* 163 */       if (inY) {
/* 164 */         if (this.shadeCrossings)
/* 165 */           if (m != this.matrix[iyr][((ix + 1) % this.cols)]) {
/* 166 */             if (m == 1)
/* 167 */               cX = 1.0F - cX;
/* 168 */             cX *= 0.5F;
/* 169 */             lrgbY = ImageMath.mixColors(cX, lrgbY, -16777216);
/* 170 */           } else if (m == 1) {
/* 171 */             lrgbY = ImageMath.mixColors(0.5F, lrgbY, -16777216);
/*     */           }
/* 173 */         v = ImageMath.mixColors(2.0F * dY, lrgbY, -16777216);
/*     */       } else {
/* 175 */         v = 0; } 
/* 176 */     }return v;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 180 */     return "Texture/Weave...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.WeaveFilter
 * JD-Core Version:    0.6.1
 */