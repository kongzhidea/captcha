/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class GrayscaleColormap
/*    */   implements Colormap
/*    */ {
/*    */   public int getColor(float v)
/*    */   {
/* 33 */     int n = (int)(v * 255.0F);
/* 34 */     if (n < 0)
/* 35 */       n = 0;
/* 36 */     else if (n > 255)
/* 37 */       n = 255;
/* 38 */     return 0xFF000000 | n << 16 | n << 8 | n;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GrayscaleColormap
 * JD-Core Version:    0.6.1
 */