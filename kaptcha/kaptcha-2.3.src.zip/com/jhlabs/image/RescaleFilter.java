/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class RescaleFilter extends TransferFilter
/*    */ {
/* 27 */   private float scale = 1.0F;
/*    */ 
/*    */   public RescaleFilter() {
/*    */   }
/*    */ 
/*    */   public RescaleFilter(float scale) {
/* 33 */     this.scale = scale;
/*    */   }
/*    */ 
/*    */   protected float transferFunction(float v) {
/* 37 */     return v * this.scale;
/*    */   }
/*    */ 
/*    */   public void setScale(float scale)
/*    */   {
/* 48 */     this.scale = scale;
/* 49 */     this.initialized = false;
/*    */   }
/*    */ 
/*    */   public float getScale()
/*    */   {
/* 58 */     return this.scale;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 62 */     return "Colors/Rescale...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RescaleFilter
 * JD-Core Version:    0.6.1
 */