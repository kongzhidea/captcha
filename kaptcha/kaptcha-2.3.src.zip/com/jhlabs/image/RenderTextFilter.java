/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Composite;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class RenderTextFilter extends AbstractBufferedImageOp
/*     */ {
/*     */   private String text;
/*     */   private Font font;
/*     */   private Paint paint;
/*     */   private Composite composite;
/*     */   private AffineTransform transform;
/*     */ 
/*     */   public RenderTextFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public RenderTextFilter(String text, Font font, Paint paint, Composite composite, AffineTransform transform)
/*     */   {
/*  49 */     this.text = text;
/*  50 */     this.font = font;
/*  51 */     this.composite = composite;
/*  52 */     this.paint = paint;
/*  53 */     this.transform = transform;
/*     */   }
/*     */ 
/*     */   public void setText(String text)
/*     */   {
/*  62 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public String getText()
/*     */   {
/*  71 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void setComposite(Composite composite)
/*     */   {
/*  80 */     this.composite = composite;
/*     */   }
/*     */ 
/*     */   public Composite getComposite()
/*     */   {
/*  89 */     return this.composite;
/*     */   }
/*     */ 
/*     */   public void setPaint(Paint paint)
/*     */   {
/*  98 */     this.paint = paint;
/*     */   }
/*     */ 
/*     */   public Paint getPaint()
/*     */   {
/* 107 */     return this.paint;
/*     */   }
/*     */ 
/*     */   public void setFont(Font font)
/*     */   {
/* 116 */     this.font = font;
/*     */   }
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 125 */     return this.font;
/*     */   }
/*     */ 
/*     */   public void setTransform(AffineTransform transform)
/*     */   {
/* 134 */     this.transform = transform;
/*     */   }
/*     */ 
/*     */   public AffineTransform getTransform()
/*     */   {
/* 143 */     return this.transform;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 147 */     if (dst == null) {
/* 148 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/* 150 */     Graphics2D g = dst.createGraphics();
/* 151 */     g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 152 */     if (this.font != null)
/* 153 */       g.setFont(this.font);
/* 154 */     if (this.transform != null)
/* 155 */       g.setTransform(this.transform);
/* 156 */     if (this.composite != null)
/* 157 */       g.setComposite(this.composite);
/* 158 */     if (this.paint != null)
/* 159 */       g.setPaint(this.paint);
/* 160 */     if (this.text != null)
/* 161 */       g.drawString(this.text, 10, 100);
/* 162 */     g.dispose();
/* 163 */     return dst;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.RenderTextFilter
 * JD-Core Version:    0.6.1
 */