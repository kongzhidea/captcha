/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class ErodeAlphaFilter extends PointFilter
/*    */ {
/*    */   private float threshold;
/* 12 */   private float softness = 0.0F;
/* 13 */   protected float radius = 5.0F;
/*    */   private float lowerThreshold;
/*    */   private float upperThreshold;
/*    */ 
/*    */   public ErodeAlphaFilter()
/*    */   {
/* 18 */     this(3.0F, 0.75F, 0.0F);
/*    */   }
/*    */ 
/*    */   public ErodeAlphaFilter(float radius, float threshold, float softness) {
/* 22 */     this.radius = radius;
/* 23 */     this.threshold = threshold;
/* 24 */     this.softness = softness;
/*    */   }
/*    */ 
/*    */   public void setRadius(float radius) {
/* 28 */     this.radius = radius;
/*    */   }
/*    */ 
/*    */   public float getRadius() {
/* 32 */     return this.radius;
/*    */   }
/*    */ 
/*    */   public void setThreshold(float threshold) {
/* 36 */     this.threshold = threshold;
/*    */   }
/*    */ 
/*    */   public float getThreshold() {
/* 40 */     return this.threshold;
/*    */   }
/*    */ 
/*    */   public void setSoftness(float softness) {
/* 44 */     this.softness = softness;
/*    */   }
/*    */ 
/*    */   public float getSoftness() {
/* 48 */     return this.softness;
/*    */   }
/*    */ 
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 52 */     dst = new GaussianFilter((int)this.radius).filter(src, null);
/* 53 */     this.lowerThreshold = (255.0F * (this.threshold - this.softness * 0.5F));
/* 54 */     this.upperThreshold = (255.0F * (this.threshold + this.softness * 0.5F));
/* 55 */     return super.filter(dst, dst);
/*    */   }
/*    */ 
/*    */   public int filterRGB(int x, int y, int rgb) {
/* 59 */     int a = rgb >> 24 & 0xFF;
/* 60 */     int r = rgb >> 16 & 0xFF;
/* 61 */     int g = rgb >> 8 & 0xFF;
/* 62 */     int b = rgb & 0xFF;
/* 63 */     if (a == 255)
/* 64 */       return -1;
/* 65 */     float f = ImageMath.smoothStep(this.lowerThreshold, this.upperThreshold, a);
/* 66 */     a = (int)(f * 255.0F);
/* 67 */     if (a < 0)
/* 68 */       a = 0;
/* 69 */     else if (a > 255)
/* 70 */       a = 255;
/* 71 */     return a << 24 | 0xFFFFFF;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 75 */     return "Alpha/Erode...";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.ErodeAlphaFilter
 * JD-Core Version:    0.6.1
 */