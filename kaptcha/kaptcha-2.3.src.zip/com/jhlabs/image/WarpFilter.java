/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class WarpFilter extends WholeImageFilter
/*     */ {
/*     */   private WarpGrid sourceGrid;
/*     */   private WarpGrid destGrid;
/*  34 */   private int frames = 1;
/*     */   private BufferedImage morphImage;
/*     */   private float time;
/*     */ 
/*     */   public WarpFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public WarpFilter(WarpGrid sourceGrid, WarpGrid destGrid)
/*     */   {
/*  51 */     this.sourceGrid = sourceGrid;
/*  52 */     this.destGrid = destGrid;
/*     */   }
/*     */ 
/*     */   public void setSourceGrid(WarpGrid sourceGrid)
/*     */   {
/*  61 */     this.sourceGrid = sourceGrid;
/*     */   }
/*     */ 
/*     */   public WarpGrid getSourceGrid()
/*     */   {
/*  70 */     return this.sourceGrid;
/*     */   }
/*     */ 
/*     */   public void setDestGrid(WarpGrid destGrid)
/*     */   {
/*  79 */     this.destGrid = destGrid;
/*     */   }
/*     */ 
/*     */   public WarpGrid getDestGrid()
/*     */   {
/*  88 */     return this.destGrid;
/*     */   }
/*     */ 
/*     */   public void setFrames(int frames) {
/*  92 */     this.frames = frames;
/*     */   }
/*     */ 
/*     */   public int getFrames() {
/*  96 */     return this.frames;
/*     */   }
/*     */ 
/*     */   public void setMorphImage(BufferedImage morphImage)
/*     */   {
/* 103 */     this.morphImage = morphImage;
/*     */   }
/*     */ 
/*     */   public BufferedImage getMorphImage() {
/* 107 */     return this.morphImage;
/*     */   }
/*     */ 
/*     */   public void setTime(float time) {
/* 111 */     this.time = time;
/*     */   }
/*     */ 
/*     */   public float getTime() {
/* 115 */     return this.time;
/*     */   }
/*     */ 
/*     */   protected void transformSpace(Rectangle r) {
/* 119 */     r.width *= this.frames;
/*     */   }
/*     */ 
/*     */   protected int[] filterPixels(int width, int height, int[] inPixels, Rectangle transformedSpace) {
/* 123 */     int[] outPixels = new int[width * height];
/*     */ 
/* 125 */     if (this.morphImage != null) {
/* 126 */       int[] morphPixels = getRGB(this.morphImage, 0, 0, width, height, null);
/* 127 */       morph(inPixels, morphPixels, outPixels, this.sourceGrid, this.destGrid, width, height, this.time);
/* 128 */     } else if (this.frames <= 1) {
/* 129 */       this.sourceGrid.warp(inPixels, width, height, this.sourceGrid, this.destGrid, outPixels);
/*     */     } else {
/* 131 */       WarpGrid newGrid = new WarpGrid(this.sourceGrid.rows, this.sourceGrid.cols, width, height);
/* 132 */       for (int i = 0; i < this.frames; i++) {
/* 133 */         float t = i / this.frames - 1;
/* 134 */         this.sourceGrid.lerp(t, this.destGrid, newGrid);
/* 135 */         this.sourceGrid.warp(inPixels, width, height, this.sourceGrid, newGrid, outPixels);
/*     */       }
/*     */     }
/* 138 */     return outPixels;
/*     */   }
/*     */ 
/*     */   public void morph(int[] srcPixels, int[] destPixels, int[] outPixels, WarpGrid srcGrid, WarpGrid destGrid, int width, int height, float t) {
/* 142 */     WarpGrid newGrid = new WarpGrid(srcGrid.rows, srcGrid.cols, width, height);
/* 143 */     srcGrid.lerp(t, destGrid, newGrid);
/* 144 */     srcGrid.warp(srcPixels, width, height, srcGrid, newGrid, outPixels);
/* 145 */     int[] destPixels2 = new int[width * height];
/* 146 */     destGrid.warp(destPixels, width, height, destGrid, newGrid, destPixels2);
/* 147 */     crossDissolve(outPixels, destPixels2, width, height, t);
/*     */   }
/*     */ 
/*     */   public void crossDissolve(int[] pixels1, int[] pixels2, int width, int height, float t) {
/* 151 */     int index = 0;
/* 152 */     for (int y = 0; y < height; y++)
/* 153 */       for (int x = 0; x < width; x++) {
/* 154 */         pixels1[index] = ImageMath.mixColors(t, pixels1[index], pixels2[index]);
/* 155 */         index++;
/*     */       }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 161 */     return "Distort/Mesh Warp...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.WarpFilter
 * JD-Core Version:    0.6.1
 */