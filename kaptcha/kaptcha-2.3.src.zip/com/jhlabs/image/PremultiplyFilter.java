/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class PremultiplyFilter extends PointFilter
/*    */ {
/*    */   public int filterRGB(int x, int y, int rgb)
/*    */   {
/* 20 */     int a = rgb >> 24 & 0xFF;
/* 21 */     int r = rgb >> 16 & 0xFF;
/* 22 */     int g = rgb >> 8 & 0xFF;
/* 23 */     int b = rgb & 0xFF;
/* 24 */     float f = a * 0.003921569F;
/* 25 */     r = (int)(r * f);
/* 26 */     g = (int)(g * f);
/* 27 */     b = (int)(b * f);
/* 28 */     return a << 24 | r << 16 | g << 8 | b;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 32 */     return "Alpha/Premultiply";
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PremultiplyFilter
 * JD-Core Version:    0.6.1
 */