/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import com.jhlabs.composite.SubtractComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class DoGFilter extends AbstractBufferedImageOp
/*     */ {
/*  29 */   private float radius1 = 1.0F;
/*  30 */   private float radius2 = 2.0F;
/*  31 */   private boolean normalize = true;
/*     */   private boolean invert;
/*     */ 
/*     */   public void setRadius1(float radius1)
/*     */   {
/*  45 */     this.radius1 = radius1;
/*     */   }
/*     */ 
/*     */   public float getRadius1()
/*     */   {
/*  54 */     return this.radius1;
/*     */   }
/*     */ 
/*     */   public void setRadius2(float radius2)
/*     */   {
/*  65 */     this.radius2 = radius2;
/*     */   }
/*     */ 
/*     */   public float getRadius2()
/*     */   {
/*  74 */     return this.radius2;
/*     */   }
/*     */ 
/*     */   public void setNormalize(boolean normalize) {
/*  78 */     this.normalize = normalize;
/*     */   }
/*     */ 
/*     */   public boolean getNormalize() {
/*  82 */     return this.normalize;
/*     */   }
/*     */ 
/*     */   public void setInvert(boolean invert) {
/*  86 */     this.invert = invert;
/*     */   }
/*     */ 
/*     */   public boolean getInvert() {
/*  90 */     return this.invert;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  94 */     int width = src.getWidth();
/*  95 */     int height = src.getHeight();
/*  96 */     BufferedImage image1 = new BoxBlurFilter(this.radius1, this.radius1, 3).filter(src, null);
/*  97 */     BufferedImage image2 = new BoxBlurFilter(this.radius2, this.radius2, 3).filter(src, null);
/*  98 */     Graphics2D g2d = image2.createGraphics();
/*  99 */     g2d.setComposite(new SubtractComposite(1.0F));
/* 100 */     g2d.drawImage(image1, 0, 0, null);
/* 101 */     g2d.dispose();
/* 102 */     if ((this.normalize) && (this.radius1 != this.radius2)) {
/* 103 */       int[] pixels = null;
/* 104 */       int max = 0;
/* 105 */       for (int y = 0; y < height; y++) {
/* 106 */         pixels = getRGB(image2, 0, y, width, 1, pixels);
/* 107 */         for (int x = 0; x < width; x++) {
/* 108 */           int rgb = pixels[x];
/* 109 */           int r = rgb >> 16 & 0xFF;
/* 110 */           int g = rgb >> 8 & 0xFF;
/* 111 */           int b = rgb & 0xFF;
/* 112 */           if (r > max)
/* 113 */             max = r;
/* 114 */           if (g > max)
/* 115 */             max = g;
/* 116 */           if (b > max) {
/* 117 */             max = b;
/*     */           }
/*     */         }
/*     */       }
/* 121 */       for (int y = 0; y < height; y++) {
/* 122 */         pixels = getRGB(image2, 0, y, width, 1, pixels);
/* 123 */         for (int x = 0; x < width; x++) {
/* 124 */           int rgb = pixels[x];
/* 125 */           int r = rgb >> 16 & 0xFF;
/* 126 */           int g = rgb >> 8 & 0xFF;
/* 127 */           int b = rgb & 0xFF;
/* 128 */           r = r * 255 / max;
/* 129 */           g = g * 255 / max;
/* 130 */           b = b * 255 / max;
/* 131 */           pixels[x] = (rgb & 0xFF000000 | r << 16 | g << 8 | b);
/*     */         }
/* 133 */         setRGB(image2, 0, y, width, 1, pixels);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 138 */     if (this.invert) {
/* 139 */       image2 = new InvertFilter().filter(image2, image2);
/*     */     }
/* 141 */     return image2;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 145 */     return "Blur/Difference of Gaussians...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.DoGFilter
 * JD-Core Version:    0.6.1
 */