/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Kernel;
/*     */ 
/*     */ public class GaussianFilter extends ConvolveFilter
/*     */ {
/*     */   protected float radius;
/*     */   protected Kernel kernel;
/*     */ 
/*     */   public GaussianFilter()
/*     */   {
/*  42 */     this(2.0F);
/*     */   }
/*     */ 
/*     */   public GaussianFilter(float radius)
/*     */   {
/*  50 */     setRadius(radius);
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/*  61 */     this.radius = radius;
/*  62 */     this.kernel = makeKernel(radius);
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/*  71 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  75 */     int width = src.getWidth();
/*  76 */     int height = src.getHeight();
/*     */ 
/*  78 */     if (dst == null) {
/*  79 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  81 */     int[] inPixels = new int[width * height];
/*  82 */     int[] outPixels = new int[width * height];
/*  83 */     src.getRGB(0, 0, width, height, inPixels, 0, width);
/*     */ 
/*  85 */     if (this.radius > 0.0F) {
/*  86 */       convolveAndTranspose(this.kernel, inPixels, outPixels, width, height, this.alpha, (this.alpha) && (this.premultiplyAlpha), false, CLAMP_EDGES);
/*  87 */       convolveAndTranspose(this.kernel, outPixels, inPixels, height, width, this.alpha, false, (this.alpha) && (this.premultiplyAlpha), CLAMP_EDGES);
/*     */     }
/*     */ 
/*  90 */     dst.setRGB(0, 0, width, height, inPixels, 0, width);
/*  91 */     return dst;
/*     */   }
/*     */ 
/*     */   public static void convolveAndTranspose(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha, boolean premultiply, boolean unpremultiply, int edgeAction)
/*     */   {
/* 105 */     float[] matrix = kernel.getKernelData(null);
/* 106 */     int cols = kernel.getWidth();
/* 107 */     int cols2 = cols / 2;
/*     */ 
/* 109 */     for (int y = 0; y < height; y++) {
/* 110 */       int index = y;
/* 111 */       int ioffset = y * width;
/* 112 */       for (int x = 0; x < width; x++) {
/* 113 */         float r = 0.0F; float g = 0.0F; float b = 0.0F; float a = 0.0F;
/* 114 */         int moffset = cols2;
/* 115 */         for (int col = -cols2; col <= cols2; col++) {
/* 116 */           float f = matrix[(moffset + col)];
/*     */ 
/* 118 */           if (f != 0.0F) {
/* 119 */             int ix = x + col;
/* 120 */             if (ix < 0) {
/* 121 */               if (edgeAction == CLAMP_EDGES)
/* 122 */                 ix = 0;
/* 123 */               else if (edgeAction == WRAP_EDGES)
/* 124 */                 ix = (x + width) % width;
/* 125 */             } else if (ix >= width) {
/* 126 */               if (edgeAction == CLAMP_EDGES)
/* 127 */                 ix = width - 1;
/* 128 */               else if (edgeAction == WRAP_EDGES)
/* 129 */                 ix = (x + width) % width;
/*     */             }
/* 131 */             int rgb = inPixels[(ioffset + ix)];
/* 132 */             int pa = rgb >> 24 & 0xFF;
/* 133 */             int pr = rgb >> 16 & 0xFF;
/* 134 */             int pg = rgb >> 8 & 0xFF;
/* 135 */             int pb = rgb & 0xFF;
/* 136 */             if (premultiply) {
/* 137 */               float a255 = pa * 0.003921569F;
/* 138 */               pr = (int)(pr * a255);
/* 139 */               pg = (int)(pg * a255);
/* 140 */               pb = (int)(pb * a255);
/*     */             }
/* 142 */             a += f * pa;
/* 143 */             r += f * pr;
/* 144 */             g += f * pg;
/* 145 */             b += f * pb;
/*     */           }
/*     */         }
/* 148 */         if ((unpremultiply) && (a != 0.0F) && (a != 255.0F)) {
/* 149 */           float f = 255.0F / a;
/* 150 */           r *= f;
/* 151 */           g *= f;
/* 152 */           b *= f;
/*     */         }
/* 154 */         int ia = alpha ? PixelUtils.clamp((int)(a + 0.5D)) : 255;
/* 155 */         int ir = PixelUtils.clamp((int)(r + 0.5D));
/* 156 */         int ig = PixelUtils.clamp((int)(g + 0.5D));
/* 157 */         int ib = PixelUtils.clamp((int)(b + 0.5D));
/* 158 */         outPixels[index] = (ia << 24 | ir << 16 | ig << 8 | ib);
/* 159 */         index += height;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Kernel makeKernel(float radius)
/*     */   {
/* 170 */     int r = (int)Math.ceil(radius);
/* 171 */     int rows = r * 2 + 1;
/* 172 */     float[] matrix = new float[rows];
/* 173 */     float sigma = radius / 3.0F;
/* 174 */     float sigma22 = 2.0F * sigma * sigma;
/* 175 */     float sigmaPi2 = 6.283186F * sigma;
/* 176 */     float sqrtSigmaPi2 = (float)Math.sqrt(sigmaPi2);
/* 177 */     float radius2 = radius * radius;
/* 178 */     float total = 0.0F;
/* 179 */     int index = 0;
/* 180 */     for (int row = -r; row <= r; row++) {
/* 181 */       float distance = row * row;
/* 182 */       if (distance > radius2)
/* 183 */         matrix[index] = 0.0F;
/*     */       else
/* 185 */         matrix[index] = ((float)Math.exp(-distance / sigma22) / sqrtSigmaPi2);
/* 186 */       total += matrix[index];
/* 187 */       index++;
/*     */     }
/* 189 */     for (int i = 0; i < rows; i++) {
/* 190 */       matrix[i] /= total;
/*     */     }
/* 192 */     return new Kernel(rows, 1, matrix);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 196 */     return "Blur/Gaussian Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.GaussianFilter
 * JD-Core Version:    0.6.1
 */