/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class PinchFilter extends TransformFilter
/*     */ {
/*  28 */   private float angle = 0.0F;
/*  29 */   private float centreX = 0.5F;
/*  30 */   private float centreY = 0.5F;
/*  31 */   private float radius = 100.0F;
/*  32 */   private float amount = 0.5F;
/*     */ 
/*  34 */   private float radius2 = 0.0F;
/*     */   private float icentreX;
/*     */   private float icentreY;
/*     */   private float width;
/*     */   private float height;
/*     */ 
/*     */   public void setAngle(float angle)
/*     */   {
/*  49 */     this.angle = angle;
/*     */   }
/*     */ 
/*     */   public float getAngle()
/*     */   {
/*  58 */     return this.angle;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/*  67 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/*  76 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/*  85 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/*  94 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 103 */     this.centreX = (float)centre.getX();
/* 104 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 113 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public void setRadius(float radius)
/*     */   {
/* 123 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/* 132 */     return this.radius;
/*     */   }
/*     */ 
/*     */   public void setAmount(float amount)
/*     */   {
/* 143 */     this.amount = amount;
/*     */   }
/*     */ 
/*     */   public float getAmount()
/*     */   {
/* 152 */     return this.amount;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 156 */     this.width = src.getWidth();
/* 157 */     this.height = src.getHeight();
/* 158 */     this.icentreX = (this.width * this.centreX);
/* 159 */     this.icentreY = (this.height * this.centreY);
/* 160 */     if (this.radius == 0.0F)
/* 161 */       this.radius = Math.min(this.icentreX, this.icentreY);
/* 162 */     this.radius2 = (this.radius * this.radius);
/* 163 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 167 */     float dx = x - this.icentreX;
/* 168 */     float dy = y - this.icentreY;
/* 169 */     float distance = dx * dx + dy * dy;
/*     */ 
/* 171 */     if ((distance > this.radius2) || (distance == 0.0F)) {
/* 172 */       out[0] = x;
/* 173 */       out[1] = y;
/*     */     } else {
/* 175 */       float d = (float)Math.sqrt(distance / this.radius2);
/* 176 */       float t = (float)Math.pow(Math.sin(1.570796326794897D * d), -this.amount);
/*     */ 
/* 178 */       dx *= t;
/* 179 */       dy *= t;
/*     */ 
/* 181 */       float e = 1.0F - d;
/* 182 */       float a = this.angle * e * e;
/*     */ 
/* 184 */       float s = (float)Math.sin(a);
/* 185 */       float c = (float)Math.cos(a);
/*     */ 
/* 187 */       out[0] = (this.icentreX + c * dx - s * dy);
/* 188 */       out[1] = (this.icentreY + s * dx + c * dy);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 193 */     return "Distort/Pinch...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PinchFilter
 * JD-Core Version:    0.6.1
 */