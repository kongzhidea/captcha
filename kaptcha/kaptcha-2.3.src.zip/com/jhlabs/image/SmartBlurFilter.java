/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.Kernel;
/*     */ 
/*     */ public class SmartBlurFilter extends AbstractBufferedImageOp
/*     */ {
/*  28 */   private int hRadius = 5;
/*  29 */   private int vRadius = 5;
/*  30 */   private int threshold = 10;
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  33 */     int width = src.getWidth();
/*  34 */     int height = src.getHeight();
/*     */ 
/*  36 */     if (dst == null) {
/*  37 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*  39 */     int[] inPixels = new int[width * height];
/*  40 */     int[] outPixels = new int[width * height];
/*  41 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */ 
/*  43 */     Kernel kernel = GaussianFilter.makeKernel(this.hRadius);
/*  44 */     thresholdBlur(kernel, inPixels, outPixels, width, height, true);
/*  45 */     thresholdBlur(kernel, outPixels, inPixels, height, width, true);
/*     */ 
/*  47 */     setRGB(dst, 0, 0, width, height, inPixels);
/*  48 */     return dst;
/*     */   }
/*     */ 
/*     */   private void thresholdBlur(Kernel kernel, int[] inPixels, int[] outPixels, int width, int height, boolean alpha)
/*     */   {
/*  55 */     int index = 0;
/*  56 */     float[] matrix = kernel.getKernelData(null);
/*  57 */     int cols = kernel.getWidth();
/*  58 */     int cols2 = cols / 2;
/*     */ 
/*  60 */     for (int y = 0; y < height; y++) {
/*  61 */       int ioffset = y * width;
/*  62 */       int outIndex = y;
/*  63 */       for (int x = 0; x < width; x++) {
/*  64 */         float r = 0.0F; float g = 0.0F; float b = 0.0F; float a = 0.0F;
/*  65 */         int moffset = cols2;
/*     */ 
/*  67 */         int rgb1 = inPixels[(ioffset + x)];
/*  68 */         int a1 = rgb1 >> 24 & 0xFF;
/*  69 */         int r1 = rgb1 >> 16 & 0xFF;
/*  70 */         int g1 = rgb1 >> 8 & 0xFF;
/*  71 */         int b1 = rgb1 & 0xFF;
/*  72 */         float af = 0.0F; float rf = 0.0F; float gf = 0.0F; float bf = 0.0F;
/*  73 */         for (int col = -cols2; col <= cols2; col++) {
/*  74 */           float f = matrix[(moffset + col)];
/*     */ 
/*  76 */           if (f != 0.0F) {
/*  77 */             int ix = x + col;
/*  78 */             if ((0 > ix) || (ix >= width))
/*  79 */               ix = x;
/*  80 */             int rgb2 = inPixels[(ioffset + ix)];
/*  81 */             int a2 = rgb2 >> 24 & 0xFF;
/*  82 */             int r2 = rgb2 >> 16 & 0xFF;
/*  83 */             int g2 = rgb2 >> 8 & 0xFF;
/*  84 */             int b2 = rgb2 & 0xFF;
/*     */ 
/*  87 */             int d = a1 - a2;
/*  88 */             if ((d >= -this.threshold) && (d <= this.threshold)) {
/*  89 */               a += f * a2;
/*  90 */               af += f;
/*     */             }
/*  92 */             d = r1 - r2;
/*  93 */             if ((d >= -this.threshold) && (d <= this.threshold)) {
/*  94 */               r += f * r2;
/*  95 */               rf += f;
/*     */             }
/*  97 */             d = g1 - g2;
/*  98 */             if ((d >= -this.threshold) && (d <= this.threshold)) {
/*  99 */               g += f * g2;
/* 100 */               gf += f;
/*     */             }
/* 102 */             d = b1 - b2;
/* 103 */             if ((d >= -this.threshold) && (d <= this.threshold)) {
/* 104 */               b += f * b2;
/* 105 */               bf += f;
/*     */             }
/*     */           }
/*     */         }
/* 109 */         a = af == 0.0F ? a1 : a / af;
/* 110 */         r = rf == 0.0F ? r1 : r / rf;
/* 111 */         g = gf == 0.0F ? g1 : g / gf;
/* 112 */         b = bf == 0.0F ? b1 : b / bf;
/* 113 */         int ia = alpha ? PixelUtils.clamp((int)(a + 0.5D)) : 255;
/* 114 */         int ir = PixelUtils.clamp((int)(r + 0.5D));
/* 115 */         int ig = PixelUtils.clamp((int)(g + 0.5D));
/* 116 */         int ib = PixelUtils.clamp((int)(b + 0.5D));
/* 117 */         outPixels[outIndex] = (ia << 24 | ir << 16 | ig << 8 | ib);
/* 118 */         outIndex += height;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHRadius(int hRadius)
/*     */   {
/* 130 */     this.hRadius = hRadius;
/*     */   }
/*     */ 
/*     */   public int getHRadius()
/*     */   {
/* 139 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setVRadius(int vRadius)
/*     */   {
/* 149 */     this.vRadius = vRadius;
/*     */   }
/*     */ 
/*     */   public int getVRadius()
/*     */   {
/* 158 */     return this.vRadius;
/*     */   }
/*     */ 
/*     */   public void setRadius(int radius)
/*     */   {
/* 168 */     this.hRadius = (this.vRadius = radius);
/*     */   }
/*     */ 
/*     */   public int getRadius()
/*     */   {
/* 177 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int threshold)
/*     */   {
/* 186 */     this.threshold = threshold;
/*     */   }
/*     */ 
/*     */   public int getThreshold()
/*     */   {
/* 195 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 199 */     return "Blur/Smart Blur...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SmartBlurFilter
 * JD-Core Version:    0.6.1
 */