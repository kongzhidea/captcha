/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.Rectangle2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class PerspectiveFilter extends TransformFilter
/*     */ {
/*     */   private float x0;
/*     */   private float y0;
/*     */   private float x1;
/*     */   private float y1;
/*     */   private float x2;
/*     */   private float y2;
/*     */   private float x3;
/*     */   private float y3;
/*     */   private float dx1;
/*     */   private float dy1;
/*     */   private float dx2;
/*     */   private float dy2;
/*     */   private float dx3;
/*     */   private float dy3;
/*     */   private float A;
/*     */   private float B;
/*     */   private float C;
/*     */   private float D;
/*     */   private float E;
/*     */   private float F;
/*     */   private float G;
/*     */   private float H;
/*     */   private float I;
/*     */   private float a11;
/*     */   private float a12;
/*     */   private float a13;
/*     */   private float a21;
/*     */   private float a22;
/*     */   private float a23;
/*     */   private float a31;
/*     */   private float a32;
/*     */   private float a33;
/*     */   private boolean scaled;
/*  35 */   private boolean clip = false;
/*     */ 
/*     */   public PerspectiveFilter()
/*     */   {
/*  41 */     this(0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public PerspectiveFilter(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3)
/*     */   {
/*  56 */     unitSquareToQuad(x0, y0, x1, y1, x2, y2, x3, y3);
/*     */   }
/*     */ 
/*     */   public void setClip(boolean clip) {
/*  60 */     this.clip = clip;
/*     */   }
/*     */ 
/*     */   public boolean getClip() {
/*  64 */     return this.clip;
/*     */   }
/*     */ 
/*     */   public void setCorners(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3)
/*     */   {
/*  81 */     unitSquareToQuad(x0, y0, x1, y1, x2, y2, x3, y3);
/*  82 */     this.scaled = true;
/*     */   }
/*     */ 
/*     */   public void unitSquareToQuad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3)
/*     */   {
/*  98 */     this.x0 = x0;
/*  99 */     this.y0 = y0;
/* 100 */     this.x1 = x1;
/* 101 */     this.y1 = y1;
/* 102 */     this.x2 = x2;
/* 103 */     this.y2 = y2;
/* 104 */     this.x3 = x3;
/* 105 */     this.y3 = y3;
/*     */ 
/* 107 */     this.dx1 = (x1 - x2);
/* 108 */     this.dy1 = (y1 - y2);
/* 109 */     this.dx2 = (x3 - x2);
/* 110 */     this.dy2 = (y3 - y2);
/* 111 */     this.dx3 = (x0 - x1 + x2 - x3);
/* 112 */     this.dy3 = (y0 - y1 + y2 - y3);
/*     */ 
/* 114 */     if ((this.dx3 == 0.0F) && (this.dy3 == 0.0F)) {
/* 115 */       this.a11 = (x1 - x0);
/* 116 */       this.a21 = (x2 - x1);
/* 117 */       this.a31 = x0;
/* 118 */       this.a12 = (y1 - y0);
/* 119 */       this.a22 = (y2 - y1);
/* 120 */       this.a32 = y0;
/* 121 */       this.a13 = (this.a23 = 0.0F);
/*     */     } else {
/* 123 */       this.a13 = ((this.dx3 * this.dy2 - this.dx2 * this.dy3) / (this.dx1 * this.dy2 - this.dy1 * this.dx2));
/* 124 */       this.a23 = ((this.dx1 * this.dy3 - this.dy1 * this.dx3) / (this.dx1 * this.dy2 - this.dy1 * this.dx2));
/* 125 */       this.a11 = (x1 - x0 + this.a13 * x1);
/* 126 */       this.a21 = (x3 - x0 + this.a23 * x3);
/* 127 */       this.a31 = x0;
/* 128 */       this.a12 = (y1 - y0 + this.a13 * y1);
/* 129 */       this.a22 = (y3 - y0 + this.a23 * y3);
/* 130 */       this.a32 = y0;
/*     */     }
/* 132 */     this.a33 = 1.0F;
/* 133 */     this.scaled = false;
/*     */   }
/*     */ 
/*     */   public void quadToUnitSquare(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3)
/*     */   {
/* 149 */     unitSquareToQuad(x0, y0, x1, y1, x2, y2, x3, y3);
/*     */ 
/* 152 */     float ta11 = this.a22 * this.a33 - this.a32 * this.a23;
/* 153 */     float ta21 = this.a32 * this.a13 - this.a12 * this.a33;
/* 154 */     float ta31 = this.a12 * this.a23 - this.a22 * this.a13;
/* 155 */     float ta12 = this.a31 * this.a23 - this.a21 * this.a33;
/* 156 */     float ta22 = this.a11 * this.a33 - this.a31 * this.a13;
/* 157 */     float ta32 = this.a21 * this.a13 - this.a11 * this.a23;
/* 158 */     float ta13 = this.a21 * this.a32 - this.a31 * this.a22;
/* 159 */     float ta23 = this.a31 * this.a12 - this.a11 * this.a32;
/* 160 */     float ta33 = this.a11 * this.a22 - this.a21 * this.a12;
/* 161 */     float f = 1.0F / ta33;
/*     */ 
/* 163 */     this.a11 = (ta11 * f);
/* 164 */     this.a21 = (ta12 * f);
/* 165 */     this.a31 = (ta13 * f);
/* 166 */     this.a12 = (ta21 * f);
/* 167 */     this.a22 = (ta22 * f);
/* 168 */     this.a32 = (ta23 * f);
/* 169 */     this.a13 = (ta31 * f);
/* 170 */     this.a23 = (ta32 * f);
/* 171 */     this.a33 = 1.0F;
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 175 */     this.A = (this.a22 * this.a33 - this.a32 * this.a23);
/* 176 */     this.B = (this.a31 * this.a23 - this.a21 * this.a33);
/* 177 */     this.C = (this.a21 * this.a32 - this.a31 * this.a22);
/* 178 */     this.D = (this.a32 * this.a13 - this.a12 * this.a33);
/* 179 */     this.E = (this.a11 * this.a33 - this.a31 * this.a13);
/* 180 */     this.F = (this.a31 * this.a12 - this.a11 * this.a32);
/* 181 */     this.G = (this.a12 * this.a23 - this.a22 * this.a13);
/* 182 */     this.H = (this.a21 * this.a13 - this.a11 * this.a23);
/* 183 */     this.I = (this.a11 * this.a22 - this.a21 * this.a12);
/* 184 */     if (!this.scaled) {
/* 185 */       int width = src.getWidth();
/* 186 */       int height = src.getHeight();
/* 187 */       float invWidth = 1.0F / width;
/* 188 */       float invHeight = 1.0F / height;
/*     */ 
/* 190 */       this.A *= invWidth;
/* 191 */       this.D *= invWidth;
/* 192 */       this.G *= invWidth;
/* 193 */       this.B *= invHeight;
/* 194 */       this.E *= invHeight;
/* 195 */       this.H *= invHeight;
/*     */     }
/*     */ 
/* 198 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   protected void transformSpace(Rectangle rect) {
/* 202 */     if (this.scaled) {
/* 203 */       rect.x = (int)Math.min(Math.min(this.x0, this.x1), Math.min(this.x2, this.x3));
/* 204 */       rect.y = (int)Math.min(Math.min(this.y0, this.y1), Math.min(this.y2, this.y3));
/* 205 */       rect.width = ((int)Math.max(Math.max(this.x0, this.x1), Math.max(this.x2, this.x3)) - rect.x);
/* 206 */       rect.height = ((int)Math.max(Math.max(this.y0, this.y1), Math.max(this.y2, this.y3)) - rect.y);
/* 207 */       return;
/*     */     }
/* 209 */     if (!this.clip) {
/* 210 */       float w = (float)rect.getWidth(); float h = (float)rect.getHeight();
/* 211 */       Rectangle r = new Rectangle();
/* 212 */       r.add(getPoint2D(new Point2D.Float(0.0F, 0.0F), null));
/* 213 */       r.add(getPoint2D(new Point2D.Float(w, 0.0F), null));
/* 214 */       r.add(getPoint2D(new Point2D.Float(0.0F, h), null));
/* 215 */       r.add(getPoint2D(new Point2D.Float(w, h), null));
/* 216 */       rect.setRect(r);
/*     */     }
/*     */   }
/*     */ 
/*     */   public float getOriginX()
/*     */   {
/* 225 */     return this.x0 - (int)Math.min(Math.min(this.x0, this.x1), Math.min(this.x2, this.x3));
/*     */   }
/*     */ 
/*     */   public float getOriginY()
/*     */   {
/* 233 */     return this.y0 - (int)Math.min(Math.min(this.y0, this.y1), Math.min(this.y2, this.y3));
/*     */   }
/*     */ 
/*     */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 237 */     if (this.clip)
/* 238 */       return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/* 239 */     float w = src.getWidth(); float h = src.getHeight();
/* 240 */     Rectangle2D r = new Rectangle2D.Float();
/* 241 */     r.add(getPoint2D(new Point2D.Float(0.0F, 0.0F), null));
/* 242 */     r.add(getPoint2D(new Point2D.Float(w, 0.0F), null));
/* 243 */     r.add(getPoint2D(new Point2D.Float(0.0F, h), null));
/* 244 */     r.add(getPoint2D(new Point2D.Float(w, h), null));
/* 245 */     return r;
/*     */   }
/*     */ 
/*     */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 249 */     if (dstPt == null)
/* 250 */       dstPt = new Point2D.Float();
/* 251 */     float x = (float)srcPt.getX();
/* 252 */     float y = (float)srcPt.getY();
/* 253 */     float f = 1.0F / (x * this.a13 + y * this.a23 + this.a33);
/* 254 */     dstPt.setLocation((x * this.a11 + y * this.a21 + this.a31) * f, (x * this.a12 + y * this.a22 + this.a32) * f);
/* 255 */     return dstPt;
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 259 */     out[0] = (this.originalSpace.width * (this.A * x + this.B * y + this.C) / (this.G * x + this.H * y + this.I));
/* 260 */     out[1] = (this.originalSpace.height * (this.D * x + this.E * y + this.F) / (this.G * x + this.H * y + this.I));
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 264 */     return "Distort/Perspective...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.PerspectiveFilter
 * JD-Core Version:    0.6.1
 */