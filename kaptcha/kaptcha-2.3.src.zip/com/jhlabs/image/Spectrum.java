/*    */ package com.jhlabs.image;
/*    */ 
/*    */ public class Spectrum
/*    */ {
/*    */   private static int adjust(float color, float factor, float gamma)
/*    */   {
/* 25 */     if (color == 0.0D)
/* 26 */       return 0;
/* 27 */     return (int)Math.round(255.0D * Math.pow(color * factor, gamma));
/*    */   }
/*    */ 
/*    */   public static int wavelengthToRGB(float wavelength)
/*    */   {
/* 36 */     float gamma = 0.8F;
/*    */ 
/* 39 */     int w = (int)wavelength;
/*    */     float b;
/*    */     float r;
/*    */     float g;
/*    */     float b;
/* 40 */     if (w < 380) {
/* 41 */       float r = 0.0F;
/* 42 */       float g = 0.0F;
/* 43 */       b = 0.0F;
/*    */     }
/*    */     else
/*    */     {
/*    */       float b;
/* 44 */       if (w < 440) {
/* 45 */         float r = -(wavelength - 440.0F) / 60.0F;
/* 46 */         float g = 0.0F;
/* 47 */         b = 1.0F;
/*    */       }
/*    */       else
/*    */       {
/*    */         float b;
/* 48 */         if (w < 490) {
/* 49 */           float r = 0.0F;
/* 50 */           float g = (wavelength - 440.0F) / 50.0F;
/* 51 */           b = 1.0F;
/*    */         }
/*    */         else
/*    */         {
/*    */           float b;
/* 52 */           if (w < 510) {
/* 53 */             float r = 0.0F;
/* 54 */             float g = 1.0F;
/* 55 */             b = -(wavelength - 510.0F) / 20.0F;
/*    */           }
/*    */           else
/*    */           {
/*    */             float b;
/* 56 */             if (w < 580) {
/* 57 */               float r = (wavelength - 510.0F) / 70.0F;
/* 58 */               float g = 1.0F;
/* 59 */               b = 0.0F;
/*    */             }
/*    */             else
/*    */             {
/*    */               float b;
/* 60 */               if (w < 645) {
/* 61 */                 float r = 1.0F;
/* 62 */                 float g = -(wavelength - 645.0F) / 65.0F;
/* 63 */                 b = 0.0F;
/*    */               }
/*    */               else
/*    */               {
/*    */                 float b;
/* 64 */                 if (w <= 780) {
/* 65 */                   float r = 1.0F;
/* 66 */                   float g = 0.0F;
/* 67 */                   b = 0.0F;
/*    */                 } else {
/* 69 */                   r = 0.0F;
/* 70 */                   g = 0.0F;
/* 71 */                   b = 0.0F;
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     float factor;
/*    */     float factor;
/* 75 */     if ((380 <= w) && (w <= 419)) {
/* 76 */       factor = 0.3F + 0.7F * (wavelength - 380.0F) / 40.0F;
/*    */     }
/*    */     else
/*    */     {
/*    */       float factor;
/* 77 */       if ((420 <= w) && (w <= 700)) {
/* 78 */         factor = 1.0F;
/*    */       }
/*    */       else
/*    */       {
/*    */         float factor;
/* 79 */         if ((701 <= w) && (w <= 780))
/* 80 */           factor = 0.3F + 0.7F * (780.0F - wavelength) / 80.0F;
/*    */         else
/* 82 */           factor = 0.0F; 
/*    */       }
/*    */     }
/* 84 */     int ir = adjust(r, factor, gamma);
/* 85 */     int ig = adjust(g, factor, gamma);
/* 86 */     int ib = adjust(b, factor, gamma);
/*    */ 
/* 88 */     return 0xFF000000 | ir << 16 | ig << 8 | ib;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.Spectrum
 * JD-Core Version:    0.6.1
 */