/*     */ package com.jhlabs.image;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Point2D.Float;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class SphereFilter extends TransformFilter
/*     */ {
/*  28 */   private float a = 0.0F;
/*  29 */   private float b = 0.0F;
/*  30 */   private float a2 = 0.0F;
/*  31 */   private float b2 = 0.0F;
/*  32 */   private float centreX = 0.5F;
/*  33 */   private float centreY = 0.5F;
/*  34 */   private float refractionIndex = 1.5F;
/*     */   private float icentreX;
/*     */   private float icentreY;
/*     */ 
/*     */   public SphereFilter()
/*     */   {
/*  40 */     setEdgeAction(1);
/*  41 */     setRadius(100.0F);
/*     */   }
/*     */ 
/*     */   public void setRefractionIndex(float refractionIndex)
/*     */   {
/*  50 */     this.refractionIndex = refractionIndex;
/*     */   }
/*     */ 
/*     */   public float getRefractionIndex()
/*     */   {
/*  59 */     return this.refractionIndex;
/*     */   }
/*     */ 
/*     */   public void setRadius(float r)
/*     */   {
/*  69 */     this.a = r;
/*  70 */     this.b = r;
/*     */   }
/*     */ 
/*     */   public float getRadius()
/*     */   {
/*  79 */     return this.a;
/*     */   }
/*     */ 
/*     */   public void setCentreX(float centreX)
/*     */   {
/*  88 */     this.centreX = centreX;
/*     */   }
/*     */ 
/*     */   public float getCentreX()
/*     */   {
/*  97 */     return this.centreX;
/*     */   }
/*     */ 
/*     */   public void setCentreY(float centreY)
/*     */   {
/* 106 */     this.centreY = centreY;
/*     */   }
/*     */ 
/*     */   public float getCentreY()
/*     */   {
/* 115 */     return this.centreY;
/*     */   }
/*     */ 
/*     */   public void setCentre(Point2D centre)
/*     */   {
/* 124 */     this.centreX = (float)centre.getX();
/* 125 */     this.centreY = (float)centre.getY();
/*     */   }
/*     */ 
/*     */   public Point2D getCentre()
/*     */   {
/* 134 */     return new Point2D.Float(this.centreX, this.centreY);
/*     */   }
/*     */ 
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 138 */     int width = src.getWidth();
/* 139 */     int height = src.getHeight();
/* 140 */     this.icentreX = (width * this.centreX);
/* 141 */     this.icentreY = (height * this.centreY);
/* 142 */     if (this.a == 0.0F)
/* 143 */       this.a = width / 2;
/* 144 */     if (this.b == 0.0F)
/* 145 */       this.b = height / 2;
/* 146 */     this.a2 = (this.a * this.a);
/* 147 */     this.b2 = (this.b * this.b);
/* 148 */     return super.filter(src, dst);
/*     */   }
/*     */ 
/*     */   protected void transformInverse(int x, int y, float[] out) {
/* 152 */     float dx = x - this.icentreX;
/* 153 */     float dy = y - this.icentreY;
/* 154 */     float x2 = dx * dx;
/* 155 */     float y2 = dy * dy;
/* 156 */     if (y2 >= this.b2 - this.b2 * x2 / this.a2) {
/* 157 */       out[0] = x;
/* 158 */       out[1] = y;
/*     */     } else {
/* 160 */       float rRefraction = 1.0F / this.refractionIndex;
/*     */ 
/* 162 */       float z = (float)Math.sqrt((1.0F - x2 / this.a2 - y2 / this.b2) * (this.a * this.b));
/* 163 */       float z2 = z * z;
/*     */ 
/* 165 */       float xAngle = (float)Math.acos(dx / Math.sqrt(x2 + z2));
/* 166 */       float angle1 = 1.570796F - xAngle;
/* 167 */       float angle2 = (float)Math.asin(Math.sin(angle1) * rRefraction);
/* 168 */       angle2 = 1.570796F - xAngle - angle2;
/* 169 */       out[0] = (x - (float)Math.tan(angle2) * z);
/*     */ 
/* 171 */       float yAngle = (float)Math.acos(dy / Math.sqrt(y2 + z2));
/* 172 */       angle1 = 1.570796F - yAngle;
/* 173 */       angle2 = (float)Math.asin(Math.sin(angle1) * rRefraction);
/* 174 */       angle2 = 1.570796F - yAngle - angle2;
/* 175 */       out[1] = (y - (float)Math.tan(angle2) * z);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 180 */     return "Distort/Sphere...";
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.SphereFilter
 * JD-Core Version:    0.6.1
 */