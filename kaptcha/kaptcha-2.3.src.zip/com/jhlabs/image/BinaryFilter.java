/*    */ package com.jhlabs.image;
/*    */ 
/*    */ import com.jhlabs.math.BinaryFunction;
/*    */ import com.jhlabs.math.BlackFunction;
/*    */ 
/*    */ public abstract class BinaryFilter extends WholeImageFilter
/*    */ {
/* 28 */   protected int newColor = -16777216;
/* 29 */   protected BinaryFunction blackFunction = new BlackFunction();
/* 30 */   protected int iterations = 1;
/*    */   protected Colormap colormap;
/*    */ 
/*    */   public void setIterations(int iterations)
/*    */   {
/* 40 */     this.iterations = iterations;
/*    */   }
/*    */ 
/*    */   public int getIterations()
/*    */   {
/* 49 */     return this.iterations;
/*    */   }
/*    */ 
/*    */   public void setColormap(Colormap colormap)
/*    */   {
/* 58 */     this.colormap = colormap;
/*    */   }
/*    */ 
/*    */   public Colormap getColormap()
/*    */   {
/* 67 */     return this.colormap;
/*    */   }
/*    */ 
/*    */   public void setNewColor(int newColor) {
/* 71 */     this.newColor = newColor;
/*    */   }
/*    */ 
/*    */   public int getNewColor() {
/* 75 */     return this.newColor;
/*    */   }
/*    */ 
/*    */   public void setBlackFunction(BinaryFunction blackFunction) {
/* 79 */     this.blackFunction = blackFunction;
/*    */   }
/*    */ 
/*    */   public BinaryFunction getBlackFunction() {
/* 83 */     return this.blackFunction;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.jhlabs.image.BinaryFilter
 * JD-Core Version:    0.6.1
 */