package com.google.code.kaptcha;

import java.awt.image.BufferedImage;

public abstract interface NoiseProducer
{
  public abstract void makeNoise(BufferedImage paramBufferedImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.NoiseProducer
 * JD-Core Version:    0.6.1
 */