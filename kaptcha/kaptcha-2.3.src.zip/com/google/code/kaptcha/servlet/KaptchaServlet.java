/*    */ package com.google.code.kaptcha.servlet;
/*    */ 
/*    */ import com.google.code.kaptcha.Producer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.servlet.Servlet;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class KaptchaServlet extends HttpServlet
/*    */   implements Servlet
/*    */ {
/* 30 */   private Properties props = new Properties();
/*    */ 
/* 32 */   private Producer kaptchaProducer = null;
/*    */ 
/* 34 */   private String sessionKeyValue = null;
/*    */ 
/*    */   public void init(ServletConfig conf)
/*    */     throws ServletException
/*    */   {
/* 43 */     super.init(conf);
/*    */ 
/* 46 */     ImageIO.setUseCache(false);
/*    */ 
/* 48 */     Enumeration initParams = conf.getInitParameterNames();
/* 49 */     while (initParams.hasMoreElements())
/*    */     {
/* 51 */       String key = (String)initParams.nextElement();
/* 52 */       String value = conf.getInitParameter(key);
/* 53 */       this.props.put(key, value);
/*    */     }
/*    */ 
/* 56 */     Config config = new Config(this.props);
/* 57 */     this.kaptchaProducer = config.getProducerImpl();
/* 58 */     this.sessionKeyValue = config.getSessionKey();
/*    */   }
/*    */ 
/*    */   public void doGet(HttpServletRequest req, HttpServletResponse resp)
/*    */     throws ServletException, IOException
/*    */   {
/* 66 */     resp.setDateHeader("Expires", 0L);
/*    */ 
/* 68 */     resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
/*    */ 
/* 70 */     resp.addHeader("Cache-Control", "post-check=0, pre-check=0");
/*    */ 
/* 72 */     resp.setHeader("Pragma", "no-cache");
/*    */ 
/* 75 */     resp.setContentType("image/jpeg");
/*    */ 
/* 78 */     String capText = this.kaptchaProducer.createText();
/*    */ 
/* 81 */     req.getSession().setAttribute(this.sessionKeyValue, capText);
/*    */ 
/* 84 */     BufferedImage bi = this.kaptchaProducer.createImage(capText);
/*    */ 
/* 86 */     ServletOutputStream out = resp.getOutputStream();
/*    */ 
/* 89 */     ImageIO.write(bi, "jpg", out);
/*    */     try
/*    */     {
/* 92 */       out.flush();
/*    */     }
/*    */     finally
/*    */     {
/* 96 */       out.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.servlet.KaptchaServlet
 * JD-Core Version:    0.6.1
 */