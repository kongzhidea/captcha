/*    */ package com.google.code.kaptcha.util;
/*    */ 
/*    */ public abstract class Configurable
/*    */ {
/* 10 */   private Config config = null;
/*    */ 
/*    */   public Config getConfig()
/*    */   {
/* 14 */     return this.config;
/*    */   }
/*    */ 
/*    */   public void setConfig(Config config)
/*    */   {
/* 19 */     this.config = config;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.util.Configurable
 * JD-Core Version:    0.6.1
 */