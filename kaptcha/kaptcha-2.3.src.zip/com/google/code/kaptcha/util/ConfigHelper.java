/*     */ package com.google.code.kaptcha.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ public class ConfigHelper
/*     */ {
/*     */   public Color getColor(String paramName, String paramValue, Color defaultColor)
/*     */   {
/*     */     Color color;
/*     */     Color color;
/*  18 */     if (("".equals(paramValue)) || (paramValue == null))
/*     */     {
/*  20 */       color = defaultColor;
/*     */     }
/*     */     else
/*     */     {
/*     */       Color color;
/*  22 */       if (paramValue.indexOf(",") > 0)
/*     */       {
/*  24 */         color = createColorFromCommaSeparatedValues(paramName, paramValue);
/*     */       }
/*     */       else
/*     */       {
/*  28 */         color = createColorFromFieldValue(paramName, paramValue);
/*     */       }
/*     */     }
/*  30 */     return color;
/*     */   }
/*     */ 
/*     */   public Color createColorFromCommaSeparatedValues(String paramName, String paramValue)
/*     */   {
/*  38 */     String[] colorValues = paramValue.split(",");
/*     */     Color color;
/*     */     try
/*     */     {
/*  41 */       int r = Integer.parseInt(colorValues[0]);
/*  42 */       int g = Integer.parseInt(colorValues[1]);
/*  43 */       int b = Integer.parseInt(colorValues[2]);
/*     */       Color color;
/*  44 */       if (colorValues.length == 4)
/*     */       {
/*  46 */         int a = Integer.parseInt(colorValues[3]);
/*  47 */         color = new Color(r, g, b, a);
/*     */       }
/*     */       else
/*     */       {
/*     */         Color color;
/*  49 */         if (colorValues.length == 3)
/*     */         {
/*  51 */           color = new Color(r, g, b);
/*     */         }
/*     */         else
/*     */         {
/*  55 */           throw new ConfigException(paramName, paramValue, "Color can only have 3 (RGB) or 4 (RGB with Alpha) values.");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/*  61 */       throw new ConfigException(paramName, paramValue, nfe);
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException aie)
/*     */     {
/*  65 */       throw new ConfigException(paramName, paramValue, aie);
/*     */     }
/*     */     catch (IllegalArgumentException iae)
/*     */     {
/*  69 */       throw new ConfigException(paramName, paramValue, iae);
/*     */     }
/*  71 */     return color;
/*     */   }
/*     */ 
/*     */   public Color createColorFromFieldValue(String paramName, String paramValue)
/*     */   {
/*     */     Color color;
/*     */     try
/*     */     {
/*  80 */       Field field = Class.forName("java.awt.Color").getField(paramValue);
/*  81 */       color = (Color)field.get(null);
/*     */     }
/*     */     catch (NoSuchFieldException nsfe)
/*     */     {
/*  85 */       throw new ConfigException(paramName, paramValue, nsfe);
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/*  89 */       throw new ConfigException(paramName, paramValue, cnfe);
/*     */     }
/*     */     catch (IllegalAccessException iae)
/*     */     {
/*  93 */       throw new ConfigException(paramName, paramValue, iae);
/*     */     }
/*  95 */     return color;
/*     */   }
/*     */ 
/*     */   public Object getClassInstance(String paramName, String paramValue, Object defaultInstance, Config config)
/*     */   {
/*     */     Object instance;
/*     */     Object instance;
/* 103 */     if (("".equals(paramValue)) || (paramValue == null))
/*     */     {
/* 105 */       instance = defaultInstance;
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 111 */         instance = Class.forName(paramValue).newInstance();
/*     */       }
/*     */       catch (IllegalAccessException iae)
/*     */       {
/* 115 */         throw new ConfigException(paramName, paramValue, iae);
/*     */       }
/*     */       catch (ClassNotFoundException cnfe)
/*     */       {
/* 119 */         throw new ConfigException(paramName, paramValue, cnfe);
/*     */       }
/*     */       catch (InstantiationException ie)
/*     */       {
/* 123 */         throw new ConfigException(paramName, paramValue, ie);
/*     */       }
/*     */     }
/*     */ 
/* 127 */     setConfigurable(instance, config);
/*     */ 
/* 129 */     return instance;
/*     */   }
/*     */ 
/*     */   public Font[] getFonts(String paramName, String paramValue, int fontSize, Font[] defaultFonts)
/*     */   {
/*     */     Font[] fonts;
/*     */     Font[] fonts;
/* 137 */     if (("".equals(paramValue)) || (paramValue == null))
/*     */     {
/* 139 */       fonts = defaultFonts;
/*     */     }
/*     */     else
/*     */     {
/* 143 */       String[] fontNames = paramValue.split(",");
/* 144 */       fonts = new Font[fontNames.length];
/* 145 */       for (int i = 0; i < fontNames.length; i++)
/*     */       {
/* 147 */         fonts[i] = new Font(fontNames[i], 1, fontSize);
/*     */       }
/*     */     }
/* 150 */     return fonts;
/*     */   }
/*     */ 
/*     */   public int getPositiveInt(String paramName, String paramValue, int defaultInt)
/*     */   {
/*     */     int intValue;
/*     */     int intValue;
/* 158 */     if (("".equals(paramValue)) || (paramValue == null))
/*     */     {
/* 160 */       intValue = defaultInt;
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 166 */         intValue = Integer.parseInt(paramValue);
/* 167 */         if (intValue < 1)
/*     */         {
/* 169 */           throw new ConfigException(paramName, paramValue, "Value must be greater than or equals to 1.");
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/* 175 */         throw new ConfigException(paramName, paramValue, nfe);
/*     */       }
/*     */     }
/* 178 */     return intValue;
/*     */   }
/*     */ 
/*     */   public char[] getChars(String paramName, String paramValue, char[] defaultChars)
/*     */   {
/*     */     char[] chars;
/*     */     char[] chars;
/* 186 */     if (("".equals(paramValue)) || (paramValue == null))
/*     */     {
/* 188 */       chars = defaultChars;
/*     */     }
/*     */     else
/*     */     {
/* 192 */       chars = paramValue.toCharArray();
/*     */     }
/* 194 */     return chars;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String paramName, String paramValue, boolean defaultValue)
/*     */   {
/*     */     boolean booleanValue;
/* 202 */     if (("yes".equals(paramValue)) || ("".equals(paramValue)) || (paramValue == null))
/*     */     {
/* 205 */       booleanValue = defaultValue;
/*     */     }
/*     */     else
/*     */     {
/*     */       boolean booleanValue;
/* 207 */       if ("no".equals(paramValue))
/*     */       {
/* 209 */         booleanValue = false;
/*     */       }
/*     */       else
/*     */       {
/* 213 */         throw new ConfigException(paramName, paramValue, "Value must be either yes or no.");
/*     */       }
/*     */     }
/*     */     boolean booleanValue;
/* 216 */     return booleanValue;
/*     */   }
/*     */ 
/*     */   private void setConfigurable(Object object, Config config)
/*     */   {
/* 222 */     if ((object instanceof Configurable))
/*     */     {
/* 224 */       ((Configurable)object).setConfig(config);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.util.ConfigHelper
 * JD-Core Version:    0.6.1
 */