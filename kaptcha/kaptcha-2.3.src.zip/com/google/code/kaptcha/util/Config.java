/*     */ package com.google.code.kaptcha.util;
/*     */ 
/*     */ import com.google.code.kaptcha.BackgroundProducer;
/*     */ import com.google.code.kaptcha.GimpyEngine;
/*     */ import com.google.code.kaptcha.NoiseProducer;
/*     */ import com.google.code.kaptcha.Producer;
/*     */ import com.google.code.kaptcha.impl.DefaultBackground;
/*     */ import com.google.code.kaptcha.impl.DefaultKaptcha;
/*     */ import com.google.code.kaptcha.impl.DefaultNoise;
/*     */ import com.google.code.kaptcha.impl.WaterRipple;
/*     */ import com.google.code.kaptcha.text.TextProducer;
/*     */ import com.google.code.kaptcha.text.WordRenderer;
/*     */ import com.google.code.kaptcha.text.impl.DefaultTextCreator;
/*     */ import com.google.code.kaptcha.text.impl.DefaultWordRenderer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class Config
/*     */ {
/*     */   private Properties properties;
/*     */   private ConfigHelper helper;
/*     */ 
/*     */   public Config(Properties properties)
/*     */   {
/*  34 */     this.properties = properties;
/*  35 */     this.helper = new ConfigHelper();
/*     */   }
/*     */ 
/*     */   public boolean isBorderDrawn()
/*     */   {
/*  41 */     String paramName = "kaptcha.border";
/*  42 */     String paramValue = this.properties.getProperty(paramName);
/*  43 */     return this.helper.getBoolean(paramName, paramValue, true);
/*     */   }
/*     */ 
/*     */   public Color getBorderColor()
/*     */   {
/*  49 */     String paramName = "kaptcha.border.color";
/*  50 */     String paramValue = this.properties.getProperty(paramName);
/*  51 */     return this.helper.getColor(paramName, paramValue, Color.BLACK);
/*     */   }
/*     */ 
/*     */   public int getBorderThickness()
/*     */   {
/*  57 */     String paramName = "kaptcha.border.thickness";
/*  58 */     String paramValue = this.properties.getProperty(paramName);
/*  59 */     return this.helper.getPositiveInt(paramName, paramValue, 1);
/*     */   }
/*     */ 
/*     */   public Producer getProducerImpl()
/*     */   {
/*  65 */     String paramName = "kaptcha.producer.impl";
/*  66 */     String paramValue = this.properties.getProperty(paramName);
/*  67 */     Producer producer = (Producer)this.helper.getClassInstance(paramName, paramValue, new DefaultKaptcha(), this);
/*  68 */     return producer;
/*     */   }
/*     */ 
/*     */   public TextProducer getTextProducerImpl()
/*     */   {
/*  74 */     String paramName = "kaptcha.textproducer.impl";
/*  75 */     String paramValue = this.properties.getProperty(paramName);
/*  76 */     TextProducer textProducer = (TextProducer)this.helper.getClassInstance(paramName, paramValue, new DefaultTextCreator(), this);
/*     */ 
/*  78 */     return textProducer;
/*     */   }
/*     */ 
/*     */   public char[] getTextProducerCharString()
/*     */   {
/*  84 */     String paramName = "kaptcha.textproducer.char.string";
/*  85 */     String paramValue = this.properties.getProperty(paramName);
/*  86 */     return this.helper.getChars(paramName, paramValue, "abcde2345678gfynmnpwx".toCharArray());
/*     */   }
/*     */ 
/*     */   public int getTextProducerCharLength()
/*     */   {
/*  92 */     String paramName = "kaptcha.textproducer.char.length";
/*  93 */     String paramValue = this.properties.getProperty(paramName);
/*  94 */     return this.helper.getPositiveInt(paramName, paramValue, 5);
/*     */   }
/*     */ 
/*     */   public Font[] getTextProducerFonts(int fontSize)
/*     */   {
/* 100 */     String paramName = "kaptcha.textproducer.font.names";
/* 101 */     String paramValue = this.properties.getProperty(paramName);
/* 102 */     return this.helper.getFonts(paramName, paramValue, fontSize, new Font[] { new Font("Arial", 1, fontSize), new Font("Courier", 1, fontSize) });
/*     */   }
/*     */ 
/*     */   public int getTextProducerFontSize()
/*     */   {
/* 110 */     String paramName = "kaptcha.textproducer.font.size";
/* 111 */     String paramValue = this.properties.getProperty(paramName);
/* 112 */     return this.helper.getPositiveInt(paramName, paramValue, 40);
/*     */   }
/*     */ 
/*     */   public Color getTextProducerFontColor()
/*     */   {
/* 118 */     String paramName = "kaptcha.textproducer.font.color";
/* 119 */     String paramValue = this.properties.getProperty(paramName);
/* 120 */     return this.helper.getColor(paramName, paramValue, Color.BLACK);
/*     */   }
/*     */ 
/*     */   public NoiseProducer getNoiseImpl()
/*     */   {
/* 125 */     String paramName = "kaptcha.noise.impl";
/* 126 */     String paramValue = this.properties.getProperty(paramName);
/* 127 */     NoiseProducer noiseProducer = (NoiseProducer)this.helper.getClassInstance(paramName, paramValue, new DefaultNoise(), this);
/*     */ 
/* 129 */     return noiseProducer;
/*     */   }
/*     */ 
/*     */   public Color getNoiseColor()
/*     */   {
/* 135 */     String paramName = "kaptcha.noise.color";
/* 136 */     String paramValue = this.properties.getProperty(paramName);
/* 137 */     return this.helper.getColor(paramName, paramValue, Color.BLACK);
/*     */   }
/*     */ 
/*     */   public GimpyEngine getObscurificatorImpl()
/*     */   {
/* 143 */     String paramName = "kaptcha.obscurificator.impl";
/* 144 */     String paramValue = this.properties.getProperty(paramName);
/* 145 */     GimpyEngine gimpyEngine = (GimpyEngine)this.helper.getClassInstance(paramName, paramValue, new WaterRipple(), this);
/* 146 */     return gimpyEngine;
/*     */   }
/*     */ 
/*     */   public WordRenderer getWordRendererImpl()
/*     */   {
/* 152 */     String paramName = "kaptcha.word.impl";
/* 153 */     String paramValue = this.properties.getProperty(paramName);
/* 154 */     WordRenderer wordRenderer = (WordRenderer)this.helper.getClassInstance(paramName, paramValue, new DefaultWordRenderer(), this);
/*     */ 
/* 156 */     return wordRenderer;
/*     */   }
/*     */ 
/*     */   public BackgroundProducer getBackgroundImpl()
/*     */   {
/* 162 */     String paramName = "kaptcha.background.impl";
/* 163 */     String paramValue = this.properties.getProperty(paramName);
/* 164 */     BackgroundProducer backgroundProducer = (BackgroundProducer)this.helper.getClassInstance(paramName, paramValue, new DefaultBackground(), this);
/*     */ 
/* 166 */     return backgroundProducer;
/*     */   }
/*     */ 
/*     */   public Color getBackgroundColorFrom()
/*     */   {
/* 172 */     String paramName = "kaptcha.background.clear.from";
/* 173 */     String paramValue = this.properties.getProperty(paramName);
/* 174 */     return this.helper.getColor(paramName, paramValue, Color.LIGHT_GRAY);
/*     */   }
/*     */ 
/*     */   public Color getBackgroundColorTo()
/*     */   {
/* 180 */     String paramName = "kaptcha.background.clear.to";
/* 181 */     String paramValue = this.properties.getProperty(paramName);
/* 182 */     return this.helper.getColor(paramName, paramValue, Color.WHITE);
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 188 */     String paramName = "kaptcha.image.width";
/* 189 */     String paramValue = this.properties.getProperty(paramName);
/* 190 */     return this.helper.getPositiveInt(paramName, paramValue, 200);
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 196 */     String paramName = "kaptcha.image.height";
/* 197 */     String paramValue = this.properties.getProperty(paramName);
/* 198 */     return this.helper.getPositiveInt(paramName, paramValue, 50);
/*     */   }
/*     */ 
/*     */   public String getSessionKey()
/*     */   {
/* 207 */     return this.properties.getProperty("kaptcha.session.key", "KAPTCHA_SESSION_KEY");
/*     */   }
/*     */ 
/*     */   public Properties getProperties()
/*     */   {
/* 213 */     return this.properties;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.util.Config
 * JD-Core Version:    0.6.1
 */