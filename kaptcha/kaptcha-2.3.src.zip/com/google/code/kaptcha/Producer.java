package com.google.code.kaptcha;

import java.awt.image.BufferedImage;

public abstract interface Producer
{
  public abstract BufferedImage createImage(String paramString);

  public abstract String createText();
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.Producer
 * JD-Core Version:    0.6.1
 */