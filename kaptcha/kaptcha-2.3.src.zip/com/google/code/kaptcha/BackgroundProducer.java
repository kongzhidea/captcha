package com.google.code.kaptcha;

import java.awt.image.BufferedImage;

public abstract interface BackgroundProducer
{
  public abstract BufferedImage addBackground(BufferedImage paramBufferedImage);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.BackgroundProducer
 * JD-Core Version:    0.6.1
 */