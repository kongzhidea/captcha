/*    */ package com.google.code.kaptcha.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.BackgroundProducer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import java.awt.Color;
/*    */ import java.awt.GradientPaint;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.geom.Rectangle2D.Double;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class DefaultBackground extends Configurable
/*    */   implements BackgroundProducer
/*    */ {
/*    */   public BufferedImage addBackground(BufferedImage baseImage)
/*    */   {
/* 26 */     Color colorFrom = getConfig().getBackgroundColorFrom();
/* 27 */     Color colorTo = getConfig().getBackgroundColorTo();
/*    */ 
/* 29 */     int width = baseImage.getWidth();
/* 30 */     int height = baseImage.getHeight();
/*    */ 
/* 33 */     BufferedImage imageWithBackground = new BufferedImage(width, height, 1);
/*    */ 
/* 36 */     Graphics2D graph = (Graphics2D)imageWithBackground.getGraphics();
/* 37 */     RenderingHints hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/*    */ 
/* 41 */     hints.add(new RenderingHints(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY));
/*    */ 
/* 43 */     hints.add(new RenderingHints(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY));
/*    */ 
/* 46 */     hints.add(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
/*    */ 
/* 49 */     graph.setRenderingHints(hints);
/*    */ 
/* 51 */     GradientPaint paint = new GradientPaint(0.0F, 0.0F, colorFrom, width, height, colorTo);
/*    */ 
/* 53 */     graph.setPaint(paint);
/* 54 */     graph.fill(new Rectangle2D.Double(0.0D, 0.0D, width, height));
/*    */ 
/* 57 */     graph.drawImage(baseImage, 0, 0, null);
/*    */ 
/* 59 */     return imageWithBackground;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.DefaultBackground
 * JD-Core Version:    0.6.1
 */