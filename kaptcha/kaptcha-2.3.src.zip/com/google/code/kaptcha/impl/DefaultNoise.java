/*    */ package com.google.code.kaptcha.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.NoiseProducer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.geom.CubicCurve2D;
/*    */ import java.awt.geom.CubicCurve2D.Float;
/*    */ import java.awt.geom.PathIterator;
/*    */ import java.awt.geom.Point2D;
/*    */ import java.awt.geom.Point2D.Float;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class DefaultNoise extends Configurable
/*    */   implements NoiseProducer
/*    */ {
/*    */   public void makeNoise(BufferedImage image, float factorOne, float factorTwo, float factorThree, float factorFour)
/*    */   {
/* 36 */     Color color = getConfig().getNoiseColor();
/*    */ 
/* 39 */     int width = image.getWidth();
/* 40 */     int height = image.getHeight();
/*    */ 
/* 43 */     Point2D[] pts = null;
/* 44 */     Random rand = new Random();
/*    */ 
/* 47 */     CubicCurve2D cc = new CubicCurve2D.Float(width * factorOne, height * rand.nextFloat(), width * factorTwo, height * rand.nextFloat(), width * factorThree, height * rand.nextFloat(), width * factorFour, height * rand.nextFloat());
/*    */ 
/* 54 */     PathIterator pi = cc.getPathIterator(null, 2.0D);
/* 55 */     Point2D[] tmp = new Point2D['È'];
/* 56 */     int i = 0;
/*    */ 
/* 59 */     while (!pi.isDone())
/*    */     {
/* 61 */       float[] coords = new float[6];
/* 62 */       switch (pi.currentSegment(coords))
/*    */       {
/*    */       case 0:
/*    */       case 1:
/* 66 */         tmp[i] = new Point2D.Float(coords[0], coords[1]);
/*    */       }
/* 68 */       i++;
/* 69 */       pi.next();
/*    */     }
/*    */ 
/* 72 */     pts = new Point2D[i];
/* 73 */     System.arraycopy(tmp, 0, pts, 0, i);
/*    */ 
/* 75 */     Graphics2D graph = (Graphics2D)image.getGraphics();
/* 76 */     graph.setRenderingHints(new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON));
/*    */ 
/* 80 */     graph.setColor(color);
/*    */ 
/* 83 */     for (i = 0; i < pts.length - 1; i++)
/*    */     {
/* 85 */       if (i < 3)
/* 86 */         graph.setStroke(new BasicStroke(0.9F * 4 - i));
/* 87 */       graph.drawLine((int)pts[i].getX(), (int)pts[i].getY(), (int)pts[(i + 1)].getX(), (int)pts[(i + 1)].getY());
/*    */     }
/*    */ 
/* 91 */     graph.dispose();
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.DefaultNoise
 * JD-Core Version:    0.6.1
 */