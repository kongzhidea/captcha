package com.google.code.kaptcha.impl;

import com.google.code.kaptcha.NoiseProducer;
import com.google.code.kaptcha.util.Configurable;
import java.awt.image.BufferedImage;

public class NoNoise extends Configurable
  implements NoiseProducer
{
  public void makeNoise(BufferedImage image, float factorOne, float factorTwo, float factorThree, float factorFour)
  {
  }
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.NoNoise
 * JD-Core Version:    0.6.1
 */