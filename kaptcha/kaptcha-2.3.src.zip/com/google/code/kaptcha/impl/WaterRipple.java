/*    */ package com.google.code.kaptcha.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.GimpyEngine;
/*    */ import com.google.code.kaptcha.NoiseProducer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import com.jhlabs.image.RippleFilter;
/*    */ import com.jhlabs.image.WaterFilter;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class WaterRipple extends Configurable
/*    */   implements GimpyEngine
/*    */ {
/*    */   public BufferedImage getDistortedImage(BufferedImage baseImage)
/*    */   {
/* 26 */     NoiseProducer noiseProducer = getConfig().getNoiseImpl();
/* 27 */     BufferedImage distortedImage = new BufferedImage(baseImage.getWidth(), baseImage.getHeight(), 2);
/*    */ 
/* 30 */     Graphics2D graphics = (Graphics2D)distortedImage.getGraphics();
/*    */ 
/* 32 */     RippleFilter rippleFilter = new RippleFilter();
/* 33 */     rippleFilter.setWaveType(0);
/* 34 */     rippleFilter.setXAmplitude(2.6F);
/* 35 */     rippleFilter.setYAmplitude(1.7F);
/* 36 */     rippleFilter.setXWavelength(15.0F);
/* 37 */     rippleFilter.setYWavelength(5.0F);
/* 38 */     rippleFilter.setEdgeAction(0);
/*    */ 
/* 40 */     WaterFilter waterFilter = new WaterFilter();
/* 41 */     waterFilter.setAmplitude(1.5F);
/* 42 */     waterFilter.setPhase(10.0F);
/* 43 */     waterFilter.setWavelength(2.0F);
/*    */ 
/* 45 */     BufferedImage effectImage = waterFilter.filter(baseImage, null);
/* 46 */     effectImage = rippleFilter.filter(effectImage, null);
/*    */ 
/* 48 */     graphics.drawImage(effectImage, 0, 0, null, null);
/*    */ 
/* 50 */     graphics.dispose();
/*    */ 
/* 52 */     noiseProducer.makeNoise(distortedImage, 0.1F, 0.1F, 0.25F, 0.25F);
/* 53 */     noiseProducer.makeNoise(distortedImage, 0.1F, 0.25F, 0.5F, 0.9F);
/* 54 */     return distortedImage;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.WaterRipple
 * JD-Core Version:    0.6.1
 */