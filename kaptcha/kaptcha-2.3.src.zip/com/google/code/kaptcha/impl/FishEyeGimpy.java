/*     */ package com.google.code.kaptcha.impl;
/*     */ 
/*     */ import com.google.code.kaptcha.GimpyEngine;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ public class FishEyeGimpy
/*     */   implements GimpyEngine
/*     */ {
/*     */   public BufferedImage getDistortedImage(BufferedImage baseImage)
/*     */   {
/*  24 */     Graphics2D graph = (Graphics2D)baseImage.getGraphics();
/*  25 */     int imageHeight = baseImage.getHeight();
/*  26 */     int imageWidth = baseImage.getWidth();
/*     */ 
/*  29 */     int horizontalLines = imageHeight / 7;
/*  30 */     int verticalLines = imageWidth / 7;
/*     */ 
/*  33 */     int horizontalGaps = imageHeight / (horizontalLines + 1);
/*  34 */     int verticalGaps = imageWidth / (verticalLines + 1);
/*     */ 
/*  37 */     for (int i = horizontalGaps; i < imageHeight; i += horizontalGaps)
/*     */     {
/*  39 */       graph.setColor(Color.blue);
/*  40 */       graph.drawLine(0, i, imageWidth, i);
/*     */     }
/*     */ 
/*  45 */     for (int i = verticalGaps; i < imageWidth; i += verticalGaps)
/*     */     {
/*  47 */       graph.setColor(Color.red);
/*  48 */       graph.drawLine(i, 0, i, imageHeight);
/*     */     }
/*     */ 
/*  54 */     int[] pix = new int[imageHeight * imageWidth];
/*  55 */     int j = 0;
/*     */ 
/*  57 */     for (int j1 = 0; j1 < imageWidth; j1++)
/*     */     {
/*  59 */       for (int k1 = 0; k1 < imageHeight; k1++)
/*     */       {
/*  61 */         pix[j] = baseImage.getRGB(j1, k1);
/*  62 */         j++;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  67 */     double distance = ranInt(imageWidth / 4, imageWidth / 3);
/*     */ 
/*  70 */     int widthMiddle = baseImage.getWidth() / 2;
/*  71 */     int heightMiddle = baseImage.getHeight() / 2;
/*     */ 
/*  74 */     for (int x = 0; x < baseImage.getWidth(); x++)
/*     */     {
/*  76 */       for (int y = 0; y < baseImage.getHeight(); y++)
/*     */       {
/*  79 */         int relX = x - widthMiddle;
/*  80 */         int relY = y - heightMiddle;
/*     */ 
/*  82 */         double d1 = Math.sqrt(relX * relX + relY * relY);
/*  83 */         if (d1 < distance)
/*     */         {
/*  86 */           int j2 = widthMiddle + (int)(fishEyeFormula(d1 / distance) * distance / d1 * x - widthMiddle);
/*     */ 
/*  88 */           int k2 = heightMiddle + (int)(fishEyeFormula(d1 / distance) * distance / d1 * y - heightMiddle);
/*     */ 
/*  90 */           baseImage.setRGB(x, y, pix[(j2 * imageHeight + k2)]);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  96 */     return baseImage;
/*     */   }
/*     */ 
/*     */   private int ranInt(int i, int j)
/*     */   {
/* 106 */     double d = Math.random();
/* 107 */     return (int)(i + j - i + 1 * d);
/*     */   }
/*     */ 
/*     */   private double fishEyeFormula(double s)
/*     */   {
/* 119 */     if (s < 0.0D)
/* 120 */       return 0.0D;
/* 121 */     if (s > 1.0D) {
/* 122 */       return s;
/*     */     }
/* 124 */     return -0.75D * s * s * s + 1.5D * s * s + 0.25D * s;
/*     */   }
/*     */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.FishEyeGimpy
 * JD-Core Version:    0.6.1
 */