/*    */ package com.google.code.kaptcha.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.GimpyEngine;
/*    */ import com.google.code.kaptcha.NoiseProducer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import com.jhlabs.image.RippleFilter;
/*    */ import com.jhlabs.image.ShadowFilter;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class ShadowGimpy extends Configurable
/*    */   implements GimpyEngine
/*    */ {
/*    */   public BufferedImage getDistortedImage(BufferedImage baseImage)
/*    */   {
/* 27 */     NoiseProducer noiseProducer = getConfig().getNoiseImpl();
/* 28 */     BufferedImage distortedImage = new BufferedImage(baseImage.getWidth(), baseImage.getHeight(), 2);
/*    */ 
/* 31 */     Graphics2D graph = (Graphics2D)distortedImage.getGraphics();
/*    */ 
/* 33 */     ShadowFilter shadowFilter = new ShadowFilter();
/* 34 */     shadowFilter.setRadius(10.0F);
/* 35 */     shadowFilter.setDistance(5.0F);
/* 36 */     shadowFilter.setOpacity(1.0F);
/*    */ 
/* 38 */     Random rand = new Random();
/*    */ 
/* 40 */     RippleFilter rippleFilter = new RippleFilter();
/* 41 */     rippleFilter.setWaveType(0);
/* 42 */     rippleFilter.setXAmplitude(7.6F);
/* 43 */     rippleFilter.setYAmplitude(rand.nextFloat() + 1.0F);
/* 44 */     rippleFilter.setXWavelength(rand.nextInt(7) + 8);
/* 45 */     rippleFilter.setYWavelength(rand.nextInt(3) + 2);
/* 46 */     rippleFilter.setEdgeAction(1);
/*    */ 
/* 48 */     BufferedImage effectImage = rippleFilter.filter(baseImage, null);
/* 49 */     effectImage = shadowFilter.filter(effectImage, null);
/*    */ 
/* 51 */     graph.drawImage(effectImage, 0, 0, null, null);
/* 52 */     graph.dispose();
/*    */ 
/* 55 */     noiseProducer.makeNoise(distortedImage, 0.1F, 0.1F, 0.25F, 0.25F);
/* 56 */     noiseProducer.makeNoise(distortedImage, 0.1F, 0.25F, 0.5F, 0.9F);
/*    */ 
/* 58 */     return distortedImage;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.ShadowGimpy
 * JD-Core Version:    0.6.1
 */