/*    */ package com.google.code.kaptcha.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.BackgroundProducer;
/*    */ import com.google.code.kaptcha.GimpyEngine;
/*    */ import com.google.code.kaptcha.Producer;
/*    */ import com.google.code.kaptcha.text.TextProducer;
/*    */ import com.google.code.kaptcha.text.WordRenderer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.geom.Line2D;
/*    */ import java.awt.geom.Line2D.Double;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class DefaultKaptcha extends Configurable
/*    */   implements Producer
/*    */ {
/* 23 */   private int width = 200;
/*    */ 
/* 25 */   private int height = 50;
/*    */ 
/*    */   public BufferedImage createImage(String text)
/*    */   {
/* 36 */     WordRenderer wordRenderer = getConfig().getWordRendererImpl();
/* 37 */     GimpyEngine gimpyEngine = getConfig().getObscurificatorImpl();
/* 38 */     BackgroundProducer backgroundProducer = getConfig().getBackgroundImpl();
/* 39 */     boolean isBorderDrawn = getConfig().isBorderDrawn();
/* 40 */     this.width = getConfig().getWidth();
/* 41 */     this.height = getConfig().getHeight();
/*    */ 
/* 43 */     BufferedImage bi = wordRenderer.renderWord(text, this.width, this.height);
/* 44 */     bi = gimpyEngine.getDistortedImage(bi);
/* 45 */     bi = backgroundProducer.addBackground(bi);
/* 46 */     Graphics2D graphics = bi.createGraphics();
/* 47 */     if (isBorderDrawn)
/*    */     {
/* 49 */       drawBox(graphics);
/*    */     }
/* 51 */     return bi;
/*    */   }
/*    */ 
/*    */   private void drawBox(Graphics2D graphics)
/*    */   {
/* 56 */     Color borderColor = getConfig().getBorderColor();
/* 57 */     int borderThickness = getConfig().getBorderThickness();
/*    */ 
/* 59 */     graphics.setColor(borderColor);
/*    */ 
/* 61 */     if (borderThickness != 1)
/*    */     {
/* 63 */       BasicStroke stroke = new BasicStroke(borderThickness);
/* 64 */       graphics.setStroke(stroke);
/*    */     }
/*    */ 
/* 67 */     Line2D line1 = new Line2D.Double(0.0D, 0.0D, 0.0D, this.width);
/* 68 */     graphics.draw(line1);
/* 69 */     Line2D line2 = new Line2D.Double(0.0D, 0.0D, this.width, 0.0D);
/* 70 */     graphics.draw(line2);
/* 71 */     line2 = new Line2D.Double(0.0D, this.height - 1, this.width, this.height - 1);
/* 72 */     graphics.draw(line2);
/* 73 */     line2 = new Line2D.Double(this.width - 1, this.height - 1, this.width - 1, 0.0D);
/* 74 */     graphics.draw(line2);
/*    */   }
/*    */ 
/*    */   public String createText()
/*    */   {
/* 82 */     return getConfig().getTextProducerImpl().getText();
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.impl.DefaultKaptcha
 * JD-Core Version:    0.6.1
 */