/*    */ package com.google.code.kaptcha.text.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.text.TextProducer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class DefaultTextCreator extends Configurable
/*    */   implements TextProducer
/*    */ {
/*    */   public String getText()
/*    */   {
/* 19 */     int length = getConfig().getTextProducerCharLength();
/* 20 */     char[] chars = getConfig().getTextProducerCharString();
/* 21 */     int randomContext = chars.length - 1;
/* 22 */     Random rand = new Random();
/* 23 */     StringBuffer text = new StringBuffer();
/* 24 */     for (int i = 0; i < length; i++)
/*    */     {
/* 26 */       text.append(chars[(rand.nextInt(randomContext) + 1)]);
/*    */     }
/*    */ 
/* 29 */     return text.toString();
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.text.impl.DefaultTextCreator
 * JD-Core Version:    0.6.1
 */