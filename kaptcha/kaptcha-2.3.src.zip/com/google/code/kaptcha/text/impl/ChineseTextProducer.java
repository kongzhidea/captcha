/*    */ package com.google.code.kaptcha.text.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.text.TextProducer;
/*    */ 
/*    */ public class ChineseTextProducer
/*    */   implements TextProducer
/*    */ {
/* 12 */   private String[] simplifiedChineseTexts = { "ÂåÖÊã¨ÁÑ¶ÁÇπ", "Êñ∞ÈÅìÊ∂àÁÇπ", "ÊúçÂàÜÁõÆÊêú", "Á¥¢ÂßìÂêçÈõª", "Â≠êÈÉµ‰ª∂‰ø°", "‰∏ªÊó®Ë´ãÂõû", "ÈõªÂ≠êÈÉµ‰ª∂", "Áµ¶ÊàëÊâÄÊúâ", "Ë®éË´ñÂçÄÊòé", "ÁôºË°®Êñ∞Êñá", "Á´†Ê≠§Ë®éË´ñ", "ÂçÄÊâÄÊúâÊñá", "Á´†Âõû‰∏ªÈ°å", "Ê®πÁÄèË¶ΩÊêú" };
/*    */ 
/*    */   public String getText()
/*    */   {
/* 22 */     return this.simplifiedChineseTexts[new java.util.Random().nextInt(this.simplifiedChineseTexts.length)];
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.text.impl.ChineseTextProducer
 * JD-Core Version:    0.6.1
 */