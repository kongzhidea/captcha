/*    */ package com.google.code.kaptcha.text.impl;
/*    */ 
/*    */ import com.google.code.kaptcha.text.WordRenderer;
/*    */ import com.google.code.kaptcha.util.Config;
/*    */ import com.google.code.kaptcha.util.Configurable;
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.font.FontRenderContext;
/*    */ import java.awt.font.GlyphVector;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class DefaultWordRenderer extends Configurable
/*    */   implements WordRenderer
/*    */ {
/*    */   public BufferedImage renderWord(String word, int width, int height)
/*    */   {
/* 34 */     int fontSize = getConfig().getTextProducerFontSize();
/* 35 */     Font[] fonts = getConfig().getTextProducerFonts(fontSize);
/* 36 */     Color color = getConfig().getTextProducerFontColor();
/* 37 */     BufferedImage image = new BufferedImage(width, height, 2);
/*    */ 
/* 39 */     Graphics2D g2D = image.createGraphics();
/* 40 */     g2D.setColor(color);
/*    */ 
/* 42 */     RenderingHints hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*    */ 
/* 45 */     hints.add(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
/*    */ 
/* 47 */     g2D.setRenderingHints(hints);
/*    */ 
/* 49 */     FontRenderContext frc = g2D.getFontRenderContext();
/* 50 */     Random random = new Random();
/*    */ 
/* 52 */     int startPosX = width / (2 + word.length());
/* 53 */     int startPosY = (height - fontSize) / 5 + fontSize;
/*    */ 
/* 55 */     char[] wordChars = word.toCharArray();
/* 56 */     for (int i = 0; i < wordChars.length; i++)
/*    */     {
/* 58 */       Font chosenFont = fonts[random.nextInt(fonts.length)];
/* 59 */       g2D.setFont(chosenFont);
/*    */ 
/* 61 */       char[] charToDraw = { wordChars[i] };
/*    */ 
/* 64 */       GlyphVector gv = chosenFont.createGlyphVector(frc, charToDraw);
/* 65 */       double charWidth = gv.getVisualBounds().getWidth();
/*    */ 
/* 67 */       g2D.drawChars(charToDraw, 0, charToDraw.length, startPosX, startPosY);
/* 68 */       startPosX = startPosX + (int)charWidth + 2;
/*    */     }
/*    */ 
/* 71 */     return image;
/*    */   }
/*    */ }

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.text.impl.DefaultWordRenderer
 * JD-Core Version:    0.6.1
 */