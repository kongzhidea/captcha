package com.google.code.kaptcha.text;

public abstract interface TextProducer
{
  public abstract String getText();
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.text.TextProducer
 * JD-Core Version:    0.6.1
 */