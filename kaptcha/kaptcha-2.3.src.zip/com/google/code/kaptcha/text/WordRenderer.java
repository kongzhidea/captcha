package com.google.code.kaptcha.text;

import java.awt.image.BufferedImage;

public abstract interface WordRenderer
{
  public abstract BufferedImage renderWord(String paramString, int paramInt1, int paramInt2);
}

/* Location:           E:\workspace\javaee\addrlist\WebContent\WEB-INF\lib\kaptcha-2.3.jar
 * Qualified Name:     com.google.code.kaptcha.text.WordRenderer
 * JD-Core Version:    0.6.1
 */